"""Atomic E-drive checkpoint writes with transient Windows sharing retries."""
from pathlib import Path
import gzip
import json
import time


def save(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    raw=(json.dumps(obj,ensure_ascii=False,allow_nan=False,separators=(",",":"))+"\n").encode()
    if str(path).endswith(".gz"):raw=gzip.compress(raw,compresslevel=5,mtime=0)
    temporary=path.with_suffix(path.suffix+".partial")
    temporary.write_bytes(raw)
    for attempt in range(9):
        try:
            temporary.replace(path)
            return
        except PermissionError:
            if attempt==8:raise
            time.sleep(min(.05*2**attempt,1.))
