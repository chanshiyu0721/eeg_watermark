"""Descriptive DEV threshold margins for locked exact-readout rules."""
from pathlib import Path
import json
import numpy as np
import capacity_pilot as cp
import summarize_exact_readout as ex
from dev_capacity import ROLES

HERE=Path(__file__).resolve().parent


def main():
    factorial=cp.load(HERE/"runs/dev257/FACTORIAL_DEV_COMPARISON.json")
    results={}
    for taps,label in ((129,"dev129exact"),(257,"dev257")):
        rule=factorial["exact_calibration"][str(taps)]["selected"]
        rr={role:[r for s in names for r in cp.load(HERE/"runs"/label/f"{s}_taps{taps}.json.gz")["rows"]]
            for role,names in ROLES.items()}
        margin={}
        for role,rows in rr.items():
            reg=[-ex.values(r,rule)[0] for r in rows if r["kind"]=="enrolled" and ex.values(r,rule)[1]]
            neg=[-ex.values(r,rule)[0] for r in rows if r["kind"]!="enrolled" and ex.values(r,rule)[1]]
            pressure=[-ex.values(r,rule)[0] for r in rows if r.get("pressure") and ex.values(r,rule)[1]]
            margin[role]=dict(max_registered_distance=max(reg),min_eligible_negative_distance=min(neg),
                min_pressure_distance=min(pressure),empirical_separation_gap=min(neg)-max(reg),
                frozen_distance_upper_bound=-rule["threshold"],
                registered_to_bound_margin=-rule["threshold"]-max(reg),
                pressure_above_bound_margin=min(pressure)+rule["threshold"])
        fit_values=[ex.values(r,rule)[0] for r in rr["fit"]]
        ts=sorted(set([float(t) for t in np.quantile(fit_values,np.linspace(0,1,101))]+[rule["threshold"]]))
        curve=[]
        for t in ts:
            q=dict(rule,threshold=t)
            curve.append(dict(threshold=t,fit=ex.summary(rr["fit"],q),select=ex.summary(rr["select"],q)))
        results[str(taps)]=dict(locked_rule=rule,empirical_margins=margin,threshold_curve=curve)
    cp.save(HERE/"runs/dev257/EXACT_DEV_SENSITIVITY.json",dict(
        status="descriptive DEV sensitivity, frozen thresholds unchanged",results=results,
        no_new_confirmation_data=True,threshold_curve_does_not_replace_locked_rule=True))
    print(json.dumps({k:v["empirical_margins"] for k,v in results.items()}))


if __name__=="__main__":main()
