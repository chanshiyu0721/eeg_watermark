"""P191 frozen new-person collector; --contract reads metadata only.

Reuses P190 issuance, actual EDF quality matching and source-cache functions in
a private in-memory module. No P190 file is edited. New EEG is gated by the
complete scientific freeze, pinned SHA and acquisition receipts.
"""
from pathlib import Path
import argparse
import gc
import hashlib
import importlib.util
import json
import os
import sys
import time
import numpy as np
from threadpoolctl import threadpool_limits
import capacity_pilot as cp
import checkpoint_io
from dev_capacity import DevelopmentReceiver,CONDITIONS
import calibrate_allarms as rules_api

HERE=Path(__file__).resolve().parent
ROOT=cp.ROOT
OUT=HERE.parent/"p191_confirmation_v1"
PREP=HERE.parent/"p191_new_records_v1"
TARGETS=tuple(f"OpenBMI{s:03d}" for s in range(17,25))
WRONG=tuple(f"OpenBMI{s:03d}" for s in range(25,29))
ARMS=("smooth","direct","hybrid05","spatial","qid")
LEVEL=1.0
RULES=HERE/"ALLARM_DEV_RULES.json"
FREEZE=OUT/"CONFIRMATION_FREEZE.json"
EXPECTED_FREEZE_SHA=None
_VALIDATED=None
cp.save=checkpoint_io.save


def private_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


new_adapter=private_module("_p191_confirmation_new_adapter",PREP/"adapter.py")


def relative(path):return str(Path(path).resolve().relative_to(ROOT)).replace("\\","/")


def contract_snapshot():
    """No EEG values: fixed menus, immutable code, DEV rules and raw receipts."""
    bundle=cp.load(RULES)
    assert bundle["status"]=="complete DEV rule bundle before independent confirmation"
    assert bundle["primary_passes_admission"]
    historical=cp.load(cp.P190/"CONFIRMATION_FREEZE.json")
    files=dict(historical["contract_snapshot"]["code_files"])
    for p in (Path(__file__),HERE/"dev_capacity.py",HERE/"capacity_pilot.py",HERE/"calibrate_allarms.py",
              HERE/"multiarm_dev.py",HERE/"multiarm_resume.py",HERE/"checkpoint_io.py",
              HERE/"summarize_confirmation.py",PREP/"adapter.py",RULES):files[relative(p)]=cp.sha(p)
    # People/URLs are fixed before decoding. A download can finish after the
    # scientific freeze; its completed receipt and raw SHA are bound by the
    # adapter and stored in the source cache before any query is evaluated.
    acquisition_plan=PREP/"ACQUISITION_PLAN.json"
    plan=cp.load(acquisition_plan);files[relative(acquisition_plan)]=cp.sha(acquisition_plan)
    acquired=[r for r in plan["sources"] if 17<=r["subject"]<=28]
    assert {r["subject"] for r in acquired}==set(range(17,29))
    assert plan["confirmation_people"]==list(range(17,25)) and plan["independent_wrong_people"]==list(range(25,29))
    files.update(bundle["development_score_files"])
    return dict(version="P191-same-response-normalized-identity-mismatch-confirmation-v1",
        targets=list(TARGETS),wrong_sources=list(WRONG),arms=list(ARMS),levels=[LEVEL],conditions=list(CONDITIONS),
        reference_seconds=112,scored_seconds=40,visible_context_seconds=48,scored_windows=5,
        sampling_rate=160,channels=list(cp.CHANNELS),actual_EDF_bits=16,
        caps_percent=dict(global_ac_prd=.25,max_channel_ac_prd=.5,band_8_30_prd=1.),
        actual_registered_relative_spread_max=.001,phase_codes="original_p181_pool:32 IDs",
        qid_codes="original fixed_messages:32 IDs; strict chip labels retained",
        source_key="P190-{source}-first-fixed-block (unchanged deterministic issuer namespace)",
        query_range="one range per target/processing from clean and all allocated wrong sources",
        response_orders=[129,257],response_estimators=list(cp.api.METHODS),
        readouts=dict(order129="frozen original12-menu DEV rule",order257=["frozen original12-menu DEV rule","frozen4-menu exact normalized mismatch"]),
        rule_file=relative(RULES),rule_sha256=cp.sha(RULES),primary=bundle["primary"],
        no_confirmation_selection=True,acquisitions=acquired,
        acquisition_validation="Fixed URLs/roles in prefreeze acquisition plan; completed per-source metadata/receipt/raw SHA verified at decode and retained in source.json before scoring",
        files=files)


def validate_freeze():
    global _VALIDATED
    assert FREEZE.is_file(),"P191 scientific freeze is required"
    digest=cp.sha(FREEZE)
    assert isinstance(EXPECTED_FREEZE_SHA,str) and len(EXPECTED_FREEZE_SHA)==64
    assert digest==EXPECTED_FREEZE_SHA,"P191 freeze differs from supplied pinned SHA"
    if _VALIDATED==digest:return cp.load(FREEZE)
    doc=cp.load(FREEZE)
    assert doc["status"] in ("frozen_before_new_signal_confirmation","frozen_before_new_person_confirmation")
    assert doc["contract_snapshot"]==contract_snapshot(),"Scientific contract differs from freeze"
    required=doc["contract_snapshot"]["files"]
    assert all(doc["files"].get(k)==v for k,v in required.items()),"Frozen evidence is incomplete"
    assert doc.get("primary_endpoints") and doc.get("success_criteria") and doc.get("statistical_plan"),"Endpoints, success criteria and statistics must be frozen"
    for name,expected in doc["files"].items():
        p=(ROOT/name).resolve()
        assert p.is_relative_to(ROOT) and p.drive.upper()=="E:"
        assert cp.sha(p)==expected,("Frozen evidence changed",name)
    new_adapter.CONFIRMATION_FREEZE=FREEZE
    new_adapter.EXPECTED_FREEZE_SHA256=digest
    _VALIDATED=digest
    return doc


_ISSUER=None
def issuer():
    global _ISSUER
    if _ISSUER is None:
        module=private_module("_p191_readonly_reused_P190_issuer",cp.P190/"run_experiment.py")
        module.HERE=OUT;module.FREEZE=FREEZE;module.adapter=new_adapter
        module.validate_confirmation_freeze=validate_freeze
        module.environment()
        _ISSUER=module
    return _ISSUER


def decision(feature,method,rule):
    # Match the existing JSON boundary without changing any statistic.
    item=feature['methods'][method]
    item['by_ridge']={str(k):v for k,v in item['by_ridge'].items()}
    value,eligible,top=rules_api.score(dict(receiver=feature),method,rule)
    return int(top) if eligible and value>=rule["threshold"] else -1


def validate_completed_acquisition(names,freeze):
    acquisition={int(r["subject"]):r for r in freeze["contract_snapshot"]["acquisitions"]}
    for name in names:
        number=int(name[-3:]);receipt=cp.load(PREP/"acquisition"/f"subject{number:03d}_acquisition.json")
        assert receipt["status"]=="complete"
        assert Path(receipt["path"]).resolve()==Path(acquisition[number]["path"]).resolve()
        if "url" in receipt:assert receipt["url"]==acquisition[number]["url"]


def collect(source):
    freeze=validate_freeze()
    assert source in TARGETS
    bundle=cp.load(RULES);m0=issuer();m=m0.backend("P191-confirm/"+source)
    # Validate each completed receipt against its fixed URL/source before decode.
    validate_completed_acquisition((source,)+WRONG,freeze)
    record=m0.prepare_source(m,source,allow_new=True)
    wrongs=[m0.prepare_source(m,name,allow_new=True) for name in WRONG]
    qlimits=m0.query_ranges(m,record,wrongs)
    copies,metadata,issuance=m0.issue_point(m,record,LEVEL,"confirm")
    signature=hashlib.sha256(json.dumps(freeze["contract_snapshot"],sort_keys=True).encode()).hexdigest()
    for arm in ARMS:
        dest=OUT/"raw/confirm"/source/"level100"/(arm+".json.gz")
        before=cp.load(dest) if dest.exists() else None
        if before:
            assert before["confirmation_freeze_sha256"]==EXPECTED_FREEZE_SHA
            assert before["collection_signature"]==signature
            if before["status"]=="complete":continue
        started=time.monotonic();past=before.get("seconds",0.) if before else 0.
        rows=before["rows"] if before else []
        done={(r["query_index"],r["condition"]) for r in rows}
        valid=issuance["registered_group_valid"]
        receiver257=DevelopmentReceiver(record["x"],np.asarray(copies[arm][:8]),257) if valid else None
        receiver129=cp.api.MatchedFIRReceivers(record["x"],np.asarray(copies[arm][:8])) if valid else None
        values=copies[arm]+[record["x"]]+[w["x"] for w in wrongs]
        infos=metadata[arm]+[dict(kind="clean",identity=None,parent=None,pressure=False)]+[
            dict(kind="wrong_source",identity=None,parent=None,pressure=False,negative_source=w["name"]) for w in wrongs]
        receipts=before.get("EDF_receipts",[]) if before else []
        for i,(value,info) in enumerate(zip(values,infos)):
            for condition in CONDITIONS:
                if (i,condition) in done:continue
                common=dict(cohort="confirm",source=source,level=LEVEL,arm=arm,query_index=i,
                    **{k:v for k,v in info.items() if k!="feasible"},condition=condition)
                if value is None or not valid:
                    row=dict(common,issuance_feasible=False,receivers_by_order=None,
                        decisions={k:-1 for k in bundle["rules"][arm]},
                        failure_reason=info.get("failure_reason") or "registered_template_group_invalid")
                    if arm=="qid":row["qid_native_policy_decisions"]={k:-1 for k in bundle["qid_native_policy"]}
                else:
                    query,h=m.io.edf_roundtrip(m.c.transform(value,condition),qlimits[condition],
                        f"{source}_level100_{arm}_q{i}_{condition}.edf",dest.parent,receipts,False,m.domain.BCI_CHANNELS)
                    t129=time.monotonic();v129=receiver129.extract(query,h,record["h0"]);seconds129=time.monotonic()-t129
                    t257=time.monotonic();v257=receiver257.extract_all(query);seconds257=time.monotonic()-t257
                    features={"129":v129,"257":v257};decisions={}
                    for key,entry in bundle["rules"][arm].items():
                        order,method,readout=key.split("/")
                        decisions[key]=decision(features[order],method,entry["selected"])
                    row=dict(common,issuance_feasible=True,receivers_by_order=features,decisions=decisions,
                        query_raw_sha256=receipts[-1]["raw_sha256"],primary_decision=decisions["257/candidate_FIR_GLRT/exact"],
                        receiver_wall_seconds=dict(order129=seconds129,order257=seconds257))
                    if arm=="qid":
                        row["qid_native_policy_decisions"]={}
                        for key,entry in bundle["qid_native_policy"].items():
                            order,method,readout=key.split("/")
                            row["qid_native_policy_decisions"][key]=decision(features[order],method,entry["selected"])
                rows.append(row)
                result=dict(status="running",source=source,cohort="confirm",arm=arm,level=LEVEL,rows=rows,
                    expected_n=len(values)*len(CONDITIONS),seconds=past+time.monotonic()-started,
                    collection_signature=signature,confirmation_freeze_sha256=EXPECTED_FREEZE_SHA,
                    rule_file_sha256=cp.sha(RULES),registered_group_valid=valid,
                    EDF_receipts=receipts,
                    issuance_sha256=cp.sha(OUT/"issuance"/source/"level100/issuance_summary.json"),
                    query_limits_uv={k:[v.tolist() for v in z] for k,z in qlimits.items()},
                    scored_seconds=40,visible_context_seconds=48,owner_reference_seconds=112,
                    receiver_configurations_selected_on_confirmation=False)
                cp.save(dest,result)
                print(json.dumps(dict(event="P191_confirm_query",source=source,arm=arm,n=len(rows),total=result["expected_n"])),flush=True)
        result["status"]="complete";cp.save(dest,result)
        del receiver129,receiver257;gc.collect()
    if freeze.get("modern_extension"):
        modern_folder=HERE.parent/"p191_modern_carrier_v1"
        if str(modern_folder) not in sys.path:sys.path.insert(0,str(modern_folder))
        modern=private_module("_p191_globally_frozen_modern_companion",modern_folder/"modern_confirm_api.py")
        modern.collect_from_prepared(record,wrongs,copies["smooth"][:8],qlimits,
            FREEZE,EXPECTED_FREEZE_SHA,OUT/"modern_A400")
    print(json.dumps(dict(event="P191_source_complete",source=source,
        classical_arms=list(ARMS),modern_companion=bool(freeze.get("modern_extension")))),flush=True)


def main():
    global OUT,RULES,FREEZE,EXPECTED_FREEZE_SHA
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--contract",action="store_true");ap.add_argument("--contract-output",type=Path)
    ap.add_argument("--source");ap.add_argument("--rules",type=Path,default=RULES)
    ap.add_argument("--out",type=Path,default=OUT);ap.add_argument("--freeze",type=Path,default=FREEZE)
    ap.add_argument("--freeze-sha");ap.add_argument("--validate-only",action="store_true")
    ap.add_argument("--prepare-wrongs",action="store_true")
    args=ap.parse_args();OUT=args.out.resolve();RULES=args.rules.resolve();FREEZE=args.freeze.resolve()
    assert OUT.is_relative_to(ROOT) and OUT.drive.upper()=="E:"
    if args.contract:
        snapshot=contract_snapshot()
        if args.contract_output:cp.save(args.contract_output,snapshot)
        else:print(json.dumps(snapshot,ensure_ascii=False,indent=2))
        return
    EXPECTED_FREEZE_SHA=args.freeze_sha
    validate_freeze()
    if args.validate_only:
        print(json.dumps(dict(status="P191 frozen contract validated",new_signals_decoded=0)));return
    if args.prepare_wrongs:
        freeze=validate_freeze();validate_completed_acquisition(WRONG,freeze)
        m0=issuer();m=m0.backend("prepare-shared-wrongs")
        with threadpool_limits(limits=1):
            for name in WRONG:m0.prepare_source(m,name,allow_new=True)
        print(json.dumps(dict(status="Shared wrong-source caches prepared after freeze",people=list(WRONG),queries_scored=0)));return
    assert args.source in TARGETS,"Pass one fixed target source from OpenBMI017-024"
    with threadpool_limits(limits=1):collect(args.source)


if __name__=="__main__":main()
