# Five-carrier frozen-rule development bundle

Each carrier and response estimator follows the same D_fit/D_select policy. Original129 compatibility scores are inherited; new257 scores include the exact conditional template-energy readout. QIM native unknown codes and1/2-chip modifications retain separate result columns.

|Carrier|Order / receiver / readout|Fit correct|Select correct|Select total strict negative accepts|
|---|---|---:|---:|---:|
|smooth|129/ordinary_FIR/compatibility|0/96|0/96|0|
|smooth|129/projected_FIR/compatibility|58/96|75/96|0|
|smooth|129/candidate_FIR_GLRT/compatibility|95/96|94/96|0|
|smooth|257/ordinary_FIR/compatibility|0/96|0/96|0|
|smooth|257/ordinary_FIR/exact|0/96|2/96|2|
|smooth|257/projected_FIR/compatibility|88/96|88/96|0|
|smooth|257/projected_FIR/exact|82/96|83/96|0|
|smooth|257/candidate_FIR_GLRT/compatibility|86/96|89/96|0|
|smooth|257/candidate_FIR_GLRT/exact|96/96|96/96|0|
|direct|129/ordinary_FIR/compatibility|0/96|0/96|0|
|direct|129/projected_FIR/compatibility|55/96|57/96|0|
|direct|129/candidate_FIR_GLRT/compatibility|86/96|74/96|0|
|direct|257/ordinary_FIR/compatibility|0/96|0/96|0|
|direct|257/ordinary_FIR/exact|0/96|26/96|11|
|direct|257/projected_FIR/compatibility|64/96|57/96|0|
|direct|257/projected_FIR/exact|80/96|82/96|0|
|direct|257/candidate_FIR_GLRT/compatibility|56/96|78/96|0|
|direct|257/candidate_FIR_GLRT/exact|96/96|96/96|0|
|spatial|129/ordinary_FIR/compatibility|17/96|35/96|0|
|spatial|129/projected_FIR/compatibility|41/96|41/96|0|
|spatial|129/candidate_FIR_GLRT/compatibility|49/96|43/96|0|
|spatial|257/ordinary_FIR/compatibility|73/96|79/96|0|
|spatial|257/ordinary_FIR/exact|89/96|84/96|0|
|spatial|257/projected_FIR/compatibility|85/96|93/96|0|
|spatial|257/projected_FIR/exact|96/96|96/96|0|
|spatial|257/candidate_FIR_GLRT/compatibility|90/96|96/96|0|
|spatial|257/candidate_FIR_GLRT/exact|96/96|96/96|0|
|hybrid05|129/ordinary_FIR/compatibility|0/96|2/96|0|
|hybrid05|129/projected_FIR/compatibility|70/96|78/96|0|
|hybrid05|129/candidate_FIR_GLRT/compatibility|91/96|94/96|0|
|hybrid05|257/ordinary_FIR/compatibility|0/96|2/96|0|
|hybrid05|257/ordinary_FIR/exact|0/96|10/96|3|
|hybrid05|257/projected_FIR/compatibility|88/96|88/96|0|
|hybrid05|257/projected_FIR/exact|82/96|83/96|0|
|hybrid05|257/candidate_FIR_GLRT/compatibility|90/96|92/96|0|
|hybrid05|257/candidate_FIR_GLRT/exact|96/96|96/96|0|
|qid|129/ordinary_FIR/compatibility|49/96|65/96|0|
|qid|129/projected_FIR/compatibility|55/96|64/96|0|
|qid|129/candidate_FIR_GLRT/compatibility|48/96|69/96|0|
|qid|257/ordinary_FIR/compatibility|64/96|95/96|0|
|qid|257/ordinary_FIR/exact|38/96|50/96|0|
|qid|257/projected_FIR/compatibility|80/96|93/96|0|
|qid|257/projected_FIR/exact|86/96|96/96|0|
|qid|257/candidate_FIR_GLRT/compatibility|96/96|96/96|0|
|qid|257/candidate_FIR_GLRT/exact|96/96|96/96|0|

## QIM native identity policy, separate damaged-copy endpoints

|Receiver / readout|Fit correct|Select correct|Select native unknown FA|Select clean / wrong FA|Chip1 parent recovery|Chip2 parent recovery|
|---|---:|---:|---:|---:|---:|---:|
|129/ordinary_FIR/compatibility|96/96|96/96|0/96|0/12 / 0/24|96/96|96/96|
|129/projected_FIR/compatibility|96/96|96/96|0/96|0/12 / 0/24|96/96|96/96|
|129/candidate_FIR_GLRT/compatibility|96/96|96/96|0/96|0/12 / 0/24|96/96|96/96|
|257/ordinary_FIR/compatibility|96/96|96/96|0/96|0/12 / 0/24|96/96|96/96|
|257/ordinary_FIR/exact|96/96|96/96|0/96|0/12 / 0/24|96/96|96/96|
|257/projected_FIR/compatibility|96/96|96/96|0/96|0/12 / 0/24|96/96|96/96|
|257/projected_FIR/exact|96/96|96/96|0/96|0/12 / 0/24|96/96|96/96|
|257/candidate_FIR_GLRT/compatibility|96/96|96/96|0/96|0/12 / 0/24|96/96|96/96|
|257/candidate_FIR_GLRT/exact|96/96|96/96|0/96|0/12 / 0/24|96/96|96/96|
