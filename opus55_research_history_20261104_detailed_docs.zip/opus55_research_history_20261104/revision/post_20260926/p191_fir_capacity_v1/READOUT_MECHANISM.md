# Identity mismatch measured against its own conditional response

The useful technical hypothesis is that a residual-ratio compatibility score mixes identity mismatch with background response error. The new readout cancels the common background term before normalizing by fingerprint energy.

For candidate response fit `i`, concatenate the held-out, channel/temporal-centered identity templates into `T_i` and the received-minus-predicted-clean signal into `v_i`. Across the five held-out folds, store

```
G_i = sum(T_i^T T_i)
b_i = sum(T_i^T v_i)
d_i = sum(v_i^T v_i)
```

The fixed one-hot registered identity has residual

```
R_i = d_i + [G_i]_ii - 2[b_i]_i.
```

An unrestricted identity coefficient under the **same candidate-conditioned response** has

```
beta_i = G_i^dagger b_i
U_i = d_i - b_i^T beta_i.
```

The conditional identity defect is therefore

```
D_i = R_i - U_i = [G_i]_ii - 2[b_i]_i + b_i^T beta_i.
```

The unstructured held-out residual energy `d_i` cancels. For nonsingular `G_i`, `D_i = (e_i-beta_i)^T G_i (e_i-beta_i)`. The readout uses the dimensionless mismatch

```
q_i = max(0, D_i) / [G_i]_ii.
```

The current implementation retains the original winning candidate `i=argmin_j R_j`, support, alignment, presence and eligibility. It changes the final score to `-q_i`, fitted against independent unknown codes as well as clean/wrong-source controls.

## What this explains

For an additive model-error component orthogonal to `T_i`, `G_i` and `b_i` stay fixed while the same error energy enters both `R_i` and `U_i`. The defect `D_i` stays fixed. The ratio `U_i/R_i` instead approaches one as this common background dominates. A high ratio can then represent background response error rather than accurate agreement with a registered identity.

The historical score uses `min_j U_j / R_i`; the unrestricted minimum can come from another response fit. The new defect deliberately uses `U_i`, which shares the winner's response and cancels its own `d_i`. The template energy `[G_i]_ii` supplies the relevant signal scale. Fitted clean-H0 improvement is a different quantity and was unstable in the earlier failed proxy.

Response error that projects into the identity-template span still affects the readout. Presence and the observed negative calibration remain part of the rule. This algebra characterizes the statistic under its fixed conditional template dictionary; the query-selected, cross-fitted system is evaluated by frozen empirical rules.

## Evidence map

- Known-processing-response diagnostics on observed005/012 separate residual-model error from alignment and candidate-fitting hypotheses: `p191_separation_v1/runs/pilot01/`.
-129/257/513 FIR pilot shows strong elliptic background-residual reduction with approximately retained identity-defect energy: `runs/pilot01/` and `DESCRIPTIVE_DATA.json`.
- Full8-person DEV shows that longer support with the original compatibility readout alone loses coverage, so longer FIR is not sufficient: `runs/dev257/DEV_COMPARISON.json`.
- The exact conditional energy readout restores the full observed DEV coverage with no measured .0125/.025/control acceptance in the first257 DEV experiment: `runs/dev257/EXACT_READOUT_COMPARISON.json`.
- The129/257 x compatibility/exact factorial result determines whether response order is necessary or whether the main gain comes from the readout: `runs/dev257/FACTORIAL_DEV_COMPARISON.json`.

P190 original decisions, identity meanings and acceptance counts remain intact. All current records in this folder are observed DEV evidence; a fresh-person frozen confirmation supplies the next independent test.
