"""Append newly required conditional template-energy statistics on observed pilot.

Does not replace any old pilot file or recollect old parity evidence.
"""
from pathlib import Path
import json
import time
import numpy as np
from threadpoolctl import threadpool_limits
import capacity_pilot as cp
from dev_capacity import DevelopmentReceiver

HERE=Path(__file__).resolve().parent


def run(source,taps):
    dest=HERE/"runs/exact_pilot01"/f"{source}_taps{taps}.json.gz"
    previous=cp.load(dest) if dest.exists() else None
    if previous and previous["status"]=="complete":return
    raw_path=cp.P190/"raw/confirm"/source/"level100/smooth.json.gz"
    raw=cp.load(raw_path)
    originals=[r for r in raw["rows"] if r["condition"]=="elliptic_new_causal"]
    folder=cp.P190/"issuance"/source/"level100"
    x=cp.read_edf(cp.P190/"sources"/source/"clean.edf.gz")
    book=np.asarray([cp.read_edf(folder/f"smooth_r{i}_issued.edf.gz") for i in range(8)])
    receiver=DevelopmentReceiver(x,book,taps)
    rows=previous["rows"] if previous else []
    done={r["query_index"] for r in rows}
    receipts=[]
    started=time.monotonic()
    for old in originals:
        i=old["query_index"]
        if i in done:continue
        if old["kind"]=="clean":issued=x
        elif old["kind"]=="wrong_source":issued=cp.read_edf(cp.P190/"sources"/old["negative_source"]/"clean.edf.gz")
        else:issued=cp.read_edf(folder/f"smooth_r{i}_issued.edf.gz")
        condition=old["condition"]
        query,_=cp.edf.edf_roundtrip(cp.common.transform(issued,condition),
            tuple(np.asarray(v) for v in raw["query_limits_uv"][condition]),
            f"{source}_level100_smooth_q{i}_{condition}.edf",dest.parent,receipts,False,cp.CHANNELS)
        assert old["query_raw_sha256"]==receipts[-1]["raw_sha256"]
        row={k:v for k,v in old.items() if k!="receiver"}
        row["receiver"]=receiver.extract_all(query)
        rows.append(row)
        out=dict(status="running",purpose="New conditional template-energy scalar readout on observed pilot",
            source=source,taps=taps,condition=condition,rows=rows,expected_n=len(originals),
            new_confirmation_performed=False,seconds=time.monotonic()-started,
            raw_bytes_match_n=len(rows),original_raw_sha256=cp.sha(raw_path),
            code_sha256=cp.sha(__file__),expanded_receiver_sha256=cp.sha(HERE/"dev_capacity.py"))
        cp.save(dest,out)
        print(json.dumps(dict(event="exact_scalar",source=source,taps=taps,n=len(rows),total=len(originals))),flush=True)
    out["status"]="complete"
    cp.save(dest,out)


if __name__=="__main__":
    with threadpool_limits(limits=1):
        for source in ("OpenBMI005","OpenBMI012"):
            for taps in (129,257):run(source,taps)
