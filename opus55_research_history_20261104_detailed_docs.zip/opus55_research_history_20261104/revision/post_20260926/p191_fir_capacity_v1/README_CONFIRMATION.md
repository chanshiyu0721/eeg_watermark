# P191 independent confirmation entry

`confirm_collector.py` is the new-person entry. It preserves the P190 original directory and loads its issuance/source-cache functions into a private in-memory module with a new output root. It inherits actual16-bit EDF serialization, all five carrier issuance rules, PRD quality gates and registered relative-spread matching. The received query is shared between both response orders and all frozen readouts.

The static roster is targets OpenBMI017–024 and independent wrong sources025–028, session1/train. Newperson decoding needs a complete scientific freeze and its explicit SHA. Acquisition can continue after freeze: the roster, URLs and roles are already fixed, and each completed raw receipt/SHA is checked before decoding and retained in the source cache.

## Inputs

- `ALLARM_DEV_RULES.json`, produced by `calibrate_allarms.py` once all four additional carrier DEV collections complete. Each arm has three inherited129 rules, three257 legacy-menu rules and three257 exact-readout rules. No received newperson score chooses a rule.
- `p191_new_records_v1/adapter.py`, acquisition plan, completed per-source downloads and metadata.
- Root-authored `p191_confirmation_v1/CONFIRMATION_FREEZE.json`, containing the exact contract, file hashes, endpoints, success criteria and statistical plan.

## Commands

Run from this folder with the existing project environment:

```powershell
& 'E:\python\数字水印\.venv-rerun\Scripts\python.exe' .\calibrate_allarms.py
& 'E:\python\数字水印\.venv-rerun\Scripts\python.exe' .\confirm_collector.py --contract --contract-output 'E:\python\数字水印\revision\post_20260926\p191_confirmation_v1\CONTRACT.json'
```

`--contract` reads only code, DEV scores, rules and the fixed acquisition plan. It never decodes newperson EEG. The freeze format is:

```
status: frozen_before_new_person_confirmation
contract_snapshot: complete contents of CONTRACT.json
files: contract_snapshot.files plus any additional frozen analysis/policy files
primary_endpoints: root's declared primary endpoint specification
success_criteria: root's declared success/gating specification
statistical_plan: participant-level analysis and random seed specification
```

After the root writes and hashes that complete freeze:

```powershell
& 'E:\python\数字水印\.venv-rerun\Scripts\python.exe' .\confirm_collector.py --freeze 'E:\python\数字水印\revision\post_20260926\p191_confirmation_v1\CONFIRMATION_FREEZE.json' --freeze-sha '<actual pinned SHA256>' --validate-only
& 'E:\python\数字水印\.venv-rerun\Scripts\python.exe' .\confirm_collector.py --freeze 'E:\python\数字水印\revision\post_20260926\p191_confirmation_v1\CONFIRMATION_FREEZE.json' --freeze-sha '<actual pinned SHA256>' --source OpenBMI017
```

The same command resumes a partial source without replacing its frozen rules. Each source needs all four wrong-source downloads because they define the common query range. `--prepare-wrongs` with the same freeze/SHA first creates all four shared caches in one process without scoring a query. Targets may then use separate source processes. This avoids concurrent first creation of shared caches.

Primary raw results are saved at `p191_confirmation_v1/raw/confirm/<source>/level100/<arm>.json.gz`. They contain both response orders, the nine frozen decisions, actual query EDF receipts, source/issuance hashes, fitted-model times and the pinned scientific freeze SHA. Five arms × eight targets ×111 queries yields4440 actual query observations; identities and processing conditions remain repeated observations within eight independent people.

After complete collection:

```powershell
& 'E:\python\数字水印\.venv-rerun\Scripts\python.exe' .\summarize_confirmation.py
```

This replays saved decisions, reports per-person/per-processing counts and emits paired primary vectors for the separately frozen statistical analysis. `--allow-partial` emits an explicitly partial progress artifact and never labels it a completed confirmation.

`COLLECTOR_IMPLEMENTATION_CHECK.json` records deployment-decision replay on existing DEV scores:81 known queries,24/24 registered correct and zero negative accepts. No newperson EEG was decoded for this implementation check.
