"""Resume unchanged multiarm numerical collection with resilient atomic I/O."""
import multiarm_dev as runner
import checkpoint_io


if __name__=="__main__":
    runner.cp.save=checkpoint_io.save
    runner.main()
