"""Descriptive paired-record report; identities are not independent subjects."""
from pathlib import Path
import gzip
import json
import statistics

HERE = Path(__file__).resolve().parent
RUN = HERE / "runs" / "pilot01"


def load(path):
    raw = Path(path).read_bytes()
    return json.loads(gzip.decompress(raw) if str(path).endswith(".gz") else raw)


def family(m):
    return "registered" if m["kind"] == "enrolled" else ("pressure0125" if m["angle"] == .0125 else "near025")


summary = load(RUN / "SUMMARY.json")
assert summary["status"] == "complete"
report = [
    "# P191 FIR 容量开发对照",
    "",
    "日期：2026-11-04。结果：仅扩大参考侧 FIR 长度，在两条已观察记录的 elliptic 因果滤波条件下，"
    "257 taps 已使原阈值下的 0.0125 压力误接收从 7/16 降至 0/16，登记归因保持 16/16；"
    "513 taps 未增加归因或拒判正确数，分数间隔进一步变化较小。",
    "",
    "## 固定条件",
    "",
    "- 纯平滑，实际 P190 level100（原 1% 档）已发行 EDF；原 112 s owner reference。",
    "- 原五个 9.6 s query context，共 48 s 可见、40 s 计分；增加的 FIR context 只来自 owner reference。",
    "- 同一粗模型、四训练窗共同对齐、逐窗留出评分及两档 ridge（1e-4、1e-6）。",
    "- 仅 005/012 两条已观察记录，各 8 登记、8 个 0.0125、16 个 0.025 独立近码。",
    "- 逐 query 重新生成 EDF 并要求 SHA-256 与原 P190 query 完全相同；129 taps 对原分数进行一致性核验。",
    "- 原阈值 0.9957274054693162、presence≥0.25、support≥1、原 eligibility；"
    "pressure-aware 历史阈值 0.9987280466974421 另行描述，不在本轮重新校准。",
    "",
    "## 主结果：rho=1e-6，原阈值",
    "",
    "| 记录 | taps | 登记正确 | 0.0125误接收 | 0.025误接收 | 登记最低SC | 0.0125最高SC | 两组分数间隔 | 登记平均 held RSS |",
    "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
]
descriptives = []
costs = []
for group in summary["groups"]:
    source, taps = group["source"], group["taps"]
    data = load(RUN / f"{source}_taps{taps}.json.gz")
    assert len(data["rows"]) == 32
    z = group["summary"]["1e-06"]
    report.append(f"| {source[-3:]} | {taps} | {z['registered']['correct']}/8 | "
        f"{z['pressure0125']['accepted']}/8 | {z['near025']['accepted']}/16 | "
        f"{z['registered']['min_score']:.8f} | {z['pressure0125']['max_score']:.8f} | "
        f"{z['registered_minus_pressure_score_gap']:.8f} | {z['registered']['mean_top_held_RSS']:.9g} |")
    for ridge in ("0.0001", "1e-06"):
        for fam in ("registered", "pressure0125", "near025"):
            vv = [r["features"]["by_ridge"][ridge]["compatibility"] for r in data["rows"]
                  if family(r["metadata"]) == fam]
            descriptives.append(dict(source=source,taps=taps,ridge=ridge,family=fam,n=len(vv),
                mean=statistics.mean(vv),sd=statistics.stdev(vv),median=statistics.median(vv),
                minimum=min(vv),maximum=max(vv)))
    cond = {}
    for ridge in (1e-4,1e-6):
        cc = [z for model in data["conditioning"].values() for z in model["folds"] if z["ridge"]==ridge]
        cond[str(ridge)] = dict(minimum=min(z["condition_min"] for z in cc),
                                maximum=max(z["condition_max"] for z in cc))
    costs.append(dict(source=source,taps=taps,
        design_seconds=sum(z["seconds"] for z in data["conditioning"].values()),
        median_query_seconds_excluding_design=statistics.median(
            r["features"]["extraction_seconds_excluding_new_design"] for r in data["rows"]),
        total_seconds=data["seconds"],conditioning=cond,
        baseline_parity_max_error=data["parity_score_max_abs_error"]))

report += ["", "129 taps 在两记录、64 query、两 ridge 上均与原 P190 的 compatibility/presence/gap 完全一致"
    "（最大绝对误差 0.0，top/support 相同）。所有 192 次载体-长度 query 的 EDF 哈希核验通过。",
    "", "## 成本与条件数", "",
    "| 记录 | taps | 设计/逆矩阵总秒数 | query中位秒数（不含新设计） | rho=1e-6 条件数最小–最大 |",
    "|---|---:|---:|---:|---:|"]
for z in costs:
    c=z["conditioning"]["1e-06"]
    report.append(f"| {z['source'][-3:]} | {z['taps']} | {z['design_seconds']:.3f} | "
        f"{z['median_query_seconds_excluding_design']:.3f} | {c['minimum']:.5g}–{c['maximum']:.5g} |")
report += ["", "设计成本包含参考矩阵、候选 Gram、两 ridge 的逆矩阵和特征值条件数计算。"
    "每 query、每 ridge 为 40 个候选响应和 5 个 clean-null 响应；query成本还包括匹配与留出评分。"
    "条件数取加正则后的候选 Gram 的谱条件数，覆盖本记录所有折与候选。计时是本机单线程描述值。",
    "", "CAPACITY_SCORES.svg/pdf/png 展示全部逐身份分数，曲线为各组中位数。纵轴为 1−SC 的对数尺度；"
    "登记分数应在虚线下、独立未登记分数应在虚线上。点表示同一记录的不同身份实例，不是独立受试者。",
    "", "## 机制解释与下一步", "",
    "005 的登记 held RSS 在 129→257 taps 时从 0.129910675 降至 0.000807806（约 160.8 倍）；"
    "近码的不受约束拟合与固定父码拟合的残差差值仍被保留，因此 compatibility 离开 1 并形成明显间隔。"
    "012 方向相同。结合已知真实算子诊断，这支持原 129-tap 残余响应误差遮蔽身份偏移的解释；"
    "不能再把这两记录的主要失败归为共同对齐或候选吸收。",
    "",
    "257 taps 应作为后续结构方法必须比较的强容量基线。513 taps 的计数收益在本轮为零，"
    "不继续扩大长度或增加 ridge 菜单。新的低维稳定响应方法须同时比较 held RSS、身份分离和计算成本，"
    "避免把原 FIR 容量不足当作新机制优势。",
    "",
    "历史 pressure-aware 阈值在这两记录的 129 taps 下已实现 0/16 压力误接收、16/16登记正确；"
    "因此本轮更强的证据是原阈值下的恢复、明显扩大的分数间隔及残余误差下降。"
    "这些记录是机制开发材料；下一阶段须先冻结选择，再用新记录验证，"
    "不能把 192 次 query 评分视为 192 个独立 EEG 记录。独立记录数为 2，本报告不做总体显著性检验。",
    "",
    "## 文件与调用",
    "",
    "- capacity_pilot.py：CapacityReceiver(x, book, taps).extract_candidate(y)；不修改原接收代码。",
    "- runs/pilot01/PARITY_129.json.gz：先行单 query parity。",
    "- runs/pilot01/SUMMARY.json：六组完整结果与条件数。",
    "- runs/pilot01/OpenBMI{005,012}_taps{129,257,513}.json.gz：逐 query 原始特征。",
    "- DESCRIPTIVE_DATA.json：两 ridge 的均值、SD、中位数、范围及成本。",
]
(HERE/"CAPACITY_REPORT.md").write_text("\n".join(report)+"\n",encoding="utf-8")
(HERE/"DESCRIPTIVE_DATA.json").write_text(json.dumps(dict(
    role="paired_observed_record_descriptive_diagnostic",independent_record_n=2,
    descriptives=descriptives,costs=costs),ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(json.dumps(dict(status="report_complete",groups=len(summary["groups"]),
    parity_max=max(z["baseline_parity_max_error"] for z in costs)),ensure_ascii=False))
