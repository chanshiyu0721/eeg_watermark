"""Freeze-ready shared-policy DEV rules for five carriers and three receivers."""
from pathlib import Path
import json
import datetime
import numpy as np
import capacity_pilot as cp
from dev_capacity import ROLES,CONDITIONS,METHODS,CONFIGS

HERE=Path(__file__).resolve().parent
ARMS=("smooth","direct","spatial","hybrid05","qid")
EXACT=tuple(dict(ridge=r,support=s,head="negative_exact_normalized_identity_defect") for r in (1e-4,1e-6) for s in (1,3))


def loadrows(arm,taps,role):
    rows=[];files={}
    for source in ROLES[role]:
        if taps==129:p=cp.P190/"raw"/role/source/"level100"/(arm+".json.gz")
        elif arm=="smooth":p=HERE/"runs/dev257"/f"{source}_taps257.json.gz"
        else:p=HERE/"runs/allarm257"/arm/f"{source}_taps257.json.gz"
        obj=cp.load(p);assert obj["status"]=="complete",str(p)
        rows.extend(obj["rows"]);files[str(p.relative_to(cp.ROOT)).replace("\\","/")]=cp.sha(p)
    return rows,files


def score(row,method,config):
    if row.get("receiver") is None:return 0.,False,-1
    a=row["receiver"]["methods"][method]["by_ridge"][str(config["ridge"])]
    eligible=bool(a["eligible"] and a["support"]>=config["support"] and a["presence"]>=.25)
    value=-a["exact_normalized_identity_defect"] if config["head"]=="negative_exact_normalized_identity_defect" else a[config["head"]]
    return value,eligible,a["top"]


def family(row):
    if row["kind"]=="enrolled":return "registered"
    if row["kind"]=="clean":return "clean"
    if row["kind"]=="wrong_source":return "wrong"
    if row["kind"]=="qid_walsh_unregistered":return "qid_native_unknown"
    if row["kind"]=="qid_chip_near_unregistered":return "qid_chip"+str(row["distance"])
    if row.get("angle")==.0125:return "phase0125"
    if row.get("angle")==.025:return "phase025"
    return "other_unknown"


def summary(rows,method,rule):
    result={}
    for name in sorted(set(family(r) for r in rows)):
        rr=[r for r in rows if family(r)==name]
        aa=[r for r in rr if (lambda z:z[1] and z[0]>=rule["threshold"])(score(r,method,rule))]
        value=dict(n=len(rr),accepted=len(aa),infeasible=sum(r.get("receiver") is None for r in rr))
        if name=="registered":
            correct=sum(score(r,method,rule)[2]==r["identity"] for r in aa)
            value.update(correct=correct,misattributed=len(aa)-correct)
        if name.startswith("qid_chip"):
            value["attributed_to_parent"]=sum(score(r,method,rule)[2]==r["parent"] for r in aa)
        result[name]=value
    result["all_negative_accepted"]=sum(v["accepted"] for k,v in result.items() if k!="registered")
    return result


def calibrate(rows,method,head,policy="strict"):
    menu=EXACT if head=="exact" else CONFIGS
    candidates=[]
    for i,config in enumerate(menu):
        rule=dict(index=i,**config,presence_gate=.25)
        negative=[(r,score(r,method,rule)) for r in rows["fit"] if r["kind"]!="enrolled"
            and not (policy=="qid_native" and r["kind"]=="qid_chip_near_unregistered")]
        values=[z[0] for r,z in negative if z[1]]
        maximum=max(values) if values else None
        # Legacy heads are in[0,1], whereas exact mismatch scores are <=0.
        # With no eligible fit negative, accept every finite eligible score.
        rule["threshold"]=float(np.nextafter(maximum,np.inf)) if maximum is not None else (
            float(np.finfo(float).min) if head=="exact" else 0.)
        rule["eligible_fit_negative_n"]=len(values)
        rule["fit"]=summary(rows["fit"],method,rule);rule["select"]=summary(rows["select"],method,rule)
        for role in ROLES:
            panel=rule[role]
            panel["policy_negative_accepted"]=sum(v["accepted"] for k,v in panel.items() if isinstance(v,dict)
                and k!="registered" and not (policy=="qid_native" and k.startswith("qid_chip")))
        rule["fit_threshold_defining_negatives"]=[dict(source=r["source"],condition=r["condition"],
            query_index=r["query_index"],kind=r["kind"],score=z[0]) for r,z in negative if z[1] and z[0]==maximum]
        candidates.append(rule)
    selected=max(candidates,key=lambda r:(-r["select"]["policy_negative_accepted"],r["select"]["registered"]["correct"],-r["index"]))
    people={role:{source:summary([r for r in rows[role] if r["source"]==source],method,selected)
        for source in ROLES[role]} for role in ROLES}
    processing={role:{condition:summary([r for r in rows[role] if r["condition"]==condition],method,selected)
        for condition in CONDITIONS} for role in ROLES}
    return dict(selected=selected,candidates=candidates,people=people,processing=processing,identity_policy=policy)


def main():
    result=dict(status="complete DEV rule bundle before independent confirmation",created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        roles=ROLES,arms=ARMS,conditions=CONDITIONS,levels=[1.0],rules={},development_score_files={},
        configurations=dict(compatibility=12,exact=4),presence_gate=.25,
        fit_threshold_policy="nextafter maximum eligible nonenrolled score including0125 and QIM chip forgeries",
        select_policy="min D_select total false acceptance, max D_select registered correct, min menu index",
        empty_eligible_negative_policy="No eligible D_fit negatives: threshold0 for bounded legacy heads; finite float64 minimum for nonpositive exact score, accepting every finite eligible score",
        QIM_identity_policy="Keep historical strict chip-forgery labels; additionally report attribution-to-parent for damaged-copy interpretation",
        QIM_native_policy="Separately frozen strong native-identity control: fit negatives native Walsh unknown/clean/wrong only; chip1/chip2 are damaged-copy parent-recovery endpoints, never policy-selected against the strict table",
        primary_admission=dict(required_fit_and_select_coverage=.95,required_each_person_coverage=.90,required_negative_acceptance=0),
        primary=dict(arm="smooth",taps=257,method="candidate_FIR_GLRT",readout="exact"),
        new_person_scoring_performed=False,original_P190_unchanged=True,qid_native_policy={})
    report=["# Five-carrier frozen-rule development bundle","",
        "Each carrier and response estimator follows the same D_fit/D_select policy. Original129 compatibility scores are inherited; new257 scores include the exact conditional template-energy readout. QIM native unknown codes and1/2-chip modifications retain separate result columns.","",
        "|Carrier|Order / receiver / readout|Fit correct|Select correct|Select total strict negative accepts|","|---|---|---:|---:|---:|"]
    for arm in ARMS:
        result["rules"][arm]={}
        for taps in (129,257):
            rows={}
            for role in ROLES:
                rr,files=loadrows(arm,taps,role);rows[role]=rr;result["development_score_files"].update(files)
            for method in METHODS:
                for readout in (("compatibility",) if taps==129 else ("compatibility","exact")):
                    key=f"{taps}/{method}/{readout}"
                    entry=calibrate(rows,method,readout);result["rules"][arm][key]=entry
                    rule=entry["selected"];fit,sel=rule["fit"],rule["select"]
                    report.append(f"|{arm}|{key}|{fit['registered']['correct']}/{fit['registered']['n']}|{sel['registered']['correct']}/{sel['registered']['n']}|{sel['all_negative_accepted']}|")
                    if arm=="qid":
                        result["qid_native_policy"][key]=calibrate(rows,method,readout,"qid_native")
    report += ["","## QIM native identity policy, separate damaged-copy endpoints","",
        "|Receiver / readout|Fit correct|Select correct|Select native unknown FA|Select clean / wrong FA|Chip1 parent recovery|Chip2 parent recovery|",
        "|---|---:|---:|---:|---:|---:|---:|"]
    for key,entry in result["qid_native_policy"].items():
        f,s=entry["selected"]["fit"],entry["selected"]["select"]
        report.append(f"|{key}|{f['registered']['correct']}/{f['registered']['n']}|{s['registered']['correct']}/{s['registered']['n']}|{s['qid_native_unknown']['accepted']}/{s['qid_native_unknown']['n']}|{s['clean']['accepted']}/{s['clean']['n']} / {s['wrong']['accepted']}/{s['wrong']['n']}|{s['qid_chip1']['attributed_to_parent']}/{s['qid_chip1']['n']}|{s['qid_chip2']['attributed_to_parent']}/{s['qid_chip2']['n']}|")
    primary=result["rules"]["smooth"]["257/candidate_FIR_GLRT/exact"]
    pass_panel=all(primary["selected"][role]["registered"]["correct"]/primary["selected"][role]["registered"]["n"]>=.95
        and primary["selected"][role]["all_negative_accepted"]==0 for role in ROLES)
    pass_person=all(z["registered"]["correct"]/z["registered"]["n"]>=.90 for role in ROLES for z in primary["people"][role].values())
    result["primary_passes_admission"]=pass_panel and pass_person
    assert result["primary_passes_admission"],"Primary257 exact failed the final pre-confirmation DEV admission"
    # Fixed work point must match the already locked scientific candidate.
    earlier=cp.load(HERE/"runs/dev257/EXACT_READOUT_DEV_LOCK.json")["selected"]
    for key in ("ridge","support","threshold","presence_gate"):
        assert primary["selected"][key]==earlier[key],(key,primary["selected"][key],earlier[key])
    destination=HERE/"ALLARM_DEV_RULES.json"
    if destination.exists():
        old=cp.load(destination)
        assert old["rules"]==result["rules"] and old["qid_native_policy"]==result["qid_native_policy"] and old["development_score_files"]==result["development_score_files"],"Frozen-ready DEV evidence changed"
    else:cp.save(destination,result)
    (HERE/"ALLARM_DEV_RULES.md").write_text("\n".join(report)+"\n",encoding="utf-8")
    print(json.dumps(dict(status=result["status"],arms=ARMS,primary_passes_admission=True,rules_per_arm=9,path=str(destination),sha256=cp.sha(destination))))


if __name__=="__main__":main()
