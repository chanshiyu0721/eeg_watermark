"""Plot every observed identity score, without population error bars."""
from pathlib import Path
import os
import sys
HERE = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
os.environ["MPLCONFIGDIR"] = str(HERE/"cache"/"mplconfig")
import gzip
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

colors = {"registered":"#176FA3", "pressure0125":"#D75D22", "near025":"#7664A5"}
labels = {"registered":"Registered (8)", "pressure0125":"Independent 0.0125 (8)", "near025":"Independent 0.025 (16)"}
fig, axes = plt.subplots(2,2,figsize=(9.6,6.3),sharex=True,sharey=True)
for i,source in enumerate(("OpenBMI005","OpenBMI012")):
    for j,ridge in enumerate(("0.0001","1e-06")):
        ax=axes[i,j]
        by_family={name:[] for name in colors}
        for xpos,taps in enumerate((129,257,513)):
            data=json.loads(gzip.decompress((HERE/"runs"/"pilot01"/f"{source}_taps{taps}.json.gz").read_bytes()))
            for name in colors:
                scores=[]
                for row in data["rows"]:
                    meta=row["metadata"]
                    family="registered" if meta["kind"]=="enrolled" else ("pressure0125" if meta["angle"]==.0125 else "near025")
                    if family==name:
                        scores.append(max(1-row["features"]["by_ridge"][ridge]["compatibility"],1e-12))
                offset={"registered":-.12,"pressure0125":0.,"near025":.12}[name]
                ax.scatter(xpos+offset+np.linspace(-.04,.04,len(scores)),scores,
                    s=17,alpha=.65,c=colors[name],edgecolors="none")
                by_family[name].append(np.median(scores))
        for name in colors:
            ax.plot(range(3),by_family[name],color=colors[name],lw=1.1,label=labels[name])
        ax.axhline(1-.9957274054693162,color="#333333",ls="--",lw=.9,label="Original threshold")
        ax.set(yscale="log",ylim=(5e-7,.7),xticks=range(3),xticklabels=(129,257,513),
               title=f"{source}: ridge {ridge}")
        ax.grid(axis="y",which="major",alpha=.18)
        ax.spines[["top","right"]].set_visible(False)
        if j==0:ax.set_ylabel("1 - compatibility (log scale)")
        if i==1:ax.set_xlabel("Reference-side FIR taps")
handles,leglabels=axes[0,0].get_legend_handles_labels()
fig.legend(handles,leglabels,loc="lower center",ncol=4,frameon=False,fontsize=8.5)
fig.suptitle("Longer response support reveals near-identity separation",fontsize=13,fontweight="bold")
fig.text(.5,.925,"Observed development records; same EDF queries, 48 s visible query and 112 s references",
         ha="center",fontsize=9,color="#444444")
fig.tight_layout(rect=(0,.065,1,.92))
for suffix in ("svg","pdf","png"):
    fig.savefig(HERE/f"CAPACITY_SCORES.{suffix}",dpi=180,bbox_inches="tight")
print("Saved CAPACITY_SCORES.svg/pdf/png")
