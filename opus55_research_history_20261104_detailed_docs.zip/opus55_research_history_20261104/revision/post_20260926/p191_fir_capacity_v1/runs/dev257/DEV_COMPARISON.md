# 257-tap DEV comparison against inherited 129-tap strong controls

Thresholds include .0125 pressure negatives in D_fit; D_select chooses among the same 12 configurations for every receiver. Presence remains .25. All queries reproduce the original actual EDF bytes. These are observed development panels, not a new confirmation.

|Receiver|Chosen index / ridge / head / support|Fit registered|Fit .0125 FA|Select registered|Select .0125 FA|Select .025 FA|Select clean / wrong FA|
|---|---|---:|---:|---:|---:|---:|---:|
|taps129/ordinary_FIR|0 / 0.0001 / compatibility / 1|0/96|0/96|0/96|0/96|0/96|0/12 / 0/24|
|taps129/projected_FIR|0 / 0.0001 / compatibility / 1|58/96|0/96|75/96|0/96|0/96|0/12 / 0/24|
|taps129/candidate_FIR_GLRT|6 / 1e-06 / compatibility / 1|95/96|0/96|94/96|0/96|0/96|0/12 / 0/24|
|taps257/ordinary_FIR|0 / 0.0001 / compatibility / 1|0/96|0/96|0/96|0/96|0/96|0/12 / 0/24|
|taps257/projected_FIR|6 / 1e-06 / compatibility / 1|88/96|0/96|88/96|0/96|0/96|0/12 / 0/24|
|taps257/candidate_FIR_GLRT|0 / 0.0001 / compatibility / 1|86/96|0/96|89/96|0/96|0/96|0/12 / 0/24|

## Selected candidate receivers by participant

|Role / source|129 correct|257 correct|129 .0125 FA|257 .0125 FA|
|---|---:|---:|---:|---:|
|fit / OpenBMI001|24/24|24/24|0/24|0/24|
|fit / OpenBMI002|24/24|22/24|0/24|0/24|
|fit / A02T|23/24|19/24|0/24|0/24|
|fit / A03E|24/24|21/24|0/24|0/24|
|select / OpenBMI003|24/24|24/24|0/24|0/24|
|select / OpenBMI004|24/24|24/24|0/24|0/24|
|select / A05E|24/24|21/24|0/24|0/24|
|select / A07E|22/24|20/24|0/24|0/24|

## Costs

{
  "new257_total_recorded_seconds": 460.07191760000023,
  "extraction_median_seconds": 0.42967475000023114,
  "extraction_p95_seconds": 1.1856674250000652,
  "fits_per_query_per_ridge": {
    "ordinary_FIR": 5,
    "projected_FIR": 5,
    "candidate_FIR_GLRT": 40
  },
  "all_three_methods_total_fits_per_ridge": 50,
  "extra_scalar_readout_fits": 0,
  "inherited129_collection_runtime_not_reinterpreted": true
}

The DEV panel supplies four people per role. Repeated identities and processing conditions are paired observations within person. Independent confirmation is still required before interpreting transfer gains.
