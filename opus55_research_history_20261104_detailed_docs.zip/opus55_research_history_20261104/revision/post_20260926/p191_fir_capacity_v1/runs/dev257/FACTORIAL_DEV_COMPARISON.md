# FIR support x exact readout: fixed DEV factorial ablation

The 2x2 comparison isolates response support from the readout. Compatibility receives the original12 choices; exact normalized mismatch receives the fixed4 ridge/support choices. Each threshold uses only D_fit negatives including .0125; D_select chooses among the corresponding fixed rules.

|Response / readout|Fit correct|Select correct|Select .0125 FA|Select .025 FA|Select clean / wrong FA|
|---|---:|---:|---:|---:|---:|
|129/compatibility|95/96|94/96|0/96|0/96|0/12 / 0/24|
|129/exact|88/96|96/96|0/96|0/96|0/12 / 0/24|
|257/compatibility|86/96|89/96|0/96|0/96|0/12 / 0/24|
|257/exact|96/96|96/96|0/96|0/96|0/12 / 0/24|

Recommended DEV rule: **129/exact**.

{
  "index": 0,
  "ridge": 0.0001,
  "support": 1,
  "score": "negative_exact_normalized_identity_defect",
  "presence_gate": 0.25,
  "threshold": -3.9465113764708024e-05,
  "fit": {
    "registered": {
      "n": 96,
      "accepted": 88,
      "correct": 88,
      "misattributed": 0
    },
    "pressure0125": {
      "n": 96,
      "accepted": 0
    },
    "near025": {
      "n": 96,
      "accepted": 0
    },
    "clean": {
      "n": 12,
      "accepted": 0
    },
    "wrong": {
      "n": 24,
      "accepted": 0
    },
    "all_negative_accepted": 0
  },
  "select": {
    "registered": {
      "n": 96,
      "accepted": 96,
      "correct": 96,
      "misattributed": 0
    },
    "pressure0125": {
      "n": 96,
      "accepted": 0
    },
    "near025": {
      "n": 96,
      "accepted": 0
    },
    "clean": {
      "n": 12,
      "accepted": 0
    },
    "wrong": {
      "n": 24,
      "accepted": 0
    },
    "all_negative_accepted": 0
  }
}

Participant-level results and per-processing score ranges are retained in the JSON. These are8 observed development people, four per role. No fresh-person confirmation is counted.

The earlier H0-gain proxy failure and257 compatibility coverage loss remain separate results. Exact normalization uses each winner's own conditional unrestricted residual and true template energy.
