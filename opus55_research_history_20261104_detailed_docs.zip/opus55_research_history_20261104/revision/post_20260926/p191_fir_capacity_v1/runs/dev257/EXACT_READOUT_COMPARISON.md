# Exact template-energy normalization: one explanation check

The failed proxy divides identity defect by fitted H0 improvement. This check instead uses the winning template's actual squared norm and its own conditional unrestricted residual. It changes one normalization and one conditional-reference convention, while preserving the same response estimates and actual EDF queries.

Score: `-max(0, R_top - R_U_same_winning_response) / G_top_top`. Presence .25; four fixed ridge/support choices. D_fit includes pressure negatives; D_select chooses the rule. The DEV lock was written before observing the new005/012 scalar outcomes.

|Panel|Registered correct|.0125 accepted|.025 accepted|Clean accepted|Wrong accepted|
|---|---:|---:|---:|---:|---:|
|257 exact / fit|96/96|0/96|0/96|0/12|0/24|
|257 exact / select|96/96|0/96|0/96|0/12|0/24|
|129 / OpenBMI005 / compatibility_DEV_rule|8/8|0/8|0/16|0/1|0/4|
|129 / OpenBMI005 / exact_DEV_rule|8/8|0/8|0/16|0/1|0/4|
|129 / OpenBMI012 / compatibility_DEV_rule|8/8|0/8|0/16|0/1|0/4|
|129 / OpenBMI012 / exact_DEV_rule|8/8|0/8|0/16|0/1|0/4|
|257 / OpenBMI005 / compatibility_DEV_rule|8/8|0/8|0/16|0/1|0/4|
|257 / OpenBMI005 / exact_DEV_rule|8/8|0/8|0/16|0/1|0/4|
|257 / OpenBMI012 / compatibility_DEV_rule|8/8|0/8|0/16|0/1|0/4|
|257 / OpenBMI012 / exact_DEV_rule|8/8|0/8|0/16|0/1|0/4|

Selected DEV rule:

{
  "index": 0,
  "ridge": 0.0001,
  "support": 1,
  "score": "negative_exact_normalized_identity_defect",
  "presence_gate": 0.25,
  "threshold": -5.941561436978785e-05,
  "fit": {
    "registered": {
      "n": 96,
      "accepted": 96,
      "correct": 96,
      "misattributed": 0
    },
    "pressure0125": {
      "n": 96,
      "accepted": 0
    },
    "near025": {
      "n": 96,
      "accepted": 0
    },
    "clean": {
      "n": 12,
      "accepted": 0
    },
    "wrong": {
      "n": 24,
      "accepted": 0
    },
    "all_negative_accepted": 0
  },
  "select": {
    "registered": {
      "n": 96,
      "accepted": 96,
      "correct": 96,
      "misattributed": 0
    },
    "pressure0125": {
      "n": 96,
      "accepted": 0
    },
    "near025": {
      "n": 96,
      "accepted": 0
    },
    "clean": {
      "n": 12,
      "accepted": 0
    },
    "wrong": {
      "n": 24,
      "accepted": 0
    },
    "all_negative_accepted": 0
  }
}

The 129 exact pilot rows apply the 257-trained exact rule only as a descriptive transfer diagnostic; they do not represent a separately calibrated129 exact receiver. The strong129 compatibility control uses its own equal-menu D_fit/D_select rule.

The earlier H0-gain proxy failure remains in `p191_separation_v1/energy_score_pilot/RESULT.json`; its old observed-transfer acceptance counts are preserved. This exact-normalization check cannot retrospectively overwrite them.
