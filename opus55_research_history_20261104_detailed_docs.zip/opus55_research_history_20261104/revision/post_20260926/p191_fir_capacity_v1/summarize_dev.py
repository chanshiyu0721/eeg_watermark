"""Equal 12-config pressure-aware calibration for inherited129 vs new257 DEV."""
from pathlib import Path
import argparse
import json
import math
import statistics
import numpy as np
import capacity_pilot as cp
from dev_capacity import ROLES, CONDITIONS, METHODS, CONFIGS

HERE = Path(__file__).resolve().parent


def method_rows(source, role, capacity, label):
    if capacity == 129:
        path = cp.P190/"raw"/role/source/"level100/smooth.json.gz"
    else:
        path = HERE/"runs"/label/f"{source}_taps{capacity}.json.gz"
    obj = cp.load(path)
    assert obj["status"] == "complete", (str(path),obj["status"])
    return obj["rows"], obj


def eligible(row, method, index):
    cfg = row["receiver"]["methods"][method]["configs"][index]
    ridge = str(CONFIGS[index]["ridge"])
    presence = row["receiver"]["methods"][method]["by_ridge"][ridge]["presence"]
    return bool(cfg["eligible"] and presence >= .25)


def accepted(row, method, index, threshold):
    cfg = row["receiver"]["methods"][method]["configs"][index]
    return bool(eligible(row,method,index) and cfg["score"] >= threshold)


def family(row):
    if row["kind"] == "enrolled":return "registered"
    if row.get("pressure"):return "pressure0125"
    if row.get("angle") == .025:return "near025"
    if row["kind"] == "clean":return "clean"
    if row["kind"] == "wrong_source":return "wrong"
    return "other_unknown"


def summary(rows, method, rule):
    out = {}
    i, t = rule["index"],rule["threshold"]
    for name in ("registered","pressure0125","near025","clean","wrong"):
        rr = [r for r in rows if family(r) == name]
        aa = [r for r in rr if accepted(r,method,i,t)]
        out[name] = dict(n=len(rr),accepted=len(aa))
        if name == "registered":
            correct = sum(r["receiver"]["methods"][method]["configs"][i]["top"] == r["identity"] for r in aa)
            out[name].update(correct=correct,misattributed=len(aa)-correct)
    out["all_negative_accepted"] = sum(z["accepted"] for k,z in out.items() if k != "registered")
    return out


def calibrate(fit_rows, select_rows, method):
    candidates = []
    for index,config in enumerate(CONFIGS):
        neg = [r["receiver"]["methods"][method]["configs"][index]["score"] for r in fit_rows
               if r["kind"] != "enrolled" and eligible(r,method,index)]
        rule = dict(index=index,**config,threshold=float(np.nextafter(max(neg),np.inf)) if neg else 0.,
                    eligible_fit_negatives=len(neg),presence_gate=.25)
        rule["fit"] = summary(fit_rows,method,rule)
        rule["select"] = summary(select_rows,method,rule)
        candidates.append(rule)
    # Fixed before complete collection in runs/dev257/PROTOCOL.json.
    chosen = max(candidates,key=lambda r:(-r["select"]["all_negative_accepted"],
                 r["select"]["registered"]["correct"],-r["index"]))
    return dict(selected=chosen,candidates=candidates)


def main():
    ap=argparse.ArgumentParser();ap.add_argument("--label",default="dev257");args=ap.parse_args()
    path=HERE/"runs"/args.label
    all_data={};objects=[]
    for taps in (129,257):
        all_data[taps]={}
        for role,names in ROLES.items():
            all_data[taps][role]=[]
            for source in names:
                rr,obj=method_rows(source,role,taps,args.label)
                all_data[taps][role].extend(rr)
                if taps==257:objects.append(obj)
    out=dict(status="complete DEV comparison",original_P190_unchanged=True,
        new_confirmation_performed=False,roles=ROLES,conditions=CONDITIONS,
        level_interpretation="level100 means 1.0x original feasible strength, not 1% global PRD",
        fair_conditions=dict(owner_reference_seconds=112,query_context_seconds=48,scored_seconds=40,
            scored_windows=5,channels=8,hz=160,actual_16bit_EDF_queries_matched=True,
            configured_PRD_caps_percent=dict(global_PRD=.25,max_channel_PRD=.5,band_8_30_PRD=1.)),
        configurations_per_method=12,presence_gate=.25,
        threshold_policy="D_fit-only nextafter maximum eligible negative; .0125 included",
        selection_policy="D_select: minimum total negative accepts, maximum registered correct, lowest config index",
        methods={},pairwise={},costs={},source_condition_mechanism=[])
    curves=[]
    for taps in (129,257):
        for method in METHODS:
            key=f"taps{taps}/{method}"
            rr=all_data[taps]
            cal=calibrate(rr["fit"],rr["select"],method)
            rule=cal["selected"]
            panels={}
            for role,rows in rr.items():
                panels[role]=dict(total=summary(rows,method,rule),
                    processing={c:summary([r for r in rows if r["condition"]==c],method,rule) for c in CONDITIONS},
                    people={s:summary([r for r in rows if r["source"]==s],method,rule) for s in ROLES[role]},
                    people_processing={s:{c:summary([r for r in rows if r["source"]==s and r["condition"]==c],method,rule)
                        for c in CONDITIONS} for s in ROLES[role]})
            out["methods"][key]=dict(calibration=cal,panels=panels)
            fixed=cal["candidates"][6]
            out["methods"][key]["fixed_weak_compatibility"] = dict(rule=fixed,
                fit=summary(rr["fit"],method,fixed),select=summary(rr["select"],method,fixed))
            # Descriptive DEV threshold curves for the selected ridge/head/support.
            # These do not replace the fitted threshold or create extra configurations.
            i=rule["index"]
            fit_values=[r["receiver"]["methods"][method]["configs"][i]["score"] for r in rr["fit"]]
            thresholds=sorted(set([float(v) for v in np.quantile(fit_values,np.linspace(0,1,81))]+[rule["threshold"]]))
            for threshold in thresholds:
                q=dict(rule,threshold=threshold)
                curves.append(dict(receiver=key,threshold=threshold,
                    fit=summary(rr["fit"],method,q),select=summary(rr["select"],method,q)))
        # Fixed weak-ridge candidate statistics separate support adequacy from
        # D_select configuration changes or pressure-aware recalibration.
        for role,rows in all_data[taps].items():
            for source in ROLES[role]:
                for condition in CONDITIONS:
                    for label in ("registered","pressure0125","near025"):
                        vv=[r["receiver"]["methods"]["candidate_FIR_GLRT"]["by_ridge"]["1e-06"]
                            for r in rows if r["source"]==source and r["condition"]==condition and family(r)==label]
                        held=[v["candidate_RSS"][v["top"]] for v in vv]
                        unrestricted=[v["unrestricted_RSS"] for v in vv]
                        scores=[v["compatibility"] for v in vv]
                        out["source_condition_mechanism"].append(dict(taps=taps,role=role,source=source,
                            condition=condition,family=label,n=len(vv),compatibility_min=min(scores),
                            compatibility_max=max(scores),mean_top_held_RSS=statistics.mean(held),
                            mean_global_unrestricted_RSS=statistics.mean(unrestricted),
                            mean_identity_defect_against_global_U=statistics.mean(max(0.,a-b) for a,b in zip(held,unrestricted))))
    # Direct participant-paired differences use people, never individual IDs as independent N.
    a=out["methods"]["taps129/candidate_FIR_GLRT"]["panels"]
    b=out["methods"]["taps257/candidate_FIR_GLRT"]["panels"]
    for role in ROLES:
        out["pairwise"][role]=[]
        for s in ROLES[role]:
            aa,bb=a[role]["people"][s],b[role]["people"][s]
            out["pairwise"][role].append(dict(source=s,
                registered_correct_difference_257_minus129=bb["registered"]["correct"]-aa["registered"]["correct"],
                pressure_accept_difference_257_minus129=bb["pressure0125"]["accepted"]-aa["pressure0125"]["accepted"],
                near025_accept_difference_257_minus129=bb["near025"]["accepted"]-aa["near025"]["accepted"]))
    extraction=[r["receiver"]["extraction_seconds_excluding_new_design"] for obj in objects for r in obj["rows"]]
    out["costs"]=dict(new257_total_recorded_seconds=sum(z["seconds"] for z in objects),
        extraction_median_seconds=statistics.median(extraction),extraction_p95_seconds=float(np.quantile(extraction,.95)),
        fits_per_query_per_ridge=dict(ordinary_FIR=5,projected_FIR=5,candidate_FIR_GLRT=40),
        all_three_methods_total_fits_per_ridge=50,extra_scalar_readout_fits=0,
        inherited129_collection_runtime_not_reinterpreted=True)
    cp.save(path/"DEV_COMPARISON.json",out)
    cp.save(path/"THRESHOLD_CURVES.json",curves)
    report=["# 257-tap DEV comparison against inherited 129-tap strong controls","",
        "Thresholds include .0125 pressure negatives in D_fit; D_select chooses among the same 12 configurations for every receiver. Presence remains .25. All queries reproduce the original actual EDF bytes. These are observed development panels, not a new confirmation.","",
        "|Receiver|Chosen index / ridge / head / support|Fit registered|Fit .0125 FA|Select registered|Select .0125 FA|Select .025 FA|Select clean / wrong FA|",
        "|---|---|---:|---:|---:|---:|---:|---:|"]
    for key,z in out["methods"].items():
        rule=z["calibration"]["selected"];f=z["panels"]["fit"]["total"];s=z["panels"]["select"]["total"]
        ratio=lambda t,k,m="accepted":f"{t[k][m]}/{t[k]['n']}"
        report.append("|"+key+"|"+f"{rule['index']} / {rule['ridge']} / {rule['head']} / {rule['support']}"+"|"+
            "|".join([ratio(f,"registered","correct"),ratio(f,"pressure0125"),ratio(s,"registered","correct"),
                ratio(s,"pressure0125"),ratio(s,"near025"),ratio(s,"clean")+" / "+ratio(s,"wrong")])+"|")
    report += ["","## Selected candidate receivers by participant","",
        "|Role / source|129 correct|257 correct|129 .0125 FA|257 .0125 FA|","|---|---:|---:|---:|---:|"]
    for role in ROLES:
        for s in ROLES[role]:
            aa,bb=a[role]["people"][s],b[role]["people"][s]
            report.append(f"|{role} / {s}|{aa['registered']['correct']}/{aa['registered']['n']}|{bb['registered']['correct']}/{bb['registered']['n']}|{aa['pressure0125']['accepted']}/{aa['pressure0125']['n']}|{bb['pressure0125']['accepted']}/{bb['pressure0125']['n']}|")
    report += ["","## Costs","",json.dumps(out["costs"],indent=2),"",
        "The DEV panel supplies four people per role. Repeated identities and processing conditions are paired observations within person. Independent confirmation is still required before interpreting transfer gains.",""]
    (path/"DEV_COMPARISON.md").write_text("\n".join(report),encoding="utf-8")
    print(json.dumps({k:dict(selected=v["calibration"]["selected"],select=v["panels"]["select"]["total"]) for k,v in out["methods"].items()}),flush=True)


if __name__=="__main__":main()
