"""P191 DEV response-capacity comparison; existing P190 data stay read-only.

257 taps use longer owner-reference context only. Received-query context,
five held-out folds, ridge/head/support menu and actual EDF bytes are unchanged.
"""
from pathlib import Path
import argparse
import hashlib
import json
import time
import numpy as np
from threadpoolctl import threadpool_limits
import capacity_pilot as cp

HERE = Path(__file__).resolve().parent
P190 = cp.P190
ROLES = dict(fit=("OpenBMI001", "OpenBMI002", "A02T", "A03E"),
             select=("OpenBMI003", "OpenBMI004", "A05E", "A07E"))
CONDITIONS = ("reexport", "elliptic_new_causal", "bessel_shifted_causal")
METHODS = cp.api.METHODS
CONFIGS = cp.api.CONFIGS


def expanded_stats(stats, nulls, folds):
    value = cp.summarize_stats(stats, nulls, folds)
    top = value["top"]
    G, b, d = (sum(row[top][j] for row in stats) for j in range(3))
    beta = np.linalg.lstsq(G, b, rcond=1e-7)[0]
    conditional_ru = max(0., float(d - b @ beta))
    template_energy = float(G[top, top])
    defect = max(0., value["top_held_RSS"] - conditional_ru)
    value.update(winning_template_energy=template_energy,
                 conditional_unrestricted_RSS=conditional_ru,
                 exact_identity_defect=defect,
                 exact_normalized_identity_defect=defect/max(template_energy, 1e-30),
                 pooled_winning_G=G.tolist(), pooled_winning_b=b.tolist(),
                 pooled_winning_d=float(d))
    fold_values = []
    for row in stats:
        gg, bb, dd = row[top]
        be = np.linalg.lstsq(gg, bb, rcond=1e-7)[0]
        ru = max(0., float(dd - bb @ be))
        rr = max(0., float(dd + gg[top, top] - 2*bb[top]))
        fold_values.append(dict(template_energy=float(gg[top, top]), fixed_RSS=rr,
            conditional_unrestricted_RSS=ru, exact_identity_defect=max(0., rr-ru)))
    value["winning_template_fold_stats"] = fold_values
    return value


class DevelopmentReceiver(cp.CapacityReceiver):
    def design(self, k):
        data, cw = super().design(k)
        if not data.get("projected_ready"):
            for w, z in enumerate(data["windows"]):
                other = [a for j,a in enumerate(data["windows"]) if j != w]
                G = sum(a["xx"] for a in other)
                cross = sum(a["xt"] for a in other)
                TT = sum(a["tt"] for a in other)
                CT = cross @ np.linalg.pinv(TT, rcond=1e-9)
                projected = G - CT @ cross.T
                z["CT"] = CT
                for ridge in cp.RIDGES:
                    z["inverse"][ridge, True] = cp.api._inv(projected, ridge, np.trace(G)/len(G))
            data["projected_ready"] = True
        return data, cw

    def extract_all(self, y):
        started = time.monotonic()
        design_start = self.design_seconds
        _, lags, peaks, errors = cp.api.old.blind_match(self.receiver.refs, y)
        chosen = np.asarray([np.argmin(np.sum(errors[:, [j for j in range(5) if j != w]], axis=1))
                             for w in range(5)])
        buffers = [cp.api.p.filt(cp.api.p.center(y[:, st*160-128:(st+8)*160+128]))
                   for st in cp.api.p.STARTS]
        prep, folds = {}, []
        stats = {m:{r:[] for r in cp.RIDGES} for m in METHODS}
        nulls = {r:[] for r in cp.RIDGES}
        for w in range(5):
            ids = [j for j in range(5) if j != w]
            k = int(chosen[w]); delay = cp.api.recv.lower_median(lags[k, ids])
            if (k, delay) not in prep:
                data, cw = self.design(k)
                ys = [buf[:, 128+delay:1408+delay] for buf in buffers]
                _, bx, bt, cb = self._prepare(data, ys, cw)
                prep[k, delay] = data, cw, ys, bx, bt, cb
            data, cw, ys, bx, bt, cb = prep[k, delay]
            z = data["windows"][w]
            BB, BT, CB = (sum(v[j] for j in ids) for v in (bx, bt, cb))
            folds.append(dict(model=k, delay=delay, peak=float(peaks[k, w])))
            for ridge in cp.RIDGES:
                ho = z["inverse"][ridge, False] @ BB
                hp = z["inverse"][ridge, True] @ (BB-z["CT"]@BT)
                hc = np.einsum("nij,nj->ni", cw[w]["inverse"][ridge], CB)
                ordinary = self._stats(z, data, ys[w], ho)
                projected = self._stats(z, data, ys[w], hp)
                stats["ordinary_FIR"][ridge].append([ordinary]*8)
                stats["projected_FIR"][ridge].append([projected]*8)
                stats["candidate_FIR_GLRT"][ridge].append([self._stats(z, data, ys[w], h) for h in hc])
                nulls[ridge].append(ordinary[2])
        methods = {}
        for method in METHODS:
            by_ridge = {str(r):expanded_stats(stats[method][r], nulls[r], folds) for r in cp.RIDGES}
            configs = []
            for config in CONFIGS:
                a = by_ridge[str(config["ridge"])]
                configs.append(dict(score=a[config["head"]], top=a["top"],
                    eligible=bool(a["eligible"] and a["support"] >= config["support"])))
            methods[method] = dict(by_ridge=by_ridge, configs=configs)
        elapsed = time.monotonic()-started
        return dict(methods=methods, folds=folds, seconds=elapsed,
            new_design_seconds=self.design_seconds-design_start,
            extraction_seconds_excluding_new_design=elapsed-(self.design_seconds-design_start),
            response_fits_per_ridge=50, fits_by_method=dict(ordinary_FIR=5,projected_FIR=5,candidate_FIR_GLRT=40),
            extra_scalar_readout_fits=0)


def role_for(source):
    return next(role for role, names in ROLES.items() if source in names)


def run(source, taps, label):
    role = role_for(source)
    dest = HERE/"runs"/label/f"{source}_taps{taps}.json.gz"
    previous = cp.load(dest) if dest.exists() else None
    if previous and previous.get("status") == "complete":
        print(json.dumps(dict(event="reused_complete", source=source, taps=taps)),flush=True)
        return previous
    raw_path = P190/"raw"/role/source/"level100/smooth.json.gz"
    raw = cp.load(raw_path)
    folder = P190/"issuance"/source/"level100"
    issue = cp.load(folder/"issuance_summary.json")
    x = cp.read_edf(P190/"sources"/source/"clean.edf.gz")
    book = np.asarray([cp.read_edf(folder/f"smooth_r{i}_issued.edf.gz") for i in range(8)])
    receiver = DevelopmentReceiver(x, book, taps)
    copies, wrong, receipts = {}, {}, []
    rows = previous["rows"] if previous else []
    done = {(r["condition"],r["query_index"]) for r in rows}
    started = time.monotonic()
    past_seconds = previous.get("seconds",0.) if previous else 0.
    for old in raw["rows"]:
        key = old["condition"],old["query_index"]
        if key in done:
            continue
        i = old["query_index"]
        if old["kind"] == "clean":
            issued = x
        elif old["kind"] == "wrong_source":
            negative = old["negative_source"]
            if negative not in wrong:
                wrong[negative] = cp.read_edf(P190/"sources"/negative/"clean.edf.gz")
            issued = wrong[negative]
        else:
            if i not in copies:
                copies[i] = cp.read_edf(folder/f"smooth_r{i}_issued.edf.gz")
            issued = copies[i]
        limits = tuple(np.asarray(v) for v in raw["query_limits_uv"][old["condition"]])
        query, _ = cp.edf.edf_roundtrip(cp.common.transform(issued, old["condition"]), limits,
            f"{source}_level100_smooth_q{i}_{old['condition']}.edf",dest.parent,receipts,False,cp.CHANNELS)
        assert old["query_raw_sha256"] == receipts[-1]["raw_sha256"], (source,key,"P190 query bytes differ")
        value = {k:v for k,v in old.items() if k != "receiver"}
        value["receiver"] = receiver.extract_all(query)
        rows.append(value)
        result = dict(status="running", role=role, source=source, taps=taps,
            arm="smooth", level=1.0, rows=rows, expected_n=len(raw["rows"]),
            seconds=past_seconds+time.monotonic()-started,
            conditioning=receiver.conditioning,
            code_sha256=cp.sha(__file__), receiver_code_sha256=cp.sha(cp.__file__),
            original_raw_sha256=cp.sha(raw_path), actual_EDF_query_bytes_verified=len(rows),
            no_unobserved_confirmation_used=True, query_context_seconds=48,
            scored_query_seconds=40, owner_reference_seconds=112,
            reference_half_context_samples=(taps-1)//2, query_context_not_extended=True,
            head_support_ridge_menu=list(CONFIGS), extra_scalar_readout_fits=0)
        cp.save(dest,result)
        print(json.dumps(dict(event="query",source=source,taps=taps,n=len(rows),total=len(raw["rows"]),
            query_index=i,condition=old["condition"],kind=old["kind"],
            seconds=value["receiver"]["seconds"])),flush=True)
    result["status"] = "complete"
    cp.save(dest,result)
    print(json.dumps(dict(event="source_complete",source=source,taps=taps,n=len(rows),seconds=result["seconds"])),flush=True)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--sources",default="OpenBMI001,OpenBMI002,OpenBMI003,OpenBMI004,A02T,A03E,A05E,A07E")
    parser.add_argument("--taps",type=int,default=257)
    parser.add_argument("--label",default="dev257")
    args = parser.parse_args()
    manifest = HERE/"runs"/args.label/"PROTOCOL.json"
    if not manifest.exists():
        cp.save(manifest,dict(status="DEV collection protocol", roles=ROLES, conditions=CONDITIONS,
            taps=args.taps, arm="smooth",level=1.0, pressure0125_in_fit_negatives=True,
            search_menu=list(CONFIGS),presence_gate=.25,
            threshold_policy="D_fit-only nextafter maximum eligible negative including pressure0125",
            select_policy="D_select chooses fixed D_fit rules: minimize false acceptance, maximize enrolled correct, tie lowest menu index",
            original_P190_untouched=True,new_confirmation_performed=False))
    with threadpool_limits(limits=1):
        for source in args.sources.split(","):
            run(source,args.taps,args.label)


if __name__ == "__main__":
    main()
