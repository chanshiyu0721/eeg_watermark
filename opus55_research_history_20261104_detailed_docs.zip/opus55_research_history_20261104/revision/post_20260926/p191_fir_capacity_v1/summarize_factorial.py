"""Isolate readout vs FIR-support effects with a fixed 2x2 DEV ablation."""
from pathlib import Path
import datetime
import json
import statistics
import numpy as np
import capacity_pilot as cp
import summarize_dev as sd
import summarize_exact_readout as ex
from dev_capacity import ROLES,CONDITIONS

HERE=Path(__file__).resolve().parent
METHOD=ex.METHOD


def calibrate(rows):
    configs=[]
    for i,c in enumerate(ex.MENU):
        rule=dict(index=i,**c,score="negative_exact_normalized_identity_defect",presence_gate=.25)
        scores=[ex.values(r,rule)[0] for r in rows["fit"] if r["kind"]!="enrolled" and ex.values(r,rule)[1]]
        rule["threshold"]=float(np.nextafter(max(scores),np.inf)) if scores else 0.
        rule["fit"]=ex.summary(rows["fit"],rule);rule["select"]=ex.summary(rows["select"],rule)
        configs.append(rule)
    return dict(candidates=configs,selected=max(configs,key=lambda r:(-r["select"]["all_negative_accepted"],
         r["select"]["registered"]["correct"],-r["index"])))


def main():
    compat=cp.load(HERE/"runs/dev257/DEV_COMPARISON.json")
    rows={};objects={}
    for taps,label in ((129,"dev129exact"),(257,"dev257")):
        rows[taps]={};objects[taps]=[]
        for role,names in ROLES.items():
            rows[taps][role]=[]
            for s in names:
                obj=cp.load(HERE/"runs"/label/f"{s}_taps{taps}.json.gz")
                assert obj["status"]=="complete"
                rows[taps][role].extend(obj["rows"]);objects[taps].append(obj)
    exact={t:calibrate(rows[t]) for t in (129,257)}
    # Lock both independently DEV-selected readouts before any additional transfer use.
    locked=dict(status="DEV-only factorial rules",locked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        roles=ROLES,score="-max(0,Rtop-RU_same_winner)/Gii",presence_gate=.25,
        exact_configurations=4,compatibility_configurations=12,
        identity_support_changes_do_not_change_the_score_formula=True,
        rules={str(t):exact[t]["selected"] for t in exact},new_person_scoring_performed=False)
    lock_path=HERE/"runs/dev257/FACTORIAL_DEV_LOCK.json"
    if lock_path.exists():
        old=cp.load(lock_path);assert old["rules"]==locked["rules"];locked=old
    else:cp.save(lock_path,locked)
    result=dict(status="complete 2x2 DEV ablation",roles=ROLES,conditions=CONDITIONS,panels={},
        exact_calibration=exact,rule_lock_sha256=cp.sha(lock_path),
        new_confirmation_performed=False,all_query_bytehashes_match_original=True,
        identity_labels_and_perturbation_unchanged=True,source_processing_ranges=[],
        readout_cost="No additional response fits; pooled G/b/d already available",costs={})
    for taps in (129,257):
        key=f"{taps}/exact";rule=exact[taps]["selected"]
        result["panels"][key]={}
        for role,rr in rows[taps].items():
            result["panels"][key][role]=dict(total=ex.summary(rr,rule),
                people={s:ex.summary([r for r in rr if r["source"]==s],rule) for s in ROLES[role]},
                processing={c:ex.summary([r for r in rr if r["condition"]==c],rule) for c in CONDITIONS})
            for source in ROLES[role]:
                for condition in CONDITIONS:
                    for name in ("registered","pressure0125","near025"):
                        ss=[r for r in rr if r["source"]==source and r["condition"]==condition and sd.family(r)==name]
                        vv=[ex.values(r,rule) for r in ss]
                        vals=[-v[0] for v in vv]
                        result["source_processing_ranges"].append(dict(taps=taps,role=role,source=source,
                            condition=condition,family=name,n=len(vals),distance_min=min(vals),distance_max=max(vals),
                            eligible_n=sum(v[1] for v in vv)))
        result["panels"][f"{taps}/compatibility"]=compat["methods"][f"taps{taps}/{METHOD}"]["panels"]
        durations=[r["receiver"]["extraction_seconds_excluding_new_design"] for obj in objects[taps] for r in obj["rows"]]
        result["costs"][str(taps)]=dict(recorded_total_seconds=sum(o["seconds"] for o in objects[taps]),
            median_extraction_seconds=statistics.median(durations),p95_extraction_seconds=float(np.quantile(durations,.95)),
            per_ridge_candidate_FIR_fits=40,per_ridge_all_three_estimators_FIR_fits=50,
            extra_response_fits_for_exact_readout=0)
    # Within an identical model/readout outcome, choose fewer FIR coefficients.
    candidates=[]
    for taps in (129,257):
        for head in ("compatibility","exact"):
            key=f"{taps}/{head}"
            panel=result["panels"][key]["select"]["total"]
            rule=exact[taps]["selected"] if head=="exact" else compat["methods"][f"taps{taps}/{METHOD}"]["calibration"]["selected"]
            candidates.append(dict(name=key,taps=taps,readout=head,rule=rule,select=panel))
    recommended=max(candidates,key=lambda z:(-z["select"]["all_negative_accepted"],z["select"]["registered"]["correct"],
        -z["taps"],z["readout"]=="compatibility"))
    proposal=dict(status="DEV rule proposal; full independent-confirmation freeze remains to be completed",
        recommendation=recommended,candidates=candidates,DEV_lock_sha256=cp.sha(lock_path),
        rationale="Minimize D_select false acceptance; maximize correct enrolled attribution; prefer lower response order on ties",
        no_new_people_scored=True,original_P190_unchanged=True,
        primary_endpoint="elliptic .0125 rejection constrained by registered coverage and .025/clean/wrong accepts",
        query_reference_seconds=112,visible_query_seconds=48,scored_query_seconds=40,
        PRD_caps_percent=dict(global_PRD=.25,max_channel_PRD=.5,band_8_30_PRD=1.))
    cp.save(HERE/"runs/dev257/FACTORIAL_DEV_RULE_PROPOSAL.json",proposal)
    result["recommended_DEV_rule"]=recommended
    cp.save(HERE/"runs/dev257/FACTORIAL_DEV_COMPARISON.json",result)
    report=["# FIR support x exact readout: fixed DEV factorial ablation","",
        "The 2x2 comparison isolates response support from the readout. Compatibility receives the original12 choices; exact normalized mismatch receives the fixed4 ridge/support choices. Each threshold uses only D_fit negatives including .0125; D_select chooses among the corresponding fixed rules.","",
        "|Response / readout|Fit correct|Select correct|Select .0125 FA|Select .025 FA|Select clean / wrong FA|",
        "|---|---:|---:|---:|---:|---:|"]
    for z in candidates:
        key=z["name"];f=result["panels"][key]["fit"]["total"];s=result["panels"][key]["select"]["total"]
        report.append(f"|{key}|{f['registered']['correct']}/96|{s['registered']['correct']}/96|{s['pressure0125']['accepted']}/96|{s['near025']['accepted']}/96|{s['clean']['accepted']}/12 / {s['wrong']['accepted']}/24|")
    report += ["",f"Recommended DEV rule: **{recommended['name']}**.","",json.dumps(recommended["rule"],indent=2),"",
        "Participant-level results and per-processing score ranges are retained in the JSON. These are8 observed development people, four per role. No fresh-person confirmation is counted.","",
        "The earlier H0-gain proxy failure and257 compatibility coverage loss remain separate results. Exact normalization uses each winner's own conditional unrestricted residual and true template energy.",""]
    (HERE/"runs/dev257/FACTORIAL_DEV_COMPARISON.md").write_text("\n".join(report),encoding="utf-8")
    print(json.dumps(dict(recommended=recommended,panels={k:{r:v[r]["total"] for r in ROLES} for k,v in result["panels"].items()})),flush=True)


if __name__=="__main__":main()
