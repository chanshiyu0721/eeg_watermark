# P191 response support and normalized identity mismatch

This folder adds two DEV hypotheses to the preserved P190 experiment:

1. Longer owner-reference FIR support can reduce unmodelled processing residuals.
2. Identity mismatch should be normalized by the actual identity template energy, using the unrestricted identity fit under the same winning response.

The implementation keeps the received observation at five 8 s scoring windows with 1.6 s context each (40 s scored, 48 s visible total), 112 s owner-held references, eight channels, 160 Hz, and original16-bit EDF readback. It does not reissue or change a fingerprint, the PRD budget or the perturbation matching. Each new received EDF byte hash must match its P190 row.

The original DEV panel contains24 encoded copies per source:8 registered,8 independent .025 near codes and8 independent .0125 pressure codes. With one clean and two wrong-source queries under three processing conditions, it has81 queries per person. Original confirmation had a wider32-copy menu and is now observed DEV evidence for this new research.

## Outputs

- `runs/dev257/DEV_COMPARISON.{json,md}`: original129 vs new257 with ordinary, projected and candidate-conditioned FIR; twelve ridge/head/support configurations each.
- `runs/dev257/EXACT_READOUT_PROTOCOL.json`: the single normalization check and its fixed four ridge/support configurations.
- `runs/dev257/EXACT_READOUT_DEV_LOCK.json`: exact257 rule chosen solely from original D_fit and D_select.
- `runs/dev257/EXACT_READOUT_COMPARISON.{json,md}`: exact257 development and subsequent descriptive application on005/012; preserves the earlier failed H0-gain proxy.
- `runs/dev257/FACTORIAL_DEV_COMPARISON.{json,md}`: the necessary129/257 x compatibility/exact ablation, isolating readout from response order.
- `runs/dev257/FACTORIAL_DEV_RULE_PROPOSAL.json`: machine-readable DEV recommendation; this is not a complete fresh-person confirmation freeze.
- `runs/exact_pilot01/`: newly required conditional template-energy statistics on the already-observed005/012 pilot. Old pilot files remain intact.
- `runs/dev257/NEW_IMPLEMENTATION_SINGLE_QUERY_PARITY.json`: one targeted check of the newly shared score aggregation against all three inherited129 estimators; maximum score difference0.0.

`exact_normalized_identity_defect` is

```
max(0, R_top - R_U_under_the_same_winning_response) / G_top_top
```

where `G_top_top` is the pooled energy of the winning fingerprint template. The high-is-good score is its negative. Pooled `G`, `b`, `d`, the winning conditional unrestricted residual and fold summaries are saved so this readout requires no extra FIR fits.

## Reproduction

Use the existing project environment and run from this folder. Intermediate and cache files remain on E:.

```powershell
& 'E:\python\数字水印\.venv-rerun\Scripts\python.exe' .\dev_capacity.py --label dev257
& 'E:\python\数字水印\.venv-rerun\Scripts\python.exe' .\summarize_dev.py --label dev257
& 'E:\python\数字水印\.venv-rerun\Scripts\python.exe' .\exact_readout_pilot.py
& 'E:\python\数字水印\.venv-rerun\Scripts\python.exe' .\summarize_exact_readout.py
& 'E:\python\数字水印\.venv-rerun\Scripts\python.exe' .\dev_capacity.py --taps 129 --label dev129exact
& 'E:\python\数字水印\.venv-rerun\Scripts\python.exe' .\summarize_factorial.py
```

Collections resume at the last saved query and reuse complete source outputs. Required data are the immutable P190 source EDF caches, issued EDF copies, and saved raw scores. Dependencies are inherited from the project: NumPy, SciPy and threadpoolctl, together with the existing EDF/receiver modules. The numerical routines are deterministic and introduce no random draws.

Thresholds use only D_fit eligible negatives, now including .0125. D_select minimizes all negative acceptance, then maximizes correct registered attribution, then uses the lowest configuration index. Candidate recommendations use the same false-acceptance/coverage priority and prefer lower FIR order when outcomes tie. All people in these files were previously observed; a fresh-person evaluation requires its own complete frozen protocol.

## Cost interpretation

Each query and ridge fits5 ordinary,5 projected and40 candidate-specific FIR models when all three estimators are collected. Exact scalar readout adds no response fits. Recorded timings include real concurrent workstation load; they describe these runs, rather than a dedicated hardware benchmark.
