"""Saved-decision summary for the fixed P191 confirmation; no rule selection."""
from pathlib import Path
import argparse
import json
import capacity_pilot as cp
import calibrate_allarms as dev

HERE=Path(__file__).resolve().parent
OUT=HERE.parent/"p191_confirmation_v1"
ARMS=("smooth","direct","hybrid05","spatial","qid")
CONDITIONS=("reexport","elliptic_new_causal","bessel_shifted_causal")
PEOPLE=tuple(f"OpenBMI{s:03d}" for s in range(17,25))


def summary(rows,key,decision_field="decisions"):
    result={}
    for name in sorted(set(dev.family(r) for r in rows)):
        zz=[r for r in rows if dev.family(r)==name]
        aa=[r for r in zz if r[decision_field][key]>=0]
        value=dict(n=len(zz),accepted=len(aa),infeasible=sum(not r["issuance_feasible"] for r in zz))
        if name=="registered":
            value["correct"]=sum(r[decision_field][key]==r["identity"] for r in aa)
            value["misattributed"]=len(aa)-value["correct"]
        if name.startswith("qid_chip"):
            value["attributed_to_parent"]=sum(r[decision_field][key]==r["parent"] for r in aa)
        result[name]=value
    result["all_negative_accepted"]=sum(v["accepted"] for k,v in result.items() if k!="registered")
    return result


def main():
    ap=argparse.ArgumentParser();ap.add_argument("--out",type=Path,default=OUT)
    ap.add_argument("--allow-partial",action="store_true");args=ap.parse_args();root=args.out.resolve()
    manifest=[];allrows={a:[] for a in ARMS};freeze=None
    for arm in ARMS:
        for source in PEOPLE:
            p=root/"raw/confirm"/source/"level100"/(arm+".json.gz")
            if not p.exists():manifest.append(dict(arm=arm,source=source,status="missing"));continue
            obj=cp.load(p)
            manifest.append(dict(arm=arm,source=source,status=obj["status"],n=len(obj["rows"]),sha256=cp.sha(p)))
            if obj["status"]!="complete":continue
            assert len(obj["rows"])==obj["expected_n"]
            if freeze is None:freeze=obj["confirmation_freeze_sha256"]
            assert obj["confirmation_freeze_sha256"]==freeze
            allrows[arm].extend(obj["rows"])
    complete=all(r["status"]=="complete" for r in manifest)
    if not args.allow_partial:assert complete,"Confirmation has incomplete fixed files"
    result=dict(status="complete" if complete else "partial_descriptive_only",manifest=manifest,
        confirmation_freeze_sha256=freeze,people=list(PEOPLE),independent_statistical_unit="person",
        rule_selection_on_confirmation=False,arms={},paired_primary_vectors=[])
    for arm,rows in allrows.items():
        if not rows:continue
        keys=list(rows[0]["decisions"])
        result["arms"][arm]={key:dict(total=summary(rows,key),
            processing={c:summary([r for r in rows if r["condition"]==c],key) for c in CONDITIONS},
            people={s:{c:summary([r for r in rows if r["source"]==s and r["condition"]==c],key)
                for c in CONDITIONS} for s in PEOPLE if any(r["source"]==s for r in rows)}) for key in keys}
        if arm=="qid":
            native_keys=list(rows[0]["qid_native_policy_decisions"])
            result["qid_native_policy"]={key:dict(total=summary(rows,key,"qid_native_policy_decisions"),
                processing={c:summary([r for r in rows if r["condition"]==c],key,"qid_native_policy_decisions") for c in CONDITIONS},
                people={s:{c:summary([r for r in rows if r["source"]==s and r["condition"]==c],key,"qid_native_policy_decisions")
                    for c in CONDITIONS} for s in PEOPLE if any(r["source"]==s for r in rows)}) for key in native_keys}
    primary="257/candidate_FIR_GLRT/exact"
    for source in PEOPLE:
        rr=[r for r in allrows["smooth"] if r["source"]==source and r["condition"]=="elliptic_new_causal"]
        if not rr:continue
        for control in ("129/candidate_FIR_GLRT/compatibility","257/candidate_FIR_GLRT/compatibility","257/projected_FIR/exact"):
            a,b=summary(rr,primary),summary(rr,control)
            result["paired_primary_vectors"].append(dict(source=source,control=control,
                primary_registered_rate=a["registered"]["correct"]/a["registered"]["n"],
                control_registered_rate=b["registered"]["correct"]/b["registered"]["n"],
                primary_pressure_accept_rate=a["phase0125"]["accepted"]/a["phase0125"]["n"],
                control_pressure_accept_rate=b["phase0125"]["accepted"]/b["phase0125"]["n"]))
    path=root/("CONFIRMATION_SAVED_SUMMARY.json" if complete else "PARTIAL_SAVED_SUMMARY.json")
    cp.save(path,result)
    print(json.dumps(dict(status=result["status"],complete_files=sum(r["status"]=="complete" for r in manifest),
        expected_files=len(manifest),new_rules_fitted=False,path=str(path))))


if __name__=="__main__":main()
