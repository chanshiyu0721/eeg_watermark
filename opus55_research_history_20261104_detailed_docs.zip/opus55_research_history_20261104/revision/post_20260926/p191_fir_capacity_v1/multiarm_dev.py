"""Collect newly required257tap conditional scalar stats for P190 DEV arms."""
from pathlib import Path
import argparse
import json
import time
import numpy as np
from threadpoolctl import threadpool_limits
import capacity_pilot as cp
from dev_capacity import DevelopmentReceiver,role_for,ROLES

HERE=Path(__file__).resolve().parent
ARMS=("direct","spatial","hybrid05","qid")


def run(source,arm,label="allarm257"):
    role=role_for(source)
    dest=HERE/"runs"/label/arm/f"{source}_taps257.json.gz"
    before=cp.load(dest) if dest.exists() else None
    if before and before["status"]=="complete":return
    raw_path=cp.P190/"raw"/role/source/"level100"/(arm+".json.gz")
    raw=cp.load(raw_path)
    folder=cp.P190/"issuance"/source/"level100"
    issue=cp.load(folder/"issuance_summary.json")
    x=cp.read_edf(cp.P190/"sources"/source/"clean.edf.gz")
    def copy(index):
        name=issue["metadata"][arm][index].get("recipient",index) if arm=="qid" else index
        return cp.read_edf(folder/("qid" if arm=="qid" else "")/f"{arm}_r{name}_issued.edf.gz")
    book=np.asarray([copy(i) for i in range(8)])
    receiver=DevelopmentReceiver(x,book,257)
    values={};wrongs={};receipts=[]
    rows=before["rows"] if before else []
    done={(r["condition"],r["query_index"]) for r in rows}
    started=time.monotonic();past=before.get("seconds",0.) if before else 0.
    for old in raw["rows"]:
        key=old["condition"],old["query_index"]
        if key in done:continue
        if not old["issuance_feasible"]:
            rows.append({k:v for k,v in old.items() if k!="receiver"}|dict(receiver=None))
        else:
            i=old["query_index"]
            if old["kind"]=="clean":issued=x
            elif old["kind"]=="wrong_source":
                name=old["negative_source"]
                if name not in wrongs:wrongs[name]=cp.read_edf(cp.P190/"sources"/name/"clean.edf.gz")
                issued=wrongs[name]
            else:
                if i not in values:values[i]=copy(i)
                issued=values[i]
            condition=old["condition"]
            limits=tuple(np.asarray(v) for v in raw["query_limits_uv"][condition])
            query,_=cp.edf.edf_roundtrip(cp.common.transform(issued,condition),limits,
                f"{source}_level100_{arm}_q{i}_{condition}.edf",dest.parent,receipts,False,cp.CHANNELS)
            assert old["query_raw_sha256"]==receipts[-1]["raw_sha256"],(source,arm,key)
            row={k:v for k,v in old.items() if k!="receiver"}
            row["receiver"]=receiver.extract_all(query);rows.append(row)
        doc=dict(status="running",role=role,source=source,arm=arm,taps=257,level=1.0,rows=rows,
            expected_n=len(raw["rows"]),seconds=past+time.monotonic()-started,
            original_raw_sha256=cp.sha(raw_path),issuance_sha256=cp.sha(folder/"issuance_summary.json"),
            code_sha256=cp.sha(__file__),expanded_receiver_sha256=cp.sha(HERE/"dev_capacity.py"),
            actual_EDF_query_bytes_verified=sum(r["receiver"] is not None for r in rows),
            all_original_identity_labels_preserved=True,new_confirmation_performed=False,
            owner_reference_seconds=112,visible_context_seconds=48,scored_seconds=40)
        cp.save(dest,doc)
        print(json.dumps(dict(event="query",source=source,arm=arm,n=len(rows),total=len(raw["rows"]))),flush=True)
    doc["status"]="complete";cp.save(dest,doc)
    print(json.dumps(dict(event="source_arm_complete",source=source,arm=arm,n=len(rows),seconds=doc["seconds"])),flush=True)


def main():
    ap=argparse.ArgumentParser();ap.add_argument("--arms",default=",".join(ARMS))
    ap.add_argument("--sources",default=",".join(s for names in ROLES.values() for s in names))
    ap.add_argument("--label",default="allarm257");args=ap.parse_args()
    with threadpool_limits(limits=1):
        for arm in args.arms.split(","):
            assert arm in ARMS
            for source in args.sources.split(","):run(source,arm,args.label)


if __name__=="__main__":main()
