"""One explanation check: genuine template energy instead of fitted H0 gain."""
from pathlib import Path
import datetime
import hashlib
import json
import numpy as np
import capacity_pilot as cp
import summarize_dev as sd
from dev_capacity import ROLES, CONDITIONS

HERE=Path(__file__).resolve().parent
METHOD="candidate_FIR_GLRT"
MENU=tuple(dict(ridge=r,support=s) for r in (1e-4,1e-6) for s in (1,3))


def values(row,rule):
    a=row["receiver"]["methods"][METHOD]["by_ridge"][str(rule["ridge"])]
    eligible=bool(a["eligible"] and a["support"]>=rule["support"] and a["presence"]>=.25)
    return -a["exact_normalized_identity_defect"],eligible,a["top"]


def summary(rows,rule):
    out={}
    for name in ("registered","pressure0125","near025","clean","wrong"):
        rr=[r for r in rows if sd.family(r)==name]
        aa=[r for r in rr if (lambda v:v[1] and v[0]>=rule["threshold"])(values(r,rule))]
        out[name]=dict(n=len(rr),accepted=len(aa))
        if name=="registered":
            correct=sum(values(r,rule)[2]==r["identity"] for r in aa)
            out[name].update(correct=correct,misattributed=len(aa)-correct)
    out["all_negative_accepted"]=sum(v["accepted"] for k,v in out.items() if k!="registered")
    return out


def main():
    root=HERE/"runs/dev257"
    protocol=cp.load(root/"EXACT_READOUT_PROTOCOL.json")
    assert protocol["menu"]==list(MENU)
    rr={role:[row for source in names for row in sd.method_rows(source,role,257,"dev257")[0]]
        for role,names in ROLES.items()}
    configs=[]
    for index,config in enumerate(MENU):
        rule=dict(index=index,**config,score="negative_exact_normalized_identity_defect",presence_gate=.25)
        neg=[values(r,rule)[0] for r in rr["fit"] if r["kind"]!="enrolled" and values(r,rule)[1]]
        rule["threshold"]=float(np.nextafter(max(neg),np.inf)) if neg else 0.
        rule["fit"]=summary(rr["fit"],rule);rule["select"]=summary(rr["select"],rule)
        configs.append(rule)
    selected=max(configs,key=lambda r:(-r["select"]["all_negative_accepted"],r["select"]["registered"]["correct"],-r["index"]))
    # Commit the DEV-only rule before loading observed005/012 scalar outcomes.
    rule_path=root/"EXACT_READOUT_DEV_LOCK.json"
    lock=dict(status="DEV-only fixed rule; not new-person confirmation freeze",
        locked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),selected=selected,
        menu=list(MENU),protocol_sha256=cp.sha(root/"EXACT_READOUT_PROTOCOL.json"),
        observed005012_not_used_for_fit_or_selection=True,new_confirmation_performed=False)
    if rule_path.exists():
        earlier=cp.load(rule_path)
        assert earlier["selected"]==selected,"The DEV rule has changed; inspect new inputs explicitly"
        lock=earlier
    else:cp.save(rule_path,lock)
    out=dict(status="single normalization explanation checked",score=protocol["score"],
        configurations=configs,selected=selected,development_panels={},observed_pilot={},
        rule_lock_sha256=cp.sha(rule_path),new_confirmation_performed=False,
        primary_method=METHOD,original_proxy_failure_preserved=True)
    for role,rows in rr.items():
        out["development_panels"][role]=dict(total=summary(rows,selected),
            people={s:summary([r for r in rows if r["source"]==s],selected) for s in ROLES[role]},
            processing={c:summary([r for r in rows if r["condition"]==c],selected) for c in CONDITIONS})
    # Descriptive old-panel application begins only after the above lock exists.
    compat=cp.load(root/"DEV_COMPARISON.json")
    controls={t:compat["methods"][f"taps{t}/{METHOD}"]["calibration"]["selected"] for t in (129,257)}
    for taps in (129,257):
        groups={}
        for source in ("OpenBMI005","OpenBMI012"):
            path=HERE/"runs/exact_pilot01"/f"{source}_taps{taps}.json.gz"
            obj=cp.load(path);assert obj["status"]=="complete"
            rows=obj["rows"]
            statgroups={}
            for name in ("registered","pressure0125","near025"):
                aa=[r["receiver"]["methods"][METHOD]["by_ridge"][str(selected["ridge"])]
                    for r in rows if sd.family(r)==name]
                statgroups[name]=dict(n=len(aa),min_distance=min(a["exact_normalized_identity_defect"] for a in aa),
                    max_distance=max(a["exact_normalized_identity_defect"] for a in aa),
                    median_template_energy=float(np.median([a["winning_template_energy"] for a in aa])),
                    median_conditional_unrestricted_RSS=float(np.median([a["conditional_unrestricted_RSS"] for a in aa])))
            groups[source]=dict(exact_DEV_rule=summary(rows,selected),
                compatibility_DEV_rule=sd.summary(rows,METHOD,controls[taps]),statistics=statgroups)
        out["observed_pilot"][str(taps)]=groups
    # Keep the earlier surrogate failure as a separately named result.
    proxy_path=HERE.parent/"p191_separation_v1/energy_score_pilot/RESULT.json"
    if proxy_path.exists():
        out["prior_proxy_result_path"]=str(proxy_path)
        out["prior_proxy_result_sha256"]=cp.sha(proxy_path)
        out["prior_proxy_failure"]=cp.load(proxy_path)
    cp.save(root/"EXACT_READOUT_COMPARISON.json",out)
    report=["# Exact template-energy normalization: one explanation check","",
        "The failed proxy divides identity defect by fitted H0 improvement. This check instead uses the winning template's actual squared norm and its own conditional unrestricted residual. It changes one normalization and one conditional-reference convention, while preserving the same response estimates and actual EDF queries.","",
        "Score: `-max(0, R_top - R_U_same_winning_response) / G_top_top`. Presence .25; four fixed ridge/support choices. D_fit includes pressure negatives; D_select chooses the rule. The DEV lock was written before observing the new005/012 scalar outcomes.","",
        "|Panel|Registered correct|.0125 accepted|.025 accepted|Clean accepted|Wrong accepted|",
        "|---|---:|---:|---:|---:|---:|"]
    fmt=lambda z:[f"{z['registered']['correct']}/{z['registered']['n']}"]+[f"{z[k]['accepted']}/{z[k]['n']}" for k in ("pressure0125","near025","clean","wrong")]
    for role,panel in out["development_panels"].items():report.append("|257 exact / "+role+"|"+"|".join(fmt(panel["total"]))+"|")
    for taps in (129,257):
        for source,panel in out["observed_pilot"][str(taps)].items():
            for key in ("compatibility_DEV_rule","exact_DEV_rule"):
                report.append(f"|{taps} / {source} / {key}|"+"|".join(fmt(panel[key]))+"|")
    report += ["","Selected DEV rule:","",json.dumps(selected,indent=2),"",
        "The 129 exact pilot rows apply the 257-trained exact rule only as a descriptive transfer diagnostic; they do not represent a separately calibrated129 exact receiver. The strong129 compatibility control uses its own equal-menu D_fit/D_select rule.","",
        "The earlier H0-gain proxy failure remains in `p191_separation_v1/energy_score_pilot/RESULT.json`; its old observed-transfer acceptance counts are preserved. This exact-normalization check cannot retrospectively overwrite them.",""]
    (root/"EXACT_READOUT_COMPARISON.md").write_text("\n".join(report),encoding="utf-8")
    # Recommend using DEV only, with compatibility preferred on exact ties.
    alternatives=[dict(name="257_candidate_compatibility",rule=controls[257],
        select=compat["methods"]["taps257/candidate_FIR_GLRT"]["panels"]["select"]["total"],tie=0),
        dict(name="257_candidate_exact",rule=selected,select=selected["select"],tie=1),
        dict(name="129_candidate_compatibility_strong_control",rule=controls[129],
        select=compat["methods"]["taps129/candidate_FIR_GLRT"]["panels"]["select"]["total"],tie=2)]
    recommended=max(alternatives,key=lambda z:(-z["select"]["all_negative_accepted"],z["select"]["registered"]["correct"],-z["tie"]))
    proposal=dict(status="candidate DEV rule proposal; full independent-confirmation protocol still required",
        based_only_on=ROLES,recommended=recommended,alternatives=alternatives,
        query_access=dict(reference_seconds=112,visible_context_seconds=48,scored_seconds=40),
        primary_endpoint="elliptic .0125 rejection with registered coverage preserved",
        constraint_endpoints=[".025 acceptance","clean acceptance","wrong-source acceptance","other processing registered coverage"],
        rule_lock_sha256=cp.sha(rule_path),new_person_scoring_performed=False,
        preserves_P190_raw_results=True,
        next_step="Freeze people, models, baselines, endpoints and participant-level inference before fresh-person scoring")
    cp.save(root/"DEV_RULE_PROPOSAL.json",proposal)
    print(json.dumps(dict(selected=selected,recommended=recommended["name"],development=out["development_panels"])),flush=True)


if __name__=="__main__":main()
