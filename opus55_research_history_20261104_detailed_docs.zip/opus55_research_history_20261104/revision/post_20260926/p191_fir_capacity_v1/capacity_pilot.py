"""Observed-record FIR capacity diagnostic. Original receivers remain untouched."""
from pathlib import Path
import os
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
P190 = HERE.parent / "p190_experiment_v1"
sys.dont_write_bytecode = True
for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[key] = "1"
for key in ("TEMP", "TMP", "TMPDIR", "MPLCONFIGDIR", "NUMBA_CACHE_DIR", "TORCH_HOME", "_MNE_FAKE_HOME_DIR"):
    folder = HERE / "cache" / key.lower()
    folder.mkdir(parents=True, exist_ok=True)
    os.environ[key] = str(folder)
sys.path[:0] = [str(ROOT), str(HERE.parent / "p188_glrt_v1")]

import argparse
import gzip
import hashlib
import json
import time
import numpy as np
from scipy.signal import fftconvolve
from numpy.lib.stride_tricks import sliding_window_view
from threadpoolctl import threadpool_limits
import receiver_api as api
from revision.post_20260926 import p178_fir_prototype as proto
from revision.post_20260926 import run_p181_data as edf
from revision.post_20260926 import p181_common as common

CHANNELS = ("FC3", "FC4", "C3", "C4", "Cz", "CP3", "CP4", "Pz")
RIDGES = api.RIDGES
THRESHOLD = .9957274054693162
PRESSURE_THRESHOLD = .9987280466974421


def load(path):
    raw = Path(path).read_bytes()
    return json.loads(gzip.decompress(raw) if str(path).endswith(".gz") else raw)


def save(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".partial")
    raw = (json.dumps(obj, ensure_ascii=False, allow_nan=False, separators=(",", ":")) + "\n").encode()
    if str(path).endswith(".gz"):
        raw = gzip.compress(raw, compresslevel=5, mtime=0)
    tmp.write_bytes(raw)
    tmp.replace(path)


def read_edf(path):
    return edf.parse_edf(gzip.decompress(Path(path).read_bytes()), CHANNELS)[0]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def summarize_stats(stats, clean_rss, folds):
    # Preserve the exact P188/P190 candidate-conditional score convention.
    pooled = [tuple(sum(row[i][j] for row in stats) for j in range(3)) for i in range(8)]
    rss, full, gains, betas = [], [], [], []
    for i, (G, b, d) in enumerate(pooled):
        beta = np.linalg.lstsq(G, b, rcond=1e-7)[0]
        rss.append(max(0., float(d + G[i, i] - 2 * b[i])))
        full.append(max(0., float(d - b @ beta)))
        gains.append(float(2 * b[i] - G[i, i]))
        betas.append(beta)
    order = np.argsort(rss, kind="stable")
    top = int(order[0])
    R, R2 = rss[top], rss[order[1]]
    RU = min(full)
    scale = max(sum(t[2] for t in pooled), sum(np.trace(t[0]) for t in pooled), 1e-30)
    floor = 64 * np.finfo(float).eps * scale
    compatibility = 1. if R <= floor else RU / R
    presence = 1. - R / max(sum(clean_rss), floor)
    gap = (R2 - R) / max(R2, floor)
    windowrss = [[max(0., float(d + G[i, i] - 2 * b[i])) for i, (G, b, d) in enumerate(row)]
                 for row in stats]
    support = int((np.argmin(windowrss, axis=1) == top).sum())
    eligible = bool(gains[top] > 0 and np.median([f["peak"] for f in folds]) >= 0)
    return dict(top=top, compatibility=float(np.clip(compatibility, 0, 1)),
                relative_gap=float(np.clip(gap, 0, 1)), presence=float(np.clip(presence, 0, 1)),
                support=support, eligible=eligible, candidate_RSS=rss, unrestricted_RSS=RU,
                clean_RSS=float(sum(clean_rss)), beta=betas[top].tolist(),
                fold_RSS=windowrss, top_held_RSS=R, second_held_RSS=R2,
                beta_distance_to_top=float(np.linalg.norm(betas[top] - np.eye(8)[top])))


def decision(value, threshold=THRESHOLD):
    return value["top"] if (value["eligible"] and value["support"] >= 1
        and value["presence"] >= .25 and value["compatibility"] >= threshold) else -1


class CapacityReceiver(api.MatchedFIRReceivers):
    def __init__(self, x, book, taps):
        assert taps in (129, 257, 513)
        super().__init__(x, book)
        self.taps = taps
        self.half = (taps - 1) // 2
        self.design_seconds = 0.
        self.conditioning = {}

    def design(self, k):
        if k in self.candidate:
            return self.receiver.designs[k], self.candidate[k]
        started = time.monotonic()
        books = np.asarray([api.c.r.common.transform(b, api.old.BANK[k]) for b in self.receiver.book])
        # The only increased context is in owner-held 112-s references.
        data = proto.design(self.receiver.refs[k], books, half=self.half)
        ws, cw = data["windows"], []
        for z in ws:
            G = sum(q["xx"] for q in ws if q is not z)
            z["inverse"] = {(ridge, False): api._inv(G, ridge) for ridge in RIDGES}
            xx, xt = [], []
            for identity in range(8):
                DX = sliding_window_view(z["ext"][identity], self.taps, axis=-1) / data["scale"]
                DX = DX - DX.mean(axis=1, keepdims=True)
                XX = z["X"] + DX.reshape(-1, self.taps)
                xx.append(XX.T @ XX)
                xt.append(XX.T @ z["T"][:, identity])
            cw.append(dict(xx=np.asarray(xx), xt=np.asarray(xt)))
        conditioning = []
        for w, z in enumerate(cw):
            G = sum(cw[j]["xx"] for j in range(5) if j != w)
            cleanG = sum(ws[j]["xx"] for j in range(5) if j != w)
            absolute_scale = np.trace(cleanG) / len(cleanG)
            z["inverse"] = {ridge: np.asarray([api._inv(g, ridge, absolute_scale) for g in G])
                            for ridge in RIDGES}
            eigenvalues = np.linalg.eigvalsh((G + G.transpose(0, 2, 1)) / 2)
            for ridge in RIDGES:
                regularized = eigenvalues + ridge * absolute_scale
                conditioning.append(dict(fold=w, ridge=ridge,
                    condition_min=float(np.min(regularized[:, -1] / regularized[:, 0])),
                    condition_max=float(np.max(regularized[:, -1] / regularized[:, 0])),
                    min_regularized_eigenvalue=float(np.min(regularized[:, 0])),
                    max_regularized_eigenvalue=float(np.max(regularized[:, -1])),
                    absolute_ridge=float(ridge * absolute_scale)))
        elapsed = time.monotonic() - started
        self.design_seconds += elapsed
        self.conditioning[k] = dict(taps=self.taps, seconds=elapsed, folds=conditioning)
        self.receiver.designs[k], self.candidate[k] = data, cw
        print(json.dumps(dict(event="design_ready", taps=self.taps, model=k, seconds=elapsed)), flush=True)
        return data, cw

    def _stats(self, z, data, yy, kernel):
        reference = z["x"] + (z["X"] @ kernel).reshape(8, 1280) * data["scale"]
        delta = z["ext"][:, :, self.half:self.half + 1280] + fftconvolve(
            z["ext"], kernel[None, None, ::-1], mode="valid", axes=-1)
        T = np.column_stack([api.old.vector(a) for a in delta]) / data["scale"]
        v = api.old.vector(yy - reference) / data["scale"]
        return T.T @ T, T.T @ v, float(v @ v)

    def extract_candidate(self, y):
        started = time.monotonic()
        design_start = self.design_seconds
        _, lags, peaks, errors = api.old.blind_match(self.receiver.refs, y)
        chosen = np.asarray([np.argmin(np.sum(errors[:, [j for j in range(5) if j != w]], axis=1))
                             for w in range(5)])
        # Unchanged five 9.6-s query contexts, 48 s in total. No query FIR context extension.
        buffers = [api.p.filt(api.p.center(y[:, st*160-128:(st+8)*160+128])) for st in api.p.STARTS]
        prep, folds = {}, []
        stats, nulls = {r: [] for r in RIDGES}, {r: [] for r in RIDGES}
        for w in range(5):
            ids = [j for j in range(5) if j != w]
            k = int(chosen[w])
            delay = api.recv.lower_median(lags[k, ids])
            key = k, delay
            if key not in prep:
                data, cw = self.design(k)
                ys = [buf[:, 128+delay:1408+delay] for buf in buffers]
                _, bx, _, cb = self._prepare(data, ys, cw)
                prep[key] = data, cw, ys, bx, cb
            data, cw, ys, bx, cb = prep[key]
            z = data["windows"][w]
            BB, CB = sum(bx[j] for j in ids), sum(cb[j] for j in ids)
            folds.append(dict(model=k, delay=delay, peak=float(peaks[k, w])))
            for ridge in RIDGES:
                ho = z["inverse"][ridge, False] @ BB
                hc = np.einsum("nij,nj->ni", cw[w]["inverse"][ridge], CB)
                stats[ridge].append([self._stats(z, data, ys[w], h) for h in hc])
                nulls[ridge].append(self._stats(z, data, ys[w], ho)[2])
        out = {}
        for ridge in RIDGES:
            value = summarize_stats(stats[ridge], nulls[ridge], folds)
            value["legacy_threshold_decision"] = decision(value)
            value["pressure_control_threshold_decision"] = decision(value, PRESSURE_THRESHOLD)
            out[str(ridge)] = value
        elapsed = time.monotonic() - started
        return dict(by_ridge=out, folds=folds, seconds=elapsed,
                    new_design_seconds=self.design_seconds-design_start,
                    extraction_seconds_excluding_new_design=elapsed-(self.design_seconds-design_start),
                    response_fits_per_ridge=45, candidate_response_fits_per_ridge=40)


def family(meta):
    if meta["kind"] == "enrolled":
        return "registered"
    return "pressure0125" if meta.get("angle") == .0125 else "near025"


def summarize(rows):
    result = {}
    for ridge in RIDGES:
        zz = {}
        for name in ("registered", "pressure0125", "near025"):
            rr = [r for r in rows if family(r["metadata"]) == name]
            vv = [r["features"]["by_ridge"][str(ridge)] for r in rr]
            scores = [v["compatibility"] for v in vv]
            zz[name] = dict(n=len(rr), accepted=sum(v["legacy_threshold_decision"] >= 0 for v in vv),
                correct=sum(v["legacy_threshold_decision"] == r["metadata"]["identity"] for r,v in zip(rr,vv)) if name=="registered" else None,
                accepted_at_pressure_threshold=sum(v["pressure_control_threshold_decision"] >= 0 for v in vv),
                min_score=min(scores), max_score=max(scores), mean_score=float(np.mean(scores)),
                mean_top_held_RSS=float(np.mean([v["top_held_RSS"] for v in vv])),
                mean_unrestricted_RSS=float(np.mean([v["unrestricted_RSS"] for v in vv])),
                mean_clean_RSS=float(np.mean([v["clean_RSS"] for v in vv])))
        zz["registered_minus_pressure_score_gap"] = zz["registered"]["min_score"] - zz["pressure0125"]["max_score"]
        zz["registered_minus_near025_score_gap"] = zz["registered"]["min_score"] - zz["near025"]["max_score"]
        result[str(ridge)] = zz
    return result


def run(source, taps, label, parity_only=False):
    dest = HERE / "runs" / label / f"{source}_taps{taps}.json.gz"
    if dest.exists() and not parity_only:
        result = load(dest)
        if result.get("status") == "complete":
            return result
    x = read_edf(P190 / "sources" / source / "clean.edf.gz")
    folder = P190 / "issuance" / source / "level100"
    issue = load(folder / "issuance_summary.json")
    meta = issue["metadata"]["smooth"]
    raw_path = P190 / "raw" / "confirm" / source / "level100" / "smooth.json.gz"
    raw = load(raw_path)
    condition = "elliptic_new_causal"
    limits = tuple(np.asarray(v) for v in raw["query_limits_uv"][condition])
    indices = [i for i,m in enumerate(meta) if m["kind"] == "enrolled" or m.get("angle") in (.0125,.025)]
    assert len(indices) == 32
    if parity_only:
        assert taps == 129
        indices = indices[:1]
    copies = {i:read_edf(folder / f"smooth_r{i}_issued.edf.gz") for i in indices}
    book = np.asarray([copies[i] for i in range(8)]) if len(copies) >= 8 else np.asarray([
        read_edf(folder / f"smooth_r{i}_issued.edf.gz") for i in range(8)])
    receiver = CapacityReceiver(x, book, taps)
    rows, receipts, parity_error = [], [], 0.
    started = time.monotonic()
    for index in indices:
        query, _ = edf.edf_roundtrip(common.transform(copies[index], condition), limits,
            f"{source}_level100_smooth_q{index}_{condition}.edf", dest.parent, receipts, False, CHANNELS)
        previous = next(r for r in raw["rows"] if r["query_index"] == index and r["condition"] == condition)
        assert previous["query_raw_sha256"] == receipts[-1]["raw_sha256"], "Original P190 query bytes differ"
        features = receiver.extract_candidate(query)
        if taps == 129:
            for ridge in RIDGES:
                old = previous["receiver"]["methods"]["candidate_FIR_GLRT"]["by_ridge"][str(ridge)]
                new = features["by_ridge"][str(ridge)]
                for key in ("compatibility","presence","relative_gap"):
                    err = abs(new[key] - old[key])
                    parity_error = max(parity_error, err)
                    assert err < 1e-10, (source,index,ridge,key,err)
                assert new["top"] == old["top"] and new["support"] == old["support"]
        rows.append(dict(query_index=index, metadata=meta[index], features=features,
                         query_raw_sha256=receipts[-1]["raw_sha256"]))
        result = dict(status="running", role="observed_P190_FIR_capacity_development", source=source,
            taps=taps, condition=condition, ridges=RIDGES, rows=rows,
            parity_score_max_abs_error=parity_error, conditioning=receiver.conditioning,
            seconds=time.monotonic()-started, code_sha256=sha(__file__), inputs=dict(
                P190_raw_sha256=sha(raw_path), issuance_sha256=sha(folder/"issuance_summary.json")),
            budgets_unchanged=True, query_context_seconds=48, scored_query_seconds=40,
            owner_reference_seconds=112, query_context_not_extended=True,
            no_unobserved_confirmation_used=True,
            threshold_interpretation="Historical thresholds replayed descriptively; no new calibration on these observed records")
        save(dest if not parity_only else HERE/"runs"/label/"PARITY_129.json.gz", result)
        print(json.dumps(dict(event="query", source=source,taps=taps,index=index,n=len(rows),
            seconds=features["seconds"],summary=features["by_ridge"]["1e-06"]["compatibility"])), flush=True)
    result["status"] = "parity_complete" if parity_only else "complete"
    if not parity_only:
        result["summary"] = summarize(rows)
    save(dest if not parity_only else HERE/"runs"/label/"PARITY_129.json.gz", result)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--sources", default="OpenBMI005,OpenBMI012")
    parser.add_argument("--taps", default="129,257,513")
    parser.add_argument("--label", default="pilot01")
    parser.add_argument("--parity-only", action="store_true")
    args = parser.parse_args()
    groups = []
    with threadpool_limits(limits=1):
        if args.parity_only:
            result = run(args.sources.split(",")[0], 129, args.label, True)
            print(json.dumps(dict(event="parity_complete",max_error=result["parity_score_max_abs_error"])),flush=True)
            return
        parity = HERE/"runs"/args.label/"PARITY_129.json.gz"
        assert parity.exists() and load(parity)["status"] == "parity_complete", "Run 129 parity first"
        for source in args.sources.split(","):
            for taps in map(int,args.taps.split(",")):
                result = run(source,taps,args.label)
                groups.append(dict(source=source,taps=taps,summary=result["summary"],
                    seconds=result["seconds"],conditioning=result["conditioning"],
                    parity_score_max_abs_error=result["parity_score_max_abs_error"]))
                save(HERE/"runs"/args.label/"SUMMARY.json",dict(status="running",groups=groups))
                print(json.dumps(dict(event="group_complete",source=source,taps=taps,summary=result["summary"])),flush=True)
    save(HERE/"runs"/args.label/"SUMMARY.json",dict(status="complete",groups=groups,
        new_deployment_policy_selected=False,no_unobserved_confirmation_used=True))


if __name__ == "__main__":
    main()
