"""Development mechanism screen; reference-informed oracle processing, not security proof."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
import csv
import hashlib
import json
from pathlib import Path
import mne
import numpy as np
from revision.lightweight_qc_validation.storage import encode_integer_storage, decode_integer_storage

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OUT = HERE / 'p6_fingerprint_pilot_v1'
DATA = ROOT / 'datasets/physionet_eegbci/MNE-eegbci-data/files/eegmmidb/1.0.0'

def basis(n, low, high):
    t = np.arange(n)
    columns = []
    for k in range(1, (n - 1)//2 + 1):
        if low <= k * 160 / n <= high:
            columns.extend([np.cos(2*np.pi*k*t/n), np.sin(2*np.pi*k*t/n)])
    return np.array(columns).T * np.sqrt(2/n)

def templates(x, b, seed):
    rng = np.random.default_rng(seed)
    g = rng.normal(size=(16, x.shape[0], b.shape[1]))
    g -= g.mean(axis=1, keepdims=True)
    e = g @ b.T
    rms = np.sqrt(np.mean((x-x.mean(axis=1,keepdims=True))**2, axis=1))
    if np.min(rms) <= 0: raise ValueError('flat input')
    ratio = np.sqrt(np.mean(e**2,axis=2)) / rms[None,:]
    e *= (.005 / ratio.max(axis=1))[:,None,None]
    return e

def transform(x, name):
    if name == 'car': return x-x.mean(axis=-2,keepdims=True)
    if name == 'crop_half': return x[...,x.shape[-1]//4:3*x.shape[-1]//4]
    if name.startswith('band'):
        lo,hi = (1,40) if name=='band1_40' else (8,30)
        f=np.fft.rfftfreq(x.shape[-1],1/160)
        z=np.fft.rfft(x,axis=-1);z[...,~((f>=lo)&(f<=hi))]=0
        return np.fft.irfft(z,n=x.shape[-1],axis=-1)
    return x

def identify(residual, ts):
    a=ts.reshape(16,-1);r=residual.ravel()
    denom=np.linalg.norm(a,axis=1)*np.linalg.norm(r)
    scores=np.divide(a@r,denom,out=np.zeros(16),where=denom>1e-30)
    order=np.argsort(scores)
    return int(order[-1]) if scores[order[-1]]>=.25 and scores[order[-1]]-scores[order[-2]]>=.10 else -1

def q16(x):
    return decode_integer_storage(*encode_integer_storage(x,16))

def main():
    OUT.mkdir(exist_ok=True)
    if (OUT/'summary.json').exists(): raise RuntimeError('completed output exists; do not overwrite')
    rows=[]; manifest={}
    for subject in range(19,31):
        p=DATA/f'S{subject:03d}'/f'S{subject:03d}R04.edf'
        manifest[str(p.relative_to(ROOT))]=hashlib.sha256(p.read_bytes()).hexdigest()
        raw=mne.io.read_raw_edf(p,preload=True,verbose='ERROR')
        data=raw.get_data(picks='eeg')
        ann=next(a for a in raw.annotations if a['description'] in ('T1','T2'))
        start=round((float(ann['onset'])+.5)*160)
        for seconds in (1,2,4,8):
            x=data[:,start:start+seconds*160]
            assert x.shape==(64,seconds*160)
            xc=x-x.mean(axis=1,keepdims=True); gram=xc@xc.T
            for low,high in ((8,30),(30,40)):
                b=basis(x.shape[1],low,high)
                _,s,vh=np.linalg.svd(x@b,full_matrices=True)
                rank=int(np.sum(s>s[0]*max(x.shape[0],b.shape[1])*np.finfo(float).eps))
                null=b@vh[rank:].T
                for arm,bb in (('band_ss',b),('cov_null',null)):
                    base=dict(subject=subject,seconds=seconds,band=f'{low}-{high}',arm=arm,dim=bb.shape[1],rank=rank)
                    if bb.shape[1]==0:
                        rows.append(dict(base,status='infeasible'));continue
                    es=templates(x,bb,20261004)
                    foreign=templates(x,bb,991)
                    cross=max(np.linalg.norm(x@e.T)/max(np.linalg.norm(x)*np.linalg.norm(e),1e-30) for e in es)
                    for attack in ('clean','car','band1_40','band8_30','crop_half'):
                        ts=transform(es,attack); ref=transform(x,attack)
                        decisions=[identify(transform(q16(x+e),attack)-ref,ts) for e in es]
                        negatives=[identify(transform(q16(x),attack)-ref,ts)]
                        negatives += [identify(transform(q16(x+e),attack)-ref,ts) for e in foreign]
                        cov=[];prd=[]
                        for e in es:
                            y=q16(x+e);yc=y-y.mean(axis=1,keepdims=True)
                            cov.append(np.linalg.norm(yc@yc.T-gram)/np.linalg.norm(gram))
                            prd.append(100*np.max(np.linalg.norm(y-x,axis=1)/np.linalg.norm(xc,axis=1)))
                        rows.append(dict(base,status='ok',attack=attack,correct=sum(d==i for i,d in enumerate(decisions)),wrong=sum(d>=0 and d!=i for i,d in enumerate(decisions)),abstain=decisions.count(-1),negative_accept=sum(d>=0 for d in negatives),negative_n=len(negatives),cov_rel_mean=float(np.mean(cov)),max_channel_ac_prd_pct=max(prd),normalized_cross=cross))
        print(f'S{subject:03d} done',flush=True)
    fields=list(dict.fromkeys(k for row in rows for k in row))
    with (OUT/'cases.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fields);w.writeheader();w.writerows(rows)
    groups=[]
    for seconds in (1,2,4,8):
        for band in ('8-30','30-40'):
            for arm in ('band_ss','cov_null'):
                for attack in ('clean','car','band1_40','band8_30','crop_half'):
                    rr=[r for r in rows if r['seconds']==seconds and r['band']==band and r['arm']==arm and r.get('attack')==attack]
                    if rr: groups.append(dict(seconds=seconds,band=band,arm=arm,attack=attack,windows=len(rr),dim_min=min(r['dim'] for r in rr),correct=sum(r['correct'] for r in rr),n=16*len(rr),wrong=sum(r['wrong'] for r in rr),negative_accept=sum(r['negative_accept'] for r in rr),negative_n=sum(r['negative_n'] for r in rr),cov_rel_median=float(np.median([r['cov_rel_mean'] for r in rr])),max_channel_ac_prd_pct=max(r['max_channel_ac_prd_pct'] for r in rr)))
    for p in (Path(__file__),HERE/'P6_FINGERPRINT_PILOT_PROTOCOL.md'):
        manifest[str(p.relative_to(ROOT))]=hashlib.sha256(p.read_bytes()).hexdigest()
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    (OUT/'summary.json').write_text(json.dumps(dict(groups=groups,infeasible=[r for r in rows if r['status']=='infeasible']),indent=2),encoding='utf-8')

if __name__=='__main__': main()
