"""Strict leave-one-window-out common alignment and profiled FIR response."""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import hashlib
import numpy as np
from scipy.signal import fftconvolve
from revision.post_20260926 import p180_common as c
r=c.r;p=c.p

def lower_median(values):return int(np.sort(np.asarray(values,dtype=int))[(len(values)-1)//2])

def delay_candidates(values):
    center=lower_median(values)
    return list(dict.fromkeys(int(np.clip(center+offset,-128,128)) for offset in (0,-1,1)))

class Receiver(r.Receiver):
    def design(self,k):
        data=super().design(k)
        if 'profile' not in data:
            ws=data['windows'];data['profile']=[]
            for w,z in enumerate(ws):
                ids=[j for j in range(5) if j!=w];TT=sum(ws[j]['tt'] for j in ids)
                data['profile'].append(np.linalg.pinv(TT,rcond=1e-9))
        return data

    def extract(self,y,h,h0,return_nuisance=False):
        legacy_chosen,lags,peaks,errors=r.old.blind_match(self.refs,y)
        chosen=np.array([np.argmin(np.sum(errors[:,[j for j in range(5) if j!=w]],axis=1)) for w in range(5)])
        buffers=[p.filt(p.center(y[:,st*160-128:(st+8)*160+128])) for st in p.STARTS]
        prepared={};fitted={};out={};diags={};nuisances={}

        def prepare(k,alignment):
            align=tuple(int(v) for v in alignment);key=(k,align)
            if key in prepared:return prepared[key]
            data=self.design(k);ys=[buf[:,128+align[j]:128+align[j]+1280] for j,buf in enumerate(buffers)]
            vs=[r.old.vector(yy-z['x'])/data['scale'] for yy,z in zip(ys,data['windows'])]
            result=(data,ys,[z['X'].T@v for z,v in zip(data['windows'],vs)],[z['T'].T@v for z,v in zip(data['windows'],vs)],[float(v@v) for v in vs],[float(np.sum((r.old.vector(yy)/data['scale'])**2)) for yy in ys])
            prepared[key]=result;return result

        def fit(k,w,alignment):
            key=(k,w,tuple(alignment))
            if key in fitted:return fitted[key]
            data,ys,bx,bt,vv,energy=prepare(k,alignment);z=data['windows'][w];ids=[j for j in range(5) if j!=w]
            bts=sum(bt[j] for j in ids);b=sum(bx[j] for j in ids)-z['CT']@bts
            kernels={ridge:z['inverse'][ridge,True]@b for ridge in (1e-4,1e-6)}
            projected_energy=sum(vv[j] for j in ids)-float(bts@data['profile'][w]@bts)
            objective=max(0.,projected_energy-float(b@kernels[1e-6]))/max(sum(energy[j] for j in ids),1e-40)
            result=(data,ys,kernels,float(objective));fitted[key]=result;return result

        for mode in c.MODES:
            windows=[];diagnostic=[];params=[]
            for w in range(5):
                ids=[j for j in range(5) if j!=w];k=int(legacy_chosen[w] if mode in ('legacy','median5') else chosen[w])
                candidates=[];objectives=[]
                if mode=='legacy':alignment=lags[k].tolist()
                elif mode=='median5':alignment=[int(np.rint(np.median(lags[k]))) ]*5
                elif mode=='median4':alignment=[lower_median(lags[k,ids])]*5
                else:
                    candidates=delay_candidates(lags[k,ids]);objectives=[fit(k,w,[delay]*5)[3] for delay in candidates]
                    alignment=[candidates[int(np.argmin(objectives))]]*5
                data,ys,kernels,objective=fit(k,w,alignment);z=data['windows'][w];yy=ys[w];half=data['half'];features=[];residual=None
                for ridge in (1e-4,1e-6):
                    kernel=kernels[ridge];reference=z['x']+(z['X']@kernel).reshape(8,1280)*data['scale']
                    delta=z['ext'][:,:,half:half+1280]+fftconvolve(z['ext'],kernel[None,None,::-1],mode='valid',axes=-1);book=reference[None]+delta
                    if ridge==1e-4:features.append(r.phase_solve(yy,reference,book,h,h0))
                    else:
                        T=np.column_stack([r.old.vector(v-reference) for v in book]);v=r.old.vector(yy-reference);norm=max(float(np.sum(T*T)),1e-40)
                        features.append(r.r.solve(T.T@T/norm,T.T@v/norm,float(v@v)/norm))
                        features.append(r.r.solve(*r.r.sufficient(yy,reference,'spatial',h,h0,p.build_cache(reference,book,'spatial'))))
                        beta=np.linalg.lstsq(T,v,rcond=1e-8)[0];residual=float(np.linalg.norm(v-T@beta)/max(np.linalg.norm(r.old.vector(yy)),1e-30))
                windows.append(features)
                diagnostic.append(dict(model=k,delay=int(alignment[w]),train_alignment=[int(alignment[j]) for j in ids],candidates=candidates,objectives=objectives,selected_objective=objective,response_residual=residual,kernel_sha256=[hashlib.sha256(kernels[ridge].tobytes()).hexdigest() for ridge in (1e-4,1e-6)]))
                if return_nuisance:params.append(dict(model=k,delay=int(alignment[w]),candidates=candidates,kernels=kernels))
            out[mode]={key:np.asarray([[windows[w][ro][j] for w in range(5)] for ro in range(3)]) for j,key in enumerate(r.KEYS)}
            diags[mode]=diagnostic
            if return_nuisance:nuisances[mode]=params
        diag=dict(modes=diags,preliminary_delays=lags.tolist(),preliminary_models=legacy_chosen.tolist(),matching_errors=errors.tolist())
        return (out,diag,nuisances) if return_nuisance else (out,diag)
