"""Fixed-rule angle-distance mechanism scan on two already observed people."""
from pathlib import Path
import os,sys
HERE=Path(__file__).resolve().parent
BASE=HERE.parent
ROOT=HERE.parents[2]
sys.dont_write_bytecode=True
for name in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS"):
    os.environ[name]="1"
sys.path[:0]=[str(ROOT),str(BASE/"p191_fir_capacity_v1"),str(BASE/"p186_five_arm_bridge_v1"),str(BASE/"p188_neighbors_qim_v1")]
import argparse,gzip,hashlib,json,time
import numpy as np
from threadpoolctl import threadpool_limits
import capacity_pilot as cp
from dev_capacity import DevelopmentReceiver
import calibrate_allarms as rules_api
import checkpoint_io
import phase_geometry
from continuation_api import frozen_backend
for name in ("TEMP","TMP","TMPDIR","MPLCONFIGDIR","NUMBA_CACHE_DIR","TORCH_HOME","_MNE_FAKE_HOME_DIR"):
    p=HERE/"cache"/name.lower();p.mkdir(parents=True,exist_ok=True);os.environ[name]=str(p)

ANGLES=(0.,.003125,.00625,.0125,.025,.05)
SOURCES=("OpenBMI005","OpenBMI012")
CONDITION="elliptic_new_causal"
FREEZE=BASE/"p191_confirmation_v1/CONFIRMATION_FREEZE.json"
RULEFILE=BASE/"p191_fir_capacity_v1/ALLARM_DEV_RULES.json"


def save(path,obj):checkpoint_io.save(path,obj)
def label(theta):return f"theta{round(theta*1000000):06d}"
def scored(x):return np.concatenate([x[:,s*160:(s+8)*160] for s in cp.api.p.STARTS],axis=1)


def distances(value,parent,clean,limits):
    out={};lsb=(np.asarray(limits[1])-np.asarray(limits[0]))[:,None]*1e-6/65535
    for view,a,b,c in (("full112",value,parent,clean),("score40",scored(value),scored(parent),scored(clean))):
        change=np.rint((a-b)/lsb)
        fp0=(b-c).ravel();fp1=(a-c).ravel()
        norms=np.linalg.norm(fp0)*np.linalg.norm(fp1)
        angle=float(np.arccos(np.clip(fp0@fp1/max(norms,1e-300),-1,1))) if norms else None
        out[view]=dict(parent_changed_fraction=float(np.mean(change!=0)),parent_rms_difference_lsb=float(np.sqrt(np.mean(change**2))),
            parent_rms_difference_v=float(np.sqrt(np.mean((a-b)**2))),
            parent_relative_fingerprint_L2=float(np.linalg.norm(fp1-fp0)/max(np.linalg.norm(fp0),1e-300)),
            fingerprint_angle_radians=angle,exact_parent_samples_equal=bool(np.array_equal(a,b)))
    return out


def decide(feature,rule):
    # The inherited live receiver uses float keys; its saved JSON uses strings.
    # Canonicalize this representation locally, without changing frozen code.
    for method in feature["methods"].values():
        method["by_ridge"]={str(k):v for k,v in method["by_ridge"].items()}
    value,eligible,top=rules_api.score(dict(receiver=feature),"candidate_FIR_GLRT",rule)
    return int(top) if eligible and value>=rule["threshold"] else -1


def run(source,protocol):
    dest=HERE/"runs/pilot01"/(source+".json.gz")
    dest.parent.mkdir(parents=True,exist_ok=True)
    (HERE/"received"/source).mkdir(parents=True,exist_ok=True)
    (HERE/"issuance"/source).mkdir(parents=True,exist_ok=True)
    before=cp.load(dest) if dest.exists() else None
    if before and before["status"]=="complete":return before
    folder=cp.P190/"issuance"/source/"level100"
    issue=cp.load(folder/"issuance_summary.json")
    x=cp.read_edf(cp.P190/"sources"/source/"clean.edf.gz")
    limits=tuple(np.asarray(a) for a in cp.load(cp.P190/"sources"/source/"source.json")["limits_uv"])
    oldraw=cp.load(cp.P190/"raw/confirm"/source/"level100/smooth.json.gz")
    qlimits=tuple(np.asarray(a) for a in oldraw["query_limits_uv"][CONDITION])
    book=np.asarray([cp.read_edf(folder/f"smooth_r{i}_issued.edf.gz") for i in range(8)])
    cached={t:cp.load(BASE/"p191_fir_capacity_v1/runs/exact_pilot01"/f"{source}_taps{t}.json.gz") for t in (129,257)}
    codes,metadata=phase_geometry.original_p181_pool()
    m,_=frozen_backend(HERE/"backend"/source)
    rec129=cp.api.MatchedFIRReceivers(x,book)
    rec257=DevelopmentReceiver(x,book,257)
    rows=before["rows"] if before else []
    done={(r["parent"],r["theta"]) for r in rows}
    receipts=[];started=time.monotonic()
    for parent in range(8):
        idx025=next(i for i,z in enumerate(metadata) if z.get("parent")==parent and z.get("angle")==.025 and z.get("direction")==0)
        tangent=(codes[idx025]-np.cos(.025)*codes[parent])/np.sin(.025)
        assert abs(tangent@codes[parent])<1e-10 and abs(np.linalg.norm(tangent)-1)<1e-10
        paired_clean,_=cp.edf.edf_roundtrip(cp.common.transform(x,CONDITION),qlimits,
            f"{source}_clean_{CONDITION}.edf",HERE/"received"/source,receipts,False,cp.CHANNELS)
        parent_query,_=cp.edf.edf_roundtrip(cp.common.transform(book[parent],CONDITION),qlimits,
            f"{source}_level100_smooth_q{parent}_{CONDITION}.edf",HERE/"received"/source,receipts,False,cp.CHANNELS)
        for theta in ANGLES:
            if (parent,theta) in done:continue
            existing=(parent if theta==0 else next((i for i,z in enumerate(metadata)
                if z.get("parent")==parent and z.get("angle")==theta and z.get("direction")==0),None))
            match_history=[];details=None
            if existing is not None:
                issued=cp.read_edf(folder/f"smooth_r{existing}_issued.edf.gz")
                issuepath=folder/f"smooth_r{existing}_issued.edf.gz"
                reuse="original_P190_actual_EDF_and_saved_conditional_features"
            else:
                code=np.cos(theta)*codes[parent]+np.sin(theta)*tangent
                answer,match_history=m.match_down(x,code,"smooth",issue["QID_anchors"][parent],limits)
                issuepath=HERE/"issuance"/source/f"smooth_p{parent}_{label(theta)}.edf.gz"
                if answer is None:
                    rows.append(dict(source=source,parent=parent,theta=theta,feasible=False,matching_history=match_history))
                    save(dest,dict(status="running",rows=rows,source=source,protocol=protocol));continue
                ideal,details=answer
                issued,_=cp.edf.edf_roundtrip(ideal,limits,issuepath.name[:-3],issuepath.parent,receipts,True,cp.CHANNELS)
                reuse=None
            quality=m.p.quality(x,issued);target=issue["QID_anchors"][parent]
            assert target/1.001<=quality["global_ac_prd"]<=target
            assert quality["global_ac_prd"]<=.25 and quality["max_channel_ac_prd"]<=.5 and quality["band_prd"]<=1.
            queryname=(f"{source}_level100_smooth_q{existing}_{CONDITION}.edf" if existing is not None
                else f"{source}_smooth_p{parent}_{label(theta)}_{CONDITION}.edf")
            query,_=cp.edf.edf_roundtrip(cp.common.transform(issued,CONDITION),qlimits,queryname,
                HERE/"received"/source,receipts,True,cp.CHANNELS)
            queryhash=receipts[-1]["raw_sha256"]
            if existing is not None:
                old=next(r for r in oldraw["rows"] if r["query_index"]==existing and r["condition"]==CONDITION)
                assert queryhash==old["query_raw_sha256"]
                features={str(t):next(r for r in cached[t]["rows"] if r["query_index"]==existing)["receiver"] for t in (129,257)}
            else:features={"129":rec129.extract(query),"257":rec257.extract_all(query)}
            a=features["257"]["methods"]["candidate_FIR_GLRT"]["by_ridge"][str(protocol["exact_rule"]["ridge"])]
            decision257=decide(features["257"],protocol["exact_rule"])
            decision129=decide(features["129"],protocol["compat129_rule"])
            row=dict(source=source,parent=parent,theta=theta,condition=CONDITION,feasible=True,
                actual_quality=quality,common_anchor_percent=target,
                actual_registered_parent_PRD_percent=m.p.quality(x,book[parent])["global_ac_prd"],
                issue_gzip_sha256=cp.sha(issuepath),query_raw_sha256=queryhash,reused=reuse,
                q=a["exact_normalized_identity_defect"],Gii=a["winning_template_energy"],
                conditional_U=a["conditional_unrestricted_RSS"],top_held_RSS=a["top_held_RSS"],
                top=a["top"],presence=a["presence"],support=a["support"],
                exact257_decision=decision257,exact257_parent_attributed=decision257==parent,
                compat129_decision=decision129,compat129_parent_attributed=decision129==parent,
                issued_parent_distance=distances(issued,book[parent],x,limits),
                received_parent_distance=distances(query,parent_query,paired_clean,qlimits),
                matching_history=match_history,matching_details=details,receivers_by_order=features)
            rows.append(row)
            save(dest,dict(status="running",source=source,rows=rows,protocol=protocol,
                expected_n=48,seconds=time.monotonic()-started,EDF_receipts=receipts,code_sha256=cp.sha(__file__)))
            print(json.dumps(dict(event="angle",source=source,parent=parent,theta=theta,q=row["q"],
                exact257=decision257,compat129=decision129,n=len(rows))),flush=True)
    result=cp.load(dest);result["status"]="complete";save(dest,result);return result


def summarize(groups,protocol):
    table=[];fits=[]
    for g in groups:
        for theta in ANGLES:
            rr=[r for r in g["rows"] if r["theta"]==theta and r["feasible"]]
            table.append(dict(source=g["source"],theta=theta,n=len(rr),
                exact257_accept=sum(r["exact257_decision"]>=0 for r in rr),
                exact257_parent_attributed=sum(r["exact257_parent_attributed"] for r in rr),
                compat129_accept=sum(r["compat129_decision"]>=0 for r in rr),
                q_min=min(r["q"] for r in rr),q_median=float(np.median([r["q"] for r in rr])),q_max=max(r["q"] for r in rr),
                issued_relative_distance_median=float(np.median([r["issued_parent_distance"]["score40"]["parent_relative_fingerprint_L2"] for r in rr]))))
        for parent in range(8):
            rr=sorted([r for r in g["rows"] if r["parent"]==parent and r["feasible"]],key=lambda r:r["theta"])
            theta=np.asarray([r["theta"] for r in rr]);q=np.asarray([r["q"] for r in rr])
            X=np.column_stack([np.ones(len(rr)),theta**2]);beta=np.linalg.lstsq(X,q,rcond=None)[0]
            residual=q-X@beta;total=q-q.mean()
            fits.append(dict(source=g["source"],parent=parent,intercept=float(beta[0]),theta_squared_slope=float(beta[1]),
                R_squared=float(1-residual@residual/max(total@total,1e-300)),
                smallest_rejected_scanned_angle=min((r["theta"] for r in rr if r["theta"]>0 and r["exact257_decision"]<0),default=None),
                largest_accepted_scanned_unknown_angle=max((r["theta"] for r in rr if r["theta"]>0 and r["exact257_decision"]>=0),default=None),
                decision_monotone_on_scanned_grid=all(rr[j]["exact257_decision"]<0 or rr[j-1]["exact257_decision"]>=0 for j in range(1,len(rr)))))
    save(HERE/"runs/pilot01/SUMMARY.json",dict(status="complete descriptive fixed-rule mechanism pilot",protocol=protocol,
        by_angle=table,per_parent_theta_squared_fits=fits,independent_people=2,new_confirmation=False,
        no_rule_or_threshold_selection=True,all_closer_pressure_failures_retained=True))
    print(json.dumps(dict(event="summary",by_angle=table)),flush=True)


def main():
    args=argparse.ArgumentParser();args.add_argument("--sources",default=",".join(SOURCES));opt=args.parse_args()
    assert tuple(opt.sources.split(","))==SOURCES
    freeze=cp.load(FREEZE);assert freeze["files"][str(RULEFILE.relative_to(ROOT)).replace("\\","/")]==cp.sha(RULEFILE)
    rules=cp.load(RULEFILE)["rules"]["smooth"]
    protocol=dict(status="fixed_before_bounded_angle_scan",sources=SOURCES,angles=ANGLES,condition=CONDITION,
        tangent="original P181 evaluation direction0, same tangent for all theta within parent",
        exact_rule=rules["257/candidate_FIR_GLRT/exact"]["selected"],
        compat129_rule=rules["129/candidate_FIR_GLRT/compatibility"]["selected"],
        actual_PRD_matching="original per-parent QID anchor interval [anchor/1.001,anchor]",caps_percent=[.25,.5,1.],
        reference_seconds=112,scored_seconds=40,visible_context_seconds=48,
        freeze_sha256=cp.sha(FREEZE),rule_file_sha256=cp.sha(RULEFILE),
        diagnostic_only_not_new_method_selection=True,new_confirmation_people_used=[])
    path=HERE/"PROTOCOL.json"
    if path.exists():assert cp.load(path)==json.loads(json.dumps(protocol))
    else:save(path,protocol)
    with threadpool_limits(limits=1):summarize([run(s,protocol) for s in SOURCES],protocol)


if __name__=="__main__":main()
