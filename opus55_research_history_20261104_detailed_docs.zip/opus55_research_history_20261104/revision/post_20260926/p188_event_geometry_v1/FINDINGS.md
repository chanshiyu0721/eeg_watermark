# Boundary-sensitive task preservation

The original270 scored events contain216 epochs crossing4s embedding joins.
All54episodes share the same five within-grid epoch positions. This geometry
arises from the unchanged annotation/time-window rule; no outcome-based event
exclusions occurred. All20 artifact events remain.

The targeted intervention moves only the encoder grid by1s, while keeping the
physical EEG, original task events, model checkpoints, receiver observation and
actualEDF budgets fixed. All270 events then lie inside blocks away from taper
transitions.864 new registered actualEDF files and6912 model/query rows were
computed; no new task model was fitted. Original grid0 results were reused.

| Model | Original smooth MAE | Original direct MAE | Grid+1s smooth | Grid+1s direct |
|---|---:|---:|---:|---:|
| CSP/LDA |0.000161788|0.000182971|0.000150590|0.000144611|
| EEGNet |0.000220458|0.000240420|0.000206597|0.000198213|

The advantage reverses in all9participants for both models at grid+1s.
Direct-minus-smooth becomes−5.979e−6(CSP) and−8.385e−6(EEGNet), each with an
exploratory exact512sign-flip p=.00390625. The original smooth advantage is
therefore a boundary-dependent allocation effect at the tested grid, rather
than a uniform task-stability advantage. Processed-clean-lag diagnostics retain
the reversal, ruling out query-lag changes as its sole explanation.

Grid+1s CSP predictions remain unchanged for both carriers. EEGNet has6 smooth
and5 direct repeated-copy flips. These repeats are not independent events.
Participants remain the inferential unit; grid interaction tests are posthoc.

The shifted grid is a task-only sensitivity. Its attribution compatibility with
the original phase receiver is not inferred. The working frontier retains the
original encoder grid and must be interpreted with this result alongside it.

The first launch stopped before freezing/evaluation because a historical import
had already set Torch interop threads. Removing the duplicate runtime setter
allowed the second launch to finish. The initial failure record/log is retained;
there was no model or outcome-based protocol change.
