"""Frozen-decision, participant-paired P191 analysis; no parameter fitting.

Full inference requires all eight source collections, including fixed secondary
carriers. Partial mode reports counts and paired values without tests or CIs.
"""
from pathlib import Path
import argparse,gzip,hashlib,itertools,json,math,os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
import numpy as np
from scipy import stats

HERE=Path(__file__).resolve().parent
PRIMARY='257/candidate_FIR_GLRT/exact'
CONDITIONS=('reexport','elliptic_new_causal','bessel_shifted_causal')
ARMS=('smooth','direct','hybrid05','spatial','qid')


def load(path):
    raw=Path(path).read_bytes()
    return json.loads(gzip.decompress(raw)if str(path).endswith('.gz')else raw)


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def family(row):
    if row['kind']=='enrolled':return 'registered'
    if row['kind']=='clean':return 'clean'
    if row['kind']=='wrong_source':return 'wrong'
    if row['kind']=='native_hamming_unknown':return 'modern_native_H'+str(row['hamming_to_parent'])
    if row['kind']=='qid_walsh_unregistered':return 'QIM_native_unknown'
    if row['kind']=='qid_chip_near_unregistered':return 'QIM_chip'+str(row['distance'])
    if row.get('angle')==.0125:return 'phase0125'
    if row.get('angle')==.025:return 'phase025'
    return 'other_unknown'


def counts(rows,key,field='decisions'):
    output={}
    for row in rows:
        name=family(row);decision=row[field][key]
        v=output.setdefault(name,dict(n=0,accepted=0,infeasible=0))
        v['n']+=1;v['accepted']+=int(decision>=0)
        v['infeasible']+=int(not row['issuance_feasible'])
        if name=='registered':
            v['correct']=v.get('correct',0)+int(decision==row['identity'])
            v['misattributed']=v.get('misattributed',0)+int(decision>=0 and decision!=row['identity'])
        if name.startswith('QIM_chip'):
            v['attributed_to_parent']=v.get('attributed_to_parent',0)+int(decision==row['parent'])
    return output


def paired_t(values,null=0.):
    x=np.asarray(values,dtype=float)
    assert len(x)==8 and np.isfinite(x).all()
    mean=float(x.mean());sd=float(x.std(ddof=1));se=sd/math.sqrt(8)
    if sd==0.:
        p=0. if mean>null else 1.
        statistic=('+infinity'if mean>null else '-infinity'if mean<null else None)
        ci=[mean,mean]
    else:
        statistic=(mean-null)/se;p=float(stats.t.sf(statistic,7))
        q=float(stats.t.ppf(.975,7));ci=[mean-q*se,mean+q*se]
    return dict(values=x.tolist(),n_people=8,mean=mean,sd=sd,median=float(np.median(x)),
        minimum=float(x.min()),maximum=float(x.max()),df=7,SE=se,CI95=ci,
        t=statistic,p_one_sided=p,null_boundary=null,alternative='greater',
        empirical_zero_variance=sd==0.,
        zero_variance_interpretation=('collapsed observed vector; no independent-query population precision inferred' if sd==0. else None))


def signflip(values,null=0.):
    x=np.asarray(values,dtype=float)-null
    assert len(x)==8
    signs=np.asarray(list(itertools.product((-1.,1.),repeat=8)))
    means=(signs*x).mean(axis=1);observed=float(x.mean())
    return dict(permutations=256,null_boundary=null,centered_observed_mean=observed,
        p_greater=float(np.mean(means>=observed-1e-12)),
        p_two_sided=float(np.mean(np.abs(means)>=abs(observed)-1e-12)),
        all_signed_means=means.tolist(),
        positive=int(np.sum(x>1e-12)),negative=int(np.sum(x< -1e-12)),ties=int(np.sum(np.abs(x)<=1e-12)),
        assumption='conditional sign exchangeability about the specified null boundary',sensitivity_only=True)


def holm(values):
    previous=0.;output={}
    for i,key in enumerate(sorted(values,key=lambda k:(values[k],k))):
        adjusted=min(1.,max(previous,(len(values)-i)*values[key]));previous=adjusted
        output[key]=dict(raw_p=float(values[key]),holm_adjusted_p=adjusted,reject_at_05=adjusted<=.05)
    return output


def bootstrap(values,indices):
    x=np.asarray(values,dtype=float);means=x[indices].mean(axis=1)
    return dict(draws=len(indices),participant_percentile_CI95=np.quantile(means,[.025,.975]).tolist(),
        empirical_mean=float(x.mean()),sensitivity_only=True,degenerate=bool(np.std(x)==0.))


def participant_values(rows,key):
    registered=[r for r in rows if r['kind']=='enrolled']
    pressure=[r for r in rows if r.get('angle')==.0125 and r['condition']=='elliptic_new_causal']
    assert len(registered)==24 and len(pressure)==8
    return dict(coverage=sum(r['decisions'][key]==r['identity']for r in registered)/24,
        elliptic0125_acceptance=sum(r['decisions'][key]>=0 for r in pressure)/8)


def budget_gate(root,source,obj):
    path=root/'issuance'/source/'level100/issuance_summary.json'
    z=load(path);actual=[r for r in z['phase_matching']if r.get('arm')=='smooth'
        and r.get('index',999)<8 and r.get('status')=='actual_EDF_verified']
    ok=bool(z['registered_group_valid']and len(actual)==8 and
        all(v<=.001 for v in z['actual_registered_relative_spreads'])and
        all(r['global_ac_prd']<=.25 and r['max_channel_ac_prd']<=.5 and r['band_prd']<=1. for r in actual))
    assert obj['issuance_sha256']==digest(path)
    return dict(passed=ok,actual_registered_quality=actual,
        actual_registered_relative_spreads=z['actual_registered_relative_spreads'],
        issuance_sha256=digest(path))


def analyze(root,allow_partial=False,freeze_path=None):
    freeze_path=Path(freeze_path)if freeze_path else root/'CONFIRMATION_FREEZE.json'
    freeze=load(freeze_path);freeze_sha=digest(freeze_path)
    sidecar=freeze_path.with_suffix('.sha256')
    if sidecar.exists():assert sidecar.read_text().strip().split()[0]==freeze_sha
    plan=freeze['statistical_plan'];people=freeze['contract_snapshot']['targets']
    controls=freeze['primary_endpoints']['comparators']
    assert len(people)==8 and len(controls)==2 and freeze['primary_endpoints']['candidate'].endswith('/'+PRIMARY)
    manifest=[];objects={arm:{}for arm in ARMS};modern={}
    for source in people:
        paths={arm:root/'raw/confirm'/source/'level100'/f'{arm}.json.gz'for arm in ARMS}
        if freeze.get('modern_extension'):
            paths['modern_A400']=root/'modern_A400/raw'/source/'modern_A400.json.gz'
        for arm,path in paths.items():
            if not path.exists():manifest.append(dict(source=source,arm=arm,status='missing'));continue
            obj=load(path);entry=dict(source=source,arm=arm,status=obj['status'],n=len(obj['rows']))
            if obj['status']=='complete':
                assert len(obj['rows'])==obj['expected_n'],str(path)
                assert obj['confirmation_freeze_sha256']==freeze_sha
                entry['sha256']=digest(path)
                (modern if arm=='modern_A400'else objects[arm])[source]=obj
            manifest.append(entry)
    complete=all(r['status']=='complete'for r in manifest)
    if not complete and not allow_partial:raise RuntimeError('All eight complete source collections are required for primary inference')
    output=dict(status='complete_primary_analysis'if complete else 'partial_descriptive_only',
        confirmation_freeze_sha256=freeze_sha,confirmation_freeze_file=str(freeze_path),
        analysis_code_sha256=digest(__file__),statistical_plan=plan,manifest=manifest,
        fixed_candidate=PRIMARY,fixed_controls=controls,independent_unit='person',
        code_windows_and_processing_are_repeated_within_person=True,new_rules_fitted=False,
        formal_inference_performed=complete,descriptive={},QIM_native_policy={},modern_native={},paired_vectors={})
    for arm,group in objects.items():
        if not group:continue
        rows=[r for obj in group.values()for r in obj['rows']]
        keys=list(rows[0]['decisions'])
        output['descriptive'][arm]={key:dict(total=counts(rows,key),
            processing={c:counts([r for r in rows if r['condition']==c],key)for c in CONDITIONS},
            people={s:counts(obj['rows'],key)for s,obj in group.items()})for key in keys}
        if arm=='qid':
            keys=list(rows[0]['qid_native_policy_decisions'])
            output['QIM_native_policy']={key:dict(total=counts(rows,key,'qid_native_policy_decisions'),
                people={s:counts(obj['rows'],key,'qid_native_policy_decisions')for s,obj in group.items()})for key in keys}
            output['QIM_native_policy_semantics']='Walsh-native unknown rejection; chip1/2 damaged-copy attribution reported separately from original strict chip-forgery counts in descriptive/qid'
    if modern:
        rows=[r for obj in modern.values()for r in obj['rows']]
        output['modern_native']={key:dict(total=counts(rows,key),
            processing={c:counts([r for r in rows if r['condition']==c],key)for c in CONDITIONS},
            people={s:counts(obj['rows'],key)for s,obj in modern.items()})for key in rows[0]['decisions']}
        output['modern_native_semantics']='native Hamming1/2 tests, separate from phase0125/025 and QIM chip semantics'
    paired={s:{key:participant_values(obj['rows'],key)for key in [PRIMARY]+controls}
            for s,obj in objects['smooth'].items()}
    for control in controls:
        ids=[s for s in people if s in paired]
        output['paired_vectors'][control]=dict(people=ids,
            coverage_candidate_minus_control=[paired[s][PRIMARY]['coverage']-paired[s][control]['coverage']for s in ids],
            elliptic0125_control_minus_candidate=[paired[s][control]['elliptic0125_acceptance']-paired[s][PRIMARY]['elliptic0125_acceptance']for s in ids],
            raw_person_values={s:dict(candidate=paired[s][PRIMARY],control=paired[s][control])for s in ids})
        vectors=output['paired_vectors'][control]
        vectors['raw_difference_signs']={name:dict(
            positive=sum(v>1e-12 for v in vectors[name]),
            negative=sum(v< -1e-12 for v in vectors[name]),
            ties=sum(abs(v)<=1e-12 for v in vectors[name]))for name in
            ('coverage_candidate_minus_control','elliptic0125_control_minus_candidate')}
    if complete:
        assert len(paired)==8
        indices=np.random.default_rng(plan['bootstrap_seed']).integers(0,8,(plan['bootstrap_draws'],8))
        contrasts={};joint={};permutation_joint={}
        for control,vectors in output['paired_vectors'].items():
            coverage=vectors['coverage_candidate_minus_control'];pressure=vectors['elliptic0125_control_minus_candidate']
            cov=paired_t(coverage,null=-.05);near=paired_t(pressure,null=0.)
            permcov=signflip(coverage,null=-.05);permnear=signflip(pressure,null=0.)
            joint[control]=max(cov['p_one_sided'],near['p_one_sided'])
            permutation_joint[control]=max(permcov['p_greater'],permnear['p_greater'])
            contrasts[control]=dict(coverage_noninferiority=cov,elliptic0125_superiority=near,
                IUT_p=joint[control],IUT_definition='maximum of one-sided coverage-NI and pressure-superiority p values',
                signflip_coverage_NI=permcov,signflip_pressure_superiority=permnear,
                bootstrap_coverage=bootstrap(coverage,indices),bootstrap_pressure=bootstrap(pressure,indices))
        adjusted=holm(joint);sensitivity=holm(permutation_joint)
        output['primary_inference']=dict(contrasts=contrasts,Holm=adjusted,
            both_comparators_pass=all(v['reject_at_05']for v in adjusted.values()),
            signflip_IUT_Holm_sensitivity=sensitivity,
            bootstrap_seed=plan['bootstrap_seed'],bootstrap_draws=plan['bootstrap_draws'],
            no_test_switching=True)
        rows=[r for obj in objects['smooth'].values()for r in obj['rows']]
        allcounts=counts(rows,PRIMARY);elliptic=counts([r for r in rows if r['condition']=='elliptic_new_causal'],PRIMARY)
        budget={s:budget_gate(root,s,obj)for s,obj in objects['smooth'].items()}
        criteria=freeze['success_criteria']['absolute_transfer']
        coverage=[paired[s][PRIMARY]['coverage']for s in people]
        checks=dict(mean_registered_correct=float(np.mean(coverage))>=criteria['mean_registered_correct_min'],
            minimum_person_coverage=min(coverage)>=criteria['minimum_target_registered_correct_min'],
            elliptic_registered_correct=elliptic['registered']['correct']/elliptic['registered']['n']>=criteria['elliptic_registered_correct_min'],
            elliptic0125_zero_accept=elliptic['phase0125']['accepted']<=criteria['elliptic0125_accepted_max'],
            all_phase025_zero_accept=allcounts['phase025']['accepted']<=criteria['phase025_accepted_max'],
            clean_zero_accept=allcounts['clean']['accepted']<=criteria['clean_accepted_max'],
            wrong_zero_accept=allcounts['wrong']['accepted']<=criteria['wrong_accepted_max'],
            registered_zero_misattribution=allcounts['registered']['misattributed']<=criteria['registered_misattributed_max'],
            actual_EDF_budget=all(v['passed']for v in budget.values()))
        output['absolute_transfer']=dict(passed=all(checks.values()),checks=checks,
            primary_counts=allcounts,primary_elliptic_counts=elliptic,
            person_coverages=coverage,budget=budget)
        output['incremental_superiority']=dict(passed=output['primary_inference']['both_comparators_pass'],
            absolute_transfer_evaluated_separately=True)
    return output


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,default=HERE)
    parser.add_argument('--freeze',type=Path)
    parser.add_argument('--allow-partial',action='store_true');args=parser.parse_args()
    root=args.out.resolve();result=analyze(root,args.allow_partial,args.freeze)
    path=root/('PRIMARY_ANALYSIS.json'if result['formal_inference_performed']else'PARTIAL_PRIMARY_DESCRIPTIVE.json')
    temporary=path.with_suffix(path.suffix+'.partial')
    temporary.write_text(json.dumps(result,ensure_ascii=False,allow_nan=False,indent=2)+'\n',encoding='utf-8')
    temporary.replace(path)
    print(json.dumps(dict(status=result['status'],complete_files=sum(r['status']=='complete'for r in result['manifest']),
        expected_files=len(result['manifest']),formal_inference_performed=result['formal_inference_performed'],path=str(path))))


if __name__=='__main__':main()
