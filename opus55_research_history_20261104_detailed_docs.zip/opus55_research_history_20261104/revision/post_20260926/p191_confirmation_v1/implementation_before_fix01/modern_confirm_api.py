"""Companion modern-carrier collection from the common frozen source objects.

No raw source acquisition or threshold fitting occurs here. The common
confirmation owner passes its already prepared record, wrong records, smooth
copies and physical query ranges after the single global scientific freeze.
"""
from pathlib import Path
import time
import numpy as np
import a400_carrier as encoder_api
import common_owner_dev as dev
from dev_capacity import DevelopmentReceiver
import calibrate_allarms as decisions_api
import checkpoint_io
m=dev.m
RULES=dev.HERE/'common_owner_dev02/MODERN_DEV_LOCK.json'


def contract_snapshot():
    lock=m.load(RULES)
    assert lock['status']=='full DEV rules fixed before fresh-person modern scoring'
    pinned={**lock['frozen_files'],**lock['data_files_sha256']}
    files={str(Path(k).resolve().relative_to(m.ROOT)).replace('\\','/'):v for k,v in pinned.items()}
    for path in (RULES,Path(__file__),Path(encoder_api.__file__),Path(checkpoint_io.__file__),
                 Path(decisions_api.__file__),Path(m.api.__file__),
                 Path(DevelopmentReceiver.extract_all.__code__.co_filename)):
        files[str(path.resolve().relative_to(m.ROOT)).replace('\\','/')]=m.sha(path)
    return dict(version='P191-fixed-A400-modern-carrier-companion-v1',
        rule_file=str(RULES.resolve().relative_to(m.ROOT)).replace('\\','/'),rule_sha256=m.sha(RULES),
        files=files,carrier='fixed A400 owner-adapted public-structure RPW finite-eight encoder',
        checkpoint_sha256=encoder_api.CHECKPOINT_SHA256,
        reference_seconds=112,scored_seconds=40,visible_context_seconds=48,
        source_roster='same targets and wrong sources as the common confirmation contract',
        actual_PRD_match='same source/rid common QID anchor: anchor/1.001 <= modern actual global PRD <= anchor; all-carrier overall spread <=.001',
        conditions=list(m.CONDITIONS),registered=8,native_unknown_H1=8,native_unknown_H2=8,
        native_unknowns_are_distinct_legal_30bit_encoder_inputs=True,
        phase_angle_025_0125_not_applicable=True,receiver_rules=list(lock['methods']),
        primary_comparison_rule='257/candidate_FIR_GLRT/exact',
        endpoints=['registered correct coverage','native H1/H2 false acceptance separately',
                   'clean/wrong false acceptance','processing-specific coverage','actual PRD and compute cost'],
        no_confirmation_rule_selection=True)


def _validate(freeze_path,expected_sha,source,wrongs):
    assert isinstance(expected_sha,str)and len(expected_sha)==64
    assert m.sha(freeze_path)==expected_sha,'Global confirmation freeze SHA differs'
    freeze=m.load(freeze_path)
    assert freeze['status']in('frozen_before_new_signal_confirmation','frozen_before_new_person_confirmation')
    extension=contract_snapshot()
    assert freeze.get('modern_extension')==extension,'The global freeze must include the complete modern extension'
    for name,digest in extension['files'].items():
        assert freeze['files'].get(name)==digest,('Missing modern frozen file',name)
        path=(m.ROOT/name).resolve();assert path.is_relative_to(m.ROOT)
        assert m.sha(path)==digest,('Modern frozen file differs',name)
    assert source in freeze['contract_snapshot']['targets']
    assert sorted(wrongs)==sorted(freeze['contract_snapshot']['wrong_sources'])
    return freeze,m.load(RULES)


def _decision(feature,method,rule):
    score,eligible,top=decisions_api.score(dict(receiver=feature),method,rule)
    return int(top)if eligible and score>=rule['threshold']else -1


def collect_from_prepared(record,wrong_records,smooth_copies,query_limits,
                          freeze_path,expected_freeze_sha,output_folder):
    """Called after the common owner prepares source objects and smooth EDFs.

    ``record``/``wrong_records`` are the common issuer's prepare_source results;
    ``smooth_copies`` are its eight actual readback arrays; query_limits is its
    query_ranges result. All model and rule files must already be globally frozen.
    """
    source=record['name'];wrong_names=[v['name']for v in wrong_records]
    freeze,lock=_validate(freeze_path,expected_freeze_sha,source,wrong_names)
    output=Path(output_folder).resolve()
    assert output.is_relative_to(m.ROOT)and output.drive.upper()=='E:'
    output.mkdir(parents=True,exist_ok=True)
    x=record['x'];assert x.shape==(8,17920)
    assert len(smooth_copies)>=8 and all(v.shape==x.shape for v in smooth_copies[:8])
    carrier=encoder_api.FixedA400Carrier()
    cp={'codebook':__import__('torch').as_tensor(carrier.registered_bits)}
    codes,metadata,minimum=m.codebook(cp)
    assert minimum==10
    issuefile=output/'issuance'/source/'ISSUANCE.json';issuefolder=issuefile.parent
    issuefolder.mkdir(parents=True,exist_ok=True)
    common_issue=Path(record['folder']).resolve().parents[1]/'issuance'/source/'level100/issuance_summary.json'
    original_issuance=m.load(common_issue)
    if not original_issuance['registered_group_valid']:
        infos=metadata+[dict(kind='clean',identity=None,parent=None,pressure=False)]+[
            dict(kind='wrong_source',identity=None,parent=None,pressure=False,negative_source=n)for n in wrong_names]
        query_rows=[dict(source=source,query_index=i,condition=condition,**info,
            issuance_feasible=False,receivers_by_order=None,
            decisions={k:-1 for k in lock['methods']},primary_decision=-1,
            failure_reason='shared_common_anchor_group_infeasible')for i,info in enumerate(infos)for condition in m.CONDITIONS]
        dest=output/'raw'/source/'modern_A400.json.gz'
        result=dict(status='complete',source=source,arm='modern_A400',rows=query_rows,EDF_receipts=[],
            expected_n=len(query_rows),seconds=0.,registered_group_valid=False,
            confirmation_freeze_sha256=expected_freeze_sha,rule_file_sha256=m.sha(RULES),
            native_phase_angle_not_applicable=True,new_confirmation_rule_selection=False)
        checkpoint_io.save(dest,result)
        return result
    targets=[float(v)for v in original_issuance['QID_anchors'][:8]]
    for anchor,smooth in zip(targets,smooth_copies[:8]):
        q=m.api.p.quality(x,smooth)['global_ac_prd']
        assert anchor/1.001<=q<=anchor,'Common smooth EDF lies outside original all-carrier budget interval'
    issued=m.load(issuefile)if issuefile.exists()else dict(rows=[])
    assert issued.get('confirmation_freeze_sha256',expected_freeze_sha)==expected_freeze_sha
    rows=issued['rows'];copies=[]
    for index,(bits,info)in enumerate(zip(codes,metadata)):
        if index<len(rows):
            row=rows[index];copies.append(m.read(issuefolder/f'r{index:02d}_issued.edf.gz')if row['feasible']else None)
            continue
        target=targets[info['parent']]
        result=carrier.issue_actual_edf(x,bits,record['limits'],target,issuefolder,f'r{index:02d}_issued.edf')
        copies.append(result.get('readback_v'))
        rows.append(dict(index=index,metadata=info,bits=bits.tolist(),feasible=result['feasible'],target_global_PRD=target,
            quality=result.get('quality'),EDF_receipt=result.get('EDF_receipt'),matching=result['matching']))
        checkpoint_io.save(issuefile,dict(status='running',source=source,rows=rows,
            confirmation_freeze_sha256=expected_freeze_sha,checkpoint_sha256=encoder_api.CHECKPOINT_SHA256))
    valid=all(v is not None for v in copies[:8])
    checkpoint_io.save(issuefile,dict(status='complete',source=source,rows=rows,registered_group_valid=valid,
        confirmation_freeze_sha256=expected_freeze_sha,checkpoint_sha256=encoder_api.CHECKPOINT_SHA256))
    dest=output/'raw'/source/'modern_A400.json.gz';dest.parent.mkdir(parents=True,exist_ok=True)
    before=m.load(dest)if dest.exists()else dict(rows=[],EDF_receipts=[],seconds=0.)
    if before.get('status')=='complete':
        assert before['confirmation_freeze_sha256']==expected_freeze_sha
        return before
    receiver129=m.api.MatchedFIRReceivers(x,np.asarray(copies[:8]))if valid else None
    receiver257=DevelopmentReceiver(x,np.asarray(copies[:8]),257)if valid else None
    query_rows=before['rows'];receipts=before['EDF_receipts'];done={(r['query_index'],r['condition'])for r in query_rows}
    values=copies+[x]+[v['x']for v in wrong_records]
    infos=metadata+[dict(kind='clean',identity=None,parent=None,pressure=False)]+[
        dict(kind='wrong_source',identity=None,parent=None,pressure=False,negative_source=n)for n in wrong_names]
    started=time.monotonic()
    for index,(value,info)in enumerate(zip(values,infos)):
        for condition in m.CONDITIONS:
            if(index,condition)in done:continue
            base=dict(source=source,query_index=index,condition=condition,**info)
            if value is None or not valid:
                row=dict(**base,issuance_feasible=False,decisions={k:-1 for k in lock['methods']},receivers_by_order=None)
            else:
                query,_=m.edf.edf_roundtrip(m.common.transform(value,condition),query_limits[condition],
                    f'{source}_A400_q{index}_{condition}.edf',dest.parent,receipts,True,m.CHANNELS)
                features={'129':receiver129.extract(query),'257':receiver257.extract_all(query)}
                decisions={}
                for key,entry in lock['methods'].items():
                    order,method,readout=key.split('/')
                    decisions[key]=_decision(features[order],method,entry['selected'])
                row=dict(**base,issuance_feasible=True,receivers_by_order=features,decisions=decisions,
                    query_raw_sha256=receipts[-1]['raw_sha256'],primary_decision=decisions['257/candidate_FIR_GLRT/exact'])
            query_rows.append(row)
            result=dict(status='running',source=source,arm='modern_A400',rows=query_rows,EDF_receipts=receipts,
                expected_n=len(values)*3,seconds=before['seconds']+time.monotonic()-started,
                registered_group_valid=valid,confirmation_freeze_sha256=expected_freeze_sha,
                rule_file_sha256=m.sha(RULES),issuance_sha256=m.sha(issuefile),
                native_phase_angle_not_applicable=True,new_confirmation_rule_selection=False)
            checkpoint_io.save(dest,result)
    result['status']='complete';checkpoint_io.save(dest,result)
    return result
