"""Sequential fixed-source queue, detached from interactive tool sessions."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,json,os,subprocess,sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
FREEZE=HERE/'CONFIRMATION_FREEZE_FIX01.json'
SHA='e181d74e991ef5cb2155cd41f60673dc3eaa8f1e0be449c8d6d77be1ef398fb8'
COLLECTOR=HERE.parent/'p191_fir_capacity_v1/confirm_collector.py'
def now():return datetime.now(timezone.utc).isoformat()
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--sources',required=True);ap.add_argument('--job',required=True)
    a=ap.parse_args();names=a.sources.split(',')
    assert all(n in [f'OpenBMI{s:03d}' for s in range(17,25)] for n in names)
    state=HERE/'jobs'/f'{a.job}.json';state.parent.mkdir(exist_ok=True)
    value={'pid':os.getpid(),'started_utc':now(),'sources':names,'completed_this_queue':[],
           'freeze_sha256':SHA,'status':'running'}
    def save():state.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
    save();env=dict(os.environ)
    env.update(OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
    for name in names:
        value.update(current_source=name,current_started_utc=now());save()
        print(json.dumps({'event':'source_queue_start','source':name,'utc':now()}),flush=True)
        run=subprocess.run([sys.executable,'-u','-B',str(COLLECTOR),'--freeze',str(FREEZE),
                            '--freeze-sha',SHA,'--source',name],cwd=ROOT,env=env)
        if run.returncode:
            value.update(status='terminal_error',returncode=run.returncode,stopped_utc=now());save()
            sys.exit(run.returncode)
        value['completed_this_queue'].append(name);save()
    value.update(status='complete',stopped_utc=now());save()
    print(json.dumps({'event':'queue_complete','sources':names,'utc':now()}),flush=True)
if __name__=='__main__':main()
