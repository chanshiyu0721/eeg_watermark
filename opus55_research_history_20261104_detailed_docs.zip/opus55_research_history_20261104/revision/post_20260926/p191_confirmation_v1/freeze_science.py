"""Freeze the completed DEV choices before any fresh-person attribution.

This is the experimental contract, not a submission or reproduction package.
Run only after the classical and corrected modern DEV locks are complete.
"""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,importlib,json,os,sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
CAP=HERE.parent/'p191_fir_capacity_v1'
MOD=HERE.parent/'p191_modern_carrier_v1'
PREP=HERE.parent/'p191_new_records_v1'
TEMP=HERE/'temp'
TEMP.mkdir(parents=True,exist_ok=True)
for key in ('TEMP','TMP','TMPDIR'):os.environ[key]=str(TEMP)
os.environ['PYTHONDONTWRITEBYTECODE']='1'
sys.dont_write_bytecode=True
sys.path[:0]=[str(CAP),str(MOD)]

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--write-freeze',action='store_true');args=ap.parse_args()
    collector=importlib.import_module('confirm_collector')
    modern=importlib.import_module('modern_confirm_api')
    classical=collector.contract_snapshot();extension=modern.contract_snapshot()
    acquisition=json.loads((PREP/'ACQUISITION.json').read_text(encoding='utf-8'))
    assert acquisition['status']=='all12_files_acquired_effects_unopened'
    assert acquisition['receiver_predictions']==0 and acquisition['task_predictions']==0
    files={**classical['files'],**extension['files']}
    for path in [Path(__file__),PREP/'ACQUISITION.json',PREP/'METADATA_PREPARATION.json']:
        files[str(path.relative_to(ROOT)).replace('\\','/')]=sha(path)
    value={
      'status':'frozen_before_new_person_confirmation',
      'created_utc':datetime.now(timezone.utc).isoformat(),
      'contract_snapshot':classical,'modern_extension':extension,'files':files,
      'primary_endpoints':{
        'candidate':'smooth/level100/257/candidate_FIR_GLRT/exact',
        'registered':'person-equal correct attribution over three declared conditions',
        'near_identity':'person-equal .0125 acceptance under causal elliptic',
        'controls':'all .025, clean, wrong-source and each processing slice reported separately',
        'comparators':['129/candidate_FIR_GLRT/compatibility','257/candidate_FIR_GLRT/compatibility'],
        'mechanism_ablation':'129 exact is an executed DEV ablation, not an additional unimplemented confirmation contrast'
      },
      'success_criteria':{
        'absolute_transfer':{'mean_registered_correct_min':.95,'minimum_target_registered_correct_min':.90,
                             'elliptic_registered_correct_min':.95,'elliptic0125_accepted_max':0,
                             'phase025_accepted_max':0,'clean_accepted_max':0,'wrong_accepted_max':0,
                             'registered_misattributed_max':0,'actual_EDF_budget_must_pass':True},
        'incremental_superiority':'For both fixed simple comparators: registered coverage noninferiority margin-.05 AND elliptic0125 acceptance reduction, two family-wise Holm-adjusted intersection-union tests at.05. Failure remains a separate explicit outcome even if absolute transfer passes.',
        'secondary':'Other carriers/receivers/processing and native QIM/modern unknown families have complete fixed outcomes; no confirmation-based rule substitution.'
      },
      'statistical_plan':{
        'independent_units':'8 canonical target people;4 canonical wrong-source people. Codes/windows/transforms are repeats within people.',
        'estimands':'equal-weight mean across target people; coverage averages its24 registered queries; elliptic pressure averages its8 pressure identities.',
        'paired_effects':'candidate minus comparator coverage; comparator minus candidate elliptic pressure acceptance.',
        'intervals':'two-sided95% paired mean t intervals with7df;seeded participant-percentile bootstrap as sensitivity. Degenerate empirical vectors explicitly reported as observed, without independent-query binomial precision.',
        'coverage_test':'one-sided paired mean t test H0 mean coverage difference<=-.05',
        'pressure_test':'one-sided paired mean t test H0 mean comparator-minus-candidate pressure difference<=0',
        'degenerate_test_rule':'zeroSD: p=0 only when the constant difference is strictly above the tested null boundary, otherwise p=1. All-zero pressure improvement yields p=1.',
        'joint_test':'p=max(coverage_noninferiority_p,pressure_superiority_p);Holm over the2 comparator joint tests.',
        'sensitivity':'all256 participant sign flips of paired differences, conditional on sign exchangeability; report signs, ties and full participant vectors. No outcome-driven test switching.',
        'bootstrap_seed':19120261104,'bootstrap_draws':20000,
        'scope':'conditional on fixed processing/code grid, reference access, query-range fixture and finite cohort; query counts are denominators, not independent participant sample sizes.'
      },
      'identity_policy':{
        'phase':'Original strict independent .025/.0125 code-angle labels retained.',
        'qid':'strict chip-negative and legal-native policies both fixed;chip parent attribution reported separately;no better-policy selection.',
        'modern':'independent legal Hamming1/2 messages;no equivalence to phase-angle neighborhoods.',
        'damaged_copy':'issued-parent generation histories keep their own attribution table.'
      },
      'task_stage':{
        'status':'separate task protocol/model freeze required before any new-task test predictions',
        'reason':'task model capability development uses only old people;attribution confirmation fixes no task-model choice.',
        'constraint':'new task test outcomes cannot alter this attribution contract or its frozen rules; task blocks, models and metrics are bound by the separate task freeze'
      },
      'user_delivery_scope':'Focus on experiments and research strength; no new method figures,reproduction materials or formatted manuscript; eventual draft is Markdown.'
    }
    # Validate the concrete final files once at this new freeze boundary.
    for name,digest in files.items():
        path=(ROOT/name).resolve();assert path.is_relative_to(ROOT) and sha(path)==digest,name
    target=HERE/'CONFIRMATION_FREEZE.json'
    if not args.write_freeze:
        print(json.dumps({'status':'ready_to_freeze','classical_arms':classical['arms'],'modern_rule':extension['rule_file'],'files':len(files),'fresh_predictions':0}));return
    assert not target.exists(),'Existing scientific freeze is immutable; do not overwrite.'
    HERE.mkdir(parents=True,exist_ok=True)
    target.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    digest=sha(target)
    (HERE/'CONFIRMATION_FREEZE.sha256').write_text(digest+'\n',encoding='ascii')
    print(json.dumps({'status':value['status'],'path':str(target),'sha256':digest,'fresh_predictions':0}))

if __name__=='__main__':main()
