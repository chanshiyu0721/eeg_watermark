"""Record a representation-only runtime fix; retain the original freeze."""
from pathlib import Path
from datetime import datetime,timezone
import copy,gzip,hashlib,importlib,json,os,sys
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
CAP=HERE.parent/'p191_fir_capacity_v1';MOD=HERE.parent/'p191_modern_carrier_v1'
os.environ.update(OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_NUM_THREADS='1')
sys.dont_write_bytecode=True;sys.path[:0]=[str(CAP),str(MOD)]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rel(p):return str(Path(p).relative_to(ROOT)).replace('\\','/')

def main():
    cc=importlib.import_module('confirm_collector');ma=importlib.import_module('modern_confirm_api')
    original=HERE/'CONFIRMATION_FREEZE.json'
    assert sha(original)=='00fe0e4caff25a74de2bff876723608147f68bcf98e794033658670039640b89'
    old=json.loads(original.read_text(encoding='utf-8'))
    archive=HERE/'implementation_before_fix01'
    changed=[CAP/'confirm_collector.py',MOD/'modern_confirm_api.py']
    for path in changed:assert sha(archive/path.name)==old['files'][rel(path)]
    # Check precisely the fixed failure: saved-string and live-float inputs
    # must give identical decisions for every selected rule on one DEV source.
    raw=json.loads(gzip.decompress((CAP/'runs/dev257/OpenBMI001_taps257.json.gz').read_bytes()))
    rules=json.loads((CAP/'ALLARM_DEV_RULES.json').read_text())['rules']['smooth']
    comparisons=0
    for row in raw['rows']:
        for key,entry in rules.items():
            if not key.startswith('257/'):continue
            _,method,_=key.split('/');rule=entry['selected']
            expected=cc.decision(copy.deepcopy(row['receiver']),method,rule)
            live=copy.deepcopy(row['receiver'])
            for value in live['methods'].values():value['by_ridge']={float(k):v for k,v in value['by_ridge'].items()}
            assert cc.decision(copy.deepcopy(live),method,rule)==expected
            assert ma._decision(copy.deepcopy(live),method,rule)==expected
            comparisons+=2
    saved=list((HERE/'raw/confirm').glob('*/*/*.json.gz'))
    assert not saved,'No confirmation decision files should precede this initial runtime fix.'
    classical=cc.contract_snapshot();modern=ma.contract_snapshot()
    value=copy.deepcopy(old)
    value['contract_snapshot']=classical;value['modern_extension']=modern
    value['files']={**old['files'],**classical['files'],**modern['files']}
    for path in [Path(__file__),original]+list(archive.glob('*.py')):value['files'][rel(path)]=sha(path)
    value['implementation_amendment']={
      'kind':'float/string ridge-key normalization at the two live decision boundaries',
      'created_utc':datetime.now(timezone.utc).isoformat(),'original_freeze_sha256':sha(original),
      'original_freeze_retained':True,'prior_workers_terminal_sessions':[55808,89922],
      'failure':'Both initial source workers stopped on KeyError before saving their first query decision.',
      'data_already_accessed':'Only sources17/18 issuance and first-query fitting plus sharedwrong caches; no confirmation decisions were saved or viewed.',
      'changed_files':[rel(p) for p in changed],
      'unchanged':'All numerical feature values,model weights,DEV scores,selected configurations,thresholds,people,processing,budgets,endpoints,success criteria and statistics.',
      'specific_validation':{'DEV_source':'OpenBMI001','equal_decision_comparisons':comparisons,'live_float_and_saved_string_equivalent':True},
      'resume':'Reuse all actual source caches and issuedEDF bytes; restart the first unsaved query under this pinned amendment.'
    }
    for name,digest in value['files'].items():assert sha(ROOT/name)==digest,name
    for key in ('primary_endpoints','success_criteria','statistical_plan','identity_policy','task_stage'):
        assert value[key]==old[key]
    path=HERE/'CONFIRMATION_FREEZE_FIX01.json';assert not path.exists()
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    digest=sha(path);path.with_suffix('.sha256').write_text(digest+'\n',encoding='ascii')
    print(json.dumps({'path':str(path),'sha256':digest,'same_decision_comparisons':comparisons,'new_saved_decisions_before_fix':0}))

if __name__=='__main__':main()
