"""Declared DEV -> receiver/threshold freeze -> retained-record comparison."""
from pathlib import Path
import os,sys
OUT=Path(__file__).resolve().parent;BASE=OUT.parent;ROOT=BASE.parents[1]
sys.dont_write_bytecode=True
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
for key in ('TEMP','TMP','TMPDIR','MPLCONFIGDIR','NUMBA_CACHE_DIR'):
    (OUT/'scratch').mkdir(exist_ok=True);os.environ[key]=str(OUT/'scratch')
sys.path[:0]=[str(ROOT),str(OUT)]
import argparse,gzip,hashlib,json,time,traceback
import numpy as np
from receiver_api import MatchedFIRReceivers,METHODS,CONFIGS,calibrate,apply_rules
from revision.post_20260926 import p181_common as c,p181_domain as domain,run_p181_data as io

DEV=BASE/'p186_five_arm_bridge_v1/A02T'
EVAL=BASE/'p186_new_records_v1/frozen_confirmation'
CONDITIONS=('reexport',)+tuple(c.NOVEL)

def load(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):
    with Path(path).open('x',encoding='utf-8') as f:json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False)
def read(folder,name):return io.parse_edf(gzip.decompress((folder/name).read_bytes()),domain.BCI_CHANNELS)[0]

def collect(source,pilot=False):
    folder=DEV if source=='A02T' else EVAL/source
    dest=OUT/('pilot_A02T.json' if pilot else f'{source}_raw.json')
    assert not dest.exists(),f'Preserve completed result {dest}'
    with np.load(folder/'clean.npz') as z:x=np.array(z['x']);h0=np.array(z['h0'])
    wrongfolder=BASE/'p186_five_arm_bridge_v1/A01T' if source=='A02T' else EVAL/('OpenBMI004' if source=='OpenBMI003' else 'OpenBMI003')
    with np.load(wrongfolder/'clean.npz') as z:wrong=np.array(z['x'])
    originals=load(folder/'all_rows.json')
    metadata={r['recipient']:r for r in originals if r['arm']=='smooth'}
    archive={r['name']:r for r in load(folder/'query_artifacts.json')}
    copies=[read(folder,f'smooth_r{i}_issued.edf.gz') for i in range(24)]
    receiver=MatchedFIRReceivers(x,np.array(copies[:8]))
    conditions=('reexport','bessel_shifted_causal') if pilot else CONDITIONS
    recipients=(0,8,16,24) if pilot else range(26)
    codes=copies+[x,wrong];artifacts=[];rows=[];started=time.monotonic()
    for condition in conditions:
        limits=c.p.ranges(np.concatenate([c.transform(x,condition),c.transform(wrong,condition)],axis=1))
        clean,hclean=io.edf_roundtrip(c.transform(x,condition),limits,f'smooth_{condition}_q24.edf',OUT/'scratch',artifacts,False,domain.BCI_CHANNELS)
        assert artifacts[-1]['raw_sha256']==archive[artifacts[-1]['name']]['raw_sha256']
        for recipient in recipients:
            query,h=io.edf_roundtrip(c.transform(codes[recipient],condition),limits,f'smooth_{condition}_q{recipient}.edf',OUT/'scratch',artifacts,False,domain.BCI_CHANNELS)
            assert artifacts[-1]['raw_sha256']==archive[artifacts[-1]['name']]['raw_sha256'],(source,recipient,condition)
            result=receiver.extract(query,h,h0,diagnostic_clean=clean)
            meta=metadata[recipient]
            rows.append(dict(source=source,recipient=recipient,condition=condition,kind=meta['kind'],identity=meta.get('identity'),parent=meta.get('parent'),angle=meta.get('angle'),pressure=meta.get('pressure',False),query_sha256=artifacts[-1]['raw_sha256'],receiver=result))
        print(json.dumps(dict(event='condition_complete',source=source,condition=condition,rows=len(rows),elapsed=time.monotonic()-started)),flush=True)
    save(dest,dict(status='complete',source=source,pilot=pilot,conditions=conditions,rows=rows,elapsed_seconds=time.monotonic()-started,inputs={str(folder/'all_rows.json'):sha(folder/'all_rows.json')},actual_query_EDF_hashes_match=True,diagnostic_clean_excluded_from_receiver=True))
    return rows

def freeze():
    rows=load(OUT/'A02T_raw.json')['rows'];rules=calibrate(rows)
    save(OUT/'freeze.json',dict(status='frozen_before_OpenBMI_new_receiver_scores',created_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),rules=rules,configs=CONFIGS,code={str(OUT/name):sha(OUT/name) for name in ('receiver_api.py','run_experiment.py','PROTOCOL.md')},dev_result_sha256=sha(OUT/'A02T_raw.json'),dev_queries=len(rows),test_outcomes_used=False,chronology='OpenBMI records were observed in prior P186/P187 methods; no P188 candidate receiver evaluation occurred before this freeze.'))
    print(json.dumps({m:r['selected'] for m,r in rules.items()}),flush=True)

def summarize():
    frozen=load(OUT/'freeze.json');rules=frozen['rules'];allrows=[]
    for source in ('A02T','OpenBMI003','OpenBMI004'):
        allrows+=apply_rules(load(OUT/f'{source}_raw.json')['rows'],rules)
    summary=[]
    for source in ('A02T','OpenBMI003','OpenBMI004','OpenBMI_all'):
        for method in METHODS:
            for condition in (*CONDITIONS,'all'):
                for kind in ('enrolled','near025','pressure0125','clean','wrong_source'):
                    def selected(r):
                        source_ok=(r['source'] in ('OpenBMI003','OpenBMI004')) if source=='OpenBMI_all' else r['source']==source
                        kind_ok=(r['kind']=='enrolled') if kind=='enrolled' else (r['angle']==.025) if kind=='near025' else (r['angle']==.0125) if kind=='pressure0125' else r['kind']==kind
                        return source_ok and (condition=='all' or r['condition']==condition) and kind_ok
                    z=[r for r in allrows if selected(r)]
                    summary.append(dict(source=source,method=method,condition=condition,kind=kind,n=len(z),accepted=sum(r['decisions'][method]>=0 for r in z),correct=sum(r['decisions'][method]==r['identity'] for r in z) if kind=='enrolled' else None,false_accept=sum(r['decisions'][method]>=0 for r in z) if kind!='enrolled' else None))
    save(OUT/'results.json',dict(status='complete',freeze_sha256=sha(OUT/'freeze.json'),rules=rules,summary=summary,rows=allrows,matching_access=True,fir_taps=129,scored_seconds=40,observed_seconds=48,dev_candidates_per_method=12,additional_issuance=False))
    for row in summary:
        if row['source']=='OpenBMI_all' and row['condition']=='all':print(json.dumps(row),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--stage',choices=('pilot','development','freeze','evaluation','summarize'),required=True);parser.add_argument('--source',choices=('OpenBMI003','OpenBMI004'));args=parser.parse_args()
    try:
        if args.stage=='pilot':collect('A02T',True)
        elif args.stage=='development':collect('A02T')
        elif args.stage=='freeze':freeze()
        elif args.stage=='evaluation':
            f=load(OUT/'freeze.json');assert all(sha(p)==h for p,h in f['code'].items());assert args.source
            collect(args.source)
        else:summarize()
    except BaseException:
        name=OUT/f'failure_{args.stage}_{args.source or "none"}_{int(time.time())}.json'
        save(name,dict(status='incomplete',traceback=traceback.format_exc()));raise
