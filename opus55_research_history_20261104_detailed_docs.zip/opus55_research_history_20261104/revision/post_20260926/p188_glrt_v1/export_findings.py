"""Export paired mechanism diagnostics, with no model or threshold changes."""
from pathlib import Path
import sys,json,csv
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(OUT))
import numpy as np
from receiver_api import METHODS,RIDGES

def load(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def csvwrite(path,rows):
    with path.open('x',encoding='utf-8-sig',newline='')as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

result=load(OUT/'results.json');csvwrite(OUT/'decision_summary.csv',result['summary'])
paired=[]
for source in ('A02T','OpenBMI003','OpenBMI004'):
    raw=load(OUT/f'{source}_raw.json')['rows']
    for row in raw:
        for method in METHODS:
            for ridge in RIDGES:
                a=row['receiver']['methods'][method]['by_ridge'][str(ridge)]
                d=row['receiver']['diagnostics'][method][str(ridge)]
                beta=np.asarray(a['beta']);parent=row.get('parent')
                unit=np.eye(8)[row['identity']] if row['kind']=='enrolled' else None
                paired.append(dict(source=source,phase='DEV'if source=='A02T'else'frozen_validation',condition=row['condition'],recipient=row['recipient'],kind=row['kind'],angle=row['angle'],parent=parent,method=method,ridge=ridge,top=a['top'],compatibility=a['compatibility'],relative_gap=a['relative_gap'],presence=a['presence'],beta_parent=float(beta[parent])if parent is not None else None,beta_unit_error_l2=float(np.linalg.norm(beta-unit))if unit is not None else None,beta_direction_cosine=float(beta@unit/max(np.linalg.norm(beta),1e-30))if unit is not None else None,identity_displacement_parent=float(d['identity_absorbed_coefficients'][parent])if parent is not None else None,identity_displacement_l2=float(np.linalg.norm(d['identity_absorbed_coefficients'])),response_prediction_displacement_relative_ordinary_clean_fit=d['response_prediction_bias_relative_clean_rms'],kernel_displacement_l2_relative_ordinary_clean_fit=d['kernel_delta_l2']))
csvwrite(OUT/'paired_mechanism_diagnostics.csv',paired)
mechanism=[]
for source in ('A02T','OpenBMI003','OpenBMI004','OpenBMI_all'):
    for condition in (*dict.fromkeys(r['condition']for r in paired),'all'):
        for method in METHODS:
            for ridge in RIDGES:
                z=[r for r in paired if r['kind']=='enrolled' and r['method']==method and r['ridge']==ridge and (r['source'] in ('OpenBMI003','OpenBMI004')if source=='OpenBMI_all'else r['source']==source)and(condition=='all'or r['condition']==condition)]
                mechanism.append(dict(source=source,condition=condition,method=method,ridge=ridge,n=len(z),mean_beta_parent=float(np.mean([r['beta_parent']for r in z])),mean_beta_unit_error_l2=float(np.mean([r['beta_unit_error_l2']for r in z])),mean_beta_direction_cosine=float(np.mean([r['beta_direction_cosine']for r in z])),mean_abs_identity_displacement_parent=float(np.mean([abs(r['identity_displacement_parent'])for r in z])),mean_response_prediction_displacement=float(np.mean([r['response_prediction_displacement_relative_ordinary_clean_fit']for r in z]))))
csvwrite(OUT/'registered_mechanism_summary.csv',mechanism)
lines=['# P188 equal-access receiver comparison','',
'All three methods have the same clean-reference/archive permission, coarse bank,',
'common median4 alignment,129 residual taps, absolute regularization, observed',
'contexts and twelve-candidate DEV budget. These results concern the smooth',
'carrier under a controlled receiver change. Existing native-head carrier',
'comparisons remain a separate panel.','',
'## Frozen two-record/eight-condition validation','',
'| Method | Registered correct |0.025 false accepts|0.0125 false accepts|Control false accepts|',
'|---|---:|---:|---:|---:|']
for method in METHODS:
    z={r['kind']:r for r in result['summary']if r['source']=='OpenBMI_all'and r['condition']=='all'and r['method']==method}
    control=sum(z[k]['false_accept']for k in ('clean','wrong_source'));ncontrol=sum(z[k]['n']for k in ('clean','wrong_source'))
    lines.append(f"|{method}|{z['enrolled']['correct']}/{z['enrolled']['n']}|{z['near025']['false_accept']}/{z['near025']['n']}|{z['pressure0125']['false_accept']}/{z['pressure0125']['n']}|{control}/{ncontrol}|")
lines+=['','## Same-ridge registered mechanism diagnostics','',
'Means below use the same rho1e-4 across128 matched registered queries. The',
'fitted identity coefficient is compared with the actual registered archive',
'unit coordinate. Displacements use the ordinary clean-query fit as a common',
'reference and include estimator/model differences; they are not errors against',
'a known physical filter impulse.','',
'| Method |Mean parent coefficient|Mean identity-vector L2 error|Mean abs parent displacement|Mean response displacement|',
'|---|---:|---:|---:|---:|']
for method in METHODS:
    z=next(r for r in mechanism if r['source']=='OpenBMI_all'and r['condition']=='all'and r['ridge']==1e-4 and r['method']==method)
    lines.append(f"|{method}|{z['mean_beta_parent']:.8f}|{z['mean_beta_unit_error_l2']:.6g}|{z['mean_abs_identity_displacement_parent']:.6g}|{z['mean_response_prediction_displacement']:.6g}|")
lines+=['','## Interpretation and provenance','',
'Ordinary clean-reference response fitting can absorb identity. Projection',
'removes its additive linear component. Candidate-conditioned full-waveform',
'fitting also retains response-times-identity convolution, and is a strong',
'classical comparator under the same available archive information. Its outcome',
'is retained even when stronger than the proposed shared projection. The',
'conditional likelihood family and finite variance ratios receive empirical',
'DEV calibration; no exact CFAR or general optimality claim follows.','',
'A02T supplies208 DEV queries before code/threshold freeze. OpenBMI003/004',
'then supply416 exact reconstructed queries. Their earlier P186/P187 outcomes',
'were known; this is a frozen receiver extension, not a newly sampled cohort.',
'The two sources are independent source units; copies and processing conditions',
'are repeated measures, and no query-level significance test is reported.','',
'The full candidate algorithm, actual formulas and algebra checks are in',
'receiver_api.py, METHOD_NOTES.md and algebra_check.json. Individual diagnostics',
'and all per-condition decision outcomes are exported as CSV. No E threshold',
'adjustments, source dropping or additional issuance occurred.']
(OUT/'FINDINGS.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print('\n'.join(lines[:18]),flush=True)
