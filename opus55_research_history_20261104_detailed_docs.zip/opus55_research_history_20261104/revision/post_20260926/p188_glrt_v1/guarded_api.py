"""V2 fixed presence gate; the frozen V1 raw-score implementation is unchanged."""
from receiver_api import METHODS,CONFIGS
import numpy as np
PRESENCE_GATE=.25

def v2_eligible(receiver_result,method,index):
    z=receiver_result['methods'][method]
    rho=CONFIGS[index]['ridge']
    a=z['by_ridge'][rho] if rho in z['by_ridge'] else z['by_ridge'][str(rho)]
    return bool(z['configs'][index]['eligible'] and a['presence']>=PRESENCE_GATE)

def calibrate_v2(rows):
    rules={}
    for method in METHODS:
        candidates=[]
        for i,config in enumerate(CONFIGS):
            negative=[r['receiver']['methods'][method]['configs'][i]['score']for r in rows if r['kind']!='enrolled'and not r.get('pressure',False)and v2_eligible(r['receiver'],method,i)]
            threshold=float(np.nextafter(max(negative),np.inf)) if negative else 0.
            enrolled=[r for r in rows if r['kind']=='enrolled']
            correct=sum(v2_eligible(r['receiver'],method,i)and r['receiver']['methods'][method]['configs'][i]['score']>=threshold and r['receiver']['methods'][method]['configs'][i]['top']==r['identity']for r in enrolled)
            candidates.append(dict(index=i,**config,threshold=threshold,registered_correct=correct,registered_n=len(enrolled),eligible_negative_n=len(negative),presence_gate=PRESENCE_GATE))
        selected=max(candidates,key=lambda z:(z['registered_correct'],-z['index']))
        rules[method]=dict(selected=selected,candidates=candidates)
    return rules

def apply_rules_v2(rows,rules):
    result=[]
    for row in rows:
        value={k:v for k,v in row.items()if k!='receiver'};value['decisions']={}
        for method in METHODS:
            rule=rules[method]['selected'];i=rule['index'];z=row['receiver']['methods'][method]['configs'][i]
            value['decisions'][method]=int(z['top'])if v2_eligible(row['receiver'],method,i)and z['score']>=rule['threshold']else-1
        result.append(value)
    return result
