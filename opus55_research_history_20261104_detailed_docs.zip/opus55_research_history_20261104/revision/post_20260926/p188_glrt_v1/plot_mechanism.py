"""Source-level paired diagnostics; no pseudoreplicated uncertainty bars."""
from pathlib import Path
import os,sys
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
os.environ['MPLCONFIGDIR']=str(OUT/'cache/matplotlib')
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

df=pd.read_csv(OUT/'registered_mechanism_summary.csv')
df=df[(df['condition']=='all')&(df['ridge']==1e-4)&df['source'].isin(['OpenBMI003','OpenBMI004'])]
methods=('ordinary_FIR','projected_FIR','candidate_FIR_GLRT');labels=('Ordinary FIR','Projected FIR','Candidate FIR')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8.5,'axes.labelsize':9,'axes.titlesize':9.5,'pdf.fonttype':42,'svg.fonttype':'none'})
fig,axes=plt.subplots(1,2,figsize=(7.0,2.55),layout='constrained')
for source,color,marker in [('OpenBMI003','#166b8c','o'),('OpenBMI004','#bc641c','s')]:
    z=df[df['source']==source].set_index('method').loc[list(methods)]
    for ax,column in zip(axes,('mean_beta_unit_error_l2','mean_response_prediction_displacement')):
        ax.plot(range(3),z[column],color=color,marker=marker,markersize=5,linewidth=1.4,label=source.replace('OpenBMI','Record '))
for ax in axes:
    ax.set_xticks(range(3),labels);ax.set_yscale('log');ax.grid(axis='y',which='major',alpha=.22);ax.spines[['top','right']].set_visible(False)
axes[0].set_title('(a) Identity coefficient distortion',loc='left',weight='bold')
axes[0].set_ylabel(r'Mean $\|\hat{\beta}-e_j\|_2$')
axes[1].set_title('(b) Clean-response displacement',loc='left',weight='bold')
axes[1].set_ylabel('Relative to clean-fit reference (RMS)')
axes[0].legend(frameon=False,loc='lower left',fontsize=8)
(OUT/'figures').mkdir(exist_ok=True)
fig.savefig(OUT/'figures/mechanism_diagnostics.pdf')
fig.savefig(OUT/'figures/mechanism_diagnostics.png',dpi=220)
print('Created paired source-level mechanism figure',flush=True)
