"""Bounded direct-array checks of the new candidate-convolution implementation."""
from pathlib import Path
import sys,os
OUT=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
sys.path[:0]=[str(OUT),str(OUT.parents[2])]
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import json
import numpy as np
from numpy.lib.stride_tricks import sliding_window_view
from receiver_api import MatchedFIRReceivers,old
from run_experiment import DEV,read,c,io,domain,save

with np.load(DEV/'clean.npz')as a:x=np.array(a['x']);h0=np.array(a['h0'])
book=np.array([read(DEV,f'smooth_r{i}_issued.edf.gz')for i in range(8)])
receiver=MatchedFIRReceivers(x,book);data,cw=receiver.design(0)
ys=[z['x']+z['T'][:,0].reshape(8,1280)*data['scale'] for z in data['windows']]
vs,bx,bt,cb=receiver._prepare(data,ys,cw)
cross_error=0.;gram_error=0.;rss_error=0.
for w,z in enumerate(data['windows']):
    for identity in (0,3,7):
        DX=sliding_window_view(z['ext'][identity],129,axis=-1)/data['scale']
        DX=(DX-DX.mean(axis=1,keepdims=True)).reshape(-1,129)
        A=z['X']+DX
        direct=A.T@(vs[w]-z['T'][:,identity])
        cross_error=max(cross_error,float(np.max(abs(direct-cb[w][identity]))))
        gram_error=max(gram_error,float(np.max(abs(A.T@A-cw[w]['xx'][identity]))))
    kernel=np.linspace(-.001,.001,129)
    G,b,d=receiver._stats(z,data,ys[w],kernel)
    for i in (0,3,7):
        v=old.vector(ys[w]-z['x'])/data['scale']-z['X']@kernel
        DX=sliding_window_view(z['ext'][i],129,axis=-1)/data['scale']
        DX=(DX-DX.mean(axis=1,keepdims=True)).reshape(-1,129)
        template=z['T'][:,i]+DX@kernel
        direct=float(np.sum((v-template)**2))
        rss_error=max(rss_error,abs(direct-(d+G[i,i]-2*b[i])))
assert cross_error<1e-8,cross_error
assert gram_error<1e-8,gram_error
assert rss_error<1e-9,rss_error
z=data['windows'][0];BT=sum(q['tt'] for q in data['windows'][1:])[:,0]
BB=sum(q['xt'] for q in data['windows'][1:])[:,0]
hp=z['inverse'][1e-6,True]@(BB-z['CT']@BT)
ho=z['inverse'][1e-6,False]@BB
assert np.linalg.norm(hp)<np.linalg.norm(ho)*1e-7
limits=c.p.ranges(x)
query,h=io.edf_roundtrip(book[0],limits,'algebra.edf',OUT/'scratch',[],False,domain.BCI_CHANNELS)
a=receiver.extract(query,h,h0)
b=receiver.extract(query,h,h0,diagnostic_clean=x)
assert a['methods']==b['methods'] and a['folds']==b['folds']
save(OUT/'algebra_check.json',dict(status='pass',direct_candidate_cross_max_abs=cross_error,candidate_gram_max_abs=gram_error,direct_RSS_max_abs=rss_error,linear_identity_only_projected_kernel_norm=float(np.linalg.norm(hp)),linear_identity_only_ordinary_kernel_norm=float(np.linalg.norm(ho)),clean_diagnostic_cannot_change_scores=True))
print(json.dumps(dict(status='pass',cross_error=cross_error,gram_error=gram_error,rss_error=rss_error)),flush=True)
