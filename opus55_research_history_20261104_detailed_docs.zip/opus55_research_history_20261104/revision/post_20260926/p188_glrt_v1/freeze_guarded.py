"""DEV-only, common fixed presence gate before direction-result unblinding."""
from pathlib import Path
import sys,time
OUT=Path(__file__).resolve().parent;sys.dont_write_bytecode=True;sys.path.insert(0,str(OUT))
from run_experiment import load,save,sha,METHODS
from guarded_api import calibrate_v2,apply_rules_v2,PRESENCE_GATE

rows=load(OUT/'A02T_raw.json')['rows'];rules=calibrate_v2(rows)
save(OUT/'freeze_v2.json',dict(status='frozen_before_direction_output_unblinding',utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),rules=rules,code={str(OUT/name):sha(OUT/name)for name in ('receiver_api.py','guarded_api.py','freeze_guarded.py')},DEV_sha256=sha(OUT/'A02T_raw.json'),prior_v1_freeze_sha256=sha(OUT/'freeze.json'),presence_gate=PRESENCE_GATE,presence_definition='max(0,1-R_best/R_ordinary_clean) clipped to1; fixed-amplitude clean-H0 improvement, not P181 unrestricted subspace energy_fraction',development_candidates_per_method=12,gate_selected_from_test=False,revision_reason='V1 receiver extension revealed five wrong-source accepts for projected/candidate conditional ratios. A fixed previously motivated .25 presence gate is applied identically; no gate search or E threshold optimization.',chronology='A V1 direction replay had just started when parent instructed gate revision first. That job was stopped; neither source raw output existed and no new direction scores/decisions were viewed. Partial computation before freeze is disclosed; V2 freeze is before direction-output unblinding rather than before all direction computation.',no_new_direction_outcomes_used=True))
print({m:r['selected']for m,r in rules.items()},flush=True)
allrows=[]
for source in ('A02T','OpenBMI003','OpenBMI004'):
    allrows+=apply_rules_v2(load(OUT/f'{source}_raw.json')['rows'],rules)
summary=[]
for method in METHODS:
    for kind in ('enrolled','near025','pressure0125','clean','wrong_source'):
        z=[r for r in allrows if r['source']!='A02T'and(r['kind']=='enrolled'if kind=='enrolled'else r['angle']==.025 if kind=='near025'else r['angle']==.0125 if kind=='pressure0125'else r['kind']==kind)]
        summary.append(dict(method=method,kind=kind,n=len(z),correct=sum(r['decisions'][method]==r['identity']for r in z)if kind=='enrolled'else None,false_accept=sum(r['decisions'][method]>=0 for r in z)if kind!='enrolled'else None))
save(OUT/'bridge416_v2_posthoc.json',dict(status='complete',classification='posthoc diagnostic replay of previously observed V1 receiver scores',rules_fitted_on_A02T_only=True,presence_gate=PRESENCE_GATE,summary=summary,rows=allrows))
for r in summary:print(r,flush=True)
