"""Fixed warm-cache branch timing, with exact score-parity checks.

Receiver source is copied in memory to omit unused branches, not altered on
disk. Common synchronization/contexts and all numerical expressions are kept.
Each method runs in a fresh subprocess so peak resident memory is comparable.
"""
from pathlib import Path
import sys,os
OUT=Path(__file__).resolve().parent;sys.dont_write_bytecode=True;sys.path.insert(0,str(OUT))
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import argparse,ctypes,inspect,json,subprocess,textwrap,time
import numpy as np
import receiver_api as api
from run_experiment import DEV,BASE,read,c,io,domain,save

def peak_rss():
    from ctypes import wintypes
    class Memory(ctypes.Structure):
        _fields_=[('cb',wintypes.DWORD),('PageFaultCount',wintypes.DWORD)]+[(k,ctypes.c_size_t)for k in('PeakWorkingSetSize','WorkingSetSize','QuotaPeakPagedPoolUsage','QuotaPagedPoolUsage','QuotaPeakNonPagedPoolUsage','QuotaNonPagedPoolUsage','PagefileUsage','PeakPagefileUsage')]
    getcurrent=ctypes.windll.kernel32.GetCurrentProcess;getcurrent.restype=wintypes.HANDLE
    get=ctypes.windll.psapi.GetProcessMemoryInfo;get.argtypes=[wintypes.HANDLE,ctypes.c_void_p,wintypes.DWORD]
    z=Memory();z.cb=ctypes.sizeof(z);assert get(getcurrent(),ctypes.byref(z),z.cb)
    return int(z.PeakWorkingSetSize)

def receiver_class(method):
    source=textwrap.dedent(inspect.getsource(api.MatchedFIRReceivers.extract))
    source=source.replace('for m in METHODS','for m in (BENCH_METHOD,)').replace('for method in METHODS:','for method in (BENCH_METHOD,):')
    before='for method,kernels in zip(METHODS,((ho,),(hp,),hc)):'
    assert source.count(before)==1
    source=source.replace(before,"for method,kernels in ((BENCH_METHOD,{'ordinary_FIR':(ho,),'projected_FIR':(hp,),'candidate_FIR_GLRT':hc}[BENCH_METHOD]),):")
    before="clean_rss[ridge].append(stats['ordinary_FIR'][ridge][-1][0][2])"
    assert source.count(before)==1
    source=source.replace(before,'clean_rss[ridge].append(clean_energy(z,data,ys[w],ho))')
    if method!='candidate_FIR_GLRT':
        before="hc=np.einsum('nij,nj->ni',cw[w]['inverse'][ridge],CB)";assert source.count(before)==1
        source=source.replace(before,'hc=()')
    def clean_energy(z,data,yy,kernel):
        reference=z['x']+(z['X']@kernel).reshape(8,1280)*data['scale']
        v=api.old.vector(yy-reference)/data['scale']
        return float(v@v)
    namespace=dict(api.__dict__,BENCH_METHOD=method,clean_energy=clean_energy);exec(compile(source,f'<benchmark-only:{method}>','exec'),namespace)
    def shared_design(self,k):
        data=self.receiver.design(k)
        if '_bench_shared_abs'not in data:
            ws=data['windows']
            for w,z in enumerate(ws):
                G=sum(ws[j]['xx']for j in range(5)if j!=w);C=sum(ws[j]['xt']for j in range(5)if j!=w);TT=sum(ws[j]['tt']for j in range(5)if j!=w);P=G-C@np.linalg.pinv(TT,rcond=1e-9)@C.T
                for rho in api.RIDGES:
                    z['inverse'][rho,False]=api._inv(G,rho)
                    z['inverse'][rho,True]=api._inv(P,rho,np.trace(G)/len(G))
            data['_bench_shared_abs']=True
        return data,None
    def shared_prepare(data,ys,cw):
        vs=[api.old.vector(yy-z['x'])/data['scale']for yy,z in zip(ys,data['windows'])]
        bx=[z['X'].T@v for z,v in zip(data['windows'],vs)];bt=[z['T'].T@v for z,v in zip(data['windows'],vs)]
        return vs,bx,bt,[np.zeros((8,129))for _ in range(5)]
    attrs=dict(extract=namespace['extract'])
    if method!='candidate_FIR_GLRT':attrs.update(design=shared_design,_prepare=staticmethod(shared_prepare))
    return type('OneMethodBenchmark',(api.MatchedFIRReceivers,),attrs)

def child(method):
    with np.load(DEV/'clean.npz')as z:x=np.array(z['x']);h0=np.array(z['h0'])
    with np.load(BASE/'p186_five_arm_bridge_v1/A01T/clean.npz')as z:wrong=np.array(z['x'])
    book=np.array([read(DEV,f'smooth_r{i}_issued.edf.gz')for i in range(8)])
    copies=[book[0],read(DEV,'smooth_r8_issued.edf.gz'),read(DEV,'smooth_r16_issued.edf.gz'),x]
    cases=[]
    for condition in ('reexport','bessel_shifted_causal'):
        limits=c.p.ranges(np.concatenate([c.transform(x,condition),c.transform(wrong,condition)],axis=1))
        for i,copy in enumerate(copies):
            y,h=io.edf_roundtrip(c.transform(copy,condition),limits,'bench.edf',OUT/'scratch',[],False,domain.BCI_CHANNELS)
            cases.append((condition,i,y,h))
    started=time.perf_counter();receiver=receiver_class(method)(x,book)
    outputs=[receiver.extract(y,h,h0)for _,_,y,h in cases]
    cold=time.perf_counter()-started
    latencies=[]
    for repeat in range(2):
        for _,_,y,h in cases:
            t=time.perf_counter();receiver.extract(y,h,h0);latencies.append(time.perf_counter()-t)
    measured_rss=peak_rss()
    # Cross-check *all eight* fixed cases against the full receiver. This work
    # occurs after the peak-RSS snapshot and is excluded from timing.
    full=api.MatchedFIRReceivers(x,book)
    error=0.
    for (_,_,y,h),a in zip(cases,outputs):
        b=full.extract(y,h,h0)
        assert a['methods'][method]==b['methods'][method]
    save(OUT/f'benchmark_branch_{method}.json',dict(status='complete',method=method,fixed_cases=8,warm_timed_queries=16,initialization_and_first_eight_seconds=cold,mean_warm_seconds=float(np.mean(latencies)),median_warm_seconds=float(np.median(latencies)),min_warm_seconds=min(latencies),max_warm_seconds=max(latencies),latencies=latencies,peak_resident_bytes_before_parity=measured_rss,exact_all_eight_case_method_parity=True,threads=1,includes='shared coarse-bank matching, synchronization, context filtering, method response fit and scoring',excludes='EDF issuance/serialization, cold design construction and unrelated receiver branches'))
    print(json.dumps(dict(method=method,mean_warm_seconds=np.mean(latencies),peak_resident_bytes=measured_rss)),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--method',choices=api.METHODS);args=parser.parse_args()
    if args.method:child(args.method)
    else:
        for method in api.METHODS:subprocess.run([sys.executable,str(Path(__file__)),'--method',method],check=True,cwd=OUT)
        rows=[json.loads((OUT/f'benchmark_branch_{m}.json').read_text())for m in api.METHODS]
        save(OUT/'benchmark_results.json',dict(status='complete',design='fresh process per method; identical A02T eight-case two-condition fixed subset, all eight exact parity checked; each16 warm calls, one CPU thread',results=rows))
