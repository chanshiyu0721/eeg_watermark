"""Equal-access, equal-order cross-fitted response-estimator comparison.

The candidate branch estimates a distinct 129-tap response from each of the
eight *actual serialized archive copies*. All branches see the same four
training windows and common coarse-model/alignment selected from clean refs.
The held-out window supplies detection evidence, never response coefficients.

Conditional spherical-residual likelihood statistics are empirically calibrated;
the cross-fitted, query-selected design has no asserted exact CFAR distribution.
"""
from pathlib import Path
import os,sys
sys.dont_write_bytecode=True
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[key]='1'
ROOT=Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
import numpy as np
from scipy.signal import fftconvolve
from numpy.lib.stride_tricks import sliding_window_view
from revision.post_20260926 import p181_receiver as recv,p181_common as c
p=c.p;old=c.r.old
METHODS=('ordinary_FIR','projected_FIR','candidate_FIR_GLRT')
RIDGES=(1e-4,1e-6)
HEADS=('compatibility','relative_gap','presence')
CONFIGS=tuple(dict(ridge=r,head=h,support=s) for r in RIDGES for h in HEADS for s in (1,3))

def _inv(G,ridge,absolute_scale=None):
    G=(G+G.T)/2
    scale=np.trace(G)/len(G) if absolute_scale is None else absolute_scale
    return np.linalg.inv(G+ridge*scale*np.eye(len(G)))

class MatchedFIRReceivers:
    def __init__(self,x,book):
        assert x.shape==(8,17920) and book.shape==(8,8,17920)
        self.receiver=recv.Receiver(x,book)
        self.candidate={}

    def design(self,k):
        data=self.receiver.design(k)
        if k in self.candidate:return data,self.candidate[k]
        ws=data['windows'];cw=[]
        for z in ws:
            G=sum(q['xx'] for q in ws if q is not z)
            cross=sum(q['xt'] for q in ws if q is not z)
            TT=sum(q['tt'] for q in ws if q is not z)
            P=G-cross@np.linalg.pinv(TT,rcond=1e-9)@cross.T
            for ridge in RIDGES:
                # Hold absolute regularization fixed across projection and
                # candidate dictionaries; trace(P) would be a confound here.
                z['inverse'][ridge,False]=_inv(G,ridge)
                z['inverse'][ridge,True]=_inv(P,ridge,np.trace(G)/len(G))
            xx=[];xt=[]
            for identity in range(8):
                DX=sliding_window_view(z['ext'][identity],129,axis=-1)/data['scale']
                DX=DX-DX.mean(axis=1,keepdims=True)
                XX=z['X']+DX.reshape(-1,129)
                xx.append(XX.T@XX)
                xt.append(XX.T@z['T'][:,identity])
            cw.append(dict(xx=np.array(xx),xt=np.array(xt)))
        for w,z in enumerate(cw):
            G=sum(cw[j]['xx'] for j in range(5) if j!=w)
            cleanG=sum(ws[j]['xx'] for j in range(5) if j!=w)
            z['inverse']={ridge:np.array([_inv(g,ridge,np.trace(cleanG)/len(cleanG)) for g in G]) for ridge in RIDGES}
        self.candidate[k]=cw
        return data,cw

    @staticmethod
    def _prepare(data,ys,cw):
        vs=[old.vector(yy-z['x'])/data['scale'] for yy,z in zip(ys,data['windows'])]
        bx=[z['X'].T@v for z,v in zip(data['windows'],vs)]
        bt=[z['T'].T@v for z,v in zip(data['windows'],vs)]
        cb=[]
        for z,cc,v,bb in zip(data['windows'],cw,vs,bx):
            # Correlation computes delta-convolution design products without
            # retaining 8x5 full tall matrices in memory. v is channel-centered.
            vv=v.reshape(8,1280)
            cross=fftconvolve(z['ext'],vv[None,:,::-1],mode='valid',axes=-1).sum(axis=1)/data['scale']
            cb.append(bb[None,:]+cross-cc['xt'])
        return vs,bx,bt,cb

    @staticmethod
    def _stats(z,data,yy,kernel):
        reference=z['x']+(z['X']@kernel).reshape(8,1280)*data['scale']
        delta=z['ext'][:,:,64:1344]+fftconvolve(z['ext'],kernel[None,None,::-1],mode='valid',axes=-1)
        T=np.column_stack([old.vector(a) for a in delta])/data['scale']
        v=old.vector(yy-reference)/data['scale']
        return T.T@T,T.T@v,float(v@v)

    def extract(self,y,h=None,h0=None,diagnostic_clean=None):
        """Return label-free raw scores; optional clean is diagnostics ONLY.

        diagnostic_clean is the paired transformed clean EDF query. It never
        affects model choice, fitted kernels, likelihood statistics or decisions.
        It measures change relative to a same-design, four-window clean fit.
        """
        _,lags,peaks,errors=old.blind_match(self.receiver.refs,y)
        chosen=np.array([np.argmin(np.sum(errors[:,[j for j in range(5) if j!=w]],axis=1)) for w in range(5)])
        buffers=[p.filt(p.center(y[:,st*160-128:(st+8)*160+128])) for st in p.STARTS]
        clean_buffers=None if diagnostic_clean is None else [p.filt(p.center(diagnostic_clean[:,st*160-128:(st+8)*160+128])) for st in p.STARTS]
        prep={};folds=[]
        stats={m:{r:[] for r in RIDGES} for m in METHODS}
        diag={m:{r:[] for r in RIDGES} for m in METHODS}
        clean_rss={r:[] for r in RIDGES}
        for w in range(5):
            ids=[j for j in range(5) if j!=w];k=int(chosen[w]);delay=recv.lower_median(lags[k,ids]);key=(k,delay)
            if key not in prep:
                data,cw=self.design(k)
                ys=[buf[:,128+delay:1408+delay] for buf in buffers]
                vs,bx,bt,cb=self._prepare(data,ys,cw)
                clean_bx=None
                if clean_buffers is not None:
                    clean_ys=[buf[:,128+delay:1408+delay] for buf in clean_buffers]
                    clean_bx=[z['X'].T@(old.vector(yy-z['x'])/data['scale']) for z,yy in zip(data['windows'],clean_ys)]
                prep[key]=(data,cw,ys,vs,bx,bt,cb,clean_bx)
            data,cw,ys,vs,bx,bt,cb,clean_bx=prep[key];z=data['windows'][w]
            BB=sum(bx[j] for j in ids);BT=sum(bt[j] for j in ids);CB=sum(cb[j] for j in ids)
            fold=dict(model=k,delay=delay,peak=float(peaks[k,w]));folds.append(fold)
            for ridge in RIDGES:
                ho=z['inverse'][ridge,False]@BB
                hp=z['inverse'][ridge,True]@(BB-z['CT']@BT)
                hc=np.einsum('nij,nj->ni',cw[w]['inverse'][ridge],CB)
                hclean=None if clean_bx is None else z['inverse'][ridge,False]@sum(clean_bx[j] for j in ids)
                for method,kernels in zip(METHODS,((ho,),(hp,),hc)):
                    entries=[];dd=[]
                    for kernel in kernels:
                        G,b,d=self._stats(z,data,ys[w],kernel)
                        entries.append((G,b,d))
                        if hclean is not None:
                            displacement=z['X']@(kernel-hclean)
                            leak=np.linalg.lstsq(z['T'],displacement,rcond=1e-8)[0]
                            dd.append(dict(identity_absorbed_coefficients=leak.tolist(),response_prediction_bias_relative_clean_rms=float(np.linalg.norm(displacement)/max(np.linalg.norm(old.vector(z['x'])/data['scale']),1e-30)),kernel_delta_l2=float(np.linalg.norm(kernel-hclean))))
                    stats[method][ridge].append(entries)
                    diag[method][ridge].append(dd)
                # Optimized clean-H0 model uses the ordinary clean-reference fit
                # for every branch, including candidate-specific response fits.
                clean_rss[ridge].append(stats['ordinary_FIR'][ridge][-1][0][2])
        methods={};diagnostics={}
        for method in METHODS:
            by_ridge={}
            for ridge in RIDGES:
                ss=stats[method][ridge]
                if method!='candidate_FIR_GLRT':
                    pooled=[tuple(sum(row[0][j] for row in ss) for j in range(3))]
                else:pooled=[tuple(sum(row[i][j] for row in ss) for j in range(3)) for i in range(8)]
                rss=[];full=[];gains=[];betas=[];windowrss=[]
                for i in range(8):
                    G,b,d=pooled[i if method=='candidate_FIR_GLRT' else 0]
                    beta=np.linalg.lstsq(G,b,rcond=1e-7)[0]
                    rss.append(max(0.,float(d+G[i,i]-2*b[i])))
                    full.append(max(0.,float(d-b@beta)))
                    gains.append(float(2*b[i]-G[i,i]));betas.append(beta)
                order=np.argsort(rss,kind='stable');top=int(order[0]);R=float(rss[top]);R2=float(rss[order[1]])
                # Unrestricted identity alternative receives the same finite
                # conditional nuisance fits; it contains every fixed identity.
                RU=min(full) if method=='candidate_FIR_GLRT' else full[0]
                scale=max(sum(t[2] for t in pooled),sum(np.trace(t[0]) for t in pooled),1e-30)
                floor=64*np.finfo(float).eps*scale
                compatibility=1. if R<=floor else RU/R
                presence=1.-R/max(sum(clean_rss[ridge]),floor)
                gap=(R2-R)/max(R2,floor)
                for row in ss:
                    rr=[]
                    for i in range(8):
                        G,b,d=row[i if method=='candidate_FIR_GLRT' else 0]
                        rr.append(max(0.,float(d+G[i,i]-2*b[i])))
                    windowrss.append(rr)
                support=int((np.argmin(windowrss,axis=1)==top).sum())
                eligible=bool(gains[top]>0 and np.median([f['peak'] for f in folds])>=0)
                by_ridge[ridge]=dict(top=top,compatibility=float(np.clip(compatibility,0,1)),relative_gap=float(np.clip(gap,0,1)),presence=float(np.clip(presence,0,1)),support=support,eligible=eligible,candidate_RSS=rss,unrestricted_RSS=RU,clean_RSS=sum(clean_rss[ridge]),beta=betas[top].tolist())
            configs=[]
            for config in CONFIGS:
                a=by_ridge[config['ridge']]
                configs.append(dict(score=a[config['head']],top=a['top'],eligible=a['eligible']and a['support']>=config['support']))
            methods[method]=dict(configs=configs,by_ridge=by_ridge)
            if diagnostic_clean is not None:
                diagnostics[method]={}
                for ridge in RIDGES:
                    i=by_ridge[ridge]['top'] if method=='candidate_FIR_GLRT' else 0
                    dd=[row[i] for row in diag[method][ridge]]
                    diagnostics[method][ridge]=dict(identity_absorbed_coefficients=np.mean([r['identity_absorbed_coefficients'] for r in dd],axis=0).tolist(),response_prediction_bias_relative_clean_rms=float(np.mean([r['response_prediction_bias_relative_clean_rms'] for r in dd])),kernel_delta_l2=float(np.mean([r['kernel_delta_l2'] for r in dd])))
        return dict(methods=methods,folds=folds,diagnostics=diagnostics)

def calibrate(rows):
    """Same 12 candidates, same threshold policy and deterministic order each."""
    rules={}
    for method in METHODS:
        candidates=[]
        for i,config in enumerate(CONFIGS):
            negative=[r['receiver']['methods'][method]['configs'][i]['score'] for r in rows if r['kind']!='enrolled' and not r.get('pressure',False) and r['receiver']['methods'][method]['configs'][i]['eligible']]
            threshold=float(np.nextafter(max(negative),np.inf)) if negative else 0.
            enrolled=[r for r in rows if r['kind']=='enrolled']
            correct=sum(r['receiver']['methods'][method]['configs'][i]['eligible'] and r['receiver']['methods'][method]['configs'][i]['score']>=threshold and r['receiver']['methods'][method]['configs'][i]['top']==r['identity'] for r in enrolled)
            candidates.append(dict(index=i,**config,threshold=threshold,registered_correct=correct,registered_n=len(enrolled),eligible_negative_n=len(negative)))
        selected=max(candidates,key=lambda z:(z['registered_correct'],-z['index']))
        rules[method]=dict(selected=selected,candidates=candidates)
    return rules

def apply_rules(rows,rules):
    result=[]
    for row in rows:
        value={k:v for k,v in row.items() if k!='receiver'};value['decisions']={}
        for method in METHODS:
            rule=rules[method]['selected'];z=row['receiver']['methods'][method]['configs'][rule['index']]
            value['decisions'][method]=int(z['top']) if z['eligible'] and z['score']>=rule['threshold'] else -1
        result.append(value)
    return result
