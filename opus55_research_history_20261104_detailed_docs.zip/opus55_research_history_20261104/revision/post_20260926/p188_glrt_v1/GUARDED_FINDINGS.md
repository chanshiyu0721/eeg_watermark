# Fixed presence gate, direction transfer, and receiver cost

## The controlled comparison and its retained failure

All three methods have the same reference/archive permission, coarse bank,
median4 alignment,129 residual-FIR taps, absolute lambda based on clean G,
four-window response training context, and twelve-candidate DEV budget.

The initial V1 conditional ratio admitted five wrong-source controls out of32
for both projected and candidate fitting. The complete V1 outcome is retained
in results.json/FINDINGS.md: ordinary87/128 registered with69/128 near025 and
81/128 pressure accepts; projected117/128 with0/128 and0/128; candidate127/128
with0/128 and0/128. All five V1 control accepts arose on OpenBMI004. This is
the familiar failure of residual compatibility near1 in large orthogonal error.

V2 applies the same fixed presence gate to every method:
`presence = clip(1 - R_best/R_ordinary_clean,0,1) >= .25`.
This is fixed-amplitude improvement over the fitted clean null. It differs
from the old P181 unrestricted-subspace explained-energy fraction. There is
no gate search. Each method's same twelve candidates are calibrated again on
A02T only, before new direction outputs are viewed. Removing high-compatibility
wrong-source DEV negatives lowers the projected/candidate decision threshold;
the V2 coverage/pressure change reflects this recalibration as well as the gate.

## V2 replay of previously observed bridge queries

This panel is posthoc diagnostic replay of existing receiver scores, not a
fresh independent confirmation after the gate change.

| Method | Registered correct |0.025 FA|0.0125 FA|Clean/wrong FA|
|---|---:|---:|---:|---:|
|ordinary FIR|87/128|69/128|81/128|0/32|
|projected FIR|120/128|0/128|5/128|0/32|
|candidate FIR/conditional GLRT|128/128|0/128|5/128|0/32|

## New P181-direction receiver outputs after V2 freeze

The same original receiver score code and V1/V2 rules are applied to384 exact
smooth-query EDFs, spanning two retained OpenBMI records, eight conditions,
two0.025 tangent directions and one0.0125 pressure direction. These are different
near codes from the earlier P186 bridge; they are not additional participants.

| Method |0.025 dir0 FA|0.025 dir1 FA|0.0125 dir0 FA|
|---|---:|---:|---:|
|ordinary FIR,V2|71/128|68/128|81/128|
|projected FIR,V2|0/128|0/128|18/128|
|candidate FIR,V2|0/128|0/128|19/128|

The tighter V1 thresholds reject all three near groups for projected/candidate,
with the previously reported coverage and control failures. Original native
phase+wave decisions are a different frozen head and remain separately reported.

Chronology: an initial V1 direction computation started just before the parent
instructed V2 freezing first. It was stopped before either source raw output
file existed and before any direction numerical score or decision was viewed.
V2's single fixed gate and DEV recalibration were frozen before direction-output
unblinding. The earlier partial computation is disclosed; the data are not
represented as wholly uncomputed before V2 freeze.

## Coefficient distortion and response displacement

At the same rho1e-4 on128 matched held-out registered queries, the mean fitted
identity-vector distance from its actual archive unit coordinate is
0.0207223/0.00366524/0.00177775 for ordinary/projected/candidate fitting. The
corresponding mean parent coefficients are1.00440766/1.00014947/0.99995866.
Ordinary fitting therefore distorts the coefficient vector rather than causing
universal attenuation. All source/condition directions are preserved in
paired_mechanism_diagnostics.csv and registered_mechanism_summary.csv.

Mean predicted clean-response displacement relative to the same-design ordinary
clean-query fit is0.00113957/0.000139278/0.0000120992, in clean-RMS units. This
common evaluation reference includes estimator/model differences and is not a
known physical impulse-response oracle. The clean evaluation control never
changes extraction scores; direct parity checks establish that separation.

## Fixed warm-cache implementation cost

Eight fixed A02T cases cover reexport/causal Bessel, registered/near/pressure/clean.
Each method has its own subprocess and16 warmed calls on one CPU thread. In-memory
branch extraction preserves exact outputs in all eight cases. Measurements include
coarse matching, synchronization, context filtering, fitting and readout, while
excluding EDF serialization and cold reference-design construction.

| Method |Mean warm query|Peak resident memory|Initialization + first8|
|---|---:|---:|---:|
|ordinary FIR|75.25ms|376.85MiB|0.889s|
|projected FIR|75.02ms|376.97MiB|0.885s|
|candidate FIR|222.23ms|415.36MiB|3.612s|

Projection is about2.96x faster in this implementation, while the stronger
candidate comparator has higher registered coverage in the V2 bridge panel.
Cost and reliability are an observed tradeoff. The query bytes and reference
reuse are equal; these timings are a fixed implementation benchmark rather
than an asymptotic or platform-wide speed guarantee.

## Reproduction entries

- receiver_api.py: frozen raw scores and original V1 calibration.
- guarded_api.py: V2 eligibility, DEV calibration and rule application.
- freeze.json/freeze_v2.json: input and rule provenance.
- direction_extension_results_v2.json: V1/V2 paired direction decisions.
- bridge416_v2_posthoc.json: explicitly posthoc bridge replay.
- benchmark_results.json: all sixteen latencies per method and parity evidence.
- algebra_check.json: direct tall-matrix/FFT and held-out energy checks.
