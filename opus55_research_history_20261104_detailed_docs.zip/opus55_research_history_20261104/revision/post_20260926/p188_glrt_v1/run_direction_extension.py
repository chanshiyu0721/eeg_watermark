"""Apply the unchanged P188 receiver freeze to P181 near-code directions."""
from pathlib import Path
import os,sys,json,time
OUT=Path(__file__).resolve().parent;sys.dont_write_bytecode=True;sys.path.insert(0,str(OUT))
from run_experiment import EVAL,BASE,load,save,sha,read,c,io,domain,np,MatchedFIRReceivers,METHODS,apply_rules
DIRECTIONS=BASE/'p188_neighbors_qim_v1'

def main():
    freeze=load(OUT/'freeze.json')
    assert all(sha(p)==h for p,h in freeze['code'].items())
    original=load(DIRECTIONS/'DIRECTION_FREEZE.json')
    inputs={str(OUT/'freeze.json'):sha(OUT/'freeze.json'),str(Path(__file__)):sha(__file__),str(DIRECTIONS/'DIRECTION_FREEZE.json'):sha(DIRECTIONS/'DIRECTION_FREEZE.json')}
    state=dict(status='frozen_before_new_direction_receiver_scores',utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),inputs=inputs,receiver_rule_change=False,registered_or_control_rerun=False,planned_queries=384,prior_native_direction_outcomes_already_seen=True)
    save(OUT/'direction_extension_freeze.json',state)
    allrows=[];started=time.monotonic()
    for source,other in (('OpenBMI003','OpenBMI004'),('OpenBMI004','OpenBMI003')):
        folder=EVAL/source
        with np.load(folder/'clean.npz')as z:x=np.array(z['x']);h0=np.array(z['h0'])
        with np.load(EVAL/other/'clean.npz')as z:wrong=np.array(z['x'])
        book=np.array([read(folder,f'smooth_r{i}_issued.edf.gz')for i in range(8)])
        receiver=MatchedFIRReceivers(x,book)
        expected={(r['index'],r['condition']):r for r in load(DIRECTIONS/f'{source}_smooth_direction_results.json')['rows']}
        copies=[read(DIRECTIONS,f'{source}_smooth_near{i}_issued.edf.gz')for i in range(24)]
        rows=[];artifacts=[]
        for condition in original['conditions']:
            limits=c.p.ranges(np.concatenate([c.transform(x,condition),c.transform(wrong,condition)],axis=1))
            for i,(copy,meta)in enumerate(zip(copies,original['fixed_metadata'])):
                query,h=io.edf_roundtrip(c.transform(copy,condition),limits,f'smooth_{condition}_near{i}.edf',OUT/'scratch',artifacts,False,domain.BCI_CHANNELS)
                assert artifacts[-1]['raw_sha256']==expected[i,condition]['query_raw_sha256']
                result=receiver.extract(query,h,h0)
                rows.append(dict(source=source,recipient=i,condition=condition,**meta,query_sha256=artifacts[-1]['raw_sha256'],receiver=result))
            print(json.dumps(dict(source=source,condition=condition,queries=len(rows),elapsed=time.monotonic()-started)),flush=True)
        save(OUT/f'{source}_direction_raw.json',dict(status='complete',rows=rows,queries=192,exact_query_EDF_reconstruction=True))
        allrows+=apply_rules(rows,freeze['rules'])
    summary=[]
    for method in METHODS:
        for source in ('OpenBMI003','OpenBMI004','all'):
            for direction,angle in ((0,.0125),(0,.025),(1,.025)):
                for condition in (*original['conditions'],'all'):
                    z=[r for r in allrows if(source=='all'or r['source']==source)and r['direction']==direction and r['angle']==angle and(condition=='all'or r['condition']==condition)]
                    summary.append(dict(method=method,source=source,direction=direction,angle=angle,condition=condition,n=len(z),false_accept=sum(r['decisions'][method]>=0 for r in z)))
    save(OUT/'direction_extension_results.json',dict(status='complete',queries=384,rules_unchanged=True,freeze_sha256=sha(OUT/'freeze.json'),summary=summary,rows=allrows,elapsed_seconds=time.monotonic()-started))
    for r in summary:
        if r['source']=='all'and r['condition']=='all':print(json.dumps(r),flush=True)

if __name__=='__main__':main()
