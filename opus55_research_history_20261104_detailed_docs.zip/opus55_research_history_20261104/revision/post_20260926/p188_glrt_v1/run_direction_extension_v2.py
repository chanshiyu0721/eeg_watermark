"""Unblind unchanged V1 and fixed-gate V2 on P181 near-code directions."""
from pathlib import Path
import sys,time
OUT=Path(__file__).resolve().parent;sys.dont_write_bytecode=True;sys.path.insert(0,str(OUT))
from run_experiment import EVAL,BASE,load,save,sha,read,c,io,domain,np,MatchedFIRReceivers,METHODS,apply_rules
from guarded_api import apply_rules_v2
DIRECTIONS=BASE/'p188_neighbors_qim_v1'

def main():
    freeze=load(OUT/'freeze.json');v2=load(OUT/'freeze_v2.json')
    assert all(sha(p)==h for p,h in freeze['code'].items())
    assert all(sha(p)==h for p,h in v2['code'].items())
    original=load(DIRECTIONS/'DIRECTION_FREEZE.json')
    save(OUT/'direction_extension_freeze_v2.json',dict(status='frozen_before_direction_output_unblinding',utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),v1_freeze_sha256=sha(OUT/'freeze.json'),v2_freeze_sha256=sha(OUT/'freeze_v2.json'),direction_pool_sha256=sha(DIRECTIONS/'DIRECTION_FREEZE.json'),runner_sha256=sha(__file__),receiver_rules_changed=False,planned_queries=384,registered_or_controls_repeated=False,earlier_V1_partial_calculation_stopped_without_outputs=True))
    allrows=[];started=time.monotonic()
    for source,other in (('OpenBMI003','OpenBMI004'),('OpenBMI004','OpenBMI003')):
        folder=EVAL/source
        with np.load(folder/'clean.npz')as z:x=np.array(z['x']);h0=np.array(z['h0'])
        with np.load(EVAL/other/'clean.npz')as z:wrong=np.array(z['x'])
        book=np.array([read(folder,f'smooth_r{i}_issued.edf.gz')for i in range(8)])
        receiver=MatchedFIRReceivers(x,book)
        expected={(r['index'],r['condition']):r for r in load(DIRECTIONS/f'{source}_smooth_direction_results.json')['rows']}
        copies=[read(DIRECTIONS,f'{source}_smooth_near{i}_issued.edf.gz')for i in range(24)]
        rows=[];artifacts=[]
        for condition in original['conditions']:
            limits=c.p.ranges(np.concatenate([c.transform(x,condition),c.transform(wrong,condition)],axis=1))
            for i,(copy,meta)in enumerate(zip(copies,original['fixed_metadata'])):
                query,h=io.edf_roundtrip(c.transform(copy,condition),limits,f'smooth_{condition}_near{i}.edf',OUT/'scratch',artifacts,False,domain.BCI_CHANNELS)
                assert artifacts[-1]['raw_sha256']==expected[i,condition]['query_raw_sha256']
                result=receiver.extract(query,h,h0)
                rows.append(dict(source=source,recipient=i,condition=condition,**meta,query_sha256=artifacts[-1]['raw_sha256'],receiver=result))
            print(dict(event='direction_condition',source=source,condition=condition,queries=len(rows),elapsed=time.monotonic()-started),flush=True)
        save(OUT/f'{source}_direction_raw_v2.json',dict(status='complete',rows=rows,queries=192,exact_query_EDF_reconstruction=True))
        a=apply_rules(rows,freeze['rules']);b=apply_rules_v2(rows,v2['rules'])
        for aa,bb in zip(a,b):
            aa['v1_decisions']=aa.pop('decisions');aa['v2_decisions']=bb['decisions'];allrows.append(aa)
    summary=[]
    for version in ('v1','v2'):
        for method in METHODS:
            for source in ('OpenBMI003','OpenBMI004','all'):
                for direction,angle in ((0,.0125),(0,.025),(1,.025)):
                    for condition in (*original['conditions'],'all'):
                        z=[r for r in allrows if(source=='all'or r['source']==source)and r['direction']==direction and r['angle']==angle and(condition=='all'or r['condition']==condition)]
                        summary.append(dict(version=version,method=method,source=source,direction=direction,angle=angle,condition=condition,n=len(z),false_accept=sum(r[version+'_decisions'][method]>=0 for r in z)))
    save(OUT/'direction_extension_results_v2.json',dict(status='complete',queries=384,rules_unchanged=True,v1_freeze_sha256=sha(OUT/'freeze.json'),v2_freeze_sha256=sha(OUT/'freeze_v2.json'),summary=summary,rows=allrows,elapsed_seconds=time.monotonic()-started,chronology='V2 fixed gate defined/frozen before direction numerical outcomes were unblinded. An earlier V1 partial computation was stopped without raw result files; not represented as completely uncomputed data.'))
    for r in summary:
        if r['source']=='all'and r['condition']=='all':print(r,flush=True)

if __name__=='__main__':main()
