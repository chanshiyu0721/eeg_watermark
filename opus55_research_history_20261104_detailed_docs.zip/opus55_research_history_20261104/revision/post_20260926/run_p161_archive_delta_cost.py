"""Read-only lossless EDF archive-delta cost audit on P160 issued files."""

import hashlib
import json
import zlib
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE / 'p160_prospective_edf16_bdf24_v1'
ISSUED = ROOT / 'issued'
OUT = HERE / 'p161_archive_delta_cost_v1'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    if OUT.exists():
        raise FileExistsError(OUT)
    p160 = json.loads((ROOT / 'results.json').read_bytes())
    issuance = json.loads((ISSUED / 'results.json').read_bytes())
    known = {r['file']: r['sha256'] for r in issuance['artifacts']}
    if len(known) != 88:
        raise RuntimeError('P160 issuance artifact count drift')
    rows = []
    for source in ('sleep', 'chb'):
        for arm in ('phase', 'qim'):
            prefix = f'{source}_{arm}'
            clean_path = ISSUED / f'{prefix}_clean_full.edf'
            clean = clean_path.read_bytes()
            if sha(clean) != known[clean_path.name]:
                raise RuntimeError(f'clean hash drift: {clean_path}')
            for recipient in range(16):
                path = ISSUED / f'{prefix}_{recipient}_full.edf'
                candidate = path.read_bytes()
                if sha(candidate) != known[path.name]:
                    raise RuntimeError(f'candidate hash drift: {path}')
                if len(candidate) != len(clean):
                    raise RuntimeError(f'EDF length differs: {path}')
                delta = bytes(a ^ b for a, b in zip(candidate, clean))
                packed = zlib.compress(delta, level=9)
                restored = bytes(a ^ b for a, b in
                                 zip(zlib.decompress(packed), clean))
                if sha(restored) != known[path.name]:
                    raise RuntimeError(f'lossless reconstruction failed: {path}')
                rows.append(dict(source=source, arm=arm,
                                 recipient=recipient, file=path.name,
                                 clean_bytes=len(clean), candidate_bytes=len(candidate),
                                 nonzero_delta_bytes=sum(v != 0 for v in delta),
                                 compressed_delta_bytes=len(packed),
                                 candidate_sha256=sha(candidate)))
    if len(rows) != 64:
        raise RuntimeError('candidate count drift')
    groups = []
    for source in ('sleep', 'chb'):
        for arm in ('phase', 'qim'):
            rr = [r for r in rows if r['source'] == source and r['arm'] == arm]
            clean_size = rr[0]['clean_bytes']
            raw_16 = sum(r['candidate_bytes'] for r in rr)
            delta_16 = sum(r['compressed_delta_bytes'] for r in rr)
            groups.append(dict(source=source, arm=arm, clean_bytes=clean_size,
                               raw_16_bytes=raw_16,
                               clean_plus_raw_16_bytes=clean_size + raw_16,
                               compressed_delta_16_bytes=delta_16,
                               clean_plus_delta_16_bytes=clean_size + delta_16,
                               compressed_vs_raw_ratio=(clean_size + delta_16)
                               / (clean_size + raw_16),
                               nonzero_delta_bytes=sum(r['nonzero_delta_bytes']
                                                       for r in rr)))
    result = dict(status='exploratory_read_only',
                  p160_results_sha256=sha((ROOT / 'results.json').read_bytes()),
                  p160_storage_result_sha256=p160.get('input_sha256'),
                  rows=rows, groups=groups)
    OUT.mkdir()
    (OUT / 'results.json').write_text(json.dumps(result, indent=2) + '\n',
                                      encoding='utf-8')
    print(json.dumps(groups, indent=2))


if __name__ == '__main__':
    main()
