"""EEGNet clean DEV after the one successful common-RMS explanation check."""
from pathlib import Path
import os
for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):
    os.environ[key]='1'
import datetime
import json
import random
import time
import numpy as np
import torch
from torch import nn
from models import EEGNet, EEGNET_AST_SHA256
from train_clean import sha, save, metrics
from rms_csp_pilot import normalized

HERE=Path(__file__).resolve().parent
OUT=HERE/'rms_dev01'
SEEDS=(191,192,193)
EPOCHS=(25,50,100)


def probability(model,x):
    model.eval()
    with torch.no_grad():
        result=np.concatenate([torch.softmax(model(x[i:i+64]),dim=1).numpy()
                               for i in range(0,len(x),64)]).astype(np.float64)
    return result/result.sum(axis=1,keepdims=True)


def main():
    torch.set_num_threads(2);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
    OUT.mkdir(exist_ok=True)
    pilot=json.loads((HERE/'rms_pilot01/RESULT.json').read_text(encoding='utf-8'))
    assert pilot['qualified']
    protocol=dict(status='RMS_adaptation_clean_DEV',train=list(range(1,13)),validation=list(range(13,17)),
                  preprocessing='8-30Hz4thButterworthfiltfilt,temporalepochdemean,onecommon8channelRMS,training-onlychannelmean/std',
                  eegnet_class_AST_sha256=EEGNET_AST_SHA256,seeds=list(SEEDS),epoch_choices=list(EPOCHS),
                  learning_rate=.001,batch_size=32,ensemble='equalsoftmaxmean3seeds',clean_BA_gate=.60,
                  successful_explanation_receipt_sha256=sha(HERE/'rms_pilot01/RESULT.json'),
                  normalization_code_sha256=sha(HERE/'rms_csp_pilot.py'),script_sha256=sha(__file__),
                  selection='source-equalcleanvalBAthenloglossthenfewerepochs',new_confirmation_accessed=False)
    save(OUT/'PROTOCOL.json',protocol)
    save(OUT/'RUN.json',dict(status='running',pid=os.getpid(),protocol_sha256=sha(OUT/'PROTOCOL.json')))
    tx,ty,vx,vy,vs=[],[],[],[],[]
    for s in range(1,17):
        data=np.load(HERE/'epochs'/f'OpenBMI{s:03d}.npz');x,y=normalized(data['x']),data['y']
        if s<=12:tx.append(x);ty.append(y)
        else:vx.append(x);vy.append(y);vs.extend([s]*len(y))
    tx,ty,vx,vy,vs=np.concatenate(tx),np.concatenate(ty),np.concatenate(vx),np.concatenate(vy),np.asarray(vs)
    mean=tx.mean(axis=(0,2),keepdims=True);std=np.maximum(tx.std(axis=(0,2),keepdims=True),1e-12)
    np.savez(OUT/'normalization.npz',mean=mean,std=std)
    tx=torch.from_numpy(np.asarray((tx-mean)/std,dtype=np.float32)[:,None])
    vx=torch.from_numpy(np.asarray((vx-mean)/std,dtype=np.float32)[:,None]);ty=torch.from_numpy(ty)
    runs={}
    for seed in SEEDS:
        random.seed(seed);np.random.seed(seed);torch.manual_seed(seed)
        started=time.perf_counter();model=EEGNet(2);opt=torch.optim.Adam(model.parameters(),lr=.001);history=[]
        for epoch in range(1,101):
            model.train();loss_sum=0.
            for batch in torch.randperm(len(ty)).split(32):
                opt.zero_grad(set_to_none=True);loss=nn.functional.cross_entropy(model(tx[batch]),ty[batch])
                loss.backward();opt.step();model.constrain();loss_sum+=float(loss.detach())*len(batch)
            history.append(dict(epoch=epoch,train_loss=loss_sum/len(ty)))
            if epoch in EPOCHS:
                p=probability(model,vx);name=f'eegnet_seed{seed}_epoch{epoch:03d}.pt'
                torch.save(dict(state_dict=model.state_dict(),seed=seed,epochs=epoch),OUT/name)
                np.save(OUT/f'eegnet_seed{seed}_epoch{epoch:03d}_val_probability.npy',p)
                row=dict(seed=seed,epochs=epoch,checkpoint=str(Path('rms_dev01')/name),checkpoint_sha256=sha(OUT/name),
                         probability=p,seconds=time.perf_counter()-started,**metrics(vy,p,vs));runs[seed,epoch]=row
                print(json.dumps({k:row[k] for k in ('seed','epochs','source_mean_balanced_accuracy','seconds')}),flush=True)
            if epoch%10==0:
                save(OUT/'PROGRESS.json',dict(pid=os.getpid(),seed=seed,epoch=epoch,train_loss=history[-1]['train_loss']))
        save(OUT/f'chain_seed{seed}.json',dict(seed=seed,history=history))
    candidates=[]
    for epoch in EPOCHS:
        p=np.mean([runs[seed,epoch]['probability'] for seed in SEEDS],axis=0);p/=p.sum(axis=1,keepdims=True)
        np.save(OUT/f'ensemble_epoch{epoch:03d}_val_probability.npy',p)
        candidates.append(dict(epochs=epoch,checkpoints=[runs[seed,epoch]['checkpoint'] for seed in SEEDS],
                               checkpoint_sha256=[runs[seed,epoch]['checkpoint_sha256'] for seed in SEEDS],**metrics(vy,p,vs)))
    selected=min(candidates,key=lambda r:(-r['source_mean_balanced_accuracy'],r['source_mean_log_loss'],r['epochs']))
    save(OUT/'RESULT.json',dict(candidates=candidates,runs=[{k:v for k,v in row.items() if k!='probability'} for row in runs.values()],selected=selected,
                               qualified=selected['source_mean_balanced_accuracy']>=.60,new_confirmation_predictions=0))
    csp=dict(pilot,checkpoint='rms_pilot01/csp_rms4.joblib',components=4)
    result=dict(status='clean_DEV_selection_complete_not_new_confirmation',csp_lda=csp,eegnet=selected,
                qualified={'csp_lda':pilot['qualified'],'eegnet':selected['source_mean_balanced_accuracy']>=.60},
                normalization='rms_dev01/normalization.npz',normalization_sha256=sha(OUT/'normalization.npz'),
                preprocessing='rms_csp_pilot.normalized',protocol_sha256=sha(OUT/'PROTOCOL.json'),
                train_people=list(range(1,13)),val_people=list(range(13,17)),test_people=list(range(17,25)),
                new_confirmation_predictions=0)
    save(HERE/'RMS_MODEL_SELECTION.json',result)
    save(OUT/'RUN.json',dict(status='terminal_clean_DEV_complete',pid=os.getpid(),selection_sha256=sha(HERE/'RMS_MODEL_SELECTION.json')))
    print(json.dumps(dict(stage='RMS_training_complete',qualified=result['qualified'],BA=selected['source_mean_balanced_accuracy'])),flush=True)


if __name__=='__main__':main()
