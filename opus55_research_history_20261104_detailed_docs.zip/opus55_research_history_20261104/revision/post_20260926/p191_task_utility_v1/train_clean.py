"""Actual binary task training: OpenBMI1-12 train,13-16 validation.

Only already-observed raw people are decoded. No new confirmation source is
accessible from this entry point. Model menus are written before first decode.
"""
from pathlib import Path
import os
for _key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[_key] = '1'
import datetime
import hashlib
import importlib.util
import json
import random
import sys
import time
import joblib
import numpy as np
import torch
from torch import nn
import mne
from mne.decoding import CSP
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.metrics import balanced_accuracy_score, log_loss
from sklearn.pipeline import make_pipeline
from models import EEGNet, EEGNET_AST_SHA256, EEGNET_SOURCE, filtered

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
BASE = HERE.parent
TRAIN = tuple(range(1, 13))
VAL = tuple(range(13, 17))
SEEDS = (191, 192, 193)
EPOCHS = (25, 50, 100)
COMPONENTS = (2, 4, 6)


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as file:
        for chunk in iter(lambda: file.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def array_sha(value):
    return hashlib.sha256(np.ascontiguousarray(value).tobytes()).hexdigest()


def save(path, value):
    temporary = Path(path).with_name(Path(path).name + '.writing')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    temporary.replace(path)


def emit(value):
    with (HERE / 'events.jsonl').open('a', encoding='utf-8') as file:
        file.write(json.dumps(dict(utc=now(), **value), ensure_ascii=False) + '\n')
    print(json.dumps(value, ensure_ascii=False), flush=True)


def private_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def source_reader():
    old = private_module('_p191_existing_people_meta', BASE / 'p190_experiment_v1/adapter.py')
    reader = private_module('_p191_existing_people_full_phase', BASE / 'p184_new_record_preparation_v1/openbmi_adapter.py')
    reader.metadata = old.metadata
    reader.CHANNELS = old.CHANNELS
    return reader, old


def prepare_person(reader, old, subject):
    assert subject in TRAIN + VAL
    folder = HERE / 'epochs'
    folder.mkdir(exist_ok=True)
    path = folder / f'OpenBMI{subject:03d}.npz'
    receipt_path = folder / f'OpenBMI{subject:03d}.json'
    if path.exists():
        receipt = json.loads(receipt_path.read_text(encoding='utf-8'))
        assert receipt['epoch_cache_sha256'] == sha(path)
        cached = np.load(path)
        return cached['x'], cached['y'], receipt
    started = time.perf_counter()
    meta = old.metadata(subject)
    native, _ = reader.load_native_microvolts(subject, phase='train')
    phase = reader.resample_phase(native)
    del native
    rows, labels, events = [], [], []
    for index, (cue, label) in enumerate(zip(meta['cues_matlab'], meta['labels'])):
        start = int(np.floor((int(cue)-1) * 4/25 + .5)) + 80
        if start < 0 or start+320 > phase.shape[1]:
            raise ValueError(f'Predeclared task epoch incomplete:person{subject},trial{index}')
        rows.append(phase[:, start:start+320].copy())
        labels.append(int(label)-1)
        events.append(dict(event_id=f'OpenBMI_MI/sub{subject:02d}/ses1/train/trial{index:03d}',
                           trial_index=index, native_cue=int(cue)-1, epoch_start160=start, label=int(label)-1))
    x = np.stack(rows)
    y = np.asarray(labels, dtype=np.int64)
    assert x.shape == (100, 8, 320) and np.bincount(y).tolist() == [50, 50]
    np.savez_compressed(path, x=x, y=y)
    receipt = dict(subject=subject, role='task_train' if subject in TRAIN else 'task_validation',
                   phase='train', n_epochs=len(y), class_counts=np.bincount(y).tolist(),
                   input_path=str(meta['path']), input_sha256=meta['raw_file_sha256'],
                   metadata_path=str(meta['metadata_path']), metadata_sha256=meta['metadata_sha256'],
                   selected_channels=list(reader.CHANNELS), native_hz=1000, output_hz=160,
                   epoch_seconds=[.5, 2.5], resampling='whole phase4/25Kaiser5/line then slice',
                   raw_epoch_sha256=array_sha(x), epoch_cache_sha256=sha(path),
                   events=events, seconds=time.perf_counter()-started)
    save(receipt_path, receipt)
    emit(dict(stage='epochs_prepared', subject=subject, epochs=len(y), seconds=receipt['seconds']))
    return x, y, receipt


def metrics(y, probability, subjects):
    predicted = np.argmax(probability, axis=1)
    people = [dict(subject=int(s), n=int(np.sum(subjects == s)),
                   balanced_accuracy=float(balanced_accuracy_score(y[subjects == s], predicted[subjects == s])),
                   log_loss=float(log_loss(y[subjects == s], probability[subjects == s], labels=[0, 1])))
              for s in np.unique(subjects)]
    return dict(people=people, source_mean_balanced_accuracy=float(np.mean([p['balanced_accuracy'] for p in people])),
                source_mean_log_loss=float(np.mean([p['log_loss'] for p in people])),
                pooled_balanced_accuracy=float(balanced_accuracy_score(y, predicted)))


def probability(model, x):
    model.eval()
    with torch.no_grad():
        return np.concatenate([torch.softmax(model(x[i:i+64]), dim=1).numpy()
                               for i in range(0, len(x), 64)]).astype(np.float64)


def main():
    (HERE / 'temp').mkdir(exist_ok=True)
    for name in ('TEMP', 'TMP'):
        os.environ[name] = str(HERE / 'temp')
    torch.set_num_threads(2)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    mne.set_log_level('ERROR')
    protocol = dict(task='OpenBMI_binary_right_vs_left_MI', training_people=list(TRAIN), validation_people=list(VAL),
                    new_confirmation_people=list(range(17, 25)), new_wrong_people=list(range(25, 29)),
                    new_confirmation_accessed=False, phase='session1 train', channels=['FC3','FC4','C3','C4','Cz','CP3','CP4','Pz'],
                    hz=160, epoch_seconds_after_cue=[.5, 2.5], class_map={'1':'right->0','2':'left->1'},
                    preprocessing='whole-phase4/25Kaiser5-line resample; per-epoch8-30Hz4thButterworthfiltfilt',
                    csp_menu=dict(components=list(COMPONENTS), reg='ledoit_wolf', lda='lsqr/auto shrinkage'),
                    eegnet_menu=dict(architecture='unchangedP181EEGNet8,2', epochs=list(EPOCHS), seeds=list(SEEDS),
                                     learning_rate=.001, batch_size=32, training_only_channel_mean_std=True, ensemble='equalsoftmaxmean3seeds'),
                    selection='maximize equal-person clean validation BA; minimize logloss; lowercomponents/epochs tie',
                    clean_mean_BA_gate=.60, gate_meaning='development capability criterion, not a population significance test',
                    eegnet_source=str(EEGNET_SOURCE), eegnet_source_sha256=sha(EEGNET_SOURCE),
                    eegnet_class_AST_sha256=EEGNET_AST_SHA256, script_sha256=sha(__file__), models_sha256=sha(HERE/'models.py'),
                    failure_policy='retain failedcleanmodel; no new-test-based selection or person replacement')
    plan = HERE / 'TRAINING_PROTOCOL.json'
    if plan.exists():
        assert json.loads(plan.read_text(encoding='utf-8')) == protocol, 'Protocol changed; use new explicit version'
    else:
        save(plan, protocol)
    emit(dict(stage='training_started', pid=os.getpid(), protocol_sha256=sha(plan), device='cpu'))
    save(HERE/'RUN.json', dict(status='running', pid=os.getpid(), started_utc=now(), protocol_sha256=sha(plan)))
    reader, old = source_reader()
    train_x, train_y, val_x, val_y, val_subjects, receipts = [], [], [], [], [], []
    for subject in TRAIN + VAL:
        x, y, receipt = prepare_person(reader, old, subject)
        receipts.append(receipt)
        if subject in TRAIN:
            train_x.append(x); train_y.append(y)
        else:
            val_x.append(x); val_y.append(y); val_subjects.extend([subject] * len(y))
    train_x, train_y = np.concatenate(train_x), np.concatenate(train_y)
    val_x, val_y, val_subjects = np.concatenate(val_x), np.concatenate(val_y), np.asarray(val_subjects)
    save(HERE/'DATASET_RECEIPTS.json', dict(people=receipts, train_epochs=len(train_y), val_epochs=len(val_y),
                                          new_confirmation_signal_values_decoded=False))
    train_filtered, val_filtered = filtered(train_x), filtered(val_x)
    csp_results = []
    for components in COMPONENTS:
        started = time.perf_counter()
        model = make_pipeline(CSP(n_components=components, reg='ledoit_wolf', log=True, norm_trace=False),
                              LinearDiscriminantAnalysis(solver='lsqr', shrinkage='auto'))
        model.fit(train_filtered, train_y)
        p = model.predict_proba(val_filtered)
        checkpoint = f'csp_{components}.joblib'
        joblib.dump(model, HERE/checkpoint)
        np.save(HERE/f'csp_{components}_val_probability.npy', p)
        row = dict(components=components, checkpoint=checkpoint, checkpoint_sha256=sha(HERE/checkpoint),
                   seconds=time.perf_counter()-started, **metrics(val_y, p, val_subjects))
        csp_results.append(row)
        emit(dict(stage='csp_completed', components=components, mean_val_BA=row['source_mean_balanced_accuracy']))
    save(HERE/'CSP_DEV.json', dict(candidates=csp_results))
    mean = train_filtered.mean(axis=(0, 2), keepdims=True)
    std = np.maximum(train_filtered.std(axis=(0, 2), keepdims=True), 1e-12)
    np.savez(HERE/'normalization.npz', mean=mean, std=std)
    tx = torch.from_numpy(np.asarray((train_filtered-mean)/std, dtype=np.float32)[:, None])
    vx = torch.from_numpy(np.asarray((val_filtered-mean)/std, dtype=np.float32)[:, None])
    ty = torch.from_numpy(train_y)
    net_results, histories = {}, []
    for seed in SEEDS:
        random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
        started = time.perf_counter()
        model = EEGNet(2)
        optimizer = torch.optim.Adam(model.parameters(), lr=.001)
        history = []
        for epoch in range(1, max(EPOCHS)+1):
            model.train()
            loss_sum = 0.
            for batch in torch.randperm(len(ty)).split(32):
                optimizer.zero_grad(set_to_none=True)
                loss = nn.functional.cross_entropy(model(tx[batch]), ty[batch])
                loss.backward(); optimizer.step(); model.constrain()
                loss_sum += float(loss.detach()) * len(batch)
            history.append(dict(epoch=epoch, train_loss=loss_sum/len(ty)))
            if epoch in EPOCHS:
                p = probability(model, vx)
                checkpoint = f'eegnet_seed{seed}_epoch{epoch:03d}.pt'
                torch.save(dict(state_dict=model.state_dict(), seed=seed, epochs=epoch, source_class_AST_sha256=EEGNET_AST_SHA256), HERE/checkpoint)
                np.save(HERE/f'eegnet_seed{seed}_epoch{epoch:03d}_val_probability.npy', p)
                net_results[seed, epoch] = dict(seed=seed, epoch=epoch, checkpoint=checkpoint,
                                                checkpoint_sha256=sha(HERE/checkpoint), probability=p,
                                                seconds=time.perf_counter()-started, **metrics(val_y,p,val_subjects))
                emit(dict(stage='eegnet_checkpoint', seed=seed, epoch=epoch,
                          mean_val_BA=net_results[seed,epoch]['source_mean_balanced_accuracy'], seconds=time.perf_counter()-started))
            if epoch % 10 == 0:
                save(HERE/'PROGRESS.json', dict(utc=now(), pid=os.getpid(), seed=seed, epoch=epoch, train_loss=history[-1]['train_loss']))
        histories.append(dict(seed=seed, history=history))
        save(HERE/f'eegnet_seed{seed}_history.json', histories[-1])
    net_candidates = []
    for epoch in EPOCHS:
        p = np.mean([net_results[seed, epoch]['probability'] for seed in SEEDS], axis=0)
        p /= p.sum(axis=1, keepdims=True)
        np.save(HERE/f'eegnet_ensemble_epoch{epoch:03d}_val_probability.npy', p)
        net_candidates.append(dict(epoch=epoch, seeds=list(SEEDS),
                                   checkpoints=[net_results[seed,epoch]['checkpoint'] for seed in SEEDS],
                                   checkpoint_sha256=[net_results[seed,epoch]['checkpoint_sha256'] for seed in SEEDS],
                                   **metrics(val_y,p,val_subjects)))
    save(HERE/'EEGNET_DEV.json', dict(candidates=net_candidates,
                                    runs=[{k:v for k,v in r.items() if k!='probability'} for r in net_results.values()]))
    key = lambda row, size: (-row['source_mean_balanced_accuracy'], row['source_mean_log_loss'], row[size])
    csp = min(csp_results, key=lambda r:key(r,'components'))
    net = min(net_candidates, key=lambda r:key(r,'epoch'))
    selection = dict(status='clean_development_complete_not_new_confirmation', csp_lda=csp, eegnet=net,
                     qualified={name:row['source_mean_balanced_accuracy']>=.60 for name,row in [('csp_lda',csp),('eegnet',net)]},
                     protocol_sha256=sha(plan), normalization_sha256=sha(HERE/'normalization.npz'),
                     train_people=list(TRAIN), validation_people=list(VAL), new_test_people=list(range(17,25)),
                     new_confirmation_predictions=0, completed_utc=now())
    save(HERE/'MODEL_SELECTION.json', selection)
    save(HERE/'RUN.json', dict(status='terminal_clean_development_complete', pid=os.getpid(), completed_utc=now(),
                               model_selection_sha256=sha(HERE/'MODEL_SELECTION.json')))
    emit(dict(stage='all_clean_training_completed', qualified=selection['qualified'],
              csp_BA=csp['source_mean_balanced_accuracy'], eegnet_BA=net['source_mean_balanced_accuracy']))


if __name__ == '__main__':
    main()
