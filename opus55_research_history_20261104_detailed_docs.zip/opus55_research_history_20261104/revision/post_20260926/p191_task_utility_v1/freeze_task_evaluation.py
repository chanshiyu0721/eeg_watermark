"""Freeze testphase utility after all eight individual task models are fixed."""
from pathlib import Path
import datetime,json
from train_clean import sha

HERE=Path(__file__).resolve().parent
BASE=HERE.parent
RECORDS=BASE/'p191_new_records_v1'


def main():
    model_file=HERE/'new_person_calibration/ALL_PERSON_MODELS_FROZEN.json'
    model=json.loads(model_file.read_text(encoding='utf-8'));assert model['status']=='all8_person_models_frozen_testphase_unopened'
    binding=BASE/'p191_confirmation_v1/CONFIRMATION_FREEZE_FIX01.json'
    assert sha(binding)=='e181d74e991ef5cb2155cd41f60673dc3eaa8f1e0be449c8d6d77be1ef398fb8'
    paths=[HERE/name for name in ('collect_task_utility.py','models.py','train_clean.py','rms_csp_pilot.py')]
    paths += [RECORDS/'task_adapter.py',RECORDS/'adapter.py',RECORDS/'MULTIBLOCK_TEST_PHASE_METADATA.json',
              HERE/'TASK_CALIBRATION_FREEZE.json',model_file,binding,
              BASE/'p191_fir_capacity_v1/ALLARM_DEV_RULES.json',BASE/'p191_fir_capacity_v1/dev_capacity.py',
              BASE/'p191_fir_capacity_v1/capacity_pilot.py',BASE/'p191_fir_capacity_v1/calibrate_allarms.py',
              BASE/'p191_modern_carrier_v1/a400_carrier.py',BASE/'p191_modern_carrier_v1/common_owner_comparison.py',
              BASE/'p191_modern_carrier_v1/common_owner_dev02/MODERN_DEV_LOCK.json',
              BASE/'p190_experiment_v1/run_experiment.py',BASE/'p186_five_arm_bridge_v1/run_bridge.py',
              BASE/'p186_five_arm_bridge_v1/continuation_api.py',BASE/'p184_new_record_preparation_v1/openbmi_adapter.py',
              BASE/'p184_new_record_preparation_v1/inspect_mat_metadata.py']
    files={str(p):sha(p) for p in paths};files.update(model['all_model_sha256'])
    modern=json.loads((BASE/'p191_modern_carrier_v1/common_owner_dev02/MODERN_DEV_LOCK.json').read_text(encoding='utf-8'))
    for path,digest in modern['frozen_files'].items():files[str(Path(path))]=digest
    panel=json.loads((RECORDS/'MULTIBLOCK_TEST_PHASE_METADATA.json').read_text(encoding='utf-8'))
    freeze=dict(status='frozen_before_new_task_test_phase_signal',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                targets=list(range(17,25)),phase='test',block_rule='nativephase0chronologicalcomplete112s;firstmin(8,completeblocks)',
                task_events='onlycue+.5to2.5sepochswhollyinside5x8sscoringwindows;metadatafixed108events',
                test_panel_metadata_sha256=sha(RECORDS/'MULTIBLOCK_TEST_PHASE_METADATA.json'),total_unique_task_epochs=panel['total_epochs'],
                task_recipients=list(range(8)),arms=['smooth','direct','hybrid05','spatial','qid','modern_A400'],
                joint_attribution_recipient='(subject_integer+block_index_zero_based)%8;onefixedrecipientperblock;eachperson8blockscovers8IDs',
                primary_attribution='separatefull8identitytrainphasefirstcue112sunchanged',
                conditions=['reexport','elliptic_new_causal','bessel_shifted_causal'],reference_seconds=112,scored_seconds=40,visible_seconds=48,
                caps_percent={'global':.25,'maximum_channel':.5,'band8_30':1.},actual_group_PRD_spread_max=.001,
                issuer='P190fixedregistered-onlyfirst8phasecodesandQIMmessages;registeredalphaandnumericalmatchingunchanged',
                source_common_cap_QC='baselineP190phasecapthenhighestfraction1,.75,.5,.25feasiblefor8modernregisteredcodes;registeredqualityonlybeforeQIM/queries;noevents/labels/scores',
                all6_matching='sameQIDperrecipientanchorinterval[anchor/1.001,anchor];all6groupinvalidifonecarrierinfeasible',
                query_EDF_grid='singlecondition-specificrangefromprocessedcleanandall6registeredgalleries;identicalforallcarrierqueries',
                task_comparator='primaryeachcarrieragainstsameprocessingactualEDFclean;separaterawpreEDFcleanability',
                identity_decoder='frozen257candidateFIRexactpercarrier;samereference/querycontext;no perblockcalibration',
                modern_label='owner-adaptedpublic-structureRPWfinite-eight;notfaithfulnative30bitSOTA',
                aggregation='personisindependentunitn8;withinpersonaggregateevents/identities/blocks;noexclusionfromtaskaccuracy',
                outcomes=['cleanBA','carrier-minus-matchedcleanaccuracy/BA','predictionflips','probabilitychange','fixedsubsetattributioncoverage','PRDandcost'],
                calibration_freeze_sha256=sha(HERE/'TASK_CALIBRATION_FREEZE.json'),all_person_models_freeze_sha256=sha(model_file),
                primary_runtime_binding_sha256=sha(binding),file_sha256=files,new_test_phase_EEG_decoded=False,new_task_test_predictions=0)
    path=HERE/'TASK_EVALUATION_FREEZE.json'
    with path.open('x',encoding='utf-8') as file:json.dump(freeze,file,ensure_ascii=False,indent=2)
    print(json.dumps(dict(status=freeze['status'],path=str(path),sha256=sha(path))),flush=True)


if __name__=='__main__':main()
