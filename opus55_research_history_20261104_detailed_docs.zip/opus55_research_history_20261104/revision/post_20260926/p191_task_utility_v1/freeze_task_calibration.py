"""Issue the fixed calibration protocol after actual old-DEV capability gate."""
from pathlib import Path
import datetime
import json
from train_clean import sha

HERE=Path(__file__).resolve().parent
RECORDS=HERE.parent/'p191_new_records_v1'


def main():
    dev_path=HERE/'within_person_dev01/global_workpoint/RESULT.json'
    dev=json.loads(dev_path.read_text(encoding='utf-8'));assert all(dev['qualified'].values())
    assert dev['selected']['csp_lda']['components']==4
    assert dev['selected']['eegnet']['init']=='pooled_warmstart' and dev['selected']['eegnet']['epochs']==25
    pooled=json.loads((HERE/'RMS_MODEL_SELECTION.json').read_text(encoding='utf-8'))
    initial=HERE/pooled['eegnet']['checkpoints'][0]
    paths=[HERE/name for name in ('calibrate_new_people.py','models.py','rms_csp_pilot.py','within_person_dev.py','train_clean.py')]
    paths += [RECORDS/'task_adapter.py',RECORDS/'adapter.py',HERE.parent/'p184_new_record_preparation_v1/openbmi_adapter.py',
              HERE.parent/'p184_new_record_preparation_v1/inspect_mat_metadata.py',HERE.parent/'p181_eegnet.py']
    freeze=dict(status='frozen_task_calibration_procedure_before_new_task_EEG',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                targets=list(range(17,25)),calibration_phase='session1 train',task_test_phase='session1 test',
                split=dict(train_epochs=80,val_epochs=20,stratified=True,random_state=191),
                channels=['FC3','FC4','C3','C4','Cz','CP3','CP4','Pz'],hz=160,epoch_seconds_after_cue=[.5,2.5],
                preprocessing='wholephase4/25Kaiser5-line resample;epoch8-30Hz4thButterworthfiltfilt;temporal-meanremoval;common8channelRMS',
                csp_lda=dict(components=4,reg='ledoit_wolf',lda='lsqr/auto'),
                eegnet=dict(architecture='inheritedEEGNet8,2',init='pooled_warmstart',initial_checkpoint=str(initial),initial_checkpoint_sha256=sha(initial),
                            epochs=25,learning_rate=.001,batch_size=32,seed=191,normalization='person80calibrationtrainingepochsonlychannelmean/std'),
                new_validation_role='diagnostics_only;noepoch/config/subjectselectionorqualificationbasedonnewpersonval',
                all_person_models='trainall8thenfreezecheckpointSHAperpersonbeforeanytestphasedecodeorprediction',
                new_test_phase_access='prohibited_until_all_models_frozen_and_evaluation_protocol',
                new_joint_panel='testphasefixedchronologicalfirstmin(8,complete112sblocks),same40sscored48svisibleperblock',
                primary_attribution='originaltrainphasefirstcue112sunchanged;taskcalibrationdoesnotenterattributionreceiver',
                capability_gate=dict(threshold=.60,old_DEV_people=[13,14,15,16],csp_BA=dev['selected']['csp_lda']['source_mean_balanced_accuracy'],
                                     eegnet_BA=dev['selected']['eegnet']['source_mean_balanced_accuracy']),
                old_DEV_result_sha256=sha(dev_path),acquisition_manifest_sha256=sha(RECORDS/'ACQUISITION.json'),
                metadata_manifest_sha256=sha(RECORDS/'METADATA_PREPARATION.json'),
                test_panel_metadata_sha256=sha(RECORDS/'MULTIBLOCK_TEST_PHASE_METADATA.json'),
                code_sha256={str(path):sha(path) for path in paths},new_task_EEG_decoded=False,new_test_predictions=0)
    path=HERE/'TASK_CALIBRATION_FREEZE.json'
    with path.open('x',encoding='utf-8') as file:json.dump(freeze,file,ensure_ascii=False,indent=2)
    print(json.dumps(dict(status=freeze['status'],path=str(path),sha256=sha(path))),flush=True)


if __name__=='__main__':main()
