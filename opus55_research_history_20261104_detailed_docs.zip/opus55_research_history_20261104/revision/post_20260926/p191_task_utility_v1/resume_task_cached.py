"""Independent execution-only cache wrapper around the immutable task collector.

The original freeze, scientific rules, query grids, and model checkpoints are
verified unchanged. Each arm's receiver survives its three processing queries.
"""
from pathlib import Path
import os
for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):
    os.environ[key]='1'
import argparse,hashlib,inspect,json,time
import numpy as np
import collect_task_utility as c

HERE=Path(__file__).resolve().parent
BINDING=HERE/'TASK_CACHE_RUNTIME_BINDING.json'
VALIDATION=HERE/'TASK_CACHE_EQUIVALENCE.json'


def validate_freeze():
    frozen=HERE/'TASK_EVALUATION_FREEZE.json'
    assert c.sha(frozen)=='ff33bb204bd675f467127459166d2545105803d4bb644458c539946f996862a3'
    freeze=c.load(frozen)
    for name,digest in freeze['file_sha256'].items():
        assert c.sha(name)==digest,('Frozen task input changed',name)
    binding=c.load(BINDING)
    assert binding['wrapper_sha256']==c.sha(__file__)
    assert binding['evaluation_freeze_sha256']==c.sha(frozen)
    return frozen,freeze


class CachedCarrier(c.modern_api.FixedA400Carrier):
    def __init__(self):
        super().__init__();self._residual_cache={}
    def residual(self,x,bits,block_samples=640):
        key=(hashlib.sha256(np.asarray(x).tobytes()).hexdigest(),tuple(bits),block_samples)
        if key not in self._residual_cache:
            self._residual_cache[key]=super().residual(x,bits,block_samples)
        return self._residual_cache[key]
    def issue_actual_edf(self,x,bits,limits,target,folder,name='a400_issued.edf'):
        folder=Path(folder);saved=folder/'ISSUANCE.json';issued=folder/(name+'.gz')
        if saved.exists() and issued.exists():
            rows=c.load(saved)['rows']
            matches=[r for r in rows if r.get('issued_file')==str(issued)]
            if len(matches)==1:
                row=matches[0];assert row['feasible']
                assert row['checkpoint_sha256']==c.modern_api.CHECKPOINT_SHA256
                assert row['EDF_receipt']['gzip_sha256']==c.sha(issued)
                value=c.modern_api.m.edf.parse_edf(c.gzip.decompress(issued.read_bytes()),c.modern_api.m.CHANNELS)[0]
                quality=c.modern_api.m.api.p.quality(x,value)
                assert target/1.001<=quality['global_ac_prd']<=target
                assert np.allclose([quality[k] for k in quality],[row['quality'][k] for k in quality],rtol=0,atol=1e-14)
                return dict(row,readback_v=value)
        return super().issue_actual_edf(x,bits,limits,target,folder,name)


def install_cached_block():
    source=inspect.getsource(c.run_block)
    start=source.index('    transformed_clean=')
    end=source.index("    result['status']='complete'")
    # Only scheduling changes: establish identical condition-specific EDF grids
    # first, then keep one arm receiver alive for its three conditions.
    replacement='''    transformed_clean={cc:m.c.transform(x,cc) for cc in CONDITIONS}
    transformed={};query_limits={}
    for cc in CONDITIONS:
        values=[transformed_clean[cc]]
        if valid:
            for arm in ARMS:
                transformed[arm,cc]=[m.c.transform(y,cc) for y in copies[arm][:8]]
                values.extend(transformed[arm,cc])
        query_limits[cc]=m.p.ranges(np.concatenate(values,axis=1))
        if cc not in clean_done:
            query,_=m.io.edf_roundtrip(transformed_clean[cc],query_limits[cc],f'{name}_clean_{cc}.edf',final.parent,all_receipts,False,m.domain.BCI_CHANNELS)
            clean_rows.append(dict(condition=cc,probabilities=predict(epochs(query,events)) if events else None,query_raw_sha256=all_receipts[-1]['raw_sha256']))
    for arm in ARMS:
        receiver=None
        rule=(modern_rules['methods']['257/candidate_FIR_GLRT/exact'] if arm=='modern_A400' else classical_rules['rules'][arm]['257/candidate_FIR_GLRT/exact'])['selected']
        for cc in CONDITIONS:
            todo=[rid for rid in range(8) if (arm,rid,cc) not in done]
            if not todo:continue
            for rid in todo:
                if valid:
                    query,_=m.io.edf_roundtrip(transformed[arm,cc][rid],query_limits[cc],f'{name}_{arm}_r{rid}_{cc}.edf',final.parent,all_receipts,False,m.domain.BCI_CHANNELS)
                    probabilities=predict(epochs(query,events)) if events else None
                    attribution=None
                    if rid==selected_rid:
                        if receiver is None:receiver=DevelopmentReceiver(x,np.asarray(copies[arm][:8]),257)
                        started=time.perf_counter();feature=receiver.extract_all(query)
                        attribution=dict(decision(feature,rule),seconds=time.perf_counter()-started,
                                         candidate_features=feature['methods']['candidate_FIR_GLRT']['by_ridge'])
                    row=dict(arm=arm,recipient=rid,condition=cc,issuance_feasible=True,probabilities=probabilities,
                             quality=quality[arm][rid],query_raw_sha256=all_receipts[-1]['raw_sha256'],attribution=attribution)
                else:row=dict(arm=arm,recipient=rid,condition=cc,issuance_feasible=False,probabilities=None,attribution=None,failure_reason='six_carrier_common_anchor_group_infeasible')
                rows.append(row)
            result=dict(status='running',subject=source,phase='test',block=block,events=events,rows=rows,processed_clean=clean_rows,
                        raw_clean_probabilities=baseline_raw,selected_joint_recipient=selected_rid,registered_group_valid=valid,
                        common_cap_QC=qc,actual_all6_relative_spreads=spreads,query_EDF_receipts=all_receipts,
                        evaluation_freeze_sha256=digest,scored_seconds=40,visible_seconds=48,reference_seconds=112)
            checkpoint(final,result)
            print(json.dumps(dict(stage='task_block_arm',subject=source,block=block,arm=arm,condition=cc,rows=len(rows))),flush=True)
        del receiver
'''
    source=source[:start]+replacement+source[end:]
    exec(compile(source,str(__file__)+'::cached_run_block','exec'),c.__dict__)


def numeric_compare(a,b,path=''):
    if isinstance(a,dict):
        assert set(a)==set(b),(path,'keys')
        for key in a:numeric_compare(a[key],b[key],path+'/'+key)
    elif isinstance(a,list):
        assert len(a)==len(b),(path,'length')
        for i,(aa,bb) in enumerate(zip(a,b)):numeric_compare(aa,bb,path+'/'+str(i))
    elif isinstance(a,(int,float)) and not isinstance(a,bool):
        assert np.isclose(a,b,rtol=1e-10,atol=1e-12),(path,a,b)
    else:assert a==b,(path,a,b)


def verify_equivalence():
    """One existing block: all six query grids, one arm across all 3 conditions.

    Existing original-collector candidate features are the numerical baseline.
    No scores are used to choose models, blocks, rules, caps, or parameters.
    """
    frozen,freeze=validate_freeze()
    prior=c.load(c.OUT/'results/OpenBMI017/block02.json.gz')
    assert prior['status']=='complete';name='OpenBMI017_task_test_b02'
    issuer,_=c.reused_issuer();m=issuer.backend('task-cache-equivalence')
    x,_=issuer.read_edf(m,c.OUT/'sources'/name/'clean.edf.gz')
    copies={}
    folder=c.OUT/'issuance'/name/'level100'
    for arm in c.ARMS:
        sub=folder/('qid' if arm=='qid' else 'modern_A400' if arm=='modern_A400' else '')
        copies[arm]=[issuer.read_edf(m,sub/f'{arm}_r{i}_issued.edf.gz')[0] for i in range(8)]
    receiver=c.DevelopmentReceiver(x,np.asarray(copies['smooth']),257)
    predict=c.person_models(17);rid=prior['selected_joint_recipient'];comparisons=[]
    classical=c.load(c.BASE/'p191_fir_capacity_v1/ALLARM_DEV_RULES.json')
    rule=classical['rules']['smooth']['257/candidate_FIR_GLRT/exact']['selected']
    with c.threadpool_limits(limits=1):
        for cc in c.CONDITIONS:
            allvalues=[m.c.transform(x,cc)]
            for arm in c.ARMS:allvalues.extend([m.c.transform(y,cc) for y in copies[arm]])
            limits=m.p.ranges(np.concatenate(allvalues,axis=1));receipts=[]
            query,_=m.io.edf_roundtrip(m.c.transform(copies['smooth'][rid],cc),limits,f'{name}_smooth_r{rid}_{cc}.edf',HERE/'temp',receipts,False,m.domain.BCI_CHANNELS)
            old=next(r for r in prior['rows'] if (r['arm'],r['recipient'],r['condition'])==('smooth',rid,cc))
            assert old['query_raw_sha256']==receipts[-1]['raw_sha256']
            feature=receiver.extract_all(query);answer=c.decision(feature,rule)
            numeric_compare(feature['methods']['candidate_FIR_GLRT']['by_ridge'],old['attribution']['candidate_features'])
            numeric_compare(answer,{k:old['attribution'][k] for k in answer})
            if prior['events']:
                pp=predict(c.epochs(query,prior['events']))
                for model in pp:
                    assert np.allclose(pp[model],old['probabilities'][model],rtol=1e-6,atol=1e-7)
                    assert np.array_equal(np.argmax(pp[model],axis=1),np.argmax(old['probabilities'][model],axis=1))
            comparisons.append(dict(condition=cc,query_raw_sha256=receipts[-1]['raw_sha256'],candidate_features_equal=True,decision_equal=True,task_predictions_equal=True))
            print(json.dumps(dict(stage='cache_equivalence_condition',condition=cc)),flush=True)
    c.checkpoint(VALIDATION,dict(status='passed',wrapper_sha256=c.sha(__file__),evaluation_freeze_sha256=c.sha(frozen),fixture='OpenBMI017/block02',arm='smooth',comparisons=comparisons,tolerance=dict(features_rtol=1e-10,features_atol=1e-12,task_rtol=1e-6,task_atol=1e-7),scientific_rules_unchanged=True))


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--subjects',required=True);parser.add_argument('--validate',action='store_true');args=parser.parse_args()
    frozen,freeze=validate_freeze();digest=c.sha(frozen)
    c.torch.set_num_threads(1);c.torch.set_num_interop_threads(1);c.torch.use_deterministic_algorithms(True)
    if args.validate:verify_equivalence()
    else:
        while not VALIDATION.exists():time.sleep(1)
    audit=c.load(VALIDATION);assert audit['status']=='passed' and audit['wrapper_sha256']==c.sha(__file__)
    install_cached_block()
    adapter=c.private_module('_p191_test_phase_after_all_person_models_frozen',c.RECORDS/'task_adapter.py')
    panel=c.load(c.RECORDS/'MULTIBLOCK_TEST_PHASE_METADATA.json')
    issuer,_=c.reused_issuer();carrier=CachedCarrier()
    classical=c.load(c.BASE/'p191_fir_capacity_v1/ALLARM_DEV_RULES.json');modern=c.load(c.BASE/'p191_modern_carrier_v1/common_owner_dev02/MODERN_DEV_LOCK.json')
    for subject in map(int,args.subjects.split(',')):
        assert 17<=subject<=24
        final=c.OUT/'results'/f'OpenBMI{subject:03d}'/'COMPLETE.json'
        if final.exists():continue
        print(json.dumps(dict(stage='task_person_start',subject=subject)),flush=True)
        predict=c.person_models(subject);phase,meta=adapter.load_phase(subject,'test',freeze_path=frozen,expected_freeze_sha256=digest,allow_new=True)
        person=next(r for r in panel['people'] if r['subject']==subject);m=issuer.backend(f'task-test-{subject}')
        with c.threadpool_limits(limits=1):
            for block,value in adapter.chronological_blocks(phase,meta,8):
                events=next(r['events'] for r in person['blocks'] if r['block_id']==block)
                c.run_block(issuer,m,carrier,subject,block,value,events,predict,freeze,digest,classical,modern)
                carrier._residual_cache.clear()
        c.save(final,dict(status='complete',subject=subject,blocks=len(person['blocks']),evaluation_freeze_sha256=digest,test_task_epochs=person['n_epochs']))
        print(json.dumps(dict(stage='task_person_complete',subject=subject)),flush=True)


if __name__=='__main__':main()
