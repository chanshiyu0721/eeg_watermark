"""Binary OpenBMI CSP/LDA and inherited EEGNet; frozen raw-epoch inference."""
from pathlib import Path
import ast
import hashlib
import json
import joblib
import numpy as np
from scipy.signal import butter, sosfiltfilt
import torch
from torch import nn

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
EEGNET_SOURCE = BASE / 'p181_eegnet.py'
_tree = ast.parse(EEGNET_SOURCE.read_text(encoding='utf-8'))
_node = next(n for n in _tree.body if isinstance(n, ast.ClassDef) and n.name == 'EEGNet')
EEGNET_AST_SHA256 = hashlib.sha256(ast.dump(_node, include_attributes=False).encode()).hexdigest()
exec(compile(ast.Module(body=[_node], type_ignores=[]), str(EEGNET_SOURCE), 'exec'), globals())


def filtered(epochs):
    value = np.asarray(epochs, dtype=np.float64)
    assert value.ndim == 3 and value.shape[1:] == (8, 320) and len(value) and np.isfinite(value).all()
    return sosfiltfilt(butter(4, [8., 30.], btype='bandpass', fs=160, output='sos'), value, axis=-1)


class FrozenCSP:
    def __init__(self, path):
        self.model = joblib.load(path)

    def predict_proba(self, raw):
        return self.model.predict_proba(filtered(raw))


class FrozenEEGNet:
    def __init__(self, checkpoint_paths, normalization):
        self.mean, self.std = normalization['mean'], normalization['std']
        self.models = []
        for path in checkpoint_paths:
            checkpoint = torch.load(path, map_location='cpu', weights_only=False)
            model = EEGNet(2)
            model.load_state_dict(checkpoint['state_dict'])
            model.eval()
            self.models.append(model)

    def predict_proba(self, raw):
        normalized = np.asarray((filtered(raw) - self.mean) / self.std, dtype=np.float32)
        data = torch.from_numpy(normalized[:, None])
        probabilities = []
        with torch.no_grad():
            for model in self.models:
                batches = [torch.softmax(model(data[i:i+64]), dim=1).numpy()
                           for i in range(0, len(data), 64)]
                probabilities.append(np.concatenate(batches))
        result = np.mean(probabilities, axis=0).astype(np.float64)
        return result / result.sum(axis=1, keepdims=True)


def load_selected_models(folder=HERE):
    folder = Path(folder)
    selected = json.loads((folder / 'MODEL_SELECTION.json').read_text(encoding='utf-8'))
    normalization = dict(np.load(folder / 'normalization.npz'))
    return dict(csp_lda=FrozenCSP(folder / selected['csp_lda']['checkpoint']),
                eegnet=FrozenEEGNet([folder / p for p in selected['eegnet']['checkpoints']], normalization))
