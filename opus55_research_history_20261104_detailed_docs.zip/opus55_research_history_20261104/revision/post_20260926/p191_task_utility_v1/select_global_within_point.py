"""Use old test phases as DEV to choose one common calibration workpoint.

Compares the original finite CSP/EEGNet menus, not new architectures or data.
Neural trajectories already exist; no neural retraining or new-person access.
"""
from pathlib import Path
import os
for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[key]='1'
import json
import numpy as np
import torch
import mne
from mne.decoding import CSP
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.pipeline import make_pipeline
import joblib
from train_clean import save,sha
from within_person_dev import PEOPLE,EPOCHS,SEED,net_probability,score
from rms_csp_pilot import normalized
from models import EEGNet

HERE=Path(__file__).resolve().parent
BASE=HERE/'within_person_dev01'
OUT=BASE/'global_workpoint'


def main():
    torch.set_num_threads(2);torch.set_num_interop_threads(1);mne.set_log_level('ERROR');OUT.mkdir(exist_ok=True)
    protocol=dict(status='old_testphases_as_DEV_global_workpoint_selection',people=list(PEOPLE),
                  csp_components=[2,4,6],neural_inits=['scratch','pooled_warmstart'],epochs=list(EPOCHS),
                  trainphase_split='samefixed80/20seed191',personal_val='reporteddiagnostic;globalworkpointfixedfromoldtestDEV',
                  neural_retraining=False,selection='equalpersonoldtestBAthenloglossthenlowercost',
                  clean_BA_gate=.60,new_confirmation_access=False,script_sha256=sha(__file__))
    save(OUT/'PROTOCOL.json',protocol)
    rows=[]
    for subject in PEOPLE:
        folder=BASE/f'OpenBMI{subject:03d}'
        freeze=json.loads((folder/'CALIBRATION_FROZEN.json').read_text(encoding='utf-8'));ids=np.asarray(freeze['train_indices'])
        train=np.load(HERE/'epochs'/f'OpenBMI{subject:03d}.npz');test=np.load(BASE/'epochs'/f'OpenBMI{subject:03d}_test.npz')
        xt=normalized(train['x'][ids]);yt=train['y'][ids];xe=normalized(test['x']);ye=test['y']
        for components in (2,4,6):
            model=make_pipeline(CSP(n_components=components,reg='ledoit_wolf',log=True,norm_trace=False),LinearDiscriminantAnalysis(solver='lsqr',shrinkage='auto'))
            model.fit(xt,yt);p=model.predict_proba(xe);name=f'csp_components{components}.joblib';joblib.dump(model,folder/name)
            rows.append(dict(subject=subject,method='csp_lda',components=components,**score(ye,p,subject)))
        norm=np.load(folder/'normalization.npz');data=torch.from_numpy(np.asarray((xe-norm['mean'])/norm['std'],dtype=np.float32)[:,None])
        for init in ('scratch','pooled_warmstart'):
            for epoch in EPOCHS:
                name=f'eegnet_{init}_{epoch:03d}.pt';model=EEGNet(2);model.load_state_dict(torch.load(folder/name,map_location='cpu',weights_only=False)['state_dict'])
                p=net_probability(model,data)
                rows.append(dict(subject=subject,method='eegnet',init=init,epochs=epoch,**score(ye,p,subject)))
        print(json.dumps(dict(subject=subject,stage='oldDEV_global_menu_scored')),flush=True)
    configurations=[]
    for components in (2,4,6):
        configs=[r for r in rows if r['method']=='csp_lda' and r['components']==components]
        configurations.append(dict(method='csp_lda',components=components,people=configs,
                                    source_mean_balanced_accuracy=float(np.mean([r['source_mean_balanced_accuracy'] for r in configs])),
                                    source_mean_log_loss=float(np.mean([r['source_mean_log_loss'] for r in configs])),cost=components))
    for init in ('scratch','pooled_warmstart'):
        for epoch in EPOCHS:
            configs=[r for r in rows if r['method']=='eegnet' and r['init']==init and r['epochs']==epoch]
            configurations.append(dict(method='eegnet',init=init,epochs=epoch,people=configs,
                                        source_mean_balanced_accuracy=float(np.mean([r['source_mean_balanced_accuracy'] for r in configs])),
                                        source_mean_log_loss=float(np.mean([r['source_mean_log_loss'] for r in configs])),cost=epoch))
    selected={}
    for method in ('csp_lda','eegnet'):
        selected[method]=min([r for r in configurations if r['method']==method],key=lambda r:(-r['source_mean_balanced_accuracy'],r['source_mean_log_loss'],r['cost']))
    result=dict(status='global_old_DEV_selection_complete',configurations=configurations,selected=selected,
                qualified={m:r['source_mean_balanced_accuracy']>=.60 for m,r in selected.items()},
                protocol_sha256=sha(OUT/'PROTOCOL.json'),new_confirmation_predictions=0)
    save(OUT/'RESULT.json',result)
    print(json.dumps(dict(selected={m:{k:v for k,v in row.items() if k!='people'} for m,row in selected.items()},qualified=result['qualified'])),flush=True)


if __name__=='__main__':main()
