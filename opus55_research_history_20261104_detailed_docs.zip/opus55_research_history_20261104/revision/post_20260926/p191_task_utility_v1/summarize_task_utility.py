"""Person-level task, signal-quality, and fixed-recipient joint summary.

Analysis is enabled only after the eight frozen people have all eight complete
blocks. Repeated recipients, conditions and events never increase inference n.
"""
from pathlib import Path
import argparse,csv,gzip,hashlib,itertools,json,sys
import numpy as np
from scipy import stats

HERE=Path(__file__).resolve().parent
OUT=HERE/'testphase_joint_utility'
DEST=HERE/'task_summary'
ARMS=('smooth','direct','hybrid05','spatial','qid','modern_A400')
CONDITIONS=('reexport','elliptic_new_causal','bessel_shifted_causal')
MODELS=('csp_lda','eegnet')
FREEZE_SHA='ff33bb204bd675f467127459166d2545105803d4bb644458c539946f996862a3'


def load(path):
    path=Path(path);raw=path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.suffix=='.gz' else raw)


def save(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    text=json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n'
    temp=path.with_suffix(path.suffix+'.writing');temp.write_text(text,encoding='utf-8');temp.replace(path)


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def common_failure_detail(subject,block):
    name=f"OpenBMI{subject:03d}_task_test_b{block['block']:02d}"
    folder=OUT/'issuance'/name/'level100'
    value=dict(subject=subject,block_index=block['block'],n_original_task_events=len(block['events']),event_ids=[e['event_id'] for e in block['events']],selected_joint_recipient=block['selected_joint_recipient'],common_cap_QC_status=block['common_cap_QC']['status'],selected_common_cap=block['common_cap_QC']['selected_common_cap'],failure_level='six-carrier common matched-budget point unavailable; not a claim that every individual carrier is infeasible',individual_issuance_failures=[])
    path=folder/'issuance_summary.json'
    if path.exists():
        issued=load(path);value['phase_issuance_summary_sha256']=sha(path)
        for arm,rows in issued['metadata'].items():
            for index,row in enumerate(rows):
                if row['feasible']:continue
                item=dict(arm=arm,recipient=row.get('recipient',index),reason=row.get('failure_reason'),target_QID_anchor=issued['QID_anchors'][index] if index<8 else None)
                failures=[r for r in issued.get('phase_matching',[]) if r['arm']==arm and r['index']==index and r['status']=='matching_unresolved']
                if failures:
                    history=failures[0]['history'];target=failures[0]['target'];low=target/1.001
                    below=[r['global_ac_prd'] for r in history if r['global_ac_prd']<low];above=[r['global_ac_prd'] for r in history if r['global_ac_prd']>target]
                    item.update(target_interval=[low,target],matching_attempts=len(history),closest_below_interval=max(below) if below else None,closest_above_interval=min(above) if above else None,all_attempted_points_pass_quality_caps=all(r['qc'] for r in history))
                value['individual_issuance_failures'].append(item)
    path=folder/'modern_A400/ISSUANCE.json'
    if path.exists():
        value['modern_issuance_summary_sha256']=sha(path)
        for index,row in enumerate(load(path)['rows']):
            if not row['feasible']:value['individual_issuance_failures'].append(dict(arm='modern_A400',recipient=index,reason=row.get('matching',{}).get('status')))
    return value


def accuracy(labels,predictions):
    y=np.asarray(labels);p=np.asarray(predictions)
    assert len(y)>0 and len(y)==len(p)
    recalls=[float(np.mean(p[y==k]==k)) for k in (0,1)]
    assert all(np.any(y==k) for k in (0,1))
    return dict(accuracy=float(np.mean(y==p)),balanced_accuracy=float(np.mean(recalls)),class_recall=recalls,n_events=len(y))


def descriptive(values):
    a=np.asarray(values,dtype=float);assert len(a)==8 and np.isfinite(a).all()
    # Report participant distribution directly. Bootstrap uncertainty reflects
    # resampling these eight people, not identity/event pseudo-replication.
    rng=np.random.default_rng(191);indices=rng.integers(0,8,size=(20000,8))
    means=a[indices].mean(axis=1)
    return dict(n_people=8,person_values=a.tolist(),mean=float(a.mean()),sd=float(a.std(ddof=1)),median=float(np.median(a)),minimum=float(a.min()),maximum=float(a.max()),bootstrap_person_percentile_CI95=np.quantile(means,[.025,.975]).tolist(),all_person_values_identical=bool(np.ptp(a)==0))


def optional_descriptive(values):
    if all(v is not None for v in values):return descriptive(values)
    return dict(n_people_with_defined_metric=sum(v is not None for v in values),person_values=values,mean=None,reason='delivered-only metric undefined if zero delivered events or a class is absent; no people removed from primary assigned analysis')


def person_summary(subject,blocks):
    base_labels=[];raw={m:[] for m in MODELS}
    for b in blocks:
        y=[e['class_id']-1 for e in b['events']]
        base_labels.extend(y)
        if y:
            for model in MODELS:raw[model].extend(np.argmax(b['raw_clean_probabilities'][model],axis=1).tolist())
    result=dict(subject=subject,n_unique_task_events=len(base_labels),n_common_feasible_task_events=sum(len(b['events']) for b in blocks if b['registered_group_valid']),n_complete_blocks=8,raw_clean={m:accuracy(base_labels,raw[m]) for m in MODELS},conditions={},registered_group_valid_blocks=sum(b['registered_group_valid'] for b in blocks),maximum_actual_relative_all6_PRD_spread=max(max(b['actual_all6_relative_spreads'],default=0.) for b in blocks))
    for condition in CONDITIONS:
        cleanlabels=[];cleanpred={m:[] for m in MODELS};cleanprob={m:[] for m in MODELS}
        for b in blocks:
            yy=[e['class_id']-1 for e in b['events']];cleanlabels.extend(yy)
            if yy:
                cc=next(r for r in b['processed_clean'] if r['condition']==condition)
                for model in MODELS:
                    pp=np.asarray(cc['probabilities'][model]);cleanprob[model].extend(pp.tolist());cleanpred[model].extend(np.argmax(pp,axis=1).tolist())
        conditional_labels=[];conditional_clean={m:[] for m in MODELS}
        for b in blocks:
            if not b['registered_group_valid'] or not b['events']:continue
            conditional_labels.extend([e['class_id']-1 for e in b['events']])
            cr=next(r for r in b['processed_clean'] if r['condition']==condition)
            for model in MODELS:conditional_clean[model].extend(np.argmax(cr['probabilities'][model],axis=1).tolist())
        conditional_defined=all(k in conditional_labels for k in (0,1))
        cond=dict(processed_clean={m:accuracy(cleanlabels,cleanpred[m]) for m in MODELS},common_feasible_processed_clean={m:accuracy(conditional_labels,conditional_clean[m]) if conditional_defined else None for m in MODELS},arms={})
        for arm in ARMS:
            labels=[];pred={m:[] for m in MODELS};flips={m:[] for m in MODELS};tv={m:[] for m in MODELS};maxdiff={m:[] for m in MODELS}
            delivered={m:dict(labels=[],predictions=[],clean_predictions=[],flips=[],tv=[],maxdiff=[]) for m in MODELS}
            q=[];joint={m:dict(labels=[],correct=[],retained=[],attributed=[]) for m in MODELS};attribution=[];cost=[];failed_events=0
            for b in blocks:
                yy=np.asarray([e['class_id']-1 for e in b['events']],dtype=int)
                clean=next(r for r in b['processed_clean'] if r['condition']==condition)
                rows=[r for r in b['rows'] if r['arm']==arm and r['condition']==condition];assert len(rows)==8
                for row in rows:
                    if row['issuance_feasible']:q.append(row['quality'])
                    else:failed_events+=len(yy)
                    labels.extend(yy.tolist())
                    if len(yy):
                        for model in MODELS:
                            cp=np.asarray(clean['probabilities'][model]);cclass=np.argmax(cp,axis=1)
                            if row['probabilities'] is None:
                                pp=None;ppclass=np.full(len(yy),-1)
                            else:pp=np.asarray(row['probabilities'][model]);ppclass=np.argmax(pp,axis=1)
                            pred[model].extend(ppclass.tolist())
                            # A missing prediction is a delivery failure. It has
                            # no observed flip or probability perturbation.
                            if pp is not None:
                                flips[model].extend((ppclass!=cclass).tolist())
                                tv[model].extend((np.abs(pp-cp).sum(axis=1)/2).tolist())
                                maxdiff[model].extend(np.max(np.abs(pp-cp),axis=1).tolist())
                            if pp is not None:
                                dd=delivered[model];dd['labels'].extend(yy.tolist());dd['predictions'].extend(ppclass.tolist());dd['clean_predictions'].extend(cclass.tolist());dd['flips'].extend((ppclass!=cclass).tolist());dd['tv'].extend((np.abs(pp-cp).sum(axis=1)/2).tolist());dd['maxdiff'].extend(np.max(np.abs(pp-cp),axis=1).tolist())
                    if row['recipient']==b['selected_joint_recipient']:
                        aa=row.get('attribution');correct=bool(aa is not None and aa['decision']==row['recipient']);attribution.append(correct)
                        if aa is not None:cost.append(aa['seconds'])
                        if len(yy):
                            for model in MODELS:
                                cp=np.argmax(np.asarray(clean['probabilities'][model]),axis=1)
                                pp=np.argmax(np.asarray(row['probabilities'][model]),axis=1) if row['probabilities'] is not None else np.full(len(yy),-1)
                                joint[model]['labels'].extend(yy.tolist());joint[model]['correct'].extend(((pp==yy)&correct).tolist());joint[model]['retained'].extend(((pp==cp)&correct).tolist());joint[model]['attributed'].extend([correct]*len(yy))
            assert len(attribution)==8
            entry=dict(fixed_recipient_attribution_correct=float(np.mean(attribution)),fixed_recipient_attribution_count=sum(attribution),fixed_recipient_attribution_denominator=8,failed_task_event_copies=failed_events,task_event_copy_delivery_fraction=1-failed_events/len(labels),quality={k:dict(mean=float(np.mean([v[k] for v in q])),maximum=float(np.max([v[k] for v in q]))) for k in ('global_ac_prd','max_channel_ac_prd','band_prd')} if q else None,attribution_seconds_mean=float(np.mean(cost)) if cost else None,models={})
            for model in MODELS:
                met=accuracy(labels,pred[model]);cleanmet=cond['processed_clean'][model];jj=joint[model];jy=np.asarray(jj['labels']);jc=np.asarray(jj['correct'])
                met.update(delta_accuracy=met['accuracy']-cleanmet['accuracy'],delta_balanced_accuracy=met['balanced_accuracy']-cleanmet['balanced_accuracy'],prediction_flip_fraction=float(np.mean(flips[model])) if flips[model] else None,probability_total_variation_mean=float(np.mean(tv[model])) if tv[model] else None,probability_max_absolute_change_mean=float(np.mean(maxdiff[model])) if maxdiff[model] else None,joint_correct_fraction=float(np.mean(jc)),joint_correct_balanced=float(np.mean([np.mean(jc[jy==k]) for k in (0,1)])),joint_prediction_retained_and_attributed=float(np.mean(jj['retained'])),task_event_attribution_coverage=float(np.mean(jj['attributed'])))
                dd=delivered[model];defined=all(k in dd['labels'] for k in (0,1))
                dmet=accuracy(dd['labels'],dd['predictions']) if defined else None
                dcmet=accuracy(dd['labels'],dd['clean_predictions']) if defined else None
                met['delivered_balanced_accuracy']=dmet['balanced_accuracy'] if defined else None
                met['delivered_delta_balanced_accuracy']=dmet['balanced_accuracy']-dcmet['balanced_accuracy'] if defined else None
                met['delivered_prediction_flip_fraction']=float(np.mean(dd['flips'])) if dd['flips'] else None
                met['delivered_probability_total_variation_mean']=float(np.mean(dd['tv'])) if dd['tv'] else None
                met['delivered_probability_max_absolute_change_mean']=float(np.mean(dd['maxdiff'])) if dd['maxdiff'] else None
                entry['models'][model]=met
            cond['arms'][arm]=entry
        result['conditions'][condition]=cond
    return result


def aggregate(people):
    report=dict(common_budget_point_availability=descriptive([p['registered_group_valid_blocks']/8 for p in people]),common_feasible_task_event_fraction=descriptive([p['n_common_feasible_task_events']/p['n_unique_task_events'] for p in people]),raw_clean={m:{k:descriptive([p['raw_clean'][m][k] for p in people]) for k in ('accuracy','balanced_accuracy')} for m in MODELS},conditions={},all_conditions={})
    metrics=('accuracy','balanced_accuracy','delta_accuracy','delta_balanced_accuracy','prediction_flip_fraction','probability_total_variation_mean','probability_max_absolute_change_mean','joint_correct_fraction','joint_correct_balanced','joint_prediction_retained_and_attributed','task_event_attribution_coverage')
    optional_metrics=('delivered_balanced_accuracy','delivered_delta_balanced_accuracy','delivered_prediction_flip_fraction','delivered_probability_total_variation_mean','delivered_probability_max_absolute_change_mean')
    for condition in CONDITIONS:
        cc=dict(processed_clean={m:{k:descriptive([p['conditions'][condition]['processed_clean'][m][k] for p in people]) for k in ('accuracy','balanced_accuracy')} for m in MODELS},common_feasible_processed_clean={m:{k:optional_descriptive([p['conditions'][condition]['common_feasible_processed_clean'][m][k] if p['conditions'][condition]['common_feasible_processed_clean'][m] is not None else None for p in people]) for k in ('accuracy','balanced_accuracy')} for m in MODELS},arms={})
        for arm in ARMS:
            cc['arms'][arm]=dict(attribution_correct=descriptive([p['conditions'][condition]['arms'][arm]['fixed_recipient_attribution_correct'] for p in people]),models={m:{k:optional_descriptive([p['conditions'][condition]['arms'][arm]['models'][m][k] for p in people]) for k in metrics} for m in MODELS})
            cc['arms'][arm]['task_event_copy_delivery_fraction']=descriptive([p['conditions'][condition]['arms'][arm]['task_event_copy_delivery_fraction'] for p in people])
            for model in MODELS:
                cc['arms'][arm]['models'][model].update({k:optional_descriptive([p['conditions'][condition]['arms'][arm]['models'][model][k] for p in people]) for k in optional_metrics})
        report['conditions'][condition]=cc
    for arm in ARMS:
        report['all_conditions'][arm]=dict(attribution_correct=descriptive([np.mean([p['conditions'][cc]['arms'][arm]['fixed_recipient_attribution_correct'] for cc in CONDITIONS]) for p in people]),models={m:{k:optional_descriptive([float(np.mean([p['conditions'][cc]['arms'][arm]['models'][m][k] for cc in CONDITIONS])) if all(p['conditions'][cc]['arms'][arm]['models'][m][k] is not None for cc in CONDITIONS) else None for p in people]) for k in metrics} for m in MODELS})
        report['all_conditions'][arm]['task_event_copy_delivery_fraction']=descriptive([np.mean([p['conditions'][cc]['arms'][arm]['task_event_copy_delivery_fraction'] for cc in CONDITIONS]) for p in people])
        for model in MODELS:
            report['all_conditions'][arm]['models'][model].update({k:optional_descriptive([float(np.mean([p['conditions'][cc]['arms'][arm]['models'][model][k] for cc in CONDITIONS])) if all(p['conditions'][cc]['arms'][arm]['models'][model][k] is not None for cc in CONDITIONS) else None for p in people]) for k in optional_metrics})
    return report


def markdown(report,people):
    n_events=sum(p['n_unique_task_events'] for p in people)
    n_feasible=sum(p['registered_group_valid_blocks'] for p in people)
    n_delivered=sum(p['conditions']['reexport']['common_feasible_processed_clean']['csp_lda']['n_events'] if p['conditions']['reexport']['common_feasible_processed_clean']['csp_lda'] is not None else 0 for p in people)
    def fmt(v,digits=2):return f'{100*v:.{digits}f}' if v is not None else '未定义'
    def effect(v):
        if v['mean'] is None:return '未定义'
        lo,hi=v['bootstrap_person_percentile_CI95']
        return f"{100*v['mean']:+.3f} [{100*lo:+.3f}, {100*hi:+.3f}]"
    lines=['# P191：新受试者任务效用与联合归属结果','',f'八名独立受试者（17–24），每人8个固定112秒区块，共{n_events}个唯一2秒任务事件。六载体均使用8个固定接收者和三类处理；统计单位为人（n=8）。', '',f'共同预算点可用性为{n_feasible}/64区块；这些共同可行区块覆盖{n_delivered}/{n_events}个原定任务事件。信号效用在所有载体共有的可行区块上配对比较同事件、同处理、同EDF网格干净信号。全分配联合成功率保留原定64区块与108事件的分母。共同点失败不等同于每个载体自身不可发行。', '', '| 模型 | 全部事件原始干净BA | 共同点重导出干净BA | 共同点椭圆滤波干净BA | 共同点Bessel滤波干净BA |','|---|---:|---:|---:|---:|']
    for model in MODELS:
        vals=[report['raw_clean'][model]['balanced_accuracy']['mean']]+[report['conditions'][cc]['common_feasible_processed_clean'][model]['balanced_accuracy']['mean'] for cc in CONDITIONS]
        lines.append('| '+model+' | '+' | '.join(fmt(v)+'%' if v is not None else '未定义' for v in vals)+' |')
    lines+=['','| 载体 | CSP ΔBA [95% CI]（百分点） | EEGNet ΔBA [95% CI]（百分点） | CSP预测翻转 | EEGNet预测翻转 | CSP平均概率TV | EEGNet平均概率TV |','|---|---:|---:|---:|---:|---:|---:|']
    for arm in ARMS:
        row=report['all_conditions'][arm];a=row['models']['csp_lda'];b=row['models']['eegnet']
        lines.append('| '+arm+' | '+effect(a['delivered_delta_balanced_accuracy'])+' | '+effect(b['delivered_delta_balanced_accuracy'])+' | '+fmt(a['delivered_prediction_flip_fraction']['mean'],3)+'% | '+fmt(b['delivered_prediction_flip_fraction']['mean'],3)+'% | '+fmt(a['delivered_probability_total_variation_mean']['mean'],5)+'pp | '+fmt(b['delivered_probability_total_variation_mean']['mean'],5)+'pp |')
    lines+=['','上表先在人内聚合8个接收者与3类处理，再对八人等权汇总。ΔBA取载体减配对干净信号；概率TV为两类预测概率的L1距离的一半。缺失预测不计作真实预测翻转或概率扰动。', '', '| 载体 | 全分配固定接收者归属正确 | 全分配CSP任务正确且归属正确 | 全分配EEGNet任务正确且归属正确 |','|---|---:|---:|---:|']
    for arm in ARMS:
        row=report['all_conditions'][arm]
        vals=[row['attribution_correct']['mean'],row['models']['csp_lda']['joint_correct_fraction']['mean'],row['models']['eegnet']['joint_correct_fraction']['mean']]
        lines.append('| '+arm+' | '+' | '.join(fmt(v)+'%' for v in vals)+' |')
    lines+=['','全分配联合指标将共同预算点失败计为系统未成功交付。每块只使用冻结接收者(subject+block)%8作归属，任务联合指标仅使用该接收者副本。完整JSON另保留三处理分项、各人差值、发行失败计错的全分配任务管线正确率与每块QC原因。', '', '95%区间使用20,000次以人为单位的百分位bootstrap（seed=191）。常量差值的经验bootstrap区间退化为单点；本实验未设非劣效或等价界。', '', 'modern_A400为经owner数据适配的公开结构RPW有限八身份载体。模型、区块、接收者、PRD上限与归属判决规则均沿用冻结协议。','']
    return '\n'.join(lines)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--wait',action='store_true');args=parser.parse_args()
    if args.wait:
        import time
        while not all((OUT/'results'/f'OpenBMI{s:03d}'/'COMPLETE.json').exists() for s in range(17,25)):time.sleep(15)
    assert sha(HERE/'TASK_EVALUATION_FREEZE.json')==FREEZE_SHA
    plan=load(HERE/'TASK_SUMMARY_ANALYSIS_PLAN.json');assert plan['summary_script_sha256']==sha(__file__)
    people=[];files={};n_feasible_blocks=0;event_ids=set();delivered_unique_task_events=0;common_failures=[]
    for subject in range(17,25):
        root=OUT/'results'/f'OpenBMI{subject:03d}';done=load(root/'COMPLETE.json');assert done['status']=='complete'
        blocks=[]
        for i in range(8):
            path=root/f'block{i:02d}.json.gz';b=load(path)
            assert b['status']=='complete' and b['evaluation_freeze_sha256']==FREEZE_SHA
            assert len(b['rows'])==144 and len({(r['arm'],r['recipient'],r['condition']) for r in b['rows']})==144
            assert b['selected_joint_recipient']==(subject+i)%8
            assert max(b['actual_all6_relative_spreads'],default=0.)<=.001
            for row in b['rows']:
                if row['issuance_feasible']:
                    quality=row['quality'];assert quality['global_ac_prd']<=.25 and quality['max_channel_ac_prd']<=.5 and quality['band_prd']<=1.
            n_feasible_blocks+=int(b['registered_group_valid'])
            for event in b['events']:
                assert event['event_id'] not in event_ids;event_ids.add(event['event_id'])
            if b['registered_group_valid']:delivered_unique_task_events+=len(b['events'])
            else:common_failures.append(common_failure_detail(subject,b))
            blocks.append(b);files[str(path)]=sha(path)
        people.append(person_summary(subject,blocks))
    assert sum(p['n_unique_task_events'] for p in people)==108
    report=aggregate(people)
    value=dict(status='complete_all8_people',evaluation_freeze_sha256=FREEZE_SHA,analysis_plan=plan,analysis_script_sha256=sha(__file__),metric_semantics=dict(primary_signal_utility='all-six-common-feasible blocks; same events and processing clean paired within person; flips and probability distances observed delivered predictions only',all_assigned_task_accuracy='composite correct-task AND delivery; unavailable predictions count as incorrect; not signal perturbation',all_assigned_joint='fixed recipient correct task AND correct attribution AND common-point availability; original planned denominators retained'),n_independent_people=8,n_unique_task_events=108,n_reference_blocks=64,n_all6_feasible_blocks=n_feasible_blocks,n_delivered_unique_task_events=delivered_unique_task_events,n_expected_pipeline_query_cases=64*6*8*3,n_expected_task_event_copy_predictions_per_model=108*6*8*3,n_expected_fixed_recipient_attribution_decisions=64*6*3,common_budget_point_failures=common_failures,people=people,aggregate=report,result_file_sha256=files)
    save(DEST/'TASK_UTILITY_PERSON_PAIRED_SUMMARY.json',value)
    (DEST/'TASK_UTILITY_RESULTS.md').write_text(markdown(report,people),encoding='utf-8')
    print(json.dumps(dict(stage='task_summary_complete',people=8,unique_events=108,output=str(DEST)),ensure_ascii=False),flush=True)


if __name__=='__main__':main()
