"""Wait for the fixed eight-person panel, then execute the current summarizer."""
from pathlib import Path
import json,subprocess,sys,time

HERE=Path(__file__).resolve().parent
while not all((HERE/'testphase_joint_utility/results'/f'OpenBMI{s:03d}'/'COMPLETE.json').exists() for s in range(17,25)):
    time.sleep(15)
result=subprocess.run([sys.executable,'-u',str(HERE/'summarize_task_utility.py')],cwd=HERE)
raise SystemExit(result.returncode)
