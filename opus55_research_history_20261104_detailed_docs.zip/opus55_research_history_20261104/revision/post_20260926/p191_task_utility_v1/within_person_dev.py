"""Standard within-person calibration, actual old-DEV test-phase validation.

Runs only after the pooled RMS EEGNet fails its capability gate. New17-28 EEG
is never loaded here. The four old test phases qualify the final task flow.
"""
from pathlib import Path
import os
for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):
    os.environ[key]='1'
import copy
import importlib.util
import json
import random
import time
import numpy as np
import torch
from torch import nn
import mne
from mne.decoding import CSP
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
import joblib
from models import EEGNet,EEGNET_AST_SHA256
from train_clean import sha,save,metrics,private_module
from rms_csp_pilot import normalized

HERE=Path(__file__).resolve().parent
BASE=HERE.parent
OUT=HERE/'within_person_dev01'
PEOPLE=(13,14,15,16)
EPOCHS=(25,50,100,200)
SEED=191


def actual_test_epochs(subject,old,reader):
    folder=OUT/'epochs';folder.mkdir(exist_ok=True)
    dest=folder/f'OpenBMI{subject:03d}_test.npz'
    if dest.exists():
        d=np.load(dest);return d['x'],d['y']
    def metadata(subject,phase='test'):
        assert subject in PEOPLE and phase=='test'
        document,mp,rp,receipt=old._metadata_and_receipt(subject)
        record=next(r for r in document['arrays'] if r['path']=='/EEG_MI_test')
        fields={r['path'].split('/')[-1]:r for r in record['children']}
        names=[r['value'] for r in fields['chan']['children']]
        assert fields['fs']['value']==[1000]
        return dict(subject=subject,session=1,phase='test',path=Path(document['path']),
                    native_shape=tuple(fields['x']['shape']),channels=old.CHANNELS,
                    channel_indices=[names.index(c) for c in old.CHANNELS],
                    cues_matlab=np.asarray(fields['t']['value'],dtype=np.int64),
                    labels=np.asarray(fields['y_dec']['value'],dtype=np.int64),native_hz=1000)
    reader.metadata=metadata;reader.CHANNELS=old.CHANNELS
    native,meta=reader.load_native_microvolts(subject,phase='test')
    phase=reader.resample_phase(native);del native
    starts=[int(np.floor((int(cue)-1)*4/25+.5))+80 for cue in meta['cues_matlab']]
    assert all(0<=s and s+320<=phase.shape[1] for s in starts)
    x=np.stack([phase[:,s:s+320] for s in starts]);y=meta['labels']-1
    assert x.shape==(100,8,320) and np.bincount(y).tolist()==[50,50]
    np.savez_compressed(dest,x=x,y=y)
    print(json.dumps(dict(stage='old_test_phase_prepared',subject=subject,epochs=len(y))),flush=True)
    return x,y


def net_probability(model,x):
    model.eval()
    with torch.no_grad():
        p=np.concatenate([torch.softmax(model(x[i:i+64]),dim=1).numpy() for i in range(0,len(x),64)]).astype(np.float64)
    return p/p.sum(axis=1,keepdims=True)


def score(y,p,subject):return metrics(y,p,np.full(len(y),subject))


def key(row):return (-row['source_mean_balanced_accuracy'],row['source_mean_log_loss'],row['size'])


def main():
    torch.set_num_threads(2);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True);mne.set_log_level('ERROR')
    pooled=json.loads((HERE/'RMS_MODEL_SELECTION.json').read_text(encoding='utf-8'))
    if pooled['qualified']['eegnet']:
        print('Pooled EEGNet qualified; no within-person expansion needed',flush=True);return
    OUT.mkdir(exist_ok=True)
    init_checkpoint=HERE/pooled['eegnet']['checkpoints'][0]
    protocol=dict(status='old_DEV_only_within_person_protocol_before_test_phase_decode',people=list(PEOPLE),
                  calibrate_phase='session1 train',independent_validation_phase='session1 test',
                  split='stratified80/20 trainphase indices,random_state191',epoch_seconds=[.5,2.5],hz=160,channels=8,
                  preprocessing='sameRMSnormaspooled; neuralmean/stdonly80train',csp_components=[2,4,6],
                  neural_inits=['scratch','pooled_warmstart'],epochs=list(EPOCHS),seed=SEED,lr=.001,batch_size=32,
                  pooled_warmstart_path=str(init_checkpoint),pooled_warmstart_sha256=sha(init_checkpoint),
                  select_each_person='trainphase20%val:BA,logloss,smallercomponents/fewerepochs; freeze80%-trainedmodelbeforetestphaseinference',
                  select_global_pipeline='old13-16independenttestphaseequal-personBA;logloss;earliestinit',
                  clean_BA_gate=.60,architecture_AST_sha256=EEGNET_AST_SHA256,script_sha256=sha(__file__),
                  future_newtask='17-24:fixedsamecalibrationalgorithm,freezeallpersonmodelsbeforetheirtestphasepredictions',
                  future_joint='testphasechronologicalfirstmin(8,complete112sblocks),same40sscoring/48svisible',
                  primary_attribution='unchangedtrainphasefirstcue112s',new_confirmation_EEG_decoded=False)
    save(OUT/'PROTOCOL.json',protocol);save(OUT/'RUN.json',dict(status='running',pid=os.getpid(),protocol_sha256=sha(OUT/'PROTOCOL.json')))
    print(json.dumps(dict(stage='within_person_started',pid=os.getpid(),protocol_sha256=sha(OUT/'PROTOCOL.json'))),flush=True)
    old=private_module('_p191_within_old_meta',BASE/'p190_experiment_v1/adapter.py')
    reader=private_module('_p191_within_old_decoder',BASE/'p184_new_record_preparation_v1/openbmi_adapter.py')
    results=[]
    for subject in PEOPLE:
        started=time.perf_counter();folder=OUT/f'OpenBMI{subject:03d}';folder.mkdir(exist_ok=True)
        d=np.load(HERE/'epochs'/f'OpenBMI{subject:03d}.npz');cx,cy=d['x'],d['y']
        train,val=train_test_split(np.arange(len(cy)),test_size=.2,stratify=cy,random_state=SEED)
        assert len(train)==80 and len(val)==20
        filtered=normalized(cx);xt,xv=filtered[train],filtered[val];yt,yv=cy[train],cy[val]
        csp_models=[]
        for components in (2,4,6):
            model=make_pipeline(CSP(n_components=components,reg='ledoit_wolf',log=True,norm_trace=False),
                                LinearDiscriminantAnalysis(solver='lsqr',shrinkage='auto'))
            model.fit(xt,yt);p=model.predict_proba(xv)
            record=dict(size=components,components=components,**score(yv,p,subject));csp_models.append((record,model))
        csp_selected,csp_model=min(csp_models,key=lambda row:key(row[0]));joblib.dump(csp_model,folder/'csp_selected.joblib')
        mean=xt.mean(axis=(0,2),keepdims=True);std=np.maximum(xt.std(axis=(0,2),keepdims=True),1e-12)
        np.savez(folder/'normalization.npz',mean=mean,std=std)
        tdata=torch.from_numpy(np.asarray((xt-mean)/std,dtype=np.float32)[:,None]);vdata=torch.from_numpy(np.asarray((xv-mean)/std,dtype=np.float32)[:,None]);truth=torch.from_numpy(yt)
        neural=[]
        for init in ('scratch','pooled_warmstart'):
            random.seed(SEED);np.random.seed(SEED);torch.manual_seed(SEED);model=EEGNet(2)
            if init=='pooled_warmstart':
                model.load_state_dict(torch.load(init_checkpoint,map_location='cpu',weights_only=False)['state_dict'])
            opt=torch.optim.Adam(model.parameters(),lr=.001);candidates=[];history=[]
            for epoch in range(1,201):
                model.train();loss_sum=0.
                for batch in torch.randperm(len(truth)).split(32):
                    opt.zero_grad(set_to_none=True);loss=nn.functional.cross_entropy(model(tdata[batch]),truth[batch]);loss.backward();opt.step();model.constrain();loss_sum+=float(loss.detach())*len(batch)
                history.append(dict(epoch=epoch,loss=loss_sum/len(truth)))
                if epoch in EPOCHS:
                    p=net_probability(model,vdata);name=f'eegnet_{init}_{epoch:03d}.pt'
                    torch.save(dict(state_dict=model.state_dict(),init=init,epochs=epoch,seed=SEED),folder/name)
                    candidates.append(dict(size=epoch,epochs=epoch,init=init,checkpoint=name,**score(yv,p,subject)))
            selected=min(candidates,key=key);save(folder/f'{init}_training.json',dict(history=history,validation_candidates=candidates,selected=selected))
            neural.append(selected)
        save(folder/'CALIBRATION_FROZEN.json',dict(subject=subject,train_indices=train.tolist(),val_indices=val.tolist(),
                                                  csp=csp_selected,eegnet=neural,normalization_sha256=sha(folder/'normalization.npz'),
                                                  no_test_phase_used_for_person_model_selection=True))
        # Models and per-person selections now fixed; decode actual old test phase.
        test_x,test_y=actual_test_epochs(subject,old,reader);test=normalized(test_x)
        csp_p=csp_model.predict_proba(test);np.save(folder/'csp_test_probability.npy',csp_p)
        neural_test=[];test_data=torch.from_numpy(np.asarray((test-mean)/std,dtype=np.float32)[:,None])
        for selected in neural:
            model=EEGNet(2);model.load_state_dict(torch.load(folder/selected['checkpoint'],map_location='cpu',weights_only=False)['state_dict'])
            p=net_probability(model,test_data);np.save(folder/f"{selected['init']}_test_probability.npy",p)
            neural_test.append(dict(init=selected['init'],epochs=selected['epochs'],checkpoint=selected['checkpoint'],**score(test_y,p,subject)))
        result=dict(subject=subject,csp=dict(components=csp_selected['components'],**score(test_y,csp_p,subject)),eegnet=neural_test,seconds=time.perf_counter()-started)
        results.append(result);save(folder/'RESULT.json',result)
        print(json.dumps(dict(stage='person_complete',subject=subject,csp_BA=result['csp']['source_mean_balanced_accuracy'],
                              eegnet_BA={r['init']:r['source_mean_balanced_accuracy'] for r in neural_test})),flush=True)
    csp_BA=float(np.mean([r['csp']['source_mean_balanced_accuracy'] for r in results]));net=[]
    for init in ('scratch','pooled_warmstart'):
        rows=[next(z for z in r['eegnet'] if z['init']==init) for r in results]
        net.append(dict(init=init,source_mean_balanced_accuracy=float(np.mean([r['source_mean_balanced_accuracy'] for r in rows])),
                        source_mean_log_loss=float(np.mean([r['source_mean_log_loss'] for r in rows]))))
    selected=min(net,key=lambda r:(-r['source_mean_balanced_accuracy'],r['source_mean_log_loss'],r['init']))
    summary=dict(status='old_DEV_within_person_capability_complete',people=results,csp_BA=csp_BA,eegnet_candidates=net,eegnet_selected=selected,
                  qualified={'csp_lda':csp_BA>=.60,'eegnet':selected['source_mean_balanced_accuracy']>=.60},
                  protocol_sha256=sha(OUT/'PROTOCOL.json'),new_confirmation_predictions=0)
    save(OUT/'RESULT.json',summary);save(OUT/'RUN.json',dict(status='terminal_capability_complete',pid=os.getpid(),result_sha256=sha(OUT/'RESULT.json')))
    print(json.dumps(dict(stage='within_person_complete',qualified=summary['qualified'],csp_BA=csp_BA,eegnet=selected)),flush=True)


if __name__=='__main__':main()
