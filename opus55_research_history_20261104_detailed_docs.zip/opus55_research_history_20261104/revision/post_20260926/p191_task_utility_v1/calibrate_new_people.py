"""Frozen person-specific calibration on new17-24 train phases only.

Allpersonmodelsfreeze precedes any test-phase signal decode/prediction. No
per-person validation result changes the frozen workpoint or participant list.
"""
from pathlib import Path
import os
for name in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[name]='1'
import argparse
import importlib.util
import json
import random
import time
import numpy as np
import torch
from torch import nn
import mne
from mne.decoding import CSP
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
import joblib
from models import EEGNet
from train_clean import sha,save,metrics
from rms_csp_pilot import normalized
from within_person_dev import net_probability

HERE=Path(__file__).resolve().parent
RECORDS=HERE.parent/'p191_new_records_v1'
OUT=HERE/'new_person_calibration'


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--freeze',type=Path,required=True);args=parser.parse_args()
    freeze=json.loads(args.freeze.read_text(encoding='utf-8'));digest=sha(args.freeze)
    assert freeze['status']=='frozen_task_calibration_procedure_before_new_task_EEG'
    assert freeze['targets']==list(range(17,25)) and freeze['new_test_phase_access']=='prohibited_until_all_models_frozen_and_evaluation_protocol'
    for path,expected in freeze['code_sha256'].items():assert sha(path)==expected,('Frozen task code changed',path)
    torch.set_num_threads(2);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True);mne.set_log_level('ERROR')
    OUT.mkdir(exist_ok=True);save(OUT/'RUN.json',dict(status='running',pid=os.getpid(),task_calibration_freeze_sha256=digest))
    spec=importlib.util.spec_from_file_location('_p191_frozen_task_phase_adapter',RECORDS/'task_adapter.py');adapter=importlib.util.module_from_spec(spec);spec.loader.exec_module(adapter)
    rows=[];initial=Path(freeze['eegnet']['initial_checkpoint']);assert sha(initial)==freeze['eegnet']['initial_checkpoint_sha256']
    for subject in freeze['targets']:
        folder=OUT/f'OpenBMI{subject:03d}';folder.mkdir(exist_ok=True);final=folder/'CALIBRATION_COMPLETE.json'
        if final.exists():
            row=json.loads(final.read_text(encoding='utf-8'));assert row['task_calibration_freeze_sha256']==digest
            for path,expected in row['model_sha256'].items():assert sha(path)==expected
            rows.append(row);continue
        started=time.perf_counter()
        volts,meta=adapter.load_phase(subject,'train',freeze_path=args.freeze,expected_freeze_sha256=digest,allow_new=True)
        raw,y=adapter.epochs_from_phase(volts,meta);del volts
        np.savez_compressed(folder/'trainphase_epochs.npz',x=raw,y=y)
        train,val=train_test_split(np.arange(100),test_size=.2,stratify=y,random_state=191)
        filtered=normalized(raw);xt,xv=filtered[train],filtered[val];yt,yv=y[train],y[val]
        csp=make_pipeline(CSP(n_components=4,reg='ledoit_wolf',log=True,norm_trace=False),LinearDiscriminantAnalysis(solver='lsqr',shrinkage='auto'))
        csp.fit(xt,yt);joblib.dump(csp,folder/'csp_lda.joblib');csp_p=csp.predict_proba(xv)
        mean=xt.mean(axis=(0,2),keepdims=True);std=np.maximum(xt.std(axis=(0,2),keepdims=True),1e-12)
        np.savez(folder/'normalization.npz',mean=mean,std=std)
        tx=torch.from_numpy(np.asarray((xt-mean)/std,dtype=np.float32)[:,None]);vx=torch.from_numpy(np.asarray((xv-mean)/std,dtype=np.float32)[:,None]);ty=torch.from_numpy(yt)
        random.seed(191);np.random.seed(191);torch.manual_seed(191);model=EEGNet(2)
        model.load_state_dict(torch.load(initial,map_location='cpu',weights_only=False)['state_dict']);opt=torch.optim.Adam(model.parameters(),lr=.001);history=[]
        for epoch in range(1,26):
            model.train();total=0.
            for batch in torch.randperm(len(ty)).split(32):
                opt.zero_grad(set_to_none=True);loss=nn.functional.cross_entropy(model(tx[batch]),ty[batch]);loss.backward();opt.step();model.constrain();total+=float(loss.detach())*len(batch)
            history.append(dict(epoch=epoch,train_loss=total/len(ty)))
        torch.save(dict(state_dict=model.state_dict(),seed=191,epochs=25,initial_checkpoint_sha256=freeze['eegnet']['initial_checkpoint_sha256']),folder/'eegnet.pt')
        neural_p=net_probability(model,vx);np.save(folder/'csp_val_probability.npy',csp_p);np.save(folder/'eegnet_val_probability.npy',neural_p)
        paths=[folder/'csp_lda.joblib',folder/'eegnet.pt',folder/'normalization.npz']
        row=dict(subject=subject,status='model_calibration_complete_testphase_unopened',task_calibration_freeze_sha256=digest,
                 train_phase_raw_file_sha256=meta['raw_file_sha256'],train_indices=train.tolist(),validation_indices=val.tolist(),
                 model_sha256={str(p):sha(p) for p in paths},history=history,
                 diagnostics=dict(csp=metrics(yv,csp_p,np.full(len(yv),subject)),eegnet=metrics(yv,neural_p,np.full(len(yv),subject))),
                 diagnostics_affect_workpoint_or_inclusion=False,test_phase_signal_decoded=False,test_predictions=0,
                 seconds=time.perf_counter()-started)
        save(final,row);rows.append(row);print(json.dumps(dict(subject=subject,stage='frozen_model_calibration_complete',seconds=row['seconds'])),flush=True)
    report=dict(status='all8_person_models_frozen_testphase_unopened',task_calibration_freeze_sha256=digest,targets=freeze['targets'],
                models=rows,all_model_sha256={path:digest for row in rows for path,digest in row['model_sha256'].items()},
                test_phase_signal_decoded=False,new_test_predictions=0)
    save(OUT/'ALL_PERSON_MODELS_FROZEN.json',report)
    save(OUT/'RUN.json',dict(status='terminal_all8_models_frozen',pid=os.getpid(),model_freeze_sha256=sha(OUT/'ALL_PERSON_MODELS_FROZEN.json')))
    print(json.dumps(dict(stage='all8_person_models_frozen',new_test_predictions=0)),flush=True)


if __name__=='__main__':main()
