"""One bounded explanation check: source-amplitude nuisance in pooled CSP."""
from pathlib import Path
import os
for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):
    os.environ[key]='1'
import json
import hashlib
import joblib
import numpy as np
import mne
from mne.decoding import CSP
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.pipeline import make_pipeline
from train_clean import metrics, sha, save
from models import filtered

HERE=Path(__file__).resolve().parent
OUT=HERE/'rms_pilot01'


def normalized(x):
    z=filtered(x)
    z=z-z.mean(axis=-1,keepdims=True)
    return z/np.maximum(np.sqrt(np.mean(z*z,axis=(1,2),keepdims=True)),1e-12)


def main():
    mne.set_log_level('ERROR');OUT.mkdir(exist_ok=True)
    baseline=json.loads((HERE/'MODEL_SELECTION.json').read_text(encoding='utf-8'))
    protocol=dict(hypothesis='cross-person common amplitude variation biases pooled absolute CSP powers',
                  intervention='per-epochdemeanthenonecommon8channelRMS; no channelwise whitening or per-source recalibration',
                  train=list(range(1,13)),validation=list(range(13,17)),fixed_components=4,
                  baseline_selection_sha256=sha(HERE/'MODEL_SELECTION.json'),script_sha256=sha(__file__),
                  success_gate=.60,new_confirmation_access=False)
    save(OUT/'PROTOCOL.json',protocol)
    tx,ty,vx,vy,vs,geometry=[],[],[],[],[],[]
    for s in range(1,17):
        d=np.load(HERE/'epochs'/f'OpenBMI{s:03d}.npz');x,y=d['x'],d['y']
        f=filtered(x);r=np.sqrt(np.mean(f*f,axis=(1,2)))
        geometry.append(dict(subject=s,median_RMS_volts=float(np.median(r)),q10=float(np.quantile(r,.1)),q90=float(np.quantile(r,.9))))
        if s<=12:tx.append(normalized(x));ty.append(y)
        else:vx.append(normalized(x));vy.append(y);vs.extend([s]*len(y))
    tx,ty,vx,vy,vs=np.concatenate(tx),np.concatenate(ty),np.concatenate(vx),np.concatenate(vy),np.asarray(vs)
    model=make_pipeline(CSP(n_components=4,reg='ledoit_wolf',log=True,norm_trace=False),
                        LinearDiscriminantAnalysis(solver='lsqr',shrinkage='auto'))
    model.fit(tx,ty);p=model.predict_proba(vx);m=metrics(vy,p,vs)
    joblib.dump(model,OUT/'csp_rms4.joblib');np.save(OUT/'val_probability.npy',p)
    result=dict(status='one_key_explanation_check_complete',original_BA=baseline['csp_lda']['source_mean_balanced_accuracy'],
                geometry=geometry,qualified=m['source_mean_balanced_accuracy']>=.60,**m,
                checkpoint_sha256=sha(OUT/'csp_rms4.joblib'),new_confirmation_predictions=0)
    save(OUT/'RESULT.json',result);print(json.dumps(result),flush=True)


if __name__=='__main__':main()
