"""Frozen six-carrier joint task utility on new test-phase112s blocks.

All eight recipient task predictions; one prespecified recipient per block for
joint attribution. Processing-clean is the primary utility reference. No fit,
threshold adjustment, or participant/block selection uses test predictions.
"""
from pathlib import Path
import os,sys
for name in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[name]='1'
import argparse,gzip,json,random,time
import numpy as np
import torch
import joblib
from models import EEGNet
from train_clean import sha,save,private_module
from rms_csp_pilot import normalized

HERE=Path(__file__).resolve().parent
BASE=HERE.parent
ROOT=BASE.parents[1]
RECORDS=BASE/'p191_new_records_v1'
OUT=HERE/'testphase_joint_utility'
sys.path[:0]=[str(BASE/'p191_fir_capacity_v1'),str(BASE/'p191_modern_carrier_v1'),str(ROOT)]
from dev_capacity import DevelopmentReceiver
import calibrate_allarms as rules_api
import a400_carrier as modern_api
from threadpoolctl import threadpool_limits

ARMS=('smooth','direct','hybrid05','spatial','qid','modern_A400')
CONDITIONS=('reexport','elliptic_new_causal','bessel_shifted_causal')


def load(path):
    path=Path(path);raw=path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.suffix=='.gz' else raw)


def checkpoint(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    raw=(json.dumps(value,ensure_ascii=False,allow_nan=False,separators=(',',':'))+'\n').encode()
    if path.suffix=='.gz':raw=gzip.compress(raw,compresslevel=5,mtime=0)
    temporary=path.with_name(path.name+'.writing');temporary.write_bytes(raw);temporary.replace(path)


def person_models(subject):
    folder=HERE/'new_person_calibration'/f'OpenBMI{subject:03d}'
    csp=joblib.load(folder/'csp_lda.joblib');norm=np.load(folder/'normalization.npz')
    model=EEGNet(2);model.load_state_dict(torch.load(folder/'eegnet.pt',map_location='cpu',weights_only=False)['state_dict']);model.eval()
    def predict(raw):
        x=normalized(raw);p0=csp.predict_proba(x)
        data=torch.from_numpy(np.asarray((x-norm['mean'])/norm['std'],dtype=np.float32)[:,None])
        with torch.no_grad():p1=torch.softmax(model(data),dim=1).numpy().astype(np.float64)
        p1/=p1.sum(axis=1,keepdims=True)
        return dict(csp_lda=p0.tolist(),eegnet=p1.tolist())
    return predict


def epochs(value,events):
    if not events:return None
    return np.stack([value[:,e['epoch_start_sample']:e['epoch_start_sample']+320] for e in events])


def reused_issuer():
    issuer=private_module('_p191_task_private_registered_only_issuer',BASE/'p190_experiment_v1/run_experiment.py')
    issuer.HERE=OUT;issuer.environment()
    codes,info=issuer.phase_codes('confirm');codes,info=codes[:8],info[:8]
    issuer.phase_codes=lambda cohort:(codes,info)
    qmessages=issuer.qid.fixed_messages()[:8]
    issuer.qid.fixed_messages=lambda:qmessages
    return issuer,codes


def common_cap(m,x,limits,source_folder,codes,carrier):
    """Registered-only QC, before QIM issuance or any task/receiver scores."""
    final=source_folder/'ALL6_COMMON_CAP_QC.json'
    if final.exists():return load(final)
    capfile=source_folder/'source_common_cap_before_QIM.json'
    original_path=source_folder/'ORIGINAL_PHASE_CAP.json'
    if original_path.exists():original=load(original_path);baseline=original['cap']
    elif capfile.exists():original=load(capfile);baseline=original['cap']
    else:
        baseline=m.phase_nominal_cap(x,limits,source_folder,codes);original=load(capfile)
    save(original_path,original)
    residuals=[carrier.residual(x,bits) for bits in carrier.registered_bits]
    trials=[];selected=None
    for fraction in (1.,.75,.5,.25):
        cap=baseline*fraction;entries=[]
        for delta in residuals:
            ideal,detail=modern_api.m.match(x,delta,limits,cap)
            entries.append(dict(feasible=ideal is not None,status=detail['status'],quality=detail.get('quality')))
        trials.append(dict(cap=cap,fraction=fraction,registered_modern=entries))
        if all(r['feasible'] for r in entries):selected=cap;break
    result=dict(status='feasible' if selected is not None else 'infeasible',baseline_phase_cap=baseline,selected_common_cap=selected,
                trials=trials,selection='highestfixedregistered-QC-onlycommonfraction,noevents/labels/predictionsused')
    if selected is not None:save(capfile,dict(original,cap=selected,all6_registered_QC=True,baseline_phase_cap=baseline))
    save(final,result);return result


def decision(feature,rule):
    value,eligible,top=rules_api.score(dict(receiver=feature),'candidate_FIR_GLRT',rule)
    return dict(score=float(value),eligible=bool(eligible),top=int(top),decision=int(top) if eligible and value>=rule['threshold'] else -1,
                threshold=rule['threshold'])


def run_block(issuer,m,carrier,source,block,raw,events,predict,freeze,digest,classical_rules,modern_rules):
    name=f'OpenBMI{source:03d}_task_test_b{block:02d}'
    final=OUT/'results'/f'OpenBMI{source:03d}'/f'block{block:02d}.json.gz'
    if final.exists():
        prior=load(final);assert prior['evaluation_freeze_sha256']==digest
        if prior['status']=='complete':return prior
    else:prior=None
    folder=OUT/'sources'/name;folder.mkdir(parents=True,exist_ok=True)
    limits=m.p.ranges(raw);receipts=[]
    x,h0=m.io.edf_roundtrip(raw,limits,'clean.edf',folder,receipts,True,m.domain.BCI_CHANNELS)
    source_doc=dict(source=name,subject=source,phase='test',block_index=block,origin_native=block*112000,
                    reference_seconds=112,clean_EDF=receipts[-1],test_panel_metadata_sha256=freeze['test_panel_metadata_sha256'])
    save(folder/'source.json',source_doc)
    record=dict(name=name,folder=folder,x=x,h0=h0,limits=limits,source=source_doc)
    codes,_=issuer.phase_codes('confirm');qc=common_cap(m,x,limits,folder,codes,carrier)
    copies={};quality={};issuance=None
    if qc['status']=='feasible':
        copies,metadata,issuance=issuer.issue_point(m,record,1.,'confirm')
        modern_copies=[];modern_quality=[];modern_rows=[]
        mf=OUT/'issuance'/name/'level100'/'modern_A400'
        for rid,bits in enumerate(carrier.registered_bits):
            target=issuance['QID_anchors'][rid]
            result=carrier.issue_actual_edf(x,bits,limits,target,mf,f'modern_A400_r{rid}_issued.edf') if target is not None else dict(feasible=False,matching={'status':'QID_anchor_infeasible'})
            modern_copies.append(result.get('readback_v'));modern_quality.append(result.get('quality'))
            modern_rows.append({k:v for k,v in result.items() if k not in ('readback_v','pre_EDF_v','virtual_readback_v')})
        copies['modern_A400']=modern_copies;save(mf/'ISSUANCE.json',dict(rows=modern_rows))
        for arm in ARMS:quality[arm]=[m.p.quality(x,y) if y is not None else None for y in copies[arm][:8]]
    valid=bool(issuance and issuance['registered_group_valid'] and all(y is not None for y in copies.get('modern_A400',[])) and len(copies.get('modern_A400',[]))==8)
    spreads=[]
    if valid:
        for rid in range(8):
            values=[quality[arm][rid]['global_ac_prd'] for arm in ARMS];spreads.append((max(values)-min(values))/min(values));assert spreads[-1]<=.001
    selected_rid=(source+block)%8
    baseline_raw=prior['raw_clean_probabilities'] if prior else (predict(epochs(raw,events)) if events else None)
    rows=prior['rows'] if prior else [];clean_rows=prior.get('processed_clean',[]) if prior else []
    done={(r['arm'],r['recipient'],r['condition']) for r in rows}
    clean_done={r['condition'] for r in clean_rows};all_receipts=prior.get('query_EDF_receipts',[]) if prior else []
    result=prior if prior else {}
    transformed_clean={c:m.c.transform(x,c) for c in CONDITIONS}
    transformed={}
    for c in CONDITIONS:
        values=[transformed_clean[c]]
        if valid:
            for arm in ARMS:
                transformed[arm,c]=[m.c.transform(y,c) for y in copies[arm][:8]]
                values.extend(transformed[arm,c])
        qlimits=m.p.ranges(np.concatenate(values,axis=1))
        if c not in clean_done:
            query,_=m.io.edf_roundtrip(transformed_clean[c],qlimits,f'{name}_clean_{c}.edf',final.parent,all_receipts,False,m.domain.BCI_CHANNELS)
            clean_rows.append(dict(condition=c,probabilities=predict(epochs(query,events)) if events else None,query_raw_sha256=all_receipts[-1]['raw_sha256']))
        for arm in ARMS:
            todo=[rid for rid in range(8) if (arm,rid,c) not in done]
            if not todo:continue
            receiver=DevelopmentReceiver(x,np.asarray(copies[arm][:8]),257) if valid else None
            rule=(modern_rules['methods']['257/candidate_FIR_GLRT/exact'] if arm=='modern_A400' else classical_rules['rules'][arm]['257/candidate_FIR_GLRT/exact'])['selected']
            for rid in todo:
                if valid:
                    query,_=m.io.edf_roundtrip(transformed[arm,c][rid],qlimits,f'{name}_{arm}_r{rid}_{c}.edf',final.parent,all_receipts,False,m.domain.BCI_CHANNELS)
                    probabilities=predict(epochs(query,events)) if events else None
                    attribution=None
                    if rid==selected_rid:
                        started=time.perf_counter();feature=receiver.extract_all(query)
                        attribution=dict(decision(feature,rule),seconds=time.perf_counter()-started,
                                         candidate_features=feature['methods']['candidate_FIR_GLRT']['by_ridge'])
                    row=dict(arm=arm,recipient=rid,condition=c,issuance_feasible=True,probabilities=probabilities,
                             quality=quality[arm][rid],query_raw_sha256=all_receipts[-1]['raw_sha256'],attribution=attribution)
                else:row=dict(arm=arm,recipient=rid,condition=c,issuance_feasible=False,probabilities=None,attribution=None,failure_reason='six_carrier_common_anchor_group_infeasible')
                rows.append(row)
            result=dict(status='running',subject=source,phase='test',block=block,events=events,rows=rows,processed_clean=clean_rows,
                        raw_clean_probabilities=baseline_raw,selected_joint_recipient=selected_rid,registered_group_valid=valid,
                        common_cap_QC=qc,actual_all6_relative_spreads=spreads,query_EDF_receipts=all_receipts,
                        evaluation_freeze_sha256=digest,scored_seconds=40,visible_seconds=48,reference_seconds=112)
            checkpoint(final,result)
            print(json.dumps(dict(stage='task_block_arm',subject=source,block=block,arm=arm,condition=c,rows=len(rows))),flush=True)
    result['status']='complete';checkpoint(final,result);return result


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--freeze',type=Path,required=True);parser.add_argument('--subject',type=int,choices=range(17,25),required=True);args=parser.parse_args()
    freeze=load(args.freeze);digest=sha(args.freeze);assert freeze['status']=='frozen_before_new_task_test_phase_signal'
    for path,expected in freeze['file_sha256'].items():assert sha(path)==expected,('Task evaluation frozen file changed',path)
    assert freeze['targets']==list(range(17,25))
    torch.set_num_threads(2);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
    source=args.subject;predict=person_models(source);adapter=private_module('_p191_test_phase_after_all_person_models_frozen',RECORDS/'task_adapter.py')
    phase,meta=adapter.load_phase(source,'test',freeze_path=args.freeze,expected_freeze_sha256=digest,allow_new=True)
    panel=load(RECORDS/'MULTIBLOCK_TEST_PHASE_METADATA.json');person=next(r for r in panel['people'] if r['subject']==source)
    issuer,codes=reused_issuer();m=issuer.backend(f'task-test-{source}');carrier=modern_api.FixedA400Carrier()
    classical=load(BASE/'p191_fir_capacity_v1/ALLARM_DEV_RULES.json');modern=load(BASE/'p191_modern_carrier_v1/common_owner_dev02/MODERN_DEV_LOCK.json')
    with threadpool_limits(limits=1):
        for block,value in adapter.chronological_blocks(phase,meta,8):
            events=next(r['events'] for r in person['blocks'] if r['block_id']==block)
            run_block(issuer,m,carrier,source,block,value,events,predict,freeze,digest,classical,modern)
    save(OUT/'results'/f'OpenBMI{source:03d}'/'COMPLETE.json',dict(status='complete',subject=source,blocks=len(person['blocks']),
                                                                evaluation_freeze_sha256=digest,test_task_epochs=person['n_epochs']))
    print(json.dumps(dict(stage='task_person_complete',subject=source)),flush=True)


if __name__=='__main__':main()
