"""Frozen, raw-voltage epoch inference for the RMS-adapted binary task models."""
from pathlib import Path
import json
import joblib
import numpy as np
import torch
from models import EEGNet
from rms_csp_pilot import normalized

HERE=Path(__file__).resolve().parent


class RMS_CSP:
    def __init__(self,path):self.model=joblib.load(path)
    def predict_proba(self,x):return self.model.predict_proba(normalized(x))


class RMS_EEGNet:
    def __init__(self,paths,normalization):
        self.mean,self.std=normalization['mean'],normalization['std'];self.models=[]
        for path in paths:
            state=torch.load(path,map_location='cpu',weights_only=False)
            model=EEGNet(2);model.load_state_dict(state['state_dict']);model.eval();self.models.append(model)
    def predict_proba(self,x):
        x=torch.from_numpy(np.asarray((normalized(x)-self.mean)/self.std,dtype=np.float32)[:,None])
        values=[]
        with torch.no_grad():
            for model in self.models:
                values.append(np.concatenate([torch.softmax(model(x[i:i+64]),dim=1).numpy() for i in range(0,len(x),64)]))
        out=np.mean(values,axis=0).astype(np.float64);return out/out.sum(axis=1,keepdims=True)


def load_rms_models(folder=HERE):
    folder=Path(folder);d=json.loads((folder/'RMS_MODEL_SELECTION.json').read_text(encoding='utf-8'))
    return dict(csp_lda=RMS_CSP(folder/d['csp_lda']['checkpoint']),
                eegnet=RMS_EEGNet([folder/p for p in d['eegnet']['checkpoints']],dict(np.load(folder/d['normalization']))))
