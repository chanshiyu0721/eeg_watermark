"""Historical-only parity and pre-freeze new-source decode-gate checks."""
from pathlib import Path
import hashlib,importlib.util,inspect,json,os,platform,time
from unittest import mock

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
for key in ('TEMP','TMP','MPLCONFIGDIR','NUMBA_CACHE_DIR','JOBLIB_TEMP_FOLDER'):
    path=ROOT/'tmp/p190_adapter_cache'/key.lower();path.mkdir(parents=True,exist_ok=True);os.environ[key]=str(path)
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'

import numpy as np
import scipy
import adapter

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    started=time.monotonic()
    old_files=[adapter.P184/'openbmi_adapter.py',adapter.P184/'inspect_mat_metadata.py',adapter.P186/'adapter.py']
    before={str(p):sha(p) for p in old_files}
    original=importlib.util.spec_from_file_location('_p190_selfcheck_original',adapter.P184/'openbmi_adapter.py')
    original_module=importlib.util.module_from_spec(original);original.loader.exec_module(original_module)
    names=['load_native_microvolts','resample_phase','_nearest_nonnegative','anchor_metadata','reference_from_phase','load_reference']
    functions={name:inspect.getsource(getattr(adapter._PRIOR,name))==inspect.getsource(getattr(original_module,name)) for name in names}
    assert all(functions.values())
    one=adapter.metadata(1)
    assert one['channels']==('FC3','FC4','C3','C4','Cz','CP3','CP4','Pz')
    assert one['channel_indices']==[32,33,12,14,13,38,40,24]
    assert int(one['cues_matlab'][0])==198717
    rejected=[]
    missing=HERE/'selfcheck_absent_confirmation_freeze.json'
    assert not missing.exists()
    def never_decode(*args,**kwargs):raise AssertionError('New-source decoder must not be reached in selfcheck')
    with mock.patch.object(adapter,'CONFIRMATION_FREEZE',missing),mock.patch.object(adapter._PRIOR,'load_reference',never_decode):
        for subject in range(5,17):
            for flag in (False,True):
                try:adapter.load_reference(subject,allow_new=flag)
                except PermissionError:rejected.append(dict(subject=subject,allow_new=flag,blocked_before_metadata_or_decode=True))
                else:raise AssertionError((subject,flag))
    assert len(rejected)==24
    prior_spec=importlib.util.spec_from_file_location('_p190_selfcheck_p186',adapter.P186/'adapter.py')
    prior=importlib.util.module_from_spec(prior_spec);prior_spec.loader.exec_module(prior)
    x,d=adapter.load_reference(3)
    historical,hd=prior.load_reference(3)
    assert x.shape==historical.shape==(8,17920)
    assert x.dtype==historical.dtype==np.float64
    assert x.tobytes()==historical.tobytes(),'Historical source3 adapted bytes differ'
    keys=['channels','physical_channel_indices','native_origin_sample','target_origin_sample','native_origin_seconds',
          'target_origin_seconds','origin_rounding_error_seconds','score_task_events','all_reference_task_events','resampling',
          'raw_file_sha256','native_source_path']
    assert all(d[k]==hd[k] for k in keys)
    assert d['native_origin_sample']==148451
    assert d['physical_channel_indices']==[32,33,12,14,13,38,40,24]
    assert before=={str(p):sha(p) for p in old_files}
    output=dict(status='passed',scope='historical subject3 byte parity and metadata/gate checks only',
        numerical_function_bodies_unchanged=functions,
        historical_subject3=dict(shape=list(x.shape),dtype=str(x.dtype),float64_bytes_sha256=hashlib.sha256(x.tobytes()).hexdigest(),
                                equal_prior_P186_bytes=True,description_keys_equal=keys,description=d),
        subject1_metadata=dict(selected_channels=list(one['channels']),physical_channel_indices=one['channel_indices'],
                               first_matlab_cue=int(one['cues_matlab'][0]),signal_values_decoded=False,
                               metadata_path=str(one['metadata_path']),metadata_sha256=one['metadata_sha256']),
        new_subject_gate_checks=rejected,new_subjects_decoded=[],new_source_receiver_scores=0,new_source_task_predictions=0,
        prior_source_file_hashes=before,prior_sources_unchanged=True,
        adapter_sha256=sha(HERE/'adapter.py'),selfcheck_sha256=sha(Path(__file__)),
        python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,seconds=time.monotonic()-started)
    (HERE/'ADAPTER_VALIDATION.json').write_text(json.dumps(output,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps({'status':output['status'],'historical_subject3_byte_parity':True,'new_subject_gate_checks':len(rejected),'new_subjects_decoded':[],'seconds':output['seconds']}))

if __name__=='__main__':main()
