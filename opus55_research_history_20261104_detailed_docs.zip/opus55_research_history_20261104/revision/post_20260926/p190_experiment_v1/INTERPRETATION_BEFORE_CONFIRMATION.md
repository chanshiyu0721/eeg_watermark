# Interpretation fixed before confirmation

Recorded 2026-10-30 while DEV runs; no changes to signal generation, selection, endpoints, success gates or the frozen collector contract.

The deletion calculation removes calibration-evidence rows explicitly naming a canonical person as `source` or `negative_source`. It reuses the fixed issued/query EDF bytes and receiver evidence. In particular, it does not regenerate quantization ranges after deleting a wrong-source person. Delta is therefore threshold influence in the saved evidence, rather than an end-to-end leave-person-out refit or an impulse-response confidence interval.

The declared query EDF range for each target and processing condition is computed from transformed clean plus all allocated wrong-source signals. Because the same four confirmation wrong-source people are used across targets, the eight target-person contrasts and their uncertainty are conditional on this fixed wrong-source/range fixture, as well as the fixed identities and processing grid. Fit and select use completely separate role-specific target/wrong people. The main paired comparison shares the actual bytes and range fixture across every calibration procedure.

The four negative people remain the units for describing wrong-source variation; crossed target-by-negative cells are not independent negative people. Person-paired t and sign-flip calculations retain their stated distribution/symmetry assumptions. This clarification adds no new experiment and cannot change the success decision.
