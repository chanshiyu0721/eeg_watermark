"""Synthetic end-to-end decision/serialization checks, never real EEG evidence."""
from pathlib import Path
import copy,json,sys
import analysis as a
sys.path.insert(0,str(a.BASE/'p190_calibration_v1'))
from test_calibration import row

HERE=Path(__file__).resolve().parent
OUT=HERE/'analysis_checks'
OUT.mkdir(exist_ok=True)
rows=[]
for source in [f'S{i}' for i in range(8)]:
    for condition in a.CONDITIONS:
        for identity in range(8):
            rows.append(row(source,'confirm','enrolled',.9,.9,identity=identity,condition=condition))
        rows.append(row(source,'confirm','phase_near_unregistered',.8,.5,condition=condition))
        rows.append(row(source,'confirm','clean',.1,.1,condition=condition))
        rows.append(row(source,'confirm','wrong_source',.1,.1,condition=condition,negative_source='N1'))
old=dict(index=0,threshold=.75)
new=dict(index=6,threshold=.7)
summaries={p:a.decision_summary(rows,new if p=='source_stable' else old,'candidate_FIR_GLRT','phase025')
    for p in ('source_stable','pooled_original','fixed_weak_pooled')}
key=a.group_key('level100','smooth','candidate_FIR_GLRT')
dev=dict(primary_group=key,groups={key:dict(policies=dict(source_stable=dict(primary_development_target_met=True)),
    leave_one_select_source=dict(stability_gate_pass=True))})
checks=[]
def ok(name,v):
    assert v,name
    checks.append(dict(name=name,passed=True))

decision=a.primary_decision(summaries,dev)
ok('joint success passes only for a complete favorable synthetic panel',decision['full_prespecified_confirmation_success'])
fallback=copy.deepcopy(dev);fallback['groups'][key]['policies']['source_stable']['primary_development_target_met']=False
ok('favorable confirmation cannot turn a DEV fallback into success',not a.primary_decision(summaries,fallback)['full_prespecified_confirmation_success'])
missing=copy.deepcopy(summaries)
missing['source_stable']['nonpressure']['sources'][-1]['primary_acceptance']=None
ok('fully missing person endpoint is preserved without imputation or crash',not a.primary_decision(missing,dev)['full_prespecified_confirmation_success'])
failed=copy.deepcopy(summaries)
next(s for s in failed['source_stable']['strata'] if s['kind']=='wrong_source')['accepted']=1
ok('wrong-source increase blocks success even with favorable near outcomes',not a.primary_decision(failed,dev)['full_prespecified_confirmation_success'])
diagnostics=a.diagnostic_report(decision,OUT/'synthetic_plots')
path=OUT/'SYNTHETIC_ANALYSIS_VALIDATION.json'
a.save_new(path,dict(status='passed',checks=checks,synthetic_only=True,no_real_scores_or_signals_read=True,
    decision=decision,diagnostics=diagnostics,analysis_sha256=a.sha(HERE/'analysis.py')))
print(json.dumps(dict(status='passed',n=len(checks),receipt=str(path))))
