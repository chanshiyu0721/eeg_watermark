"""Read-only recomputation of frozen P190 decisions; no new rules are published."""
from pathlib import Path
import json,time
import analysis as a
import run_experiment as c


def main():
    c.validate_confirmation_freeze()
    dev=a.load(a.DEV);held=a.load(a.HERE/'CONFIRMATION_RESULTS.json');history=a.load(a.HISTORICAL)['rules']
    checks=[];manifest={};confirmed={}
    for level,levelkey in a.LEVELS:
        for arm in a.ARMS:
            fit=a.read_group('fit',a.FIT,levelkey,arm,manifest)
            select=a.read_group('select',a.SELECT,levelkey,arm,manifest)
            confirm=a.read_group('confirm',a.CONFIRM,levelkey,arm,manifest)
            family='qid_legal' if arm=='qid' else 'phase025'
            for method in a.api.METHODS:
                key=a.group_key(levelkey,arm,method);expected=dev['groups'][key]
                actual=a.api.calibrate_group(fit,select,method=method,primary_family=family,
                    expected_fit_sources=a.FIT,expected_select_sources=a.SELECT,expected_conditions=a.CONDITIONS)
                assert actual=={k:v for k,v in expected.items() if k not in ('leave_one_select_source','D_select_nominal')},('DEV rules differ',key)
                for policy,rule in actual['policies'].items():
                    assert a.api.evaluate(select,rule,method,family)==expected['D_select_nominal'][policy]
                for expected_loo in expected['leave_one_select_source']['rows']:
                    omit=expected_loo['omitted'];smaller=[r for r in select if a.api.person_key(r['source'])!=a.api.person_key(omit)]
                    result=a.api.calibrate_group(fit,smaller,method=method,primary_family=family,
                        expected_fit_sources=a.FIT,expected_select_sources=[s for s in a.SELECT if s!=omit],expected_conditions=a.CONDITIONS)
                    policy=result['policies']['source_stable']
                    assert policy['selected']['index']==expected_loo['index']
                    assert policy['primary_development_target_met']==expected_loo['admissible']
                summaries={p:a.decision_summary(confirm,rule,method,family) for p,rule in actual['policies'].items()}
                summaries['historical_freeze']=a.decision_summary(confirm,history[levelkey][arm][method],method,family)
                assert summaries==held['groups'][key],('Frozen confirmation summaries differ',key)
                confirmed[key]=summaries;checks.append(dict(group=key,DEV_policies_equal=True,LOO_equal=True,confirmation_equal=True))
    primary=a.primary_decision(confirmed[dev['primary_group']],dev)
    assert primary==held['primary_decision'],'Primary success/inference decision differs'
    receipt=dict(status='saved_score_reproduction_passed',utc=a.now(),groups=checks,primary_decision_equal=True,
        confirmation_used_to_select_new_rules=False,new_rules_written=False,raw_signal_values_decoded=False,
        freeze_sha256=a.sha(a.FREEZE),results_sha256=a.sha(a.HERE/'CONFIRMATION_RESULTS.json'))
    path=a.HERE/'reproduction'/f'REPRODUCTION_CHECK_{time.time_ns()}.json';a.save_new(path,receipt)
    print(json.dumps(dict(status=receipt['status'],groups=len(checks),path=str(path)),ensure_ascii=False))


if __name__=='__main__':main()
