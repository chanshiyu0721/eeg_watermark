"""Bounded independent numerical checks of inference direction and multiplicity."""
from pathlib import Path
import hashlib,json,math
import numpy as np
from scipy import stats
from statistics_api import mean_inference,signflip,holm,paired_values,primary_contrast

HERE=Path(__file__).resolve().parent
checks=[]
def ok(name,value):
    assert value,name
    checks.append(dict(name=name,passed=True))

x=[-.2]*4+[0.]*4
r=mean_inference(x,alternative='less')
t=-math.sqrt(7.)
ok('paired t direction agrees with hand-computed t=-sqrt(7)',abs(r['t']-t)<1e-12 and abs(r['p_one_sided']-stats.t.cdf(t,7))<1e-12)
ok('effect and interval retain their signed direction',abs(r['mean']+.1)<1e-12 and r['CI95'][0]<-.1<r['CI95'][1]<0.)
zero=mean_inference([0.]*8)
ok('identical outcomes give no superiority evidence',zero['p_one_sided']==1. and zero['CI95']==[0.,0.])
ni=mean_inference([0.]*8,null=-.05,alternative='greater')
ok('perfect paired coverage distinguishes NI margin from zero null',ni['p_one_sided']==0. and ni['degenerate'])
z=signflip([-.125]*8)
ok('all256 signs retain the prespecified exact tail',z['n_signs']==256 and z['p_less']==1/256 and z['p_two_sided']==2/256)
ok('all tied signs have sensitivity p1',signflip([0.]*8)['p_two_sided']==1.)
h=holm({'a':.01,'b':.04});f=holm({'a':.03,'b':.04})
ok('Holm ordered family agrees with textbook two-hypothesis values',h['a']['holm_p']==.02 and h['b']['holm_p']==.04 and not any(v['reject'] for v in f.values()))
ids,a,b=paired_values({'S2':.2,'S1':.1},{'S1':0.,'S2':.2})
ok('pairing follows person ID rather than input order',ids==['S1','S2'] and (a-b).tolist()==[.1,0.])
try:paired_values({'S1':1.,'S2':1.},{'S1':1.,'S3':1.})
except ValueError:ok('mismatched people cannot be paired',True)
else:raise AssertionError('ID mismatch accepted')
baseline={f'S{i}':dict(coverage=1.,primary_acceptance=.25) for i in range(8)}
proposed={f'S{i}':dict(coverage=1.,primary_acceptance=.125) for i in range(8)}
c=primary_contrast(proposed,baseline)
ok('IUT combines NI and FA while practical improvement remains separate',c['iut_p']==0. and c['observed_improvement_at_least_05'] and c['strictly_better_people']==8)
receipt=dict(status='passed',checks=checks,n=len(checks),no_signal_or_score_data_read=True,
    code_sha256=hashlib.sha256((HERE/'statistics_api.py').read_bytes()).hexdigest())
(HERE/'STATISTICS_VALIDATION.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status='passed',n=len(checks),code_sha256=receipt['code_sha256'])))
