"""P190 DEV-only calibration and post-freeze confirmation analysis.

No signal decoder is imported here. Confirmation analysis never calls fitting.
"""
from __future__ import annotations
from pathlib import Path
import argparse
import datetime
import gzip
import hashlib
import importlib.util
import json
import math
import os
import sys
import statistics
from collections import defaultdict

HERE=Path(__file__).resolve().parent
BASE=HERE.parent
ROOT=BASE.parent.parent
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[key]='1'
os.environ['MPLCONFIGDIR']=str(HERE/'cache/matplotlib')
sys.path.insert(0,str(BASE/'p190_calibration_v1'))
import calibration_api as api
from statistics_api import primary_contrast,holm

FIT=('OpenBMI001','OpenBMI002','A02T','A03E')
SELECT=('OpenBMI003','OpenBMI004','A05E','A07E')
CONFIRM=tuple(f'OpenBMI{i:03d}' for i in range(5,13))
ARMS=('smooth','direct','hybrid05','spatial','qid')
LEVELS=((.5,'level050'),(.75,'level075'),(1.,'level100'))
CONDITIONS=('reexport','elliptic_new_causal','bessel_shifted_causal')
HISTORICAL=BASE/'p188_frontier_v1/freeze_before_held.json'
DEV=HERE/'DEVELOPMENT_SELECTION.json'
FREEZE=HERE/'CONFIRMATION_FREEZE.json'
TOL=1e-12


def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
    return h.hexdigest()


def load(path):
    path=Path(path)
    if path.suffix=='.gz':
        with gzip.open(path,'rt',encoding='utf-8') as f:return json.load(f)
    return json.loads(path.read_text(encoding='utf-8'))


def save_new(path,value):
    path=Path(path)
    if path.exists():raise FileExistsError('Never overwrite a completed result: '+str(path))
    path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_name(path.name+'.partial')
    if temp.exists():raise FileExistsError('Preserve interrupted output for inspection: '+str(temp))
    def numeric(v):
        if hasattr(v,'tolist'):return v.tolist()
        if hasattr(v,'item'):return v.item()
        raise TypeError('Unsupported JSON value: '+type(v).__name__)
    raw=(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False,default=numeric)+'\n').encode('utf-8')
    with temp.open('xb') as f:f.write(raw)
    temp.rename(path)


def group_key(levelkey,arm,method):return '/'.join((levelkey,arm,method))


def read_group(role,people,levelkey,arm,manifest):
    import run_experiment as collector
    signature=hashlib.sha256(json.dumps(collector.contract_snapshot(),sort_keys=True).encode()).hexdigest()
    rows=[]
    for source in people:
        path=HERE/'raw'/role/source/levelkey/(arm+'.json.gz')
        obj=load(path)
        if obj['status']!='complete' or obj['cohort']!=role or obj['source']!=source or obj['arm']!=arm:
            raise ValueError('Raw checkpoint role/group mismatch: '+str(path))
        rr=obj['rows'];expected=111 if role=='confirm' else (105 if arm=='qid' else 81)
        if len(rr)!=expected or obj['planned_n']!=expected:
            raise ValueError('Incomplete planned observation count: '+str(path))
        if obj['collection_signature']!=signature or obj['collector_code_sha256']!=sha(HERE/'run_experiment.py'):
            raise ValueError('Raw checkpoint collection contract differs: '+str(path))
        if len({(r['query_index'],r['condition']) for r in rr})!=expected:
            raise ValueError('Repeated or missing query/processing cell')
        if any(r['source']!=source or r['cohort']!=role or r['arm']!=arm for r in rr):
            raise ValueError('Raw row role mismatch')
        if {r['condition'] for r in rr}!=set(CONDITIONS):raise ValueError('Processing panel differs')
        if obj['evaluated_n']!=sum(api.feasible(r) for r in rr):raise ValueError('Evaluated denominator differs')
        if {r['negative_source'] for r in rr if r['kind']=='wrong_source'}!=set(collector.WRONG[role]):
            raise ValueError('Wrong-source roster differs')
        for condition in CONDITIONS:
            registered=[r['identity'] for r in rr if r['kind']=='enrolled' and r['condition']==condition]
            if sorted(registered)!=list(range(8)):raise ValueError('Registered identity panel differs')
        for row in rr:
            if row['kind']=='wrong_source' and not row.get('negative_source'):
                raise ValueError('Wrong-source person ID is mandatory')
        manifest[str(path)]=sha(path);rows.extend(rr)
    return rows


def build_development():
    if FREEZE.exists():raise RuntimeError('Cannot recalibrate after confirmation freeze')
    if (HERE/'raw/confirm').exists() and any((HERE/'raw/confirm').rglob('*.json.gz')):
        raise RuntimeError('Cannot calibrate after confirmation evidence exists')
    if DEV.exists():raise FileExistsError('DEV selection already completed; preserve it')
    files={};groups={};operating={}
    for level,levelkey in LEVELS:
        for arm in ARMS:
            fit=read_group('fit',FIT,levelkey,arm,files)
            select=read_group('select',SELECT,levelkey,arm,files)
            family='qid_legal' if arm=='qid' else 'phase025'
            for method in api.METHODS:
                result=api.calibrate_group(fit,select,method=method,primary_family=family,
                    expected_fit_sources=FIT,expected_select_sources=SELECT,expected_conditions=CONDITIONS)
                full=result['policies']['source_stable']['selected']['index'];loo=[]
                for omitted in SELECT:
                    smaller=[r for r in select if api.person_key(r['source'])!=api.person_key(omitted)]
                    kept=[s for s in SELECT if s!=omitted]
                    check=api.calibrate_group(fit,smaller,method=method,primary_family=family,
                        expected_fit_sources=FIT,expected_select_sources=kept,expected_conditions=CONDITIONS)
                    policy=check['policies']['source_stable'];sel=policy['selected']
                    for before,after in zip(result['policies']['source_stable']['candidates'],policy['candidates']):
                        if before['threshold']!=after['threshold'] or before['threshold_influence_delta']!=after['threshold_influence_delta']:
                            raise AssertionError('Selection deletion changed fit-only threshold or delta')
                    loo.append(dict(omitted=omitted,index=sel['index'],admissible=policy['primary_development_target_met'],
                        matches_full=bool(policy['primary_development_target_met'] and sel['index']==full)))
                result['leave_one_select_source']=dict(fit_held_fixed=True,rows=loo,
                    matching=sum(r['matches_full'] for r in loo),n=4,
                    stability_gate_pass=sum(r['matches_full'] for r in loo)>=3)
                result['D_select_nominal']={p:api.evaluate(select,z,method,family) for p,z in result['policies'].items()}
                groups[group_key(levelkey,arm,method)]=result
                for policy,metrics in result['D_select_nominal'].items():
                    eligible=bool(metrics['complete_selection_panel'] and metrics['source_mean_coverage']>=.95
                        and metrics['minimum_source_coverage']>=.90 and metrics['control_accepted']==0
                        and metrics['primary_accepted']==0)
                    key='/'.join((arm,method,policy))
                    if key not in operating:operating[key]=dict(selected_level=None,levelkey=None,checks=[])
                    entry=operating[key]
                    entry['checks'].append(dict(level=level,levelkey=levelkey,eligible=eligible,
                        coverage=metrics['source_mean_coverage'],primary_accepted=metrics['primary_accepted'],
                        control_accepted=metrics['control_accepted']))
                    if eligible and entry['selected_level'] is None:
                        entry['selected_level']=level;entry['levelkey']=levelkey
    result=dict(status='development_completed_before_confirmation',utc=now(),fit=list(FIT),select=list(SELECT),
        protocol_sha256=sha(HERE/'PROTOCOL_BEFORE_DEVELOPMENT.md'),
        calibration_api_sha256=sha(BASE/'p190_calibration_v1/calibration_api.py'),
        analysis_sha256=sha(Path(__file__)),statistics_sha256=sha(HERE/'statistics_api.py'),
        raw_score_files=files,groups=groups,operating_points=operating,
        primary_group=group_key('level100','smooth','candidate_FIR_GLRT'),
        pressure_used_for_selection=False,confirmation_signal_or_scores_seen=False,
        original_historical_rule=dict(path=str(HISTORICAL),sha256=sha(HISTORICAL)))
    save_new(DEV,result)
    return dict(path=str(DEV),sha256=sha(DEV),groups=len(groups),score_files=len(files),
        primary_selected=result['groups'][result['primary_group']]['policies']['source_stable']['selected']['index'],
        primary_development_target_met=result['groups'][result['primary_group']]['policies']['source_stable']['primary_development_target_met'])


def wrong_summary(items):
    cells=defaultdict(list);bynegative=defaultdict(list)
    for row in items:
        if row['kind']=='wrong_source':
            cells[(row['source'],row['negative_source'],row['condition'])].append(row)
            bynegative[row['negative_source']].append(row)
    def metrics(rr):
        zz=[r for r in rr if r['receiver_evaluated']]
        return dict(planned_n=len(rr),evaluated_n=len(zz),accepted=sum(r['decision']>=0 for r in zz),
            acceptance=sum(r['decision']>=0 for r in zz)/len(zz) if zz else None)
    return dict(shared_negative_people=len(bynegative),independent_crossed_cell_n=False,
        by_negative_source=[dict(negative_source=k,**metrics(v)) for k,v in sorted(bynegative.items())],
        cells=[dict(source=k[0],negative_source=k[1],condition=k[2],**metrics(v)) for k,v in sorted(cells.items())])


def decision_summary(rows,rule,method,family):
    summary=api.summarize_frozen(rows,rule,method=method,primary_family=family)
    items=summary.pop('rows')
    summary['wrong_source']=wrong_summary(items)
    summary['processing']={c:api.evaluate([r for r in rows if r['condition']==c],rule,method,family) for c in CONDITIONS}
    return summary


def _persons(summary):return {r['source']:r for r in summary['nonpressure']['sources']}


def _accepts(summary,kind):
    return sum(r['accepted'] for r in summary['strata'] if r['kind']==kind)


def primary_decision(primary,development):
    prop=primary['source_stable'];persons=_persons(prop);contrasts={};gates={}
    compared=('source_stable','pooled_original','fixed_weak_pooled')
    missing=[p+':'+s for p in compared for s,r in _persons(primary[p]).items()
        if r['coverage'] is None or r['primary_acceptance'] is None]
    if missing:
        return dict(primary_system=development['primary_group'],independent_target_people=8,
            full_prespecified_confirmation_success=False,empirical_joint_pass=False,
            inferential_joint_pass=False,inference_not_defined='Missing mandatory person endpoint; no imputation',
            failed_gates=['incomplete_primary_panel:'+v for v in missing],
            action='Preserve issuance failure and stop without confirmation-driven changes')
    for baseline in ('pooled_original','fixed_weak_pooled'):
        old=primary[baseline];oldpeople=_persons(old)
        contrast=primary_contrast(persons,oldpeople);contrasts[baseline]=contrast
        npv=[persons[k]['primary_acceptance'] for k in sorted(persons)]
        nbv=[oldpeople[k]['primary_acceptance'] for k in sorted(oldpeople)]
        gate=dict(complete_primary_panel=bool(prop['nonpressure']['complete_selection_panel'] and old['nonpressure']['complete_selection_panel']),
            ownership_mean_at_least_95=prop['nonpressure']['source_mean_coverage']>=.95-TOL,
            observed_coverage_loss_at_most_02=contrast['coverage_difference']['mean']>=-.02-TOL,
            coverage_CI95_lower_at_least_minus05=contrast['coverage_difference']['CI95'][0]>=-.05-TOL,
            observed_primary_reduction_at_least_05=contrast['observed_improvement_at_least_05'],
            nonworse_at_least_6=contrast['nonworse_people']>=6,strict_improvement_at_least_2=contrast['strictly_better_people']>=2,
            worst_person_acceptance_nonincrease=max(npv)<=max(nbv)+TOL,
            across_person_SD_nonincrease=statistics.stdev(npv)<=statistics.stdev(nbv)+TOL,
            misattribution_nonincrease=prop['nonpressure']['registered_misattributed']<=old['nonpressure']['registered_misattributed'],
            clean_acceptance_nonincrease=_accepts(prop,'clean')<=_accepts(old,'clean'),
            wrong_source_acceptance_nonincrease=_accepts(prop,'wrong_source')<=_accepts(old,'wrong_source'))
        for condition in ('elliptic_new_causal','bessel_shifted_causal'):
            gate[condition+'_primary_nonincrease']=(prop['processing'][condition]['source_mean_primary_acceptance']
                <=old['processing'][condition]['source_mean_primary_acceptance']+TOL)
        gates[baseline]=gate
    adjusted=holm({k:v['iut_p'] for k,v in contrasts.items()})
    devgroup=development['groups'][development['primary_group']]
    devgates=dict(development_feasible=devgroup['policies']['source_stable']['primary_development_target_met'],
        leave_one_select_source_stability=devgroup['leave_one_select_source']['stability_gate_pass'])
    empirical=all(devgates.values()) and all(all(g.values()) for g in gates.values())
    inferential=all(v['reject'] for v in adjusted.values())
    return dict(primary_system=development['primary_group'],independent_target_people=8,
        contrasts=contrasts,empirical_gates=gates,development_gates=devgates,holm_IUT=adjusted,
        empirical_joint_pass=empirical,inferential_joint_pass=inferential,
        full_prespecified_confirmation_success=bool(empirical and inferential),
        failed_gates=[k for k,v in devgates.items() if not v]+[b+':'+k for b,z in gates.items() for k,v in z.items() if not v]
            +[b+':Holm_IUT' for b,v in adjusted.items() if not v['reject']],
        action='Report frozen outcome; no confirmation-driven recalibration, replacement people, or additional search')


def diagnostic_report(decision,output_dir=None):
    """Fixed descriptive screens and plots of paired differences; no test switch."""
    if 'contrasts' not in decision:return dict(status='not_defined_for_missing_endpoints')
    import numpy as np
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from scipy import stats
    from vendor.assumption_checks import check_normality,detect_outliers
    out=Path(output_dir) if output_dir is not None else HERE/'analysis_diagnostics'
    out.mkdir(parents=True,exist_ok=True)
    reports={}
    for baseline,contrast in decision['contrasts'].items():
        reports[baseline]={}
        for endpoint in ('coverage_difference','primary_acceptance_difference'):
            x=np.asarray(contrast[endpoint]['values'],dtype=float)
            name=baseline+'_'+endpoint
            if np.ptp(x)==0:
                normality=dict(status='undefined_constant_differences',n=len(x),value=float(x[0]))
            else:normality=check_normality(x,name=name,plot=False)
            try:outliers=detect_outliers(x,plot=False)
            except ValueError as exc:outliers=dict(status='undefined',reason=str(exc))
            fig,axes=plt.subplots(1,3,figsize=(9,2.6))
            axes[0].scatter(range(1,len(x)+1),100*x,color='#194f7a')
            axes[0].axhline(0,color='.5',lw=.7);axes[0].set(xlabel='Fixed target-person order',ylabel='Paired difference (pp)')
            axes[1].hist(100*x,bins='auto',color='#194f7a');axes[1].set(xlabel='Paired difference (pp)',ylabel='People')
            if np.ptp(x)>0:stats.probplot(x,dist='norm',plot=axes[2])
            else:axes[2].text(.5,.5,'Constant empirical differences',ha='center',va='center',wrap=True,transform=axes[2].transAxes)
            fig.suptitle(name.replace('_',' '),fontsize=8);fig.tight_layout()
            for suffix in ('png','pdf'):fig.savefig(out/(name+'.'+suffix),dpi=160)
            plt.close(fig)
            reports[baseline][endpoint]=dict(normality=normality,outliers=outliers,
                primary_test_unchanged=True,independence_established_by_person_ledger=True,
                interpretation='Finite fixed convenience cohort; small-n bounded/discrete differences can depart from the t model. Sign-flip sensitivity requires symmetry and does not remove cohort-selection assumptions.')
    return reports


def analyze_confirmation():
    # Importing the collector here validates only contracts/hashes, never decoding.
    import run_experiment as collector
    collector.validate_confirmation_freeze()
    development=load(DEV);freeze=load(FREEZE)
    if development['status']!='development_completed_before_confirmation':raise ValueError('Bad DEV status')
    historical=load(HISTORICAL)['rules'];files={};groups={}
    for level,levelkey in LEVELS:
        for arm in ARMS:
            rows=read_group('confirm',CONFIRM,levelkey,arm,files)
            family='qid_legal' if arm=='qid' else 'phase025'
            for method in api.METHODS:
                key=group_key(levelkey,arm,method);rules=development['groups'][key]['policies']
                summaries={policy:decision_summary(rows,rule,method,family) for policy,rule in rules.items()}
                summaries['historical_freeze']=decision_summary(rows,historical[levelkey][arm][method],method,family)
                groups[key]=summaries
    decision=primary_decision(groups[development['primary_group']],development)
    diagnostics=diagnostic_report(decision)
    result=dict(status='once_frozen_confirmation_analyzed_without_refitting',utc=now(),
        confirmation_freeze_sha256=sha(FREEZE),development_sha256=sha(DEV),
        analysis_sha256=sha(Path(__file__)),statistics_sha256=sha(HERE/'statistics_api.py'),
        raw_score_files=files,groups=groups,primary_decision=decision,paired_difference_diagnostics=diagnostics,
        confirmation_used_for_fit_or_selection=False,operating_points_frozen_from_DEV=development['operating_points'])
    path=HERE/'CONFIRMATION_RESULTS.json';save_new(path,result)
    return dict(path=str(path),sha256=sha(path),full_success=decision['full_prespecified_confirmation_success'],
        failed_gates=decision['failed_gates'])


def main():
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=('develop','confirm'))
    args=parser.parse_args()
    print(json.dumps(build_development() if args.action=='develop' else analyze_confirmation(),ensure_ascii=False),flush=True)


if __name__=='__main__':main()
