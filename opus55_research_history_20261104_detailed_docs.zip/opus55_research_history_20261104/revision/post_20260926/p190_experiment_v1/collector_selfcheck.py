"""Bounded collector checks using historical A02T only; no calibration."""
from pathlib import Path
import hashlib
import json
import shutil
from unittest import mock

import run_experiment as r
import numpy as np


def main():
    out=r.HERE/'collector_checks';out.mkdir(exist_ok=True)
    checks=[]
    dev,dm=r.phase_codes('fit');confirm,cm=r.phase_codes('confirm')
    assert dev.shape==(24,8) and confirm.shape==(32,8)
    assert [m['kind'] for m in dm].count('enrolled')==8
    assert sum(m.get('angle')==.025 for m in dm)==8 and sum(m['pressure'] for m in dm)==8
    assert sum(m.get('angle')==.025 for m in cm)==16 and sum(m['pressure'] for m in cm)==8
    np.testing.assert_array_equal(dev[:8],confirm[:8])
    for code,meta in zip(dev[8:],dm[8:]):
        np.testing.assert_allclose(np.linalg.norm(code),1,atol=2e-14,rtol=0)
        np.testing.assert_allclose(code@dev[meta['parent']],np.cos(meta['angle']),atol=2e-14,rtol=0)
    checks.append('registered registry shared; exact development025 and derived0125 geometry; fixed confirmation two directions')
    absent=out/'ABSENT_CONFIRMATION_FREEZE.json';assert not absent.exists()
    blocked=[]
    with mock.patch.object(r,'FREEZE',absent):
        for number in range(5,17):
            for flag in (False,True):
                try:r.prepare_source(None,f'OpenBMI{number:03d}',allow_new=flag)
                except PermissionError:blocked.append((number,flag))
                else:raise AssertionError('Independent source cache/decode was not gated')
    assert len(blocked)==24;checks.append('24 independent-source cache/decode calls blocked before metadata, raw bytes or samples')
    path=out/'immutable_output.json';item=dict(fixed=True)
    r.save(path,item);before=r.sha(path);r.save(path,item);assert r.sha(path)==before
    try:r.save(path,dict(fixed=False))
    except RuntimeError:pass
    else:raise AssertionError('Immutable checkpoint overwritten')
    assert r.sha(path)==before;checks.append('completed checkpoint equal retry allowed, differing overwrite rejected')
    planned_dev={a:(24 if a!='qid' else 32)+3 for a in r.ARMS}
    planned_dev={a:n*3 for a,n in planned_dev.items()}
    assert sum(planned_dev.values())*8*3==10296
    assert 37*3*5*8*3==13320
    checks.append('carrier-specific planned denominators total DEV10296 and confirmation13320')
    # Rebuild only missing issued artifacts from the exact saved alpha and all
    # fourteen saved metadata frames, then compare every actual EDF byte.
    m=r.backend('collector-checks');record=r.prepare_source(m,'A02T')
    record['cap']=r.load(record['folder']/'source_common_cap_before_QIM.json')['cap']
    original=r.HERE/'issuance/A02T/level100/qid';folder=out/'same_alpha_resume'
    folder.mkdir(exist_ok=True)
    for name in ['assets.bin','source_alpha_frozen.json']+[f'metadata_frame{k:02d}.bin' for k in range(14)]:
        source=original/name;destination=folder/name
        if destination.exists():assert destination.read_bytes()==source.read_bytes()
        else:shutil.copyfile(source,destination)
    recovered=r.recover_qid(m,record,1.,folder,'P190-A02T-first-fixed-block')
    expected=r.load(original/'issuance.json')
    assert recovered['payload_meta']==expected['payload_meta'] and recovered['qualities']==expected['qualities']
    equal=[]
    for info in expected['payload_meta']:
        if info['feasible']:
            name=f"qid_r{info['recipient']}_issued.edf.gz"
            assert r.sha(original/name)==r.sha(folder/name);equal.append(name)
    assert len(equal)==32
    checks.append('interrupted QIM recovery reused frozen alpha/metadata; all32 issued gzip/EDF artifacts byte-identical')
    receipt=dict(status='passed',checks=checks,count=len(checks),independent_sources_decoded=[],new_signal_queries=0,
        historical_source='A02T',QIM_recovery_equal_artifacts=equal,planned_rows_per_DEV_arm=planned_dev,
        planned_DEV_rows=10296,planned_confirmation_rows=13320,
        collector_sha256=r.sha(r.HERE/'run_experiment.py'),selfcheck_sha256=r.sha(Path(__file__)))
    r.save(out/'COLLECTOR_VALIDATION.json',receipt)
    print(json.dumps({k:receipt[k] for k in ('status','count','independent_sources_decoded','planned_DEV_rows','planned_confirmation_rows')}))


if __name__=='__main__':main()
