"""Create the one-way P190 freeze only after DEV and finite acquisition finish."""
from pathlib import Path
import hashlib,json
import analysis as a
import run_experiment as c

HERE=Path(__file__).resolve().parent
ROOT=a.ROOT


def create_freeze():
    if a.FREEZE.exists():raise FileExistsError('Confirmation freeze already exists; never replace it')
    if (HERE/'raw/confirm').exists() and any((HERE/'raw/confirm').rglob('*.json.gz')):
        raise RuntimeError('Cannot declare a new freeze after confirmation scores exist')
    for subject in range(5,17):
        if (HERE/'sources'/f'OpenBMI{subject:03d}').exists():
            raise RuntimeError('New person already decoded before the freeze')
    dev=a.load(a.DEV)
    assert dev['status']=='development_completed_before_confirmation'
    expected={
        'protocol_sha256':HERE/'PROTOCOL_BEFORE_DEVELOPMENT.md',
        'calibration_api_sha256':a.BASE/'p190_calibration_v1/calibration_api.py',
        'analysis_sha256':HERE/'analysis.py','statistics_sha256':HERE/'statistics_api.py'}
    for key,path in expected.items():assert dev[key]==a.sha(path),('DEV code changed',key)
    contract=c.contract_snapshot();acquisition=c.acquisition_snapshot()
    assert contract['cohorts']['confirm']==list(a.CONFIRM)
    assert [row['source'] for row in acquisition['raw_sources']]==[f'OpenBMI{i:03d}' for i in range(5,17)]
    signature=hashlib.sha256(json.dumps(contract,sort_keys=True).encode()).hexdigest()
    files=dict(contract['code_files']);files.update(acquisition['files'])
    scores=[]
    assert len(dev['raw_score_files'])==120
    for path,digest in dev['raw_score_files'].items():
        path=Path(path).resolve();assert path.is_relative_to(HERE/'raw')
        assert a.sha(path)==digest
        checkpoint=a.load(path)
        assert checkpoint['collection_signature']==signature
        assert checkpoint['cohort'] in ('fit','select')
        relative=path.relative_to(ROOT).as_posix();scores.append(relative);files[relative]=digest
    extras=[a.DEV,HERE/'analysis.py',HERE/'statistics_api.py',Path(__file__),HERE/'continue_once.py',HERE/'prepare_reporting.py',
        HERE/'validate_statistics.py',HERE/'STATISTICS_VALIDATION.json',
        HERE/'validate_analysis.py',HERE/'analysis_checks/SYNTHETIC_ANALYSIS_VALIDATION.json',
        HERE/'reproduce_saved.py',HERE/'README_REPRODUCE.md',
        HERE/'ENVIRONMENT_P190.json',HERE/'requirements_p190.txt',
        HERE/'DEV_COLLECTION_COMPLETE.json',HERE/'DEV_PRIMARY_RULE_EQUIVALENCE.json',
        HERE/'vendor/assumption_checks.py',HERE/'vendor/NOTICE.md',
        HERE/'INTERPRETATION_BEFORE_CONFIRMATION.md',
        HERE/'collector_checks/COLLECTOR_VALIDATION.json',
        a.BASE/'p190_calibration_v1/check.json',a.BASE/'p190_calibration_v1/design.md',
        a.BASE/'p190_calibration_v1/test_calibration.py',
        a.BASE/'p190_source_history_v1/SOURCE_HISTORY_AND_COHORT.md',
        a.BASE/'p190_source_history_v1/AUDIT_SUMMARY.json']
    for path in extras:files[path.relative_to(ROOT).as_posix()]=a.sha(path)
    policies=[a.DEV.relative_to(ROOT).as_posix(),c.PROTOCOL.relative_to(ROOT).as_posix()]
    primary=dev['groups'][dev['primary_group']]
    result=dict(status='frozen_before_new_signal_confirmation',utc=a.now(),
        contract_snapshot=contract,acquisition_snapshot=acquisition,files=files,
        development_score_files=sorted(scores),policy_files=policies,
        primary_group=dev['primary_group'],
        primary_frozen_rules={p:z['selected'] for p,z in primary['policies'].items()},
        development_feasible=primary['policies']['source_stable']['primary_development_target_met'],
        leave_one_select_source=primary['leave_one_select_source'],
        all_rules_and_operating_points_in=policies[0],
        inferential_family='two IUT contrasts (coverage NI -.05 and FA superiority 0), Holm alpha .05',
        empirical_minimum_observed_FA_reduction=.05,
        confirmation_outputs_present=False,new_signal_decodes_present=False,
        pressure_used_for_selection=False,
        technical_resume='same missing checkpoints only; no roster/parameter/endpoint changes',
        stopping='one fixed cohort; report failure if joint success gates do not pass')
    a.save_new(a.FREEZE,result)
    c.validate_confirmation_freeze()
    return dict(path=str(a.FREEZE),sha256=a.sha(a.FREEZE),files=len(files),
        primary_index=result['primary_frozen_rules']['source_stable']['index'],
        development_feasible=result['development_feasible'])


if __name__=='__main__':print(json.dumps(create_freeze(),ensure_ascii=False),flush=True)
