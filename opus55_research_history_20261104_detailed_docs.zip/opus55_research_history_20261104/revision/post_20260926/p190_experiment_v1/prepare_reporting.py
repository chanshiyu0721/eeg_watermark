"""Render tables/figures from the once-frozen results; never select or refit."""
from pathlib import Path
import csv,json,math,os
import analysis as a
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

HERE=Path(__file__).resolve().parent
PAPER=a.BASE/'p190_manuscript_v1'
FIGURES=PAPER/'figures'
POLICIES=('pooled_original','fixed_weak_pooled','split_maxcoverage','fixed_weak_split','source_stable','historical_freeze')
LABELS=dict(pooled_original='Pooled original',fixed_weak_pooled='Fixed weak, pooled',
    split_maxcoverage='Split max coverage',fixed_weak_split='Fixed weak, split',
    source_stable='Source stable',historical_freeze='Historical freeze')


def totals(summary,predicate):
    rr=[r for r in summary['strata'] if predicate(r)]
    return {k:sum(r[k] or 0 for r in rr) for k in ('planned_n','evaluated_n','infeasible_n','accepted','correct','misattributed')}


def fraction(n,d):return f'{n}/{d}'


def main():
    result=a.load(HERE/'CONFIRMATION_RESULTS.json');dev=a.load(a.DEV)
    if result['confirmation_used_for_fit_or_selection']:raise ValueError('Unexpected refitting')
    PAPER.mkdir(exist_ok=True);FIGURES.mkdir(exist_ok=True)
    key=dev['primary_group'];main=result['groups'][key]
    lines=['# Frozen P190 confirmation numbers','',
        'Eight new target people; four shared wrong-source people. Main system: smooth, candidate-conditioned FIR, level 1. All entries are generated from the once-frozen results.',
        '', '|Calibration|Correct registered|Registered rejects|Misattributed|0.025 accepted|0.0125 accepted|Clean accepted|Wrong accepted|',
        '|---|---:|---:|---:|---:|---:|---:|---:|']
    table=[]
    for policy in POLICIES:
        s=main[policy];reg=totals(s,lambda r:r['kind']=='enrolled')
        near=totals(s,lambda r:r['angle']==.025);pressure=totals(s,lambda r:r['pressure'])
        clean=totals(s,lambda r:r['kind']=='clean');wrong=totals(s,lambda r:r['kind']=='wrong_source')
        rejected=sum(r['rejected'] for r in s['strata'] if r['kind']=='enrolled')
        values=[fraction(reg['correct'],reg['planned_n']),str(rejected),str(reg['misattributed']),
            fraction(near['accepted'],near['evaluated_n']),fraction(pressure['accepted'],pressure['evaluated_n']),
            fraction(clean['accepted'],clean['evaluated_n']),fraction(wrong['accepted'],wrong['evaluated_n'])]
        lines.append('|'+LABELS[policy]+'|'+'|'.join(values)+'|')
        table.append(dict(policy=policy,registered=reg,registered_rejected=rejected,near025=near,pressure0125=pressure,clean=clean,wrong=wrong))
    lines+=['','Unknown rates use evaluated denominators; every infeasible planned item is separately retained in the machine-readable table. Missing items do not count as receiver rejection. Repeated identities/processing do not increase independent n.','',
        '## Prespecified decision','',
        'Full success: **'+('PASS' if result['primary_decision']['full_prespecified_confirmation_success'] else 'FAIL')+'**.']
    for reason in result['primary_decision']['failed_gates']:lines.append('- '+reason)
    decision=result['primary_decision']
    if 'contrasts' in decision:
        lines+=['','## Paired primary effects','',
            '|Baseline|Coverage difference, pp [95% CI]|0.025 difference, pp [95% CI]|IUT p|Holm p|',
            '|---|---:|---:|---:|---:|']
        def effect(z):return f"{100*z['mean']:.2f} [{100*z['CI95'][0]:.2f}, {100*z['CI95'][1]:.2f}]"
        for policy,contrast in decision['contrasts'].items():
            lines.append('|'+LABELS[policy]+'|'+effect(contrast['coverage_difference'])+'|'+effect(contrast['primary_acceptance_difference'])
                +f"|{contrast['iut_p']:.6g}|{decision['holm_IUT'][policy]['holm_p']:.6g}|")
        lines+=['','Differences are source-stable minus baseline. Practical observed reduction >=5 pp is separate from the superiority test against zero. Collapsed empirical intervals and sign-flip sensitivity are retained in the result JSON.']
    lines+=['','## Development-only operating points','',
        '|Carrier|Calibration|Selected level|Confirmation coverage|Primary-unknown acceptance|','|---|---|---:|---:|---:|']
    for arm in a.ARMS:
        for policy in a.api.POLICIES:
            op=dev['operating_points']['/'.join((arm,'candidate_FIR_GLRT',policy))]
            if op['levelkey'] is None:lines.append(f'|{arm}|{LABELS[policy]}|none|—|—|');continue
            s=result['groups'][a.group_key(op['levelkey'],arm,'candidate_FIR_GLRT')][policy]['nonpressure']
            lines.append(f"|{arm}|{LABELS[policy]}|{op['selected_level']}|{100*s['source_mean_coverage']:.2f}%|{100*s['source_mean_primary_acceptance']:.2f}%|")
    report=PAPER/'FROZEN_RESULTS_FOR_MANUSCRIPT.md'
    if report.exists():raise FileExistsError('Reporting output already exists; preserve it')
    report.write_text('\n'.join(lines)+'\n',encoding='utf-8')
    a.save_new(PAPER/'PRIMARY_TABLE_DATA.json',dict(source_results_sha256=a.sha(HERE/'CONFIRMATION_RESULTS.json'),rows=table))
    draw_transfer(result)
    draw_primary_people(result,dev)
    print(json.dumps(dict(status='frozen_reporting_prepared',path=str(report)),ensure_ascii=False))


def draw_transfer(result):
    values=np.full((5,9),np.nan);flags=[];cells=[]
    for i,arm in enumerate(a.ARMS):
        for j,(level,levelkey) in enumerate(a.LEVELS):
            group=result['groups'][a.group_key(levelkey,arm,'candidate_FIR_GLRT')]
            for k,condition in enumerate(a.CONDITIONS):
                column=3*j+k;new=group['source_stable']['processing'][condition]
                old=group['pooled_original']['processing'][condition]
                complete=new['complete_selection_panel'] and old['complete_selection_panel']
                value=100*(new['source_mean_primary_acceptance']-old['source_mean_primary_acceptance']) if complete else None
                if value is not None:values[i,column]=value
                flag=bool(new['control_accepted']>0 or new['source_mean_coverage']<.95)
                if flag:flags.append((i,column))
                cells.append(dict(arm=arm,level=level,condition=condition,difference_pp=value,
                    complete=complete,coverage=new['source_mean_coverage'],control_accepted=new['control_accepted']))
    plt.rcParams.update({'font.size':8,'font.family':'DejaVu Sans'})
    fig,ax=plt.subplots(figsize=(7.15,2.55))
    im=ax.imshow(values,cmap='RdBu_r',vmin=-100,vmax=100,aspect='auto')
    for i in range(5):
        for j in range(9):
            v=values[i,j];label='N/A' if np.isnan(v) else f'{v:+.0f}'
            ax.text(j,i,label,ha='center',va='center',fontsize=7,color='white' if np.isfinite(v) and abs(v)>55 else '#111111')
    for i,j in flags:ax.add_patch(Rectangle((j-.49,i-.48),.98,.96,fill=False,edgecolor='#d28b00',linewidth=1.1))
    for x in (2.5,5.5):ax.axvline(x,color='white',lw=2)
    ax.set_xticks(range(9),['R','E','B']*3)
    ax.set_yticks(range(5),['Smooth','Direct','Hybrid','Spatial','QIM legal'])
    for x,label in ((1,'level 0.5'),(4,'level 0.75'),(7,'level 1.0')):ax.text(x,-.88,label,ha='center',va='center',fontsize=8,clip_on=False)
    ax.tick_params(length=0);ax.set_xlabel('R: reexport    E: causal elliptic    B: shifted causal Bessel')
    bar=fig.colorbar(im,ax=ax,pad=.025,fraction=.04);bar.set_label('Primary acceptance difference (pp)',fontsize=7)
    fig.tight_layout(pad=.6)
    for suffix in ('pdf','png','svg'):fig.savefig(FIGURES/('P190_transfer.'+suffix),dpi=220,bbox_inches='tight')
    plt.close(fig)
    a.save_new(PAPER/'TRANSFER_FIGURE_DATA.json',dict(cells=cells,
        caption='Source-stable minus pooled-original primary unknown acceptance, with eight target-person means per cell. Negative values favor source-stable. Phase rows use 0.025 code-angle unknowns; QIM uses native legal unknowns. Gold outlines indicate registered coverage below .95 or any clean/wrong acceptance in that cell. N/A retains an incomplete mandatory panel.'))


def draw_primary_people(result,dev):
    primary=result['groups'][dev['primary_group']]
    people=sorted(r['source'] for r in primary['source_stable']['nonpressure']['sources'])
    fig,axes=plt.subplots(1,2,figsize=(7.1,2.5),sharey=True)
    for ax,policy in zip(axes,('pooled_original','fixed_weak_pooled')):
        new={r['source']:r['primary_acceptance'] for r in primary['source_stable']['nonpressure']['sources']}
        old={r['source']:r['primary_acceptance'] for r in primary[policy]['nonpressure']['sources']}
        for i,person in enumerate(people):
            if new[person] is None or old[person] is None:continue
            ax.plot([i-.12,i+.12],[100*old[person],100*new[person]],color='.6',lw=.8)
            ax.scatter(i-.12,100*old[person],marker='o',s=16,color='#777777',label='Baseline' if i==0 else None)
            ax.scatter(i+.12,100*new[person],marker='s',s=16,color='#126b72',label='Source stable' if i==0 else None)
        ax.set_xticks(range(8),[str(int(p[-3:])) for p in people]);ax.set(xlabel='Fixed OpenBMI participant',title=LABELS[policy],ylim=(-3,103))
        ax.grid(axis='y',alpha=.2);ax.legend(fontsize=6,loc='upper right')
    axes[0].set_ylabel('0.025 acceptance (%)');fig.tight_layout()
    for suffix in ('pdf','png'):fig.savefig(FIGURES/('P190_primary_people.'+suffix),dpi=220)
    plt.close(fig)


if __name__=='__main__':main()
