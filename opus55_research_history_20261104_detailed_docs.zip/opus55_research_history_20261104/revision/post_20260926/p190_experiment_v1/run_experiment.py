"""P190 fixed-cohort signal collection; no calibration or test-set selection.

All scientific transforms are the frozen P186/P188 implementations.  One
source/level/arm publishes a complete atomic gzip checkpoint.  Re-running the
collector reuses those checkpoints and identical serialized issued copies.
"""
from __future__ import annotations

from pathlib import Path
import os
import sys

HERE=Path(__file__).resolve().parent
BASE=HERE.parent
ROOT=BASE.parents[1]
sys.dont_write_bytecode=True
assert ROOT.drive.upper()=='E:', 'P190 materials must remain on E:'


def environment():
    for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):
        os.environ[key]='1'
    for key in ('TEMP','TMP','TMPDIR','MPLCONFIGDIR','NUMBA_CACHE_DIR','TORCH_HOME','_MNE_FAKE_HOME_DIR','JOBLIB_TEMP_FOLDER'):
        path=HERE/'cache'/key.lower();path.mkdir(parents=True,exist_ok=True);os.environ[key]=str(path)


environment()
sys.path[:0]=[str(HERE),str(ROOT),str(BASE/'p186_five_arm_bridge_v1'),
              str(BASE/'p188_neighbors_qim_v1'),str(BASE/'p188_glrt_v1')]
import argparse
import ctypes
import gc
import gzip
import hashlib
import json
import subprocess
import time
import traceback
from collections import Counter
from concurrent.futures import ThreadPoolExecutor,as_completed

import numpy as np
from threadpoolctl import threadpool_limits
from continuation_api import frozen_backend,frozen_inputs
from receiver_api import MatchedFIRReceivers,METHODS,CONFIGS
import adapter
import phase_geometry
import qid_adapter as qid

BRIDGE=BASE/'p186_five_arm_bridge_v1'
ACQUISITION=BASE/'p190_source_history_v1/acquisition'
PROTOCOL=HERE/'PROTOCOL_BEFORE_DEVELOPMENT.md'
FREEZE=HERE/'CONFIRMATION_FREEZE.json'
ARMS=('smooth','direct','hybrid05','spatial','qid')
LEVELS=(.5,.75,1.)
CONDITIONS=('reexport','elliptic_new_causal','bessel_shifted_causal')
COHORTS={'fit':('OpenBMI001','OpenBMI002','A02T','A03E'),
         'select':('OpenBMI003','OpenBMI004','A05E','A07E'),
         'confirm':tuple(f'OpenBMI{s:03d}' for s in range(5,13))}
WRONG={'fit':('A01T','A04E'),'select':('A06E','A08E'),
       'confirm':tuple(f'OpenBMI{s:03d}' for s in range(13,17))}


def now():return time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
def level_name(level):return f'level{round(level*100):03d}'
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()
def load(path):
    data=Path(path).read_bytes()
    if str(path).endswith('.gz'):data=gzip.decompress(data)
    return json.loads(data.decode('utf-8-sig'))
def save(path,value):
    """An interruption can leave .partial; the published file is immutable."""
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    data=(json.dumps(value,ensure_ascii=False,allow_nan=False,separators=(',',':'))+'\n').encode('utf-8')
    if str(path).endswith('.gz'):data=gzip.compress(data,compresslevel=5,mtime=0)
    if path.exists():
        if path.read_bytes()!=data:raise RuntimeError('Immutable output already differs: '+str(path))
        return
    temporary=path.with_name(path.name+'.partial');temporary.write_bytes(data)
    os.replace(temporary,path)
def event(**value):print(json.dumps(dict(utc=now(),**value),ensure_ascii=False),flush=True)
def relative(path):return Path(path).resolve().relative_to(ROOT).as_posix()
def read_edf(m,path):return m.io.parse_edf(gzip.decompress(Path(path).read_bytes()),m.domain.BCI_CHANNELS)


def code_files():
    probe=load(BASE/'p190_pipeline_probe_v1/PIPELINE_API.json')
    paths=[]
    for row in probe['inputs']:
        path=ROOT/row['path'];assert sha(path)==row['sha256'],('Frozen backend changed',path)
        paths.append(path)
    paths += [Path(__file__),HERE/'adapter.py',PROTOCOL,
              BASE/'p190_calibration_v1/calibration_api.py',
              BASE/'p186_qim_bridge_v1/bridge_qim.py',BASE/'p185_qim_roundtrip_v1/qim_core.py',
              BRIDGE/'receiver_freeze_before_A03.json',BRIDGE/'build_freeze_before_A02.json',
              BRIDGE/'assets.bin',BRIDGE/'codes.json',
              BASE/'p188_frontier_v1/freeze_before_held.json']
    return {relative(p):sha(p) for p in sorted(set(paths),key=str)}


def contract_snapshot():
    """Metadata/code only. Safe before independent raw-signal decoding."""
    return dict(version='P190-fixed-signal-collection-v1',
        cohorts={k:list(v) for k,v in COHORTS.items()},wrong_sources={k:list(v) for k,v in WRONG.items()},
        arms=list(ARMS),levels=list(LEVELS),conditions=list(CONDITIONS),
        reference_seconds=112,scored_seconds=40,total_visible_seconds=48,
        sampling_rate=160,channels=list(adapter.CHANNELS),
        caps_percent=dict(global_ac_prd=.25,max_channel_ac_prd=.5,band_8_30_prd=1.),
        actual_registered_relative_spread_max=.001,
        phase_queries=dict(fit=24,select=24,confirm=32),qid_queries=32,
        source_key='P190-{source}-first-fixed-block',
        query_range='one range per target/processing from transformed clean plus every allocated wrong source',
        methods=list(METHODS),configs=list(CONFIGS),code_files=code_files(),frozen_backend=frozen_inputs())


def acquisition_snapshot():
    """Receipt/header inspection only; raw matrices are never decoded."""
    files={relative(ACQUISITION/'ACQUISITION_PLAN.json'):sha(ACQUISITION/'ACQUISITION_PLAN.json')}
    rows=[]
    for subject in range(5,17):
        meta=adapter.metadata(subject)
        for p in (meta['metadata_path'],meta['raw_receipt_path']):files[relative(p)]=sha(p)
        rows.append(dict(source=f'OpenBMI{subject:03d}',path=str(meta['path']),bytes=meta['raw_file_bytes'],
                         sha256=meta['raw_file_sha256'],metadata=relative(meta['metadata_path']),receipt=relative(meta['raw_receipt_path'])))
    return dict(files=files,raw_sources=rows)


_FREEZE_VERIFIED=None
def validate_confirmation_freeze():
    """Validate the complete freeze before loading even a cached new reference.

    Required JSON: status, contract_snapshot, acquisition_snapshot, files,
    development_score_files, policy_files.  'files' maps project-relative paths
    to SHA256, and includes all listed policies, scores, code, metadata and
    acquisition receipts. Raw-MAT content is verified by adapter at decoding.
    """
    global _FREEZE_VERIFIED
    if not FREEZE.is_file():raise PermissionError('No confirmation freeze; independent signal access is closed')
    freeze=load(FREEZE);assert freeze['status']=='frozen_before_new_signal_confirmation'
    assert freeze['contract_snapshot']==contract_snapshot(),'Code/protocol/cohort contract differs from freeze'
    assert freeze['acquisition_snapshot']==acquisition_snapshot(),'Acquisition lineage differs from freeze'
    required=dict(freeze['contract_snapshot']['code_files']);required.update(freeze['acquisition_snapshot']['files'])
    assert freeze['development_score_files'] and freeze['policy_files'],'DEV/policy evidence is required'
    for name in freeze['development_score_files']+freeze['policy_files']:
        assert name in freeze['files'],('Missing frozen evidence',name)
    for name,digest in required.items():assert freeze['files'].get(name)==digest,('Missing required frozen input',name)
    signature=(sha(FREEZE),tuple((name,(ROOT/name).stat().st_size,(ROOT/name).stat().st_mtime_ns) for name in sorted(freeze['files'])))
    if _FREEZE_VERIFIED!=signature:
        for name,digest in freeze['files'].items():
            p=(ROOT/name).resolve();assert p.is_relative_to(ROOT) and p.drive.upper()=='E:'
            assert sha(p)==digest,('Confirmation freeze hash mismatch',name)
        _FREEZE_VERIFIED=signature
    return freeze


def backend(label):
    m,_=frozen_backend(HERE/'backend'/label);environment();return m


def old_source_folder(name):
    if name in ('A01T','A02T'):return BRIDGE/name
    if name.startswith('A') and name.endswith('E'):
        return (BASE/'p187_complete_cohort_v1/run/episodes'/f'{name}_run0' if int(name[1:3])<=3
                else BRIDGE/'BCI_E_frozen'/name)
    raise ValueError('Not a declared historical BCI source '+name)


def prepare_source(m,name,*,allow_new=False):
    """Parent process calls this sequentially for shared wrong-source caches."""
    is_new=name.startswith('OpenBMI') and int(name[-3:])>=5
    if is_new:
        if not allow_new:raise PermissionError('Independent source requires confirmation role')
        validate_confirmation_freeze()
    folder=HERE/'sources'/name;final=folder/'source.json'
    if final.is_file():
        doc=load(final);assert doc['source']==name
        for p,h in doc['provenance_files'].items():assert sha(ROOT/p)==h,('Reference provenance changed',p)
        assert sha(folder/'clean.edf.gz')==doc['clean_gzip_sha256']
        x,h0=read_edf(m,folder/'clean.edf.gz')
        assert hashlib.sha256(x.tobytes()).hexdigest()==doc['clean_samples_sha256']
        return dict(name=name,folder=folder,x=x,h0=h0,limits=tuple(np.asarray(v) for v in doc['limits_uv']),source=doc)
    folder.mkdir(parents=True,exist_ok=True);artifacts=[]
    if name.startswith('OpenBMI'):
        number=int(name[-3:]);raw,description=adapter.load_reference(number,allow_new=is_new)
        limits=m.p.ranges(raw)
        x,h0=m.io.edf_roundtrip(raw,limits,'clean.edf',folder,artifacts,True,m.domain.BCI_CHANNELS)
        provenance={relative(description[k]):description[k.replace('_path','_sha256')]
                    for k in ('metadata_path','raw_receipt_path')}
    else:
        origin=old_source_folder(name);description=load(origin/'source.json')
        x,h0=read_edf(m,origin/'clean.edf.gz')
        limits=(np.asarray(description['low_uv']),np.asarray(description['high_uv'])) if 'low_uv' in description else tuple(np.asarray(v) for v in description['limits_uv'])
        # Reuse archived bytes exactly, retaining the original actual EDF grid.
        destination=folder/'clean.edf.gz'
        data=(origin/'clean.edf.gz').read_bytes()
        if destination.exists():assert destination.read_bytes()==data
        else:
            partial=destination.with_name(destination.name+'.partial');partial.write_bytes(data);os.replace(partial,destination)
        provenance={relative(origin/'clean.edf.gz'):sha(origin/'clean.edf.gz'),relative(origin/'source.json'):sha(origin/'source.json')}
    assert x.shape==(8,17920) and np.isfinite(x).all()
    doc=dict(status='complete',source=name,description=description,limits_uv=[v.tolist() for v in limits],
             provenance_files=provenance,clean_gzip_sha256=sha(folder/'clean.edf.gz'),
             clean_samples_sha256=hashlib.sha256(x.tobytes()).hexdigest(),EDF_receipts=artifacts,
             independently_new_person=is_new,confirmation_freeze_sha256=sha(FREEZE) if is_new else None)
    save(final,doc)
    return dict(name=name,folder=folder,x=x,h0=h0,limits=limits,source=doc)


def phase_codes(cohort):
    if cohort=='confirm':return phase_geometry.original_p181_pool()
    from revision.post_20260926 import p181_common as c
    full,meta=c.pool('development','eegbci');codes=list(full[:8])
    rows=[dict(kind='enrolled',identity=i,parent=i,angle=None,direction=None,pressure=False,legacy_pool_index=i) for i in range(8)]
    near=[(i,r) for i,r in enumerate(meta) if r['kind']=='near_unregistered' and r['angle']==.025]
    assert len(near)==8
    for angle in (.025,.0125):
        for index,row in near:
            parent=row['identity'];tangent=(full[index]-np.cos(.025)*full[parent])/np.sin(.025)
            code=full[index] if angle==.025 else np.cos(angle)*full[parent]+np.sin(angle)*tangent
            codes.append(code);rows.append(dict(kind='phase_near_unregistered',identity=None,parent=parent,angle=angle,
                direction=0,pressure=angle==.0125,legacy_pool_index=index,pressure_tangent_from_development025=angle==.0125))
    assert len(codes)==24
    return np.asarray(codes),rows


def recover_qid(m,record,level,folder,source_key):
    """Resume only the same QC-frozen alpha/metadata and recipient messages."""
    x,limits=record['x'],record['limits'];assets=(BRIDGE/'assets.bin').read_bytes()
    final=folder/'issuance.json'
    if final.exists():return load(final)
    alpha_file=folder/'source_alpha_frozen.json'
    cap=float(record['cap']*level)
    if alpha_file.exists():
        receipt=load(alpha_file)
        if receipt.get('status')=='infeasible':return dict(receipt=receipt,qualities=[],payload_meta=[],registered_failed=True)
        assert receipt['source_id']==source_key and receipt['common_global_cap_percent']==cap
        assert receipt['reference_v_sha256']==hashlib.sha256(x.tobytes()).hexdigest() and receipt['assets_sha256']==hashlib.sha256(assets).hexdigest()
        metadata=[]
        for row in receipt['metadata']:
            wire=(folder/f"metadata_frame{row['frame']:02d}.bin").read_bytes();assert hashlib.sha256(wire).hexdigest()==row['sha256'];metadata.append(wire)
    else:
        # This can only be an interrupted pre-endpoint QC operation. Recompute
        # the deterministic registered-only alpha; preserve any partial files.
        raw=[qid.q.prepare_metadata(clean,qid.source_frame_nonce(source_key,k),assets) for k,clean in enumerate(qid.native.frame_view(x))]
        alpha,metadata,history=qid.choose_alpha(x,limits,assets,raw,cap)
        if metadata is None:
            save(alpha_file,dict(status='infeasible',cap=cap,history=history))
            return dict(receipt=load(alpha_file),qualities=[],payload_meta=[],registered_failed=True)
        for k,wire in enumerate(metadata):
            p=folder/f'metadata_frame{k:02d}.bin'
            if p.exists():assert p.read_bytes()==wire
            else:p.write_bytes(wire)
        p=folder/'assets.bin'
        if p.exists():assert p.read_bytes()==assets
        else:p.write_bytes(assets)
        receipt=dict(version='p188-QIM-ID-v1',source_id=source_key,alpha=alpha,common_global_cap_percent=cap,
            original_caps=[.25,.5,1.],alpha_history=history,no_decoder_task_or_unknown_selection=True,
            reference_v_sha256=hashlib.sha256(x.tobytes()).hexdigest(),assets_sha256=hashlib.sha256(assets).hexdigest(),
            metadata=[dict(frame=k,bytes=len(w),sha256=hashlib.sha256(w).hexdigest()) for k,w in enumerate(metadata)])
        save(alpha_file,receipt)
    artifacts=[];qualities=[];payload=[]
    for message in qid.fixed_messages():
        ideal=qid.embed112(x,message['bits'],assets,metadata);ok=qid.native.in_range(ideal,limits);quality=None
        if ok:
            y,_=m.io.edf_roundtrip(ideal,limits,f"qid_r{message['recipient']}_issued.edf",folder,artifacts,True,m.domain.BCI_CHANNELS)
            quality=m.p.quality(x,y);ok=qid.native.caps_pass(quality,cap)
        qualities.append(dict(recipient=message['recipient'],feasible=ok,**(quality or {})))
        info={k:v for k,v in message.items() if k!='bits'}
        info.update(bits_hex=np.packbits(message['bits'],bitorder='big').tobytes().hex(),feasible=ok);payload.append(info)
    receipt.update(status='complete',success=all(r['feasible'] for r in payload[:8]),artifacts=artifacts,
                   technical_resume_same_QC_parameters=True)
    result=dict(receipt=receipt,qualities=qualities,payload_meta=payload);save(final,result)
    return result


def issue_point(m,record,level,cohort):
    folder=HERE/'issuance'/record['name']/level_name(level);final=folder/'issuance_summary.json'
    if final.exists():
        summary=load(final);assert summary['cohort']==cohort and summary['source']==record['name']
        copies={}
        for arm in ARMS:
            copies[arm]=[read_edf(m,folder/('qid' if arm=='qid' else '')/f"{arm}_r{row['recipient'] if arm=='qid' else i}_issued.edf.gz")[0]
                         if row['feasible'] else None for i,row in enumerate(summary['metadata'][arm])]
        return copies,summary['metadata'],summary
    folder.mkdir(parents=True,exist_ok=True);x,limits=record['x'],record['limits'];codes,phase_meta=phase_codes(cohort)
    capfile=record['folder']/'source_common_cap_before_QIM.json'
    record['cap']=load(capfile)['cap'] if capfile.exists() else m.phase_nominal_cap(x,limits,record['folder'],codes[:8])
    qfolder=folder/'qid';source_key=f"P190-{record['name']}-first-fixed-block"
    if not qfolder.exists():
        try:
            qid.issue_source(x,limits,(BRIDGE/'assets.bin').read_bytes(),source_key,qfolder,common_global_cap_percent=record['cap']*level)
        except RuntimeError:
            if not (qfolder/'source_alpha_frozen.json').exists():raise
    saved=recover_qid(m,record,level,qfolder,source_key)
    qmeta=saved['payload_meta']
    if not qmeta:
        qmeta=[dict({k:v for k,v in r.items() if k!='bits'},feasible=False) for r in qid.fixed_messages()]
    meta_q=[dict({k:v for k,v in r.items() if k!='bits_hex'},pressure=r['kind']=='qid_chip_near_unregistered') for r in qmeta]
    qcopies=[read_edf(m,qfolder/f"qid_r{r['recipient']}_issued.edf.gz")[0] if r['feasible'] else None for r in qmeta]
    anchors=[float(r['global_ac_prd']) if r['feasible'] else None for r in saved['qualities'][:8]]
    if len(anchors)!=8:anchors=[None]*8
    copies={'qid':qcopies};metadata={'qid':meta_q};matches=[];artifacts=[]
    for arm in ARMS[:-1]:
        values=[];meta=[]
        for index,(code,info) in enumerate(zip(codes,phase_meta)):
            target=anchors[info['parent']];path=folder/f'{arm}_r{index}_issued.edf.gz';quality=None;failure=None
            if target is None:y=None;failure='QIM_registered_anchor_infeasible'
            elif path.exists():y,_=read_edf(m,path);quality=m.p.quality(x,y)
            else:
                answer,history=m.match_down(x,code,arm,target,limits)
                if answer is None:
                    y=None;failure='matching_unresolved';matches.append(dict(arm=arm,index=index,parent=info['parent'],target=target,status=failure,history=history))
                else:
                    ideal,details=answer
                    y,_=m.io.edf_roundtrip(ideal,limits,f'{arm}_r{index}_issued.edf',folder,artifacts,True,m.domain.BCI_CHANNELS)
                    quality=m.p.quality(x,y)
                    matches.append(dict(arm=arm,index=index,parent=info['parent'],target=target,status='matched',history=history,**details))
            if quality is not None:
                assert target/1.001<=quality['global_ac_prd']<=target
                assert quality['global_ac_prd']<=.25 and quality['max_channel_ac_prd']<=.5 and quality['band_prd']<=1.
                matches.append(dict(arm=arm,index=index,parent=info['parent'],target=target,status='actual_EDF_verified',**quality))
            values.append(y);meta.append(dict(info,feasible=y is not None,failure_reason=failure))
        copies[arm]=values;metadata[arm]=meta
    valid=all(v is not None for arm in ARMS for v in copies[arm][:8]);spreads=[]
    if valid:
        for identity in range(8):
            actual=[m.p.quality(x,copies[arm][identity])['global_ac_prd'] for arm in ARMS]
            spread=(max(actual)-min(actual))/min(actual);assert spread<=.001;spreads.append(spread)
    summary=dict(status='complete',cohort=cohort,source=record['name'],level=level,registered_group_valid=valid,
        source_common_cap=record['cap'],requested_cap=record['cap']*level,QID_anchors=anchors,QID_alpha=saved['receipt'].get('alpha'),
        actual_registered_relative_spreads=spreads,phase_matching=matches,metadata=metadata,
        artifacts=artifacts,qid_issuance_sha256=sha(qfolder/'issuance.json') if (qfolder/'issuance.json').exists() else None,
        no_query_or_task_scores=True,source_key=source_key,source_cache_sha256=sha(record['folder']/'source.json'))
    save(final,summary);event(event='issuance_complete',source=record['name'],cohort=cohort,level=level,valid=valid)
    return copies,metadata,summary


def query_ranges(m,record,wrongs):
    return {condition:m.p.ranges(np.concatenate([m.c.transform(r['x'],condition) for r in [record]+wrongs],axis=1)) for condition in CONDITIONS}


def collect_source(cohort,name):
    if cohort=='confirm':validate_confirmation_freeze()
    assert name in COHORTS[cohort]
    m=backend(cohort+'/'+name);record=prepare_source(m,name,allow_new=cohort=='confirm')
    wrongs=[prepare_source(m,w,allow_new=cohort=='confirm') for w in WRONG[cohort]]
    qlimits=query_ranges(m,record,wrongs);source_started=time.monotonic();outputs=[]
    signature=hashlib.sha256(json.dumps(contract_snapshot(),sort_keys=True).encode()).hexdigest()
    for level in LEVELS:
        copies,metadata,issuance=issue_point(m,record,level,cohort)
        issuance_path=HERE/'issuance'/name/level_name(level)/'issuance_summary.json'
        for arm in ARMS:
            destination=HERE/'raw'/cohort/name/level_name(level)/(arm+'.json.gz')
            expected=(len(metadata[arm])+1+len(wrongs))*len(CONDITIONS)
            if destination.exists():
                old=load(destination)
                assert old['status']=='complete' and old['planned_n']==expected and len(old['rows'])==expected
                assert old['collection_signature']==signature and old['issuance_sha256']==sha(issuance_path)
                outputs.append(relative(destination));continue
            started=time.monotonic();rows=[];receipts=[]
            valid=issuance['registered_group_valid']
            receiver=MatchedFIRReceivers(record['x'],np.asarray(copies[arm][:8])) if valid else None
            values=copies[arm]+[record['x']]+[w['x'] for w in wrongs]
            infos=metadata[arm]+[dict(kind='clean',identity=None,parent=None,pressure=False)]+[
                dict(kind='wrong_source',identity=None,parent=None,pressure=False,negative_source=w['name']) for w in wrongs]
            for index,(value,info) in enumerate(zip(values,infos)):
                for condition in CONDITIONS:
                    common=dict(cohort=cohort,source=name,level=float(level),arm=arm,query_index=index,
                        **{k:v for k,v in info.items() if k!='feasible'},condition=condition)
                    if value is None or receiver is None:
                        rows.append(dict(common,issuance_feasible=False,receiver=None,
                            failure_reason=info.get('failure_reason') or ('registered_template_group_invalid' if not valid else 'issuance_infeasible')))
                        continue
                    query,h=m.io.edf_roundtrip(m.c.transform(value,condition),qlimits[condition],
                        f'{name}_{level_name(level)}_{arm}_q{index}_{condition}.edf',destination.parent,receipts,False,m.domain.BCI_CHANNELS)
                    raw=receiver.extract(query,h,record['h0'])
                    assert set(raw['methods'])==set(METHODS) and all(len(raw['methods'][method]['configs'])==12 for method in METHODS)
                    rows.append(dict(common,issuance_feasible=True,receiver=raw,query_raw_sha256=receipts[-1]['raw_sha256']))
                if index%8==7:event(event='query_progress',cohort=cohort,source=name,level=level,arm=arm,identities=index+1,rows=len(rows))
            assert len(rows)==expected
            evaluated=sum(r['receiver'] is not None for r in rows)
            doc=dict(status='complete',cohort=cohort,source=name,level=float(level),arm=arm,rows=rows,EDF_receipts=receipts,
                planned_n=expected,evaluated_n=evaluated,infeasible_n=expected-evaluated,
                truth_counts=dict(Counter(r['kind'] for r in rows)),registered_group_valid=valid,
                query_limits_uv={k:[v.tolist() for v in lim] for k,lim in qlimits.items()},
                issuance_sha256=sha(issuance_path),source_cache_sha256=sha(record['folder']/'source.json'),
                collector_code_sha256=sha(Path(__file__)),collection_signature=signature,
                confirmation_freeze_sha256=sha(FREEZE) if cohort=='confirm' else None,seconds=time.monotonic()-started)
            save(destination,doc);outputs.append(relative(destination));del receiver;gc.collect()
            event(event='arm_complete',cohort=cohort,source=name,level=level,arm=arm,planned=expected,evaluated=evaluated,seconds=doc['seconds'])
    final=HERE/'raw'/cohort/name/'COLLECTION_COMPLETE.json'
    if not final.exists():save(final,dict(status='complete',cohort=cohort,source=name,files={p:sha(ROOT/p) for p in outputs},
        collection_signature=signature,seconds=time.monotonic()-source_started))
    return dict(source=name,status='complete',files=len(outputs))


def smoke():
    """One historical query; no confirmation signal or fitted selection rule."""
    final=HERE/'smoke/HISTORICAL_SMOKE.json'
    if final.exists():return load(final)
    m=backend('smoke');record=prepare_source(m,'A02T');wrongs=[prepare_source(m,w) for w in WRONG['fit']]
    copies,meta,issuance=issue_point(m,record,1.,'fit');assert issuance['registered_group_valid']
    condition='reexport';limits=query_ranges(m,record,wrongs)[condition];receipts=[]
    read=MatchedFIRReceivers(record['x'],np.asarray(copies['smooth'][:8]))
    started=time.monotonic()
    q,h=m.io.edf_roundtrip(m.c.transform(copies['smooth'][0],condition),limits,'historical_A02T_smooth_r0.edf',final.parent,receipts,False,m.domain.BCI_CHANNELS)
    result=read.extract(q,h,record['h0'])
    assert set(result['methods'])==set(METHODS) and all(len(result['methods'][k]['configs'])==12 for k in METHODS)
    doc=dict(status='passed',source='A02T',cohort='historical_smoke',signal_queries=1,new_sources_decoded=[],
        level=1.,arm='smooth',condition=condition,receiver=result,EDF_receipts=receipts,seconds=time.monotonic()-started,
        phase_DEV_codes=len(phase_codes('fit')[1]),qid_codes=len(qid.fixed_messages()),
        planned_per_arm_DEV={a:(24 if a!='qid' else 32)+3 for a in ARMS},collector_code_sha256=sha(Path(__file__)))
    save(final,doc);event(event='historical_smoke_passed',methods=3,configs_each=12,query_seconds=doc['seconds']);return doc


def run_batch(cohort,workers=2,only=None):
    assert workers in (1,2)
    if cohort=='confirm':validate_confirmation_freeze()
    names=[only] if only is not None else list(COHORTS[cohort]);assert set(names)<=set(COHORTS[cohort])
    # Pre-cache once in this parent process, before any worker can open/write a
    # shared wrong source. New reference decoding is still freeze-gated above.
    m=backend('prepare-'+cohort)
    for name in list(WRONG[cohort])+names:prepare_source(m,name,allow_new=cohort=='confirm')
    logs=HERE/'logs'/cohort;logs.mkdir(parents=True,exist_ok=True)
    def launch(name):
        logpath=logs/f'{name}_{time.time_ns()}.log'
        with logpath.open('xb') as f:
            proc=subprocess.run([sys.executable,'-u',str(Path(__file__)),'--role',cohort,'--source',name,'--worker'],
                cwd=str(ROOT),stdout=f,stderr=subprocess.STDOUT,env=os.environ.copy())
        return dict(source=name,exit_code=proc.returncode,log=relative(logpath))
    results=[]
    with ThreadPoolExecutor(max_workers=workers) as executor:
        jobs={executor.submit(launch,name):name for name in names}
        for future in as_completed(jobs):
            result=future.result();results.append(result);event(event='source_process_complete',cohort=cohort,**result)
    status='complete' if all(r['exit_code']==0 for r in results) else 'technical_interruption'
    receipt=HERE/'logs'/cohort/f'batch_{time.time_ns()}.json';save(receipt,dict(status=status,cohort=cohort,results=results))
    if status!='complete':raise RuntimeError('Incomplete fixed-source batch; resume the same command from its checkpoints')
    return results


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--role',choices=tuple(COHORTS));p.add_argument('--source');p.add_argument('--workers',type=int,choices=(1,2),default=2)
    p.add_argument('--worker',action='store_true',help=argparse.SUPPRESS);p.add_argument('--smoke',action='store_true')
    p.add_argument('--contract',action='store_true');args=p.parse_args()
    if args.contract:
        print(json.dumps(contract_snapshot(),ensure_ascii=False,indent=2));return
    awake=False
    if os.name=='nt':awake=bool(ctypes.windll.kernel32.SetThreadExecutionState(ctypes.c_uint32(0x80000001)))
    try:
        with threadpool_limits(limits=1):
            if args.smoke:smoke()
            elif args.role:
                if args.worker:
                    assert args.source;collect_source(args.role,args.source)
                else:run_batch(args.role,args.workers,args.source)
            else:p.error('--role, --smoke, or --contract is required')
    finally:
        if awake:ctypes.windll.kernel32.SetThreadExecutionState(ctypes.c_uint32(0x80000000))


if __name__=='__main__':
    try:main()
    except BaseException:
        traceback.print_exc();raise
