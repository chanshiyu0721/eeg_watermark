# P190 protocol before development
Status: frozen design before the first P190 DEV score. Recorded 2026-10-30 (Asia/Shanghai), after E: file-system repair and before resuming development.
Historical P189 is immutable. All newly generated materials stay on E:.

## Question and main endpoint
Does source-separated calibration with source-deletion threshold perturbations reduce near-neighbor acceptance on previously unused EEG participants while retaining ownership coverage?
Primary system: smooth carrier, candidate_FIR_GLRT receiver, level 1. The common-level comparison is primary. A development-only operating-point comparison is reported separately. For each frozen procedure, choose the lowest of {.5,.75,1} whose nominal D_select decisions have source-equal registered correct coverage >=.95, minimum-source coverage >=.90, zero primary-unknown acceptance and zero clean/wrong acceptance. If none exists, report no eligible operating point; do not select from confirmation.

## Roles and independence
D_fit targets: OpenBMI001, OpenBMI002, A02T, A03E. D_select targets: OpenBMI003, OpenBMI004, A05E, A07E.
D_fit wrong-source people: A01T, A04E. D_select wrong-source people: A06E, A08E.
Confirmation targets: OpenBMI005–012; wrong-source people: OpenBMI013–016.
A person's sessions and derived copies retain the same role. No file-name alias creates a new independent person.
No new-person signal may be decoded until CONFIRMATION_FREEZE.json exists and validates its code, protocol, policies, DEV score, acquisition and metadata hashes.
The finite acquisition roster was fixed before download. No substitution or outcome-driven addition is allowed.

## Signal and query contract
Keep pure smooth as the main carrier, with direct, spatial, hybrid05 and QIM as controls.
Levels .5, .75, 1; reexport, elliptic_new_causal and bessel_shifted_causal.
PRD upper limits: global .25%, maximum channel .5%, 8–30 Hz band 1%.
Reference 112 s; 40 s scored and 48 s total visible query. Real EDF serialization, read-back, and actual distortion matching use the existing frozen implementations.
Registered identities 8. DEV phase has 8 primary .025 and 8 pressure .0125 unknowns; confirmation phase has 16 primary .025 unknowns in two fixed directions and 8 pressure .0125.
QIM has 8 registered, 8 legal unknowns and 16 chip-forgery pressure codes. Legal unknowns are the QIM-native primary family; they are not assigned a phase angle.
DEV planned signal-query observations: four phase arms 7776 plus QIM 2520 = 10296, including clean and two wrong-source queries. Confirmation planned observations: 13320, including clean and four wrong-source queries.
Counts and denominators are reported by carrier and family. Repetition does not increase the number of independent people.
Missing or infeasible issuance is retained and reported, never credited as a successful rejection or replaced with another person.
Nominal admissibility and primary confirmation require a complete evaluated registered, primary-unknown and clean/wrong panel. Pressure-only issuance failures are reported separately and cannot be interpreted as successful pressure rejection.

## Fixed calibration comparisons
Use the same 8 development target people, 4 wrong-source people, 12-config menu, receiver outputs, eligible logic, processing, and family weights for all recalibrated procedures:
1. pooled_original: max development correct coverage then earliest index, with threshold fitted on all development negatives.
2. fixed_weak_pooled: index 6, rho=1e-6, compatibility, support=1, threshold fitted on all development negatives.
3. split_maxcoverage: fit-only thresholds, selection correct coverage then earliest index.
4. fixed_weak_split: index 6 and fit-only threshold.
5. source_stable: the prespecified source-separated perturbation criterion.
Apply the original historical frozen rules separately and identify their smaller/different development set.
The .0125 and QIM-chip pressure families are excluded from every calibration threshold, selection objective and selection diagnostic.

For each configuration, t is nextafter(max eligible nonpressure fit-negative score,+infinity), or 0 if none. Scores equal to t are accepted under the inherited rule.
Delta is the largest decrease in t under one-person deletion from D_fit. Deletion must remove every row derived from that person, including rows naming it as negative_source. Delta is an empirical threshold-influence diagnostic, not a response confidence interval.
On D_select evaluate t-delta, t and t+delta, without clipping.
Nominal feasibility requires equal-source mean correct coverage >=.95, minimum-source coverage >=.90, and zero clean/wrong acceptance.
Among feasible configurations, deterministically minimize worst source-by-processing primary-unknown acceptance at t-delta, then source-equal mean primary-unknown acceptance, maximize worst-source coverage at t+delta, minimize changed decisions over the perturbation on registered plus nonpressure primary queries, maximize nominal source-equal correct coverage, then choose earliest index.
If no feasible configuration exists, retain the implemented control-first fallback and mark development_target_met=false. Confirmation cannot retrospectively convert this into development success.
Do not refit split thresholds on D_select after choosing the configuration.
Leave-one-select-source stability retains D_fit scores, thresholds and deltas, removes one of the four fixed target people and its derived rows, and repeats selection. An infeasible deletion counts as a nonmatch. At least 3/4 selections must match the full-development choice for the primary success gate.

## Statistical unit and predeclared success
For each confirmation target person, average equally across the 8 registered identities and three conditions for ownership metrics, and across the two .025 directions, 8 parents and three conditions for the primary unknown acceptance metric. Use the resulting 8 paired person values.
Report processing-specific values too. Treat the shared four wrong-source people separately: show all target-by-negative-source cells and summarize by the four negative people. Do not use the 32 crossed cells as independent n.
For each of the two primary baselines (pooled_original and fixed_weak_pooled), all of the following must hold:
- proposed mean registered correct coverage >=.95;
- observed mean coverage loss <=.02;
- paired 95% t interval lower bound for proposed-minus-baseline coverage >=-.05;
- observed primary unknown acceptance reduction >=.05;
- at least 6/8 target people have nonworse primary acceptance and at least 2/8 improve strictly (tie tolerance 1e-12);
- worst-target acceptance and across-target sample SD do not increase;
- observed misattribution and clean/wrong acceptance do not increase;
- primary acceptance averaged within elliptic and within Bessel does not increase.
Development feasibility and >=3/4 leave-one-select-source stability must also hold.

Inferential confirmation is distinguished from the observed practical .05 reduction. Per baseline contrast, test ownership noninferiority at margin -.05 and primary acceptance superiority versus zero with one-sided paired t tests. The contrast p value is the maximum of the two required p values (intersection–union). Holm adjust the two contrast p values at family alpha .05. Both must pass for the full prespecified confirmation-success claim.
Report paired 95% intervals and all 256 sign-flip outcomes as a prespecified sensitivity analysis under its symmetry assumption; do not replace the primary inference with the more favorable result.
Report degenerate empirical differences transparently. These small-cohort empirical rates do not establish a population FAR guarantee.
For zero sample variance, report the collapsed empirical CI explicitly; use the limiting one-sided t calculation for nonzero differences from the null, and p=1 when every difference equals the null. Retain the sign-flip sensitivity even in this case.
Fixed sequential cohort ascertainment and the assumptions needed for person-level inference are described once in the methods.

## Freeze and stopping
After development, hash and freeze the selected rules for all systems, all comparisons and operating points, the roster and code, acquisition and metadata receipts, DEV raw scores, success/statistical rules, and historical inputs.
Then execute one uniform confirmation round. Resume identical missing computations after a technical interruption; retain failed receipts and never recalculate completed evidence to choose a more favorable result.
No confirmation-driven threshold, ridge, carrier, source, endpoint, or sample-size change is allowed.
If the joint criteria fail, preserve the result and deliver the new paper plus a direction recommendation. No further confirmation-set search.
Reuse qualified CSP/EEGNet task outputs; retain the 45-event joint, 270-event original-grid and +1 s sensitivity distinctions. Add no third task model or offset sweep.

