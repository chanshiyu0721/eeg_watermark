# P190 experiment and reproduction

Working root: `E:/python/数字水印`. Python: `.venv-rerun/Scripts/python.exe`. Every generated file and cache stays on E:. Preserve the exact code, assets, source roles and protocol; P189 remains the historical release.

## Live continuation

The current run is already started. Inspect `CONTINUATION_STATE.json` and its recorded PID before issuing any command. `CONTINUATION_LOCK.json` prevents duplicate launch. `continue_once.py` waits for the active DEV and acquisition jobs, fits the declared rules, freezes, executes one independent confirmation and analyzes it without refitting. It stops on a technical failure, a missing E: drive or an invalid receipt.

The finite source-acquisition sentinel is `../p190_source_history_v1/acquisition/RESUME_20261030.json`, with status `FINISHED_acquisition_and_safe_metadata`. The adjacent acquisition and metadata manifests are hash-bound by that receipt. Downloading and metadata inspection do not expose the new signal values.

## Original signal experiment stages

These document the already-running stages; do not start duplicates.

1. Run the original fixed acquisition helper and safe metadata preparation (subjects5–16).
2. `run_experiment.py --role fit --workers 2`, then `--role select --workers 2`.
3. `analysis.py develop` creates `DEVELOPMENT_SELECTION.json` from saved DEV evidence only. It refuses after a confirmation freeze or confirmation scores exist.
4. `freeze_confirmation.py` requires all DEV and acquisition/metadata evidence. It refuses an existing freeze or evidence that a new person was decoded early.
5. `run_experiment.py --role confirm --workers 2` opens the new signals only after validating the complete freeze. Technical recovery uses the same command and reuses complete group checkpoints.
6. `analysis.py confirm` applies the frozen rules, then `prepare_reporting.py` creates manuscript tables and plots. Neither chooses a new configuration.

Each raw source/level/carrier file is an atomic complete checkpoint. Its rows contain all three receiver branches and twelve configurations, actual query EDF digests, source/issuance lineage and planned/evaluated/failed denominators. Source references and issued copies have separate actual EDF receipts. Failure is never relabeled as rejection. The collection contract and fixed historical backend are verified before reuse.

## Saved-evidence reproduction after completion

Run `reproduce_saved.py` once with the exact release. It reads the frozen DEV and confirmation scores, deterministically recomputes the pre-existing DEV policies/leave-one-source choices and all confirmation summaries, and compares them to the immutable files. It writes only a new reproduction receipt and publishes no new rules. It decodes no EEG, retrains no model and changes no threshold or operating point.

This saved-score scope is separate from rerunning signal acquisition, resampling, issuance and extraction. Signal-level reruns require the original public recordings, fixed assets, numerical dependencies and raw-data receipts. The source and acquisition ledgers identify them. Five FIR window folds and repeated identities are not independent people.

## Interpretation

The eight paired target-person comparisons condition on the fixed code/processing and shared wrong-source/range fixture. The four negative people describe wrong-source variation. Source-deletion delta operates on the saved fixed evidence, without regenerating quantization ranges. See `INTERPRETATION_BEFORE_CONFIRMATION.md` for the exact scope, and the original protocol for all empirical/inferential success and stopping rules.
