"""Persist the finite DEV -> freeze -> once-only confirmation workflow on E:."""
from pathlib import Path
import ctypes,datetime,json,os,subprocess,sys,time,traceback
import analysis as a
import run_experiment as c

HERE=Path(__file__).resolve().parent
ACQ=a.BASE/'p190_source_history_v1/acquisition'
LOCK=HERE/'CONTINUATION_LOCK.json'
STATE=HERE/'CONTINUATION_STATE.json'
LOGS=HERE/'continuation_logs'
LOGS.mkdir(exist_ok=True)
STARTED=time.time()
_DEAD_POLLS={}


def state(stage,**extra):
    obj=dict(stage=stage,utc=a.now(),pid=os.getpid(),**extra)
    temp=STATE.with_name(STATE.name+'.writing')
    temp.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');temp.replace(STATE)
    print(json.dumps(obj,ensure_ascii=False),flush=True)


def disk_present():
    return a.ROOT.is_dir() and (a.ROOT/'revision/post_20260926/p190_experiment_v1').is_dir()


def watch_pid(pid,label):
    """Two polls avoid a completion-marker/read race. No process is modified."""
    import ctypes.wintypes as w
    kernel=ctypes.windll.kernel32
    kernel.OpenProcess.argtypes=(w.DWORD,w.BOOL,w.DWORD);kernel.OpenProcess.restype=w.HANDLE
    kernel.GetExitCodeProcess.argtypes=(w.HANDLE,ctypes.POINTER(w.DWORD))
    kernel.CloseHandle.argtypes=(w.HANDLE,)
    handle=kernel.OpenProcess(0x1000,False,int(pid));code=w.DWORD()
    active=False
    if handle:
        active=bool(kernel.GetExitCodeProcess(handle,ctypes.byref(code)) and code.value==259)
        kernel.CloseHandle(handle)
    _DEAD_POLLS[label]=0 if active else _DEAD_POLLS.get(label,0)+1
    if _DEAD_POLLS[label]>=2:raise RuntimeError(label+' process ended without its required completion receipt')


def finished_dev():
    for role,people in (('fit',a.FIT),('select',a.SELECT)):
        for source in people:
            path=HERE/'raw'/role/source/'COLLECTION_COMPLETE.json'
            if not path.exists():return False
            obj=a.load(path)
            if obj['status']!='complete' or len(obj['files'])!=15:raise ValueError('Bad DEV source completion receipt')
    return True


def check_dev_failure():
    for role in ('fit','select'):
        directory=HERE/'logs'/role
        if not directory.exists():continue
        for path in directory.glob('batch_*.json'):
            if path.stat().st_mtime>=STARTED and a.load(path)['status']=='technical_interruption':
                raise RuntimeError('DEV stopped; preserve failure and resume only identical missing checkpoints: '+str(path))


def finished_acquisition():
    path=ACQ/'RESUME_20261030.json'
    if not path.exists():return False
    obj=a.load(path);status=obj.get('status')
    if status=='failed_preserved_no_substitution':raise RuntimeError('Finite acquisition failed; preserve original roster and partials')
    if status!='FINISHED_acquisition_and_safe_metadata':
        watch_pid(obj['pid'],'finite acquisition');return False
    for name,key in (('ACQUISITION.json','acquisition_manifest_sha256'),('METADATA_PREPARATION.json','metadata_manifest_sha256')):
        if a.sha(ACQ/name)!=obj[key]:raise ValueError('Acquisition completion receipt differs')
    acq=a.load(ACQ/'ACQUISITION.json');meta=a.load(ACQ/'METADATA_PREPARATION.json')
    assert acq['status']=='all12_files_acquired_effects_unopened' and acq['exact_subject_roster_verified'] and acq['completed_files']==12
    assert meta['status']=='all12_metadata_prepared_effects_unopened' and meta['no_signal_values_decoded']
    assert sorted(meta['qualified_train_sources'])==list(range(5,17))
    return True


def run(label,args):
    path=LOGS/(label+'_'+str(time.time_ns())+'.log')
    state(label,log=str(path))
    with path.open('xb') as f:
        result=subprocess.run([sys.executable,'-u']+list(map(str,args)),cwd=str(a.ROOT),
            stdout=f,stderr=subprocess.STDOUT,env=os.environ.copy())
    if result.returncode:raise RuntimeError(f'{label} failed with exit {result.returncode}; see {path}')


def main():
    if LOCK.exists():raise RuntimeError('Continuation lock exists; inspect the recorded process before resuming')
    a.save_new(LOCK,dict(pid=os.getpid(),utc=a.now(),script_sha256=a.sha(Path(__file__))))
    awake=False
    if os.name=='nt':awake=bool(ctypes.windll.kernel32.SetThreadExecutionState(ctypes.c_uint32(0x80000001)))
    try:
        state('waiting_for_development')
        while not finished_dev():
            if not disk_present():raise RuntimeError('E: unavailable; stop without alternate-drive material writes')
            check_dev_failure()
            run_receipt=HERE/'DEV_RUN_20261030.json'
            if run_receipt.exists():watch_pid(a.load(run_receipt)['orchestrator_pid'],'development')
            time.sleep(10)
        if not a.DEV.exists():run('calibrating_DEV',[HERE/'analysis.py','develop'])
        state('waiting_for_acquisition_and_safe_metadata',development_sha256=a.sha(a.DEV))
        while not finished_acquisition():
            if not disk_present():raise RuntimeError('E: unavailable; stop without alternate-drive material writes')
            time.sleep(10)
        if not a.FREEZE.exists():run('freezing_confirmation',[HERE/'freeze_confirmation.py'])
        else:c.validate_confirmation_freeze()
        if not (HERE/'CONFIRMATION_RESULTS.json').exists():
            run('once_frozen_signal_confirmation',[HERE/'run_experiment.py','--role','confirm','--workers','2'])
            run('analyzing_without_refitting',[HERE/'analysis.py','confirm'])
        result=a.load(HERE/'CONFIRMATION_RESULTS.json')
        state('finished_once_frozen_confirmation',results_sha256=a.sha(HERE/'CONFIRMATION_RESULTS.json'),
            full_prespecified_confirmation_success=result['primary_decision']['full_prespecified_confirmation_success'],
            manuscript_integration_pending=True)
    except BaseException as exc:
        if disk_present():state('stopped_preserving_original_contract',error=repr(exc))
        traceback.print_exc();raise
    finally:
        if awake:ctypes.windll.kernel32.SetThreadExecutionState(ctypes.c_uint32(0x80000000))


if __name__=='__main__':main()
