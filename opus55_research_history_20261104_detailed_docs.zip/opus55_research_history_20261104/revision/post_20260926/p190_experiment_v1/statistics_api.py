"""Prespecified person-paired P190 inference; no fitting or signal access."""
from __future__ import annotations
import itertools
import math
import numpy as np
from scipy import stats

TOL=1e-12


def paired_values(proposed,baseline):
    if set(proposed)!=set(baseline):
        raise ValueError('Paired person IDs differ')
    ids=sorted(proposed)
    if len(ids)<2:raise ValueError('At least two people required')
    a=np.asarray([proposed[k] for k in ids],dtype=float)
    b=np.asarray([baseline[k] for k in ids],dtype=float)
    if a.ndim!=1 or b.ndim!=1 or not np.isfinite(a).all() or not np.isfinite(b).all():
        raise ValueError('One finite value per person required')
    return ids,a,b


def mean_inference(values,*,null=0.,alternative='less'):
    x=np.asarray(values,dtype=float)
    if x.ndim!=1 or len(x)<2 or not np.isfinite(x).all():
        raise ValueError('Finite one-dimensional paired differences required')
    if alternative not in ('less','greater'):raise ValueError(alternative)
    n=len(x);mean=float(x.mean());sd=float(x.std(ddof=1));se=sd/math.sqrt(n)
    degenerate=sd==0.
    if degenerate:
        shift=mean-null
        p=(1. if shift==0 else float(shift>0) if alternative=='less' else float(shift<0))
        t=None if shift==0 else ('+infinity' if shift>0 else '-infinity')
        ci=[mean,mean];dz=None
    else:
        result=stats.ttest_1samp(x,popmean=null,alternative=alternative)
        p=float(result.pvalue);t=float(result.statistic)
        q=float(stats.t.ppf(.975,n-1));ci=[mean-q*se,mean+q*se];dz=mean/sd
    return dict(n=n,mean=mean,sd=sd,median=float(np.median(x)),minimum=float(x.min()),
        maximum=float(x.max()),se=se,df=n-1,CI95=ci,t=t,p_one_sided=p,null=null,
        alternative=alternative,paired_dz=dz,degenerate=degenerate,
        degenerate_interpretation=('collapsed empirical interval; nonzero constant differences use the limiting t calculation, not a population risk bound' if degenerate else None),
        values=x.tolist())


def signflip(values,*,null=0.):
    x=np.asarray(values,dtype=float)-null
    if x.ndim!=1 or not 1<=len(x)<=16 or not np.isfinite(x).all():
        raise ValueError('Finite small paired vector required')
    observed=float(x.mean())
    means=[float(np.mean(x*np.asarray(s))) for s in itertools.product((-1.,1.),repeat=len(x))]
    n=len(means)
    return dict(n_signs=n,null=null,centered_observed_mean=observed,
        p_two_sided=sum(abs(v)>=abs(observed)-TOL for v in means)/n,
        p_less=sum(v<=observed+TOL for v in means)/n,
        p_greater=sum(v>=observed-TOL for v in means)/n,
        assumption='independent person differences symmetric under sign changes about the specified null',
        all_centered_means=means,sensitivity_only=True)


def holm(pvalues,alpha=.05):
    if not pvalues or any(not math.isfinite(v) or not 0<=v<=1 for v in pvalues.values()):
        raise ValueError('Finite p values in [0,1] required')
    order=sorted(pvalues,key=lambda k:(pvalues[k],k));m=len(order);previous=0.;out={}
    for i,key in enumerate(order):
        adjusted=min(1.,max(previous,(m-i)*pvalues[key]));previous=adjusted
        out[key]=dict(raw_p=pvalues[key],holm_p=adjusted,reject=adjusted<=alpha)
    return out


def primary_contrast(proposed,baseline):
    """Input maps person->{coverage,primary_acceptance}; no record reweighting."""
    if set(proposed)!=set(baseline):raise ValueError('Person IDs differ')
    ids=sorted(proposed)
    dcover=[proposed[k]['coverage']-baseline[k]['coverage'] for k in ids]
    dnear=[proposed[k]['primary_acceptance']-baseline[k]['primary_acceptance'] for k in ids]
    cov=mean_inference(dcover,null=-.05,alternative='greater')
    near=mean_inference(dnear,null=0.,alternative='less')
    return dict(persons=ids,coverage_difference=cov,primary_acceptance_difference=near,
        iut_p=max(cov['p_one_sided'],near['p_one_sided']),
        iut_definition='max(coverage NI at -.05, primary-unknown superiority versus 0)',
        observed_improvement_at_least_05=(-near['mean']>=.05-TOL),
        nonworse_people=sum(v<=TOL for v in dnear),strictly_better_people=sum(v<-TOL for v in dnear),
        signflip_coverage_NI=signflip(dcover,null=-.05),signflip_primary=signflip(dnear,null=0.))
