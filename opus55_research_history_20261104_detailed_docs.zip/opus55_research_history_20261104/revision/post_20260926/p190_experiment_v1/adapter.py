"""OpenBMI train-phase adapter with frozen physical channels and decode gate.

The P184 selective MATLAB decoder, whole-phase 4/25 resampler and fixed-slice
function bodies are reused unchanged in a private module instance. Metadata
access is separate from signal decoding. New subjects require the caller's
explicit flag and the experiment's confirmation-freeze file.
"""
from pathlib import Path
import hashlib
import importlib.util
import json

import numpy as np

HERE=Path(__file__).resolve().parent
BASE=HERE.parent
P184=BASE/'p184_new_record_preparation_v1'
P186=BASE/'p186_new_records_v1'
ACQUISITION=BASE/'p190_source_history_v1/acquisition'
CONFIRMATION_FREEZE=HERE/'CONFIRMATION_FREEZE.json'
CHANNELS=('FC3','FC4','C3','C4','Cz','CP3','CP4','Pz')
HZ=160
STARTS=(8,24,40,56,72)

_spec=importlib.util.spec_from_file_location('_p190_private_p184_openbmi_reader',P184/'openbmi_adapter.py')
_PRIOR=importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_PRIOR)
_VERIFIED_RAW={}


def _sha(path):
    result=hashlib.sha256()
    with Path(path).open('rb') as file:
        for block in iter(lambda:file.read(1024*1024),b''):result.update(block)
    return result.hexdigest()


def _subject(subject):
    if isinstance(subject,bool) or not isinstance(subject,int) or not 1<=subject<=16:
        raise ValueError('OpenBMI session1 subjects1 through16 are declared')
    return subject


def _metadata_and_receipt(subject):
    subject=_subject(subject)
    if subject in (1,2):
        metadata_path=P184/f'sess01_subj{subject:02d}_EEG_MI_metadata.json'
        receipt_path=P184/'reserved_validation_manifest.json'
        receipt=json.loads(receipt_path.read_text(encoding='utf-8'))
        row=next(v for v in receipt['sources'] if v['subject']==subject)
        acquisition=dict(path=row['path'],bytes=row['source_bytes'],sha256=row['source_sha256'])
        # These original metadata bytes are bound by the acquisition-era manifest.
        assert _sha(metadata_path)==row['metadata_sha256'],'Historical metadata receipt mismatch'
    elif subject in (3,4):
        metadata_path=P186/f'sess01_subj{subject:02d}_EEG_MI_metadata.json'
        receipt_path=P186/'acquisition.json'
        receipt=json.loads(receipt_path.read_text(encoding='utf-8'))
        row=next(v for v in receipt['sources'] if v['subject']==subject)
        acquisition={k:row[k] for k in ('path','bytes','sha256')}
    else:
        metadata_path=ACQUISITION/'metadata'/f'sess01_subj{subject:02d}_EEG_MI_metadata.json'
        receipt_path=ACQUISITION/f'subject{subject:03d}_acquisition.json'
        receipt=json.loads(receipt_path.read_text(encoding='utf-8'))
        assert receipt['status']=='complete' and receipt['subject']==subject
        acquisition={k:receipt[k] for k in ('path','bytes','sha256')}
    document=json.loads(metadata_path.read_text(encoding='utf-8'))
    raw=Path(document['path']).resolve()
    assert raw==Path(acquisition['path']).resolve(),'Metadata and acquisition paths differ'
    assert document['bytes']==acquisition['bytes']==raw.stat().st_size,'Raw byte count differs from receipts'
    recorded=document.get('acquisition_sha256',document.get('source_download_sha256'))
    if recorded is not None:assert recorded==acquisition['sha256'],'Raw SHA receipts disagree'
    assert len(acquisition['sha256'])==64
    return document,metadata_path,receipt_path,acquisition


def metadata(subject,phase='train'):
    """Read declared metadata only; signal matrices remain byte-unopened here."""
    subject=_subject(subject)
    if phase!='train':raise ValueError('P190 declares session1 train phase only')
    document,metadata_path,receipt_path,acquisition=_metadata_and_receipt(subject)
    matrix=next(a for a in document['arrays'] if a['path']=='/EEG_MI_train')
    fields={v['path'].split('/')[-1]:v for v in matrix['children']}
    names=[v['value'] for v in fields['chan']['children']]
    assert fields['fs']['value']==[1000]
    assert [v['value'] for v in fields['class']['children']]==['1','2','right','left']
    assert fields['x']['values_not_loaded'] is True
    assert all(name in names for name in CHANNELS)
    result=dict(subject=subject,session=1,phase=phase,path=Path(document['path']),
        native_shape=tuple(fields['x']['shape']),channels=CHANNELS,
        channel_indices=[names.index(name) for name in CHANNELS],
        cues_matlab=np.asarray(fields['t']['value'],dtype=np.int64),
        labels=np.asarray(fields['y_dec']['value'],dtype=np.int64),native_hz=1000,
        metadata_path=metadata_path,metadata_sha256=_sha(metadata_path),
        raw_file_sha256=acquisition['sha256'],raw_file_bytes=acquisition['bytes'],
        raw_receipt_path=receipt_path,raw_receipt_sha256=_sha(receipt_path))
    # Check the fixed landmark without reading any signal values.
    origin=max(0,int(result['cues_matlab'][0])-1-2000)
    assert origin+112000<=result['native_shape'][0]
    return result


def _require_decode_authorization(subject,allow_new):
    subject=_subject(subject)
    if not isinstance(allow_new,bool):raise ValueError('allow_new must be an explicit Boolean')
    if subject>=5:
        if not allow_new:
            raise PermissionError('Subjects5–16 require allow_new=True after confirmation freeze')
        if not CONFIRMATION_FREEZE.is_file():
            raise PermissionError('New-source signal decoding requires CONFIRMATION_FREEZE.json')
        # Reject empty/truncated placeholders; the collector separately validates
        # scientific content and hashes of the full frozen protocol.
        freeze=json.loads(CONFIRMATION_FREEZE.read_text(encoding='utf-8'))
        if not isinstance(freeze,dict) or not freeze:
            raise ValueError('Confirmation freeze must be a nonempty JSON object')


def _verify_raw(meta):
    path=meta['path'].resolve();stat=path.stat()
    signature=(stat.st_size,stat.st_mtime_ns,meta['raw_file_sha256'])
    if _VERIFIED_RAW.get(path)!=signature:
        assert stat.st_size==meta['raw_file_bytes']
        assert _sha(path)==meta['raw_file_sha256'],'Raw source SHA differs from acquisition receipt'
        _VERIFIED_RAW[path]=signature


# Mutations affect this private in-memory module only. Reused numerical bodies
# and every historical source file remain unchanged.
_PRIOR.metadata=metadata
_PRIOR.CHANNELS=CHANNELS


def load_reference(subject,allow_new=False):
    """Return an8×17920 float64 voltage reference and its fixed-origin receipt."""
    _require_decode_authorization(subject,allow_new)
    meta=metadata(subject)
    _verify_raw(meta)
    x,description=_PRIOR.load_reference(subject,phase='train',entry='first_cue_minus_2s',block_index=0)
    assert x.shape==(8,17920) and x.dtype==np.float64 and np.isfinite(x).all()
    assert description['channels']==list(CHANNELS)
    description.update(source_id=f'OpenBMI-ses1-sub{subject:03d}',
        native_source_path=str(meta['path']),raw_file_sha256=meta['raw_file_sha256'],
        physical_channel_indices=meta['channel_indices'],native_units='uV',units='V',
        resampling=dict(up=4,down=25,window=['kaiser',5.0],padtype='line',mode='whole selected8channel phase then fixed slice'),
        prior_decoding_and_resampling_functions_unchanged=True,
        task_model_policy='Attribution only; no BCI four-class task inference on binary OpenBMI',
        metadata_path=str(meta['metadata_path']),metadata_sha256=meta['metadata_sha256'],
        raw_receipt_path=str(meta['raw_receipt_path']),raw_receipt_sha256=meta['raw_receipt_sha256'],
        adapter_sha256=_sha(Path(__file__)),
        new_subject_decode_authorization=(dict(explicit_allow_new=True,freeze_path=str(CONFIRMATION_FREEZE),freeze_sha256=_sha(CONFIRMATION_FREEZE)) if subject>=5 else 'historically_observed_subject'))
    return x,description
