# Actual EDF distance diagnosis

Every processed EDF serialization matches the original P190 saved query byte hash. Distances compare decoded physical samples and digital codes, not headers. Scoring-grid distances use the five fixed nominal windows and do not estimate delay.

|Stage|Code angle|n (40s)|Exact collisions|Median changed fraction|Median RMS LSB|Median waveform angle|Median relative fingerprint L2|
|---|---:|---:|---:|---:|---:|---:|---:|
|issued|0.0125|64|0|0.0542188|0.232847|0.033377|0.0333788|
|issued|0.025|128|0|0.125459|0.354698|0.0491605|0.0491564|
|reexport|0.0125|64|0|0.0439062|0.209533|0.0376372|0.03763|
|reexport|0.025|128|0|0.102188|0.319714|0.0555439|0.0555317|
|elliptic_new_causal|0.0125|64|0|0.471318|0.903075|0.0464447|0.0464442|
|elliptic_new_causal|0.025|128|0|0.628086|1.29103|0.0631226|0.0630986|
|bessel_shifted_causal|0.0125|64|0|0.442588|0.875149|0.0401659|0.0401865|
|bessel_shifted_causal|0.025|128|0|0.60668|1.25458|0.0558635|0.0559068|

Processed query byte hashes matched: 792/792.
Both family directions and parent assignments retain the existing P190 code definitions. No new unknown identity or policy is selected here.
