"""Actual stored-sample distances; all processing EDF bytes match P190 queries."""
from pathlib import Path
import csv,gzip,hashlib,io,json,os
HERE=Path(__file__).resolve().parent
for key in ('TEMP','TMP','TMPDIR','MPLCONFIGDIR'):
    p=HERE/'cache'/key.lower();p.mkdir(parents=True,exist_ok=True);os.environ[key]=str(p)
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
import edfio
import numpy as np
from scipy.signal import ellip,bessel,sosfilt

P190=HERE.parent/'p190_experiment_v1'
CHANNELS=('FC3','FC4','C3','C4','Cz','CP3','CP4','Pz')
CONDS=('reexport','elliptic_new_causal','bessel_shifted_causal')
SCORED=np.concatenate([np.arange(s*160,(s+8)*160) for s in (8,24,40,56,72)])
VISIBLE=np.concatenate([np.arange(s*160-128,(s+8)*160+128) for s in (8,24,40,56,72)])


def parse(raw):
    doc=edfio.read_edf(io.BytesIO(raw),lazy_load_data=False)
    assert [s.label for s in doc.signals]==list(CHANNELS)
    values=np.asarray([s.data*1e-6 for s in doc.signals])
    steps=np.asarray([(s.physical_max-s.physical_min)*1e-6/(s.digital_max-s.digital_min) for s in doc.signals])
    n=int(raw[252:256]);nr=int(raw[236:244]);header=int(raw[184:192])
    pos=256+n*(16+80+8+8+8+8+8+80)
    ns=[int(raw[pos+8*i:pos+8*(i+1)]) for i in range(n)]
    assert len(set(ns))==1
    digital=np.frombuffer(raw[header:],dtype='<i2').reshape(nr,n,ns[0]).transpose(1,0,2).reshape(n,-1).copy()
    return values,steps,digital


def read(path):
    return parse(gzip.decompress(path.read_bytes()))


def transform(x,c):
    if c=='reexport':return x.copy()
    sos=ellip(5,1.3,50,[1.7,32.5],btype='bandpass',fs=160,output='sos') if c=='elliptic_new_causal' else bessel(6,[3,33],btype='bandpass',fs=160,output='sos',norm='phase')
    y=sosfilt(sos,x,axis=-1)
    return y-y.mean(axis=-2,keepdims=True)


def roundtrip(x,limits):
    lo,hi=np.asarray(limits[0]),np.asarray(limits[1])
    assert not ((x<lo[:,None]*1e-6)|(x>hi[:,None]*1e-6)).any()
    signals=[edfio.EdfSignal(x[i]*1e6,160,label=CHANNELS[i],physical_dimension='uV',physical_range=(float(lo[i]),float(hi[i]))) for i in range(8)]
    stream=io.BytesIO();edfio.Edf(signals).write(stream);raw=stream.getvalue()
    return (*parse(raw),hashlib.sha256(raw).hexdigest())


def metrics(parent,unknown,clean,step,dp,du,indices):
    pp,uu,xx=parent[:,indices],unknown[:,indices],clean[:,indices]
    error=uu-pp;fp=pp-xx;fu=uu-xx
    dot=float(np.sum(fp*fu));npv=float(np.linalg.norm(fp));nuv=float(np.linalg.norm(fu))
    delta_digital=du[:,indices].astype(np.int32)-dp[:,indices].astype(np.int32)
    return dict(samples=int(error.size),identical_samples=bool(np.array_equal(du[:,indices],dp[:,indices])),
        changed_fraction=float(np.mean(delta_digital!=0)),RMS_LSB=float(np.sqrt(np.mean(delta_digital.astype(float)**2))),
        RMS_uv=float(np.sqrt(np.mean(error**2))*1e6),relative_parent_fingerprint_L2=float(np.linalg.norm(error)/max(npv,1e-30)),
        waveform_fingerprint_angle=float(np.arccos(np.clip(dot/max(npv*nuv,1e-30),-1,1))),
        parent_fingerprint_norm=npv,unknown_fingerprint_norm=nuv)


def summarize(rr,key):
    v=np.asarray([r[key] for r in rr]);return dict(n=len(v),minimum=float(v.min()),median=float(np.median(v)),maximum=float(v.max()))


def main():
    output=[];pairs=[];sha_matches=0
    for number in range(5,13):
        source=f'OpenBMI{number:03d}'
        z=json.loads(gzip.decompress((P190/'raw/confirm'/source/'level100/smooth.json.gz').read_bytes()))
        saved={(r['query_index'],r['condition']):r for r in z['rows']}
        folder=P190/'issuance'/source/'level100'
        meta=json.loads((folder/'issuance_summary.json').read_text(encoding='utf-8'))['metadata']['smooth']
        x,_,_=read(P190/'sources'/source/'clean.edf.gz')
        issued=[read(folder/f'smooth_r{i}_issued.edf.gz') for i in range(32)]
        groups={'issued':issued};cleans={'issued':x}
        for c in CONDS:
            qq=[]
            for i,(y,_,_) in enumerate(issued):
                a,step,digital,digest=roundtrip(transform(y,c),z['query_limits_uv'][c])
                assert digest==saved[i,c]['query_raw_sha256'],(source,i,c,'Reconstructed query differs')
                sha_matches+=1;qq.append((a,step,digital))
            clean,_,_,digest=roundtrip(transform(x,c),z['query_limits_uv'][c])
            assert digest==saved[32,c]['query_raw_sha256']
            sha_matches+=1;groups[c]=qq;cleans[c]=clean
        for stage,signals in groups.items():
            for i in range(8,32):
                info=meta[i];parent=info['parent']
                p,step,dp=signals[parent];u,_,du=signals[i]
                rec=saved[i,stage] if stage!='issued' else None
                rr=rec['receiver']['methods']['candidate_FIR_GLRT']['by_ridge']['1e-06'] if rec is not None else None
                accepted=bool(rr['eligible'] and rr['presence']>=.25 and rr['support']>=1 and rr['compatibility']>=.9957274054693162) if rr else None
                for scope,indices in (('full112s',np.arange(17920)),('scored40s',SCORED),('visible48s',VISIBLE)):
                    output.append(dict(source=source,stage=stage,scope=scope,query_index=i,parent=parent,
                        code_angle=info['angle'],direction=info['direction'],pressure=info['pressure'],
                        P190_accepted=accepted,compatibility=rr['compatibility'] if rr else None,
                        **metrics(p,u,cleans[stage],step,dp,du,indices)))
            for scope,indices in (('issued112s',np.arange(17920)),('scored40s',SCORED)):
                for i in range(8):
                    for j in range(i+1,8):
                        p,step,dp=signals[i];u,_,du=signals[j]
                        pairs.append(dict(source=source,stage=stage,scope=scope,identity1=i,identity2=j,
                                          **metrics(p,u,cleans[stage],step,dp,du,indices)))
        print(source,'complete',flush=True)
    with (HERE/'actual_EDF_distance_rows.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(output[0]));w.writeheader();w.writerows(output)
    with (HERE/'registered_pair_distances.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(pairs[0]));w.writeheader();w.writerows(pairs)
    summaries=[]
    for stage in ('issued',)+CONDS:
        for angle in (.0125,.025):
            for scope in ('full112s','scored40s','visible48s'):
                rr=[r for r in output if r['stage']==stage and r['code_angle']==angle and r['scope']==scope]
                summaries.append(dict(stage=stage,angle=angle,scope=scope,n=len(rr),
                    exact_parent_collisions=sum(r['identical_samples'] for r in rr),
                    metrics={k:summarize(rr,k) for k in ('changed_fraction','RMS_LSB','RMS_uv','relative_parent_fingerprint_L2','waveform_fingerprint_angle')}))
    result=dict(status='complete_actual_EDF_sample_distances',
        scope='P190 observed people005-012 smooth level1; nominal fixed scoring grid, no receiver realignment',
        processed_EDF_byte_hash_matches=sha_matches,expected_processed_EDF_byte_hash_matches=8*33*3,
        storage_parent_collisions=sum(r['identical_samples'] for r in output if r['stage']=='issued' and r['scope']=='full112s'),
        summaries=summaries,source_files='Existing clean and issued EDF archives; stored original query ranges',
        raw_MAT_decoded=False,new_method_fitted=False)
    (HERE/'ACTUAL_EDF_DISTANCES.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    report=['# Actual EDF distance diagnosis','','Every processed EDF serialization matches the original P190 saved query byte hash. Distances compare decoded physical samples and digital codes, not headers. Scoring-grid distances use the five fixed nominal windows and do not estimate delay.','',
        '|Stage|Code angle|n (40s)|Exact collisions|Median changed fraction|Median RMS LSB|Median waveform angle|Median relative fingerprint L2|',
        '|---|---:|---:|---:|---:|---:|---:|---:|']
    for s in summaries:
        if s['scope']!='scored40s':continue
        m=s['metrics'];report.append('|'+s['stage']+f"|{s['angle']}|{s['n']}|{s['exact_parent_collisions']}|{m['changed_fraction']['median']:.6g}|{m['RMS_LSB']['median']:.6g}|{m['waveform_fingerprint_angle']['median']:.6g}|{m['relative_parent_fingerprint_L2']['median']:.6g}|")
    report+=['',f'Processed query byte hashes matched: {sha_matches}/{8*33*3}.',
             'Both family directions and parent assignments retain the existing P190 code definitions. No new unknown identity or policy is selected here.','']
    (HERE/'ACTUAL_EDF_DISTANCES.md').write_text('\n'.join(report),encoding='utf-8')
    print(json.dumps(dict(status=result['status'],sha_matches=sha_matches,collisions=result['storage_parent_collisions'])))


if __name__=='__main__':main()
