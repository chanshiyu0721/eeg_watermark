# P191 saved-score diagnosis

P190 observed evidence; no policy has been fitted or replaced. All metrics below are descriptive.

|Receiver / condition|P190 pressure accepted|C range registered|C range pressure|Beta L2 range registered|Beta L2 range pressure|
|---|---:|---:|---:|---:|---:|
|candidate / reexport|0/64|0.998395–0.999747|0.848866–0.990464|0.000591285–0.00315437|0.0100108–0.0166923|
|candidate / elliptic_new_causal|30/64|0.999268–0.999926|0.971111–0.997843|0.00165646–0.00855387|0.00801469–0.0194563|
|candidate / bessel_shifted_causal|0/64|0.999449–0.999986|0.68669–0.985909|9.15599e-05–0.000937357|0.0107721–0.0190275|

## Scalar screens

|Receiver|Condition|Metric|Pressure accepted at empirical 100% registered coverage|At >=95% registered coverage|
|---|---|---|---:|---:|
|ordinary_FIR|reexport|compatibility|62/64|60/64|
|ordinary_FIR|reexport|relative_gap|63/64|60/64|
|ordinary_FIR|reexport|presence|62/64|60/64|
|ordinary_FIR|reexport|beta_l2|59/64|59/64|
|ordinary_FIR|reexport|beta_angle|59/64|58/64|
|ordinary_FIR|elliptic_new_causal|compatibility|63/64|62/64|
|ordinary_FIR|elliptic_new_causal|relative_gap|63/64|60/64|
|ordinary_FIR|elliptic_new_causal|presence|61/64|60/64|
|ordinary_FIR|elliptic_new_causal|beta_l2|59/64|59/64|
|ordinary_FIR|elliptic_new_causal|beta_angle|59/64|58/64|
|ordinary_FIR|bessel_shifted_causal|compatibility|63/64|63/64|
|ordinary_FIR|bessel_shifted_causal|relative_gap|63/64|60/64|
|ordinary_FIR|bessel_shifted_causal|presence|63/64|60/64|
|ordinary_FIR|bessel_shifted_causal|beta_l2|59/64|59/64|
|ordinary_FIR|bessel_shifted_causal|beta_angle|59/64|58/64|
|projected_FIR|reexport|compatibility|0/64|0/64|
|projected_FIR|reexport|relative_gap|39/64|38/64|
|projected_FIR|reexport|presence|40/64|40/64|
|projected_FIR|reexport|beta_l2|0/64|0/64|
|projected_FIR|reexport|beta_angle|0/64|0/64|
|projected_FIR|elliptic_new_causal|compatibility|0/64|0/64|
|projected_FIR|elliptic_new_causal|relative_gap|56/64|56/64|
|projected_FIR|elliptic_new_causal|presence|63/64|58/64|
|projected_FIR|elliptic_new_causal|beta_l2|1/64|1/64|
|projected_FIR|elliptic_new_causal|beta_angle|1/64|1/64|
|projected_FIR|bessel_shifted_causal|compatibility|55/64|55/64|
|projected_FIR|bessel_shifted_causal|relative_gap|51/64|50/64|
|projected_FIR|bessel_shifted_causal|presence|60/64|57/64|
|projected_FIR|bessel_shifted_causal|beta_l2|58/64|57/64|
|projected_FIR|bessel_shifted_causal|beta_angle|57/64|56/64|
|candidate_FIR_GLRT|reexport|compatibility|0/64|0/64|
|candidate_FIR_GLRT|reexport|relative_gap|39/64|39/64|
|candidate_FIR_GLRT|reexport|presence|40/64|40/64|
|candidate_FIR_GLRT|reexport|beta_l2|0/64|0/64|
|candidate_FIR_GLRT|reexport|beta_angle|0/64|0/64|
|candidate_FIR_GLRT|elliptic_new_causal|compatibility|0/64|0/64|
|candidate_FIR_GLRT|elliptic_new_causal|relative_gap|55/64|54/64|
|candidate_FIR_GLRT|elliptic_new_causal|presence|63/64|58/64|
|candidate_FIR_GLRT|elliptic_new_causal|beta_l2|1/64|1/64|
|candidate_FIR_GLRT|elliptic_new_causal|beta_angle|1/64|1/64|
|candidate_FIR_GLRT|bessel_shifted_causal|compatibility|0/64|0/64|
|candidate_FIR_GLRT|bessel_shifted_causal|relative_gap|0/64|0/64|
|candidate_FIR_GLRT|bessel_shifted_causal|presence|21/64|20/64|
|candidate_FIR_GLRT|bessel_shifted_causal|beta_l2|0/64|0/64|
|candidate_FIR_GLRT|bessel_shifted_causal|beta_angle|0/64|0/64|

These scalar screens use the outcome-labeled observed P190 panel and are mechanism descriptions, not new validation. Saved raw scores contain betas, pooled residuals, common fold model/delay/peak, but no fitted response kernels or nonempty paired-clean diagnostics.
