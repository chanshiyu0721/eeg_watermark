# Fixed pressure-aware threshold control

This is one D_fit-only control at unchanged config6/presence. No D_select or observed-transfer score chooses its threshold. P190 original rules/counts remain historical.

Threshold: **0.99872804669744208**; same-fit nonpressure-only reference: 0.99572740546931615.

|Panel / threshold|Registered correct|.0125 accepted|.025 accepted|Clean accepted|Wrong accepted|
|---|---:|---:|---:|---:|---:|
|fit / pressure_aware|95/96|0/96|0/96|0/12|0/24|
|fit / nonpressure_fit_reference|96/96|25/96|0/96|0/12|0/24|
|select / pressure_aware|94/96|0/96|0/96|0/12|0/24|
|select / nonpressure_fit_reference|96/96|20/96|0/96|0/12|0/24|
|observed_transfer / pressure_aware|191/192|0/192|0/384|0/24|0/96|
|observed_transfer / nonpressure_fit_reference|192/192|30/192|0/384|0/24|0/96|

Threshold-defining negatives:

- A02T / elliptic_new_causal / phase_near_unregistered / q21.

D_fit and D_select are original P190 development panels. People005-012 are an already-observed transfer panel for this new research. None of these outcomes is a new independent confirmation.
