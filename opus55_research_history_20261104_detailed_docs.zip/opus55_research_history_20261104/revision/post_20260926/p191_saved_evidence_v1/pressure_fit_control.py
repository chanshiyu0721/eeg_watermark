"""One fixed pressure-aware threshold control, fitted to P190 D_fit only."""
from pathlib import Path
import csv,gzip,json
import numpy as np

HERE=Path(__file__).resolve().parent
P190=HERE.parent/'p190_experiment_v1'
ROLES=dict(fit=('OpenBMI001','OpenBMI002','A02T','A03E'),
           select=('OpenBMI003','OpenBMI004','A05E','A07E'),
           observed_transfer=tuple(f'OpenBMI{s:03d}' for s in range(5,13)))
COND=('reexport','elliptic_new_causal','bessel_shifted_causal')


def rows(role):
    folder='confirm' if role=='observed_transfer' else role
    result=[]
    for source in ROLES[role]:
        p=P190/'raw'/folder/source/'level100/smooth.json.gz'
        z=json.loads(gzip.decompress(p.read_bytes()))
        assert z['status']=='complete'
        for raw in z['rows']:
            assert raw['issuance_feasible']
            score=raw['receiver']['methods']['candidate_FIR_GLRT']['configs'][6]
            presence=raw['receiver']['methods']['candidate_FIR_GLRT']['by_ridge']['1e-06']['presence']
            result.append(dict(role=role,source=source,condition=raw['condition'],kind=raw['kind'],
                query_index=raw['query_index'],identity=raw.get('identity'),parent=raw.get('parent'),
                angle=raw.get('angle'),pressure=bool(raw.get('pressure')),score=score['score'],
                eligible=bool(score['eligible'] and presence>=.25),presence=presence,top=score['top']))
    return result


def summarize(rr,t):
    accepted=lambda r:r['eligible'] and r['score']>=t
    result={}
    for name,pred in (('registered',lambda r:r['kind']=='enrolled'),
                      ('pressure0125',lambda r:r['pressure']),('near025',lambda r:r['angle']==.025),
                      ('clean',lambda r:r['kind']=='clean'),('wrong',lambda r:r['kind']=='wrong_source')):
        z=[r for r in rr if pred(r)]
        result[name]=dict(n=len(z),accepted=sum(accepted(r) for r in z),
            correct=sum(accepted(r) and r['top']==r['identity'] for r in z) if name=='registered' else None,
            misattributed=sum(accepted(r) and r['top']!=r['identity'] for r in z) if name=='registered' else None)
    return result


def main():
    allrows={role:rows(role) for role in ROLES}
    fit=allrows['fit']
    negatives=[r for r in fit if r['kind']!='enrolled' and r['eligible']]
    assert negatives
    maximum=max(r['score'] for r in negatives)
    t=float(np.nextafter(maximum,np.inf))
    oldneg=[r for r in negatives if not r['pressure']]
    oldt=float(np.nextafter(max(r['score'] for r in oldneg),np.inf))
    result=dict(status='pressure_aware_fixed_control_fitted_once_to_D_fit',
        objective='Reject pressure0125, near025, clean and wrong-source while retaining enrolled identities',
        config=dict(index=6,ridge=1e-6,head='compatibility',support=1,presence_gate=.25),
        fit_targets=list(ROLES['fit']),fit_only_threshold=t,fit_nonpressure_only_threshold=oldt,
        threshold_defining_negative=[r for r in negatives if r['score']==maximum],
        no_selection_using_D_select_or_observed_transfer=True,new_confirmation_performed=False,
        original_P190_rules_unchanged=True,summaries={},source_processing_gaps=[])
    for role,rr in allrows.items():
        result['summaries'][role]=dict(pressure_aware=summarize(rr,t),nonpressure_fit_reference=summarize(rr,oldt),
            people=[dict(source=s,pressure_aware=summarize([r for r in rr if r['source']==s],t),
                         original_nonpressure_fit=summarize([r for r in rr if r['source']==s],oldt)) for s in ROLES[role]],
            processing={c:dict(pressure_aware=summarize([r for r in rr if r['condition']==c],t),
                               original_nonpressure_fit=summarize([r for r in rr if r['condition']==c],oldt)) for c in COND})
        for s in ROLES[role]:
            for c in COND+('all_conditions',):
                zz=[r for r in rr if r['source']==s and (r['condition']==c or c=='all_conditions')]
                reg=[r['score'] for r in zz if r['kind']=='enrolled' and r['eligible']]
                pressure=[r['score'] for r in zz if r['pressure'] and r['eligible']]
                result['source_processing_gaps'].append(dict(role=role,source=s,condition=c,
                    registered_min=min(reg) if reg else None,pressure_max=max(pressure) if pressure else None,
                    score_gap=min(reg)-max(pressure) if reg and pressure else None,
                    registered_n=sum(r['kind']=='enrolled' for r in zz),registered_eligible_n=len(reg)))
    (HERE/'PRESSURE_AWARE_FIXED_CONTROL.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    with (HERE/'source_processing_gaps.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(result['source_processing_gaps'][0]));w.writeheader();w.writerows(result['source_processing_gaps'])
    report=['# Fixed pressure-aware threshold control','','This is one D_fit-only control at unchanged config6/presence. No D_select or observed-transfer score chooses its threshold. P190 original rules/counts remain historical.','',
        f'Threshold: **{t:.17g}**; same-fit nonpressure-only reference: {oldt:.17g}.','',
        '|Panel / threshold|Registered correct|.0125 accepted|.025 accepted|Clean accepted|Wrong accepted|',
        '|---|---:|---:|---:|---:|---:|']
    for role,panels in result['summaries'].items():
        for name in ('pressure_aware','nonpressure_fit_reference'):
            s=panels[name]
            vals=[f"{s['registered']['correct']}/{s['registered']['n']}"]
            vals.extend(f"{s[k]['accepted']}/{s[k]['n']}" for k in ('pressure0125','near025','clean','wrong'))
            report.append('|'+role+' / '+name+'|'+'|'.join(vals)+'|')
    report+=['','Threshold-defining negatives:','']
    for r in result['threshold_defining_negative']:
        report.append('- '+r['source']+' / '+r['condition']+' / '+r['kind']+' / q'+str(r['query_index'])+'.')
    report+=['','D_fit and D_select are original P190 development panels. People005-012 are an already-observed transfer panel for this new research. None of these outcomes is a new independent confirmation.','']
    (HERE/'PRESSURE_AWARE_FIXED_CONTROL.md').write_text('\n'.join(report),encoding='utf-8')
    print(json.dumps(dict(threshold=t,oldthreshold=oldt,summary={k:v['pressure_aware'] for k,v in result['summaries'].items()})))


if __name__=='__main__':main()
