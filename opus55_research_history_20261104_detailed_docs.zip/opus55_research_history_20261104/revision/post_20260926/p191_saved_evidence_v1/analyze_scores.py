"""Describe frozen P190 scores as observed development evidence for P191."""
from pathlib import Path
import csv,gzip,json,math,os,statistics
os.environ['MPLCONFIGDIR']=str(Path(__file__).resolve().parent/'cache/matplotlib')
import numpy as np

HERE=Path(__file__).resolve().parent
P190=HERE.parent/'p190_experiment_v1'
METHODS=('ordinary_FIR','projected_FIR','candidate_FIR_GLRT')
CONDITIONS=('reexport','elliptic_new_causal','bessel_shifted_causal')


def dist(a):
    a=np.asarray(a,dtype=float)
    return dict(n=len(a),minimum=float(a.min()),q05=float(np.quantile(a,.05)),median=float(np.median(a)),
                q95=float(np.quantile(a,.95)),maximum=float(a.max())) if len(a) else dict(n=0)


def auc(good,bad):
    good,bad=np.asarray(good),np.asarray(bad)
    return float(np.mean((good[:,None]>bad[None,:])+.5*(good[:,None]==bad[None,:])))


def load_rows():
    dev=json.loads((P190/'DEVELOPMENT_SELECTION.json').read_text(encoding='utf-8'))
    rule=dev['groups']['level100/smooth/candidate_FIR_GLRT']['policies']['source_stable']['selected']
    rows=[]
    for number in range(5,13):
        source=f'OpenBMI{number:03d}'
        z=json.loads(gzip.decompress((P190/'raw/confirm'/source/'level100/smooth.json.gz').read_bytes()))
        assert z['status']=='complete'
        for r in z['rows']:
            if not r['issuance_feasible']:continue
            for method in METHODS:
                rr=r['receiver']['methods'][method]['by_ridge']['1e-06']
                beta=np.asarray(rr['beta']);top=rr['top'];target=np.eye(8)[top]
                off=np.delete(beta,top);rss=np.sort(rr['candidate_RSS'])
                row={k:r.get(k) for k in ('source','query_index','kind','identity','parent','angle','direction','pressure','condition')}
                row.update(method=method,top=top,compatibility=rr['compatibility'],relative_gap=rr['relative_gap'],
                    presence=rr['presence'],support=rr['support'],eligible=rr['eligible'],
                    beta_l2=float(np.linalg.norm(beta-target)),beta_offnorm=float(np.linalg.norm(off)),
                    beta_top=float(beta[top]),beta_norm=float(np.linalg.norm(beta)),
                    beta_angle=float(np.arccos(np.clip(beta[top]/max(np.linalg.norm(beta),1e-30),-1,1))),
                    fixed_RSS=float(rss[0]),second_RSS=float(rss[1]),unrestricted_RSS=rr['unrestricted_RSS'],
                    clean_RSS=rr['clean_RSS'],RSS_clean_ratio=float(rss[0]/max(rr['clean_RSS'],1e-30)),
                    beta=json.dumps(beta.tolist()),fold_models=json.dumps([f['model'] for f in r['receiver']['folds']]),
                    fold_delays=json.dumps([f['delay'] for f in r['receiver']['folds']]),
                    delay_span=max(f['delay'] for f in r['receiver']['folds'])-min(f['delay'] for f in r['receiver']['folds']),
                    diagnostic_kernels_saved=bool(r['receiver']['diagnostics']))
                row['P190_primary_accepted']=bool(rr['eligible'] and rr['support']>=1 and rr['presence']>=.25 and rr['compatibility']>=rule['threshold']) if method=='candidate_FIR_GLRT' else None
                rows.append(row)
    return rule,rows


def main():
    HERE.mkdir(parents=True,exist_ok=True)
    rule,rows=load_rows()
    with (HERE/'score_rows.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    summaries=[];frontiers=[]
    metrics=('compatibility','relative_gap','presence','beta_l2','beta_offnorm','beta_angle','beta_top','fixed_RSS','unrestricted_RSS','RSS_clean_ratio','delay_span')
    for method in METHODS:
        for condition in CONDITIONS:
            subset=[r for r in rows if r['method']==method and r['condition']==condition]
            reg=[r for r in subset if r['kind']=='enrolled']
            for family,pred in (('pressure0125',lambda r:r['pressure']),('near025',lambda r:r['angle']==.025)):
                unk=[r for r in subset if pred(r)]
                item=dict(method=method,condition=condition,family=family,registered_n=len(reg),unknown_n=len(unk),features={})
                for metric in metrics:
                    positive=metric not in ('beta_l2','beta_offnorm','beta_angle','fixed_RSS','RSS_clean_ratio','delay_span')
                    g=[r[metric] for r in reg];u=[r[metric] for r in unk]
                    item['features'][metric]=dict(registered=dist(g),unknown=dist(u),
                        AUC_registered_high=auc(g,u),orientation_registered_high=positive,
                        zero_error_scalar_separable=bool(min(g)>max(u) if positive else max(g)<min(u)))
                    scoreg=np.array(g)*(1 if positive else -1);scoreu=np.array(u)*(1 if positive else -1)
                    for coverage in (1.,.95,.90):
                        required=math.ceil(coverage*len(g)); threshold=float(np.sort(scoreg)[len(g)-required])
                        frontiers.append(dict(method=method,condition=condition,family=family,metric=metric,
                            required_registered_coverage=coverage,observed_registered_correct=int((scoreg>=threshold).sum()),
                            registered_n=len(g),unknown_accepted=int((scoreu>=threshold).sum()),unknown_n=len(u),
                            oriented_threshold=threshold,descriptive_only=True))
                summaries.append(item)
    primary=[r for r in rows if r['method']=='candidate_FIR_GLRT']
    by_person=[]
    for number in range(5,13):
        source=f'OpenBMI{number:03d}'
        for condition in CONDITIONS:
            subset=[r for r in primary if r['source']==source and r['condition']==condition]
            reg=[r for r in subset if r['kind']=='enrolled'];pressure=[r for r in subset if r['pressure']]
            accepted=[r for r in pressure if r['P190_primary_accepted']]
            by_person.append(dict(source=source,condition=condition,pressure_accepted=len(accepted),pressure_n=len(pressure),
                registered_min_C=min(r['compatibility'] for r in reg),pressure_max_C=max(r['compatibility'] for r in pressure),
                registered_beta_l2=dist([r['beta_l2'] for r in reg]),pressure_beta_l2=dist([r['beta_l2'] for r in pressure]),
                accepted_pressure_beta_l2=dist([r['beta_l2'] for r in accepted]),
                pressure_top_is_parent=all(r['top']==r['parent'] for r in pressure),
                fold_patterns=sorted(set((r['fold_models'],r['fold_delays']) for r in subset))))
    result=dict(status='complete_observed_P190_score_diagnosis',scope='P190 observed people005-012, smooth level1, weak ridge; descriptive development evidence, no new policy selected',
        frozen_primary_rule=rule,raw_signal_values_decoded=False,response_kernels_saved=False,
        summaries=summaries,descriptive_frontiers=frontiers,by_person=by_person)
    (HERE/'SCORE_DIAGNOSIS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    report=['# P191 saved-score diagnosis','','P190 observed evidence; no policy has been fitted or replaced. All metrics below are descriptive.','',
        '|Receiver / condition|P190 pressure accepted|C range registered|C range pressure|Beta L2 range registered|Beta L2 range pressure|',
        '|---|---:|---:|---:|---:|---:|']
    for condition in CONDITIONS:
        z=next(x for x in summaries if x['method']=='candidate_FIR_GLRT' and x['condition']==condition and x['family']=='pressure0125')
        cc=z['features']['compatibility'];bb=z['features']['beta_l2']
        accepted=sum(r['P190_primary_accepted'] for r in primary if r['condition']==condition and r['pressure'])
        fm=lambda x:f"{x['minimum']:.6g}–{x['maximum']:.6g}"
        report.append('|candidate / '+condition+'|'+str(accepted)+'/64|'+fm(cc['registered'])+'|'+fm(cc['unknown'])+'|'+fm(bb['registered'])+'|'+fm(bb['unknown'])+'|')
    report+=['','## Scalar screens','','|Receiver|Condition|Metric|Pressure accepted at empirical 100% registered coverage|At >=95% registered coverage|',
             '|---|---|---|---:|---:|']
    for method in METHODS:
        for condition in CONDITIONS:
            for metric in ('compatibility','relative_gap','presence','beta_l2','beta_angle'):
                ff=[r for r in frontiers if r['method']==method and r['condition']==condition and r['family']=='pressure0125' and r['metric']==metric]
                report.append('|'+method+'|'+condition+'|'+metric+'|'+str(ff[0]['unknown_accepted'])+'/64|'+str(ff[1]['unknown_accepted'])+'/64|')
    report+=['','These scalar screens use the outcome-labeled observed P190 panel and are mechanism descriptions, not new validation. Saved raw scores contain betas, pooled residuals, common fold model/delay/peak, but no fitted response kernels or nonempty paired-clean diagnostics.','']
    (HERE/'SCORE_DIAGNOSIS.md').write_text('\n'.join(report),encoding='utf-8')
    print(json.dumps(dict(status=result['status'],pressure_acceptances={c:sum(r['P190_primary_accepted'] for r in primary if r['condition']==c and r['pressure']) for c in CONDITIONS},output=str(HERE/'SCORE_DIAGNOSIS.json'))))


if __name__=='__main__':main()
