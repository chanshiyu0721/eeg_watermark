"""Fix task-panel blocks and count eligible events using MAT metadata only."""
from pathlib import Path
import datetime
import hashlib
import json
import math

HERE = Path(__file__).resolve().parent
TARGETS = tuple(range(17, 25))
STARTS = (8, 24, 40, 56, 72)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def rounded(value):
    return int(math.floor(value + .5))


def panel(subject, fields, origin_native, block_id):
    origin = rounded(origin_native * 4/25)
    events = []
    for index, (cue, label) in enumerate(zip(fields['t']['value'], fields['y_dec']['value'])):
        start = rounded((int(cue)-1) * 4/25) + 80 - origin
        for window, sec in enumerate(STARTS):
            if sec*160 <= start and start+320 <= (sec+8)*160:
                events.append(dict(event_id=f'OpenBMI_MI/sub{subject:02d}/ses1/train/trial{index:03d}',
                                   trial_index=index, class_id=int(label), epoch_start_sample=start,
                                   epoch_samples=320, window_index=window))
    return dict(block_id=block_id, origin_native=origin_native, origin_target160=origin,
                score_epoch_count=len(events), class_counts={str(label):sum(e['class_id']==label for e in events) for label in (1,2)},
                events=events)


def main():
    protocol = dict(status='metadata_only_panel_definition_before_new_EEG_decode',
                    targets=list(TARGETS), phase='session1 train', maximum_blocks=8,
                    block_rule='from native phase sample0, chronological nonoverlapping complete112s blocks; take firstmin(8,floor(native_samples/112000)); no performance-dependent changes',
                    reference_seconds=112, score_starts_seconds=list(STARTS), score_window_seconds=8,
                    total_scored_seconds=40, total_visible_seconds=48, channels=8, hz=160,
                    task_epochs_seconds_after_cue=[.5,2.5], eligibility='complete epoch wholly inside one scoring window',
                    carriers=['smooth','direct','modern_owner_adapted'],
                    primary_joint_panel='unchangedfirstcue-minus2s112sanchor, allfiveclassicalarmsincludingQIM; thissupplementseparate',
                    cost_budget='eachcarrierusesidenticalblock/actualPRD/40sscoring/48svisible; samefrozenreceivermodelandtaskmodels',
                    statistical_unit='independentperson; averagewithineachperson; blocks/identities/windowsarenotadditionalpeople',
                    identity_testing='onlyfrozenregisteredtemplatesandrule; no block-specific threshold calibration',
                    missing_or_unusable_policy='retainplannedblockfailures; no signal/QC/performance-based block replacement',
                    purpose='strongerjointtask-utilitypanelunderthesameper-querybudget',
                    signal_values_decoded=False, receiver_predictions=0, task_predictions=0)
    path = HERE/'MULTIBLOCK_PROTOCOL.json'
    if path.exists():
        assert json.loads(path.read_text(encoding='utf-8'))==protocol
    else:
        path.write_text(json.dumps(protocol,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    rows, pending = [], []
    for subject in TARGETS:
        metadata = HERE/'metadata'/f'sess01_subj{subject:02d}_EEG_MI_metadata.json'
        if not metadata.exists():
            pending.append(subject);continue
        document=json.loads(metadata.read_text(encoding='utf-8'))
        phase=next(r for r in document['arrays'] if r['path']=='/EEG_MI_train')
        fields={r['path'].split('/')[-1]:r for r in phase['children']}
        assert fields['x']['values_not_loaded'] is True
        samples=fields['x']['shape'][0]
        n=min(8,samples//112000)
        blocks=[panel(subject,fields,b*112000,b) for b in range(n)]
        main=panel(subject,fields,max(0,int(fields['t']['value'][0])-1-2000),'primary_firstcue')
        rows.append(dict(subject=subject,metadata_sha256=sha(metadata),native_samples=samples,
                         main_panel=main,supplementary_blocks=blocks,
                         supplementary_epoch_count=sum(b['score_epoch_count'] for b in blocks),
                         n_independent_people=1))
    report=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                protocol_sha256=sha(path),records=rows,pending_people=pending,
                new_signal_values_decoded=False,receiver_predictions=0,task_predictions=0)
    final=HERE/'MULTIBLOCK_METADATA_PANEL.json'
    temporary=final.with_suffix('.json.writing')
    temporary.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');temporary.replace(final)
    print(json.dumps(dict(protocol_sha256=report['protocol_sha256'],people=len(rows),pending=pending,
                          primary_events=sum(r['main_panel']['score_epoch_count'] for r in rows),
                          supplementary_events=sum(r['supplementary_epoch_count'] for r in rows))),flush=True)


if __name__=='__main__':
    main()
