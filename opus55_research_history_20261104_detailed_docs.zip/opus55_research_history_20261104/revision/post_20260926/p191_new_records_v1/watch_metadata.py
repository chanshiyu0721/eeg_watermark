"""Finish metadata-only receipts as the fixed raw acquisition completes."""
from pathlib import Path
import json
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
SUBJECTS = tuple(range(17, 29))


def main():
    while True:
        ready = [s for s in SUBJECTS
                 if (HERE/'acquisition'/f'subject{s:03d}_acquisition.json').exists()
                 and not (HERE/'metadata'/f'sess01_subj{s:02d}_EEG_MI_metadata.json').exists()]
        if ready:
            subprocess.run([sys.executable, str(HERE/'prepare_metadata.py'), '--subjects',
                            *map(str, ready)], check=True)
            subprocess.run([sys.executable, str(HERE/'multiblock_metadata.py')], check=True)
        done = all((HERE/'metadata'/f'sess01_subj{s:02d}_EEG_MI_metadata.json').exists()
                   for s in SUBJECTS)
        if done:
            subprocess.run([sys.executable, str(HERE/'prepare_metadata.py')], check=True)
            print('All12 metadata-only receipts prepared; zero EEG predictions', flush=True)
            return
        final = HERE/'ACQUISITION.json'
        if final.exists():
            result = json.loads(final.read_text(encoding='utf-8'))
            if result['status'] != 'all12_files_acquired_effects_unopened':
                print('Raw acquisition terminal incomplete; remaining metadata preserved', flush=True)
                return
        time.sleep(15)


if __name__ == '__main__':
    main()
