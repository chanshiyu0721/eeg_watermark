"""P191 fixed new-person acquisition; opaque MAT bytes, no EEG decoding.

Reuses the existing resumable downloader as a library without changing it.
Final records: confirmation 17-24, independent wrong sources 25-28.
Dedicated task-training candidates 29-36 are listed but not downloaded here.
"""
from pathlib import Path
import argparse
import concurrent.futures
import ctypes
import datetime
import hashlib
import importlib.util
import json
import os
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
BASE = HERE.parent
DATA = ROOT / 'datasets/external/openbmi_p191/session1'
LIBRARY = BASE / 'p190_source_history_v1/acquisition/acquire_openbmi.py'
TARGETS = tuple(range(17, 25))
WRONG = tuple(range(25, 29))
TRAIN = tuple(range(29, 37))
ROSTER = TARGETS + WRONG


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as file:
        for block in iter(lambda: file.read(4 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.writing')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)


def row(subject):
    name = f'sess01_subj{subject:02d}_EEG_MI.mat'
    return dict(dataset='OpenBMI', session=1, subject=subject,
                role='new_confirmation' if subject in TARGETS else 'independent_wrong_source',
                source_file_phases=['train', 'test'], attribution_phase='train',
                path=str(DATA / f's{subject}' / name),
                url='https://s3.ap-northeast-1.wasabisys.com/gigadb-datasets/'
                    f'live/pub/10.5524/100001_101000/100542/session1/s{subject}/{name}')


def history_receipt():
    # The previous full historical audit established no prior people >=5.
    # P190 then consumed exactly 5-16. Check the current P190 cache roster.
    history = BASE / 'p190_source_history_v1/SOURCE_HISTORY_AND_COHORT.md'
    protocol = BASE / 'p190_experiment_v1/PROTOCOL_BEFORE_DEVELOPMENT.md'
    cohort_dirs = sorted(p.name for p in (BASE / 'p190_experiment_v1/sources').iterdir()
                         if p.is_dir() and p.name.startswith('OpenBMI'))
    ids = [int(name.removeprefix('OpenBMI')) for name in cohort_dirs]
    assert ids == list(range(1, 17)), ids
    existing = []
    for folder in (ROOT / 'datasets/external').glob('openbmi*'):
        existing.extend(str(p) for p in folder.rglob('sess0[12]_subj*_EEG_MI.mat')
                        if 'openbmi_p191' not in str(p))
    newer = [p for p in existing
             if int(Path(p).stem.split('_')[1].removeprefix('subj')) >= 17]
    assert not newer, ('Pre-existing new-person files require history classification', newer)
    return dict(created_utc=now(), scope='inherit prior full history audit; inspect P190 finite cohort and raw-file inventory only',
                prior_history_path=str(history), prior_history_sha256=sha(history),
                p190_protocol_path=str(protocol), p190_protocol_sha256=sha(protocol),
                p190_actual_OpenBMI_source_directories=cohort_dirs,
                pre_P191_OpenBMI_raw_files=existing,
                candidate17_36_preexisting_raw_files=newer,
                used_OpenBMI_people=list(range(1, 17)),
                proposed_confirmation=list(TARGETS), proposed_wrong_sources=list(WRONG),
                reserved_task_training=list(TRAIN),
                prior_eligibility_basis='P190 full history ledger found no >=5 use; P190 subsequently added only5-16; current P191 diagnostics reuse previously observed sources',
                outcome_based_selection=False, new_signal_values_decoded=False,
                receiver_predictions=0, task_predictions=0)


def plan():
    path = HERE / 'ACQUISITION_PLAN.json'
    if path.exists():
        value = json.loads(path.read_text(encoding='utf-8'))
        assert value['sources'] == [row(s) for s in ROSTER]
        return value, sha(path)
    receipt = history_receipt()
    save(HERE / 'HISTORY_DELTA.json', receipt)
    value = dict(created_utc=now(), status='fixed_finite_acquisition_only_not_method_freeze',
                 confirmation_people=list(TARGETS), independent_wrong_people=list(WRONG),
                 dedicated_task_training_reserved_people=list(TRAIN),
                 sources=[row(s) for s in ROSTER], maximum_workers=2,
                 history_receipt_sha256=sha(HERE / 'HISTORY_DELTA.json'),
                 selection_rule='next ascending never-used people, fixed before new outcomes; no substitution',
                 source='GigaDB DOI10.5524/100542, author-released Wasabi mirror',
                 access='download entire opaque original MAT, exact file SHA and header; no EEG values, QC, watermark queries, or task predictions',
                 reason_full_mat='Both train/test phases and whole-phase anti-aliased resampling are required; a112s byte-range fetch cannot replace full task-training phase',
                 method_and_task_decode_gate='Confirmation EEG loading requires a separate P191 confirmation freeze including method, thresholds, endpoints, role list and task models',
                 source_helper_path=str(LIBRARY), source_helper_sha256=sha(LIBRARY))
    with path.open('x', encoding='utf-8') as file:
        json.dump(value, file, ensure_ascii=False, indent=2)
    return value, sha(path)


def load_library():
    spec = importlib.util.spec_from_file_location('_p191_inherited_resumable_fetch', LIBRARY)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.HERE = HERE / 'acquisition'
    module.HERE.mkdir(exist_ok=True)
    module.ROOT = ROOT
    module.DATA = DATA.resolve()
    module.progress = {s: dict(subject=s, status='queued', downloaded_bytes=0) for s in ROSTER}
    return module


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan-only', action='store_true')
    args = parser.parse_args()
    assert str(ROOT).startswith('E:'), ROOT
    for name in ('TEMP', 'TMP'):
        folder = HERE / 'temp'
        folder.mkdir(exist_ok=True)
        os.environ[name] = str(folder)
    value, digest = plan()
    print(json.dumps(dict(status='fixed_plan_saved', pid=os.getpid(), plan_sha256=digest,
                          confirmation=list(TARGETS), wrong_sources=list(WRONG))), flush=True)
    if args.plan_only:
        return
    module = load_library()
    alive = ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
    assert alive, 'Failed temporary awake request'
    run = dict(started_utc=now(), pid=os.getpid(), plan_sha256=digest,
               script_sha256=sha(Path(__file__)), status='running', temporary_system_awake_request=True,
               signal_values_decoded=False, receiver_predictions=0, task_predictions=0)
    save(HERE / 'RUN.json', run)
    complete, errors = [], []
    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            pending = {pool.submit(module.acquire, source, digest): source['subject']
                       for source in value['sources']}
            while pending:
                done, _ = concurrent.futures.wait(pending, timeout=30, return_when=concurrent.futures.FIRST_COMPLETED)
                for future in done:
                    subject = pending.pop(future)
                    try:
                        complete.append(future.result())
                    except Exception as error:
                        errors.append(dict(subject=subject, error=repr(error)))
                with module.lock:
                    records = [dict(module.progress[s]) for s in ROSTER]
                report = dict(utc=now(), pid=os.getpid(), status='running' if pending else 'terminal',
                              completed_files=len(complete), failed_files=len(errors), files=records,
                              downloaded_or_verified_bytes=sum(r['downloaded_bytes'] for r in records),
                              signal_values_decoded=False, receiver_predictions=0, task_predictions=0)
                save(HERE / 'PROGRESS.json', report)
                print(json.dumps({k: report[k] for k in ('utc', 'status', 'completed_files', 'failed_files', 'downloaded_or_verified_bytes')}), flush=True)
        complete.sort(key=lambda r: r['subject'])
        result = dict(status='all12_files_acquired_effects_unopened' if len(complete) == 12 and not errors else 'incomplete_partial_preserved',
                      completed_utc=now(), plan_sha256=digest, sources=complete, errors=errors,
                      exact_subject_roster_verified=[r['subject'] for r in complete] == list(ROSTER),
                      total_bytes=sum(r['bytes'] for r in complete), confirmation_people=list(TARGETS),
                      wrong_source_people=list(WRONG), signal_values_decoded=False, receiver_predictions=0, task_predictions=0)
        save(HERE / 'ACQUISITION.json', result)
        run.update(status=result['status'], stopped_utc=now())
        save(HERE / 'RUN.json', run)
        if errors:
            raise RuntimeError(errors)
    finally:
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)


if __name__ == '__main__':
    main()
