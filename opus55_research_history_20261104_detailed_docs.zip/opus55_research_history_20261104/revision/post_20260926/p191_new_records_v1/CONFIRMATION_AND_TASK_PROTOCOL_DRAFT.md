# P191 新人员确认与真实任务训练准备

日期：2026-11-04。当前状态：人员与原始文件获取名单已固定；接收器、阈值、主要终点的正式冻结由主实验产生。

## 一、人员与数据访问

| 人员 | 角色 | 冻结前允许的访问 |
|---|---|---|
| OpenBMI001–016 | 已观察开发、机制研究 | 继承全部既有结果；不再计作新确认 |
| OpenBMI017–024 | 新确认目标，8人 | 完整原始MAT下载、字节哈希、跳过EEG值的元数据检查 |
| OpenBMI025–028 | 独立wrong-source，4人 | 同上；不可用于训练或阈值选择 |
| OpenBMI001–012 | 专用任务模型训练，12人 | 使用已获取完整MAT，真实训练二分类CSP/LDA和EEGNet |
| OpenBMI013–016 | 任务模型干净验证，4人 | 仅用于clean开发选择；与新017–028严格分离 |

历史资格继承P190全历史记录审计，再检查P190实际源缓存为001–016，及当前原始MAT清单中没有017以上旧文件。见`HISTORY_DELTA.json`。名单按递增ID一次确定，失败保留原分母，不按信号、任务表现或归属结果换人。

取得完整session1 MI MAT，不做仅112s的在线字节裁剪：MAT压缩容器及全相位重采样需要完整源文件；同一文件同时含train/test两相位，支持独立的任务训练/评估流程。当前获取器不解码两相位EEG值。

## 二、归属确认冻结内容

保留112s参考，8通道FC3/FC4/C3/C4/Cz/CP3/CP4/Pz，160Hz，五个8s评分窗，40s评分、48s可见上下文。沿用真实16-bit EDF发行及接收写读，PRD上限0.25%全局、0.5%最大通道、1%频带，登记载体实际全局PRD匹配相对误差≤0.001。

主候选为纯平滑，直接差分、空间、混合、适用QIM-ID及普通/投影/候选FIR按冻结方法清单执行。257-tap若进入候选，必须同时报告压力感知129-tap强基线，且两者仅利用同样48s查询上下文；额外原始参考上下文和计算成本分别披露。

建议主终点：**elliptic条件0.0125独立未登记身份误接收率的逐人配对差**。在各人员内先对8个压力身份取均值，再对8人取均值。0.025误接收、登记正确归属、clean与wrong-source接受率，以及reexport/Bessel条件为约束与次要终点。每个载体身份定义和P190压力语义保持原样。

新方法成功规则应在解码017–028前从以下具体项目确定并冻结：所比较的主工作点、候选与强基线参数、所有阈值及presence/support、配置同分规则、主终点方向、coverage允许下降幅度、0.025/clean/wrong允许接受上限、统计区间及多重比较范围。当前文档不给空缺项代填结果导向数值。签发冻结文件后，确认代码只运行已冻结规则；任何后续拟合进入事后分析。

统计单位为独立目标人员n=8。身份、窗口、三种处理重复不增加n；wrong-source池按4名负源人员分组汇报，并同时展示8×4交叉格。主比较报告每人差值、均值差及预先固定的人级区间；small-n下避免把大量身份级Bernoulli重复当独立样本。

## 三、真实二分类任务模型

OpenBMI MI为右手/左手二分类。沿用四分类BCI模型不满足任务资格。本轮分别训练CSP/LDA与EEGNet；现代水印载体训练另记，两者不互相替代。

已按主实验决定固定001–012为任务模型训练人、013–016为开发验证人，017–024仅在模型冻结后用于任务测试。复用已获取的完整MAT，不再下载029–036。旧归属研究中已观察的人员用于本轮任务训练，仍与新确认人员严格分离。全部任务模型只使用干净信号训练，并对所有水印载体复用同一冻结模型、同一预处理和模型归一化。模型选择依据干净开发任务表现，不依据哪种载体保真最好。

- 共用输入：相同8物理通道、160Hz、二分类标签1=right、2=left；固定cue后0.5–2.5s epoch，与既有适配事件定义一致。先完成全相位4/25抗混叠重采样，再按cue分段，避免每个epoch独立重采样造成边界差异。
- CSP/LDA：8–30Hz固定滤波，CSP组件菜单2/4/6，Ledoit-Wolf正则，LDA为lsqr/auto shrinkage。拟合CSP及标准化时仅用训练人。
- EEGNet：复用P181作者架构port的原class AST，输入8×320，固定种子191/192/193，学习率0.001、batch32、同一100epoch轨迹的25/50/100checkpoint；选择三种子平均softmax在验证人员的等人均值BA最高工作点，logloss及更短epoch作同分规则。归一化只用训练人。保留真实训练曲线与checkpoint；推理时对所有载体冻结。
- 干净任务资格：分别报告验证人和新测试人的clean balanced accuracy、每人准确率与class support；先确认模型学到了任务，再解释水印差异。新确认clean表现如较弱，按结果解释，不能据此换人、改epoch或重训至测试改善。

## 四、联合效用与任务样本数

主联合面板使用与归属同一112s发行记录，任务epoch必须完整位于已冻结的40s评分窗中；不得用窗口外任务预测冒充同一观察预算的联合证据。元数据阶段先列出符合时窗的事件ID、标签和数量，不根据预测或信号质量挑选。

已在新确认EEG解码前另定多区块联合补充：从每位新目标的session1/train相位native sample0开始，依时间划为不重叠112s完整块，固定前min(8,完整块数)块，末尾不足112s部分丢弃。纯平滑、直接差分、适配现代载体使用相同区块、实际PRD、冻结模型及接收规则，每块仍112s参考/40s评分/48s可见。仅完整落在评分窗内的标签epoch进入任务面板。该补充以人汇总，单独报告；空间、混合与QIM的公平对照保留在第一固定块主面板。规则见`MULTIBLOCK_PROTOCOL.json`，元数据事件清单见`MULTIBLOCK_METADATA_PANEL.json`。

对每个模型与处理条件，使用相同测试epoch比较clean、纯平滑、直接差分、空间、混合及适用QIM：balanced accuracy/准确率差、预测翻转率、正确类概率变化与概率向量距离。先按每个人汇总，报告人级配对差；分别列出实际PRD、归属coverage、误接收与任务性能。概率稳定性和准确率结论各自给证据。

## 五、原始依据与可执行入口

- 数据发布：Lee et al., *EEG dataset and OpenBMI toolbox for three BCI paradigms: an investigation into BCI illiteracy*, GigaScience2019, DOI[10.1093/gigascience/giz002](https://doi.org/10.1093/gigascience/giz002)，[GigaDB100542](https://gigadb.org/dataset/100542)。原论文由作者工具仓库关联，[OpenBMI作者仓库](https://github.com/PatternRecognition/OpenBMI)。
- 现代任务模型：Lawhern et al., *EEGNet*, [原论文arXiv1611.08024](https://arxiv.org/abs/1611.08024)，DOI10.1088/1741-2552/aace8c。
- 原始文件获取：`E:\python\数字水印\.venv-rerun\Scripts\python.exe E:\python\数字水印\revision\post_20260926\p191_new_records_v1\fetch_records.py`。固定两并发，失败保留`.part`，后续同入口续传；不覆盖既有最终MAT。
- 安全元数据准备：同一Python执行本目录`prepare_metadata.py`；只跳过信号字段，检查fs/通道/形状/固定anchor。可用`--subjects 17`先处理已完成文件；全名单完成后生成`METADATA_PREPARATION.json`。
- 清单与进度：`ACQUISITION_PLAN.json`、`RUN.json`、`PROGRESS.json`；逐人字节哈希在`acquisition/subjectNNN_acquisition.json`。完整12文件终态为`ACQUISITION.json`。

所有材料保存在E盘。当前冻结前receiver_predictions=0，task_predictions=0；已下载字节不构成已完成确认实验。
