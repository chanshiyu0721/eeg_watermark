"""P191 OpenBMI17-28 metadata and gated signal adapter.

Numerical decoding/resampling bodies inherit P184 unchanged. Only the source
metadata and input-role gate are new. Caller validates scientific freeze
content and pins EXPECTED_FREEZE_SHA256 before opening any new EEG.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import numpy as np

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
P184 = BASE / 'p184_new_record_preparation_v1'
CONFIRMATION_FREEZE = HERE / 'CONFIRMATION_FREEZE.json'
EXPECTED_FREEZE_SHA256 = None
CHANNELS = ('FC3', 'FC4', 'C3', 'C4', 'Cz', 'CP3', 'CP4', 'Pz')
HZ = 160
STARTS = (8, 24, 40, 56, 72)
_VERIFIED_RAW = {}
_spec = importlib.util.spec_from_file_location('_p191_new_people_private_p184_decoder', P184 / 'openbmi_adapter.py')
_PRIOR = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_PRIOR)


def _sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as file:
        for block in iter(lambda: file.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def _subject(subject):
    if isinstance(subject, bool) or not isinstance(subject, int) or not 17 <= subject <= 28:
        raise ValueError('P191 declares exactly OpenBMI session1 people17-28')
    return subject


def _metadata_and_receipt(subject):
    subject = _subject(subject)
    metadata_path = HERE / 'metadata' / f'sess01_subj{subject:02d}_EEG_MI_metadata.json'
    receipt_path = HERE / 'acquisition' / f'subject{subject:03d}_acquisition.json'
    receipt = json.loads(receipt_path.read_text(encoding='utf-8'))
    assert receipt['status'] == 'complete' and receipt['subject'] == subject
    document = json.loads(metadata_path.read_text(encoding='utf-8'))
    raw = Path(document['path']).resolve()
    assert raw == Path(receipt['path']).resolve()
    assert raw.stat().st_size == document['bytes'] == receipt['bytes']
    assert document['acquisition_sha256'] == receipt['sha256']
    return document, metadata_path, receipt_path, receipt


def metadata(subject, phase='train'):
    """Declared metadata only; no EEG array values loaded."""
    subject = _subject(subject)
    if phase != 'train':
        raise ValueError('Primary P191 confirmation declares train phase only')
    document, metadata_path, receipt_path, receipt = _metadata_and_receipt(subject)
    matrix = next(a for a in document['arrays'] if a['path'] == '/EEG_MI_train')
    fields = {v['path'].split('/')[-1]: v for v in matrix['children']}
    names = [v['value'] for v in fields['chan']['children']]
    assert fields['fs']['value'] == [1000]
    assert [v['value'] for v in fields['class']['children']] == ['1', '2', 'right', 'left']
    assert fields['x']['values_not_loaded'] is True
    assert all(name in names for name in CHANNELS)
    result = dict(subject=subject, session=1, phase=phase, path=Path(document['path']),
                  native_shape=tuple(fields['x']['shape']), channels=CHANNELS,
                  channel_indices=[names.index(name) for name in CHANNELS],
                  cues_matlab=np.asarray(fields['t']['value'], dtype=np.int64),
                  labels=np.asarray(fields['y_dec']['value'], dtype=np.int64), native_hz=1000,
                  metadata_path=metadata_path, metadata_sha256=_sha(metadata_path),
                  raw_file_sha256=receipt['sha256'], raw_file_bytes=receipt['bytes'],
                  raw_receipt_path=receipt_path, raw_receipt_sha256=_sha(receipt_path))
    origin = max(0, int(result['cues_matlab'][0]) - 1 - 2000)
    assert origin + 112000 <= result['native_shape'][0]
    return result


def _require_decode_authorization(subject, allow_new):
    _subject(subject)
    if allow_new is not True:
        raise PermissionError('New P191 people require explicit allow_new=True after freeze')
    if not Path(CONFIRMATION_FREEZE).is_file():
        raise PermissionError('New-person EEG requires the P191 confirmation freeze')
    if not isinstance(EXPECTED_FREEZE_SHA256, str) or len(EXPECTED_FREEZE_SHA256) != 64:
        raise PermissionError('Caller must pin the expected scientific freeze SHA before decode')
    assert _sha(CONFIRMATION_FREEZE) == EXPECTED_FREEZE_SHA256, 'P191 freeze changed'
    freeze = json.loads(Path(CONFIRMATION_FREEZE).read_text(encoding='utf-8'))
    if not isinstance(freeze, dict) or not freeze:
        raise ValueError('P191 freeze is empty')


def _verify_raw(meta):
    path = meta['path'].resolve()
    stat = path.stat()
    signature = (stat.st_size, stat.st_mtime_ns, meta['raw_file_sha256'])
    if _VERIFIED_RAW.get(path) != signature:
        assert stat.st_size == meta['raw_file_bytes']
        assert _sha(path) == meta['raw_file_sha256']
        _VERIFIED_RAW[path] = signature


_PRIOR.metadata = metadata
_PRIOR.CHANNELS = CHANNELS


def load_reference(subject, allow_new=False):
    _require_decode_authorization(subject, allow_new)
    meta = metadata(subject)
    _verify_raw(meta)
    x, description = _PRIOR.load_reference(subject, phase='train', entry='first_cue_minus_2s', block_index=0)
    assert x.shape == (8, 17920) and x.dtype == np.float64 and np.isfinite(x).all()
    description.update(source_id=f'OpenBMI-ses1-sub{subject:03d}', native_source_path=str(meta['path']),
                       raw_file_sha256=meta['raw_file_sha256'], physical_channel_indices=meta['channel_indices'],
                       native_units='uV', units='V', metadata_path=str(meta['metadata_path']),
                       metadata_sha256=meta['metadata_sha256'], raw_receipt_path=str(meta['raw_receipt_path']),
                       raw_receipt_sha256=meta['raw_receipt_sha256'], adapter_sha256=_sha(Path(__file__)),
                       resampling=dict(up=4, down=25, window=['kaiser', 5.0], padtype='line',
                                       mode='whole selected8channel phase then fixed slice'),
                       confirmation_freeze_sha256=EXPECTED_FREEZE_SHA256)
    return x, description
