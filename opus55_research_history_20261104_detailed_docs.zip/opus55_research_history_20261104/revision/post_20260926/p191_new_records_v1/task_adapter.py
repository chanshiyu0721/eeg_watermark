"""Whole train/test-phase decoder for frozen within-person task evaluation.

Separate from the primary-attribution adapter so its frozen file stays intact.
No caller in this module opens new EEG automatically.
"""
from pathlib import Path
import importlib.util
import numpy as np

HERE=Path(__file__).resolve().parent
BASE=HERE.parent


def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    out=importlib.util.module_from_spec(spec);spec.loader.exec_module(out);return out


def load_phase(subject,phase,*,freeze_path,expected_freeze_sha256,allow_new=False):
    """Return8×N volts and metadata only after a caller-pinned task freeze."""
    if phase not in ('train','test'):raise ValueError(phase)
    gate=module('_p191_task_new_people_gate',HERE/'adapter.py')
    gate.CONFIRMATION_FREEZE=Path(freeze_path)
    gate.EXPECTED_FREEZE_SHA256=expected_freeze_sha256
    gate._require_decode_authorization(subject,allow_new)
    document,mp,rp,receipt=gate._metadata_and_receipt(subject)
    row=next(r for r in document['arrays'] if r['path']==f'/EEG_MI_{phase}')
    fields={r['path'].split('/')[-1]:r for r in row['children']}
    names=[r['value'] for r in fields['chan']['children']]
    assert fields['fs']['value']==[1000] and fields['x']['values_not_loaded'] is True
    meta=dict(subject=subject,session=1,phase=phase,path=Path(document['path']),native_hz=1000,
              native_shape=tuple(fields['x']['shape']),channels=gate.CHANNELS,
              channel_indices=[names.index(c) for c in gate.CHANNELS],
              cues_matlab=np.asarray(fields['t']['value'],dtype=np.int64),
              labels=np.asarray(fields['y_dec']['value'],dtype=np.int64),
              raw_file_sha256=receipt['sha256'],raw_file_bytes=receipt['bytes'])
    gate._verify_raw(meta)
    reader=module('_p191_task_new_people_decoder',BASE/'p184_new_record_preparation_v1/openbmi_adapter.py')
    reader.CHANNELS=gate.CHANNELS
    def metadata(selected_subject,selected_phase='train'):
        assert selected_subject==subject and selected_phase==phase
        return meta
    reader.metadata=metadata
    native,_=reader.load_native_microvolts(subject,phase=phase)
    volts=reader.resample_phase(native)
    assert volts.shape[0]==8 and np.isfinite(volts).all()
    return volts,meta


def epochs_from_phase(volts,meta):
    """All100 cue+.5to2.5s epochs; no signal-dependent trial selection."""
    starts=[int(np.floor((int(cue)-1)*4/25+.5))+80 for cue in meta['cues_matlab']]
    assert all(0<=s and s+320<=volts.shape[1] for s in starts)
    x=np.stack([volts[:,s:s+320] for s in starts]);y=meta['labels']-1
    assert x.shape==(100,8,320) and np.bincount(y).tolist()==[50,50]
    return x,y


def chronological_blocks(volts,meta,maximum=8):
    """Fixed full112s blocks from phase sample0; each uses the same budgets."""
    count=min(maximum,meta['native_shape'][0]//112000)
    for block in range(count):
        origin=block*17920
        value=volts[:,origin:origin+17920].copy()
        assert value.shape==(8,17920)
        yield block,value
