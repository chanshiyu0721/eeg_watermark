"""Metadata-only test-phase task panel; no new EEG or model predictions."""
from pathlib import Path
import json
import hashlib
from multiblock_metadata import panel

HERE=Path(__file__).resolve().parent


def main():
    rows=[]
    for subject in range(17,25):
        path=HERE/'metadata'/f'sess01_subj{subject:02d}_EEG_MI_metadata.json'
        document=json.loads(path.read_text(encoding='utf-8'))
        phase=next(r for r in document['arrays'] if r['path']=='/EEG_MI_test')
        fields={r['path'].split('/')[-1]:r for r in phase['children']}
        assert fields['x']['values_not_loaded'] is True
        n=min(8,fields['x']['shape'][0]//112000)
        blocks=[panel(subject,fields,b*112000,b) for b in range(n)]
        for block in blocks:
            for event in block['events']:
                event['event_id']=event['event_id'].replace('/train/','/test/')
        rows.append(dict(subject=subject,phase='test',metadata_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                         blocks=blocks,n_epochs=sum(b['score_epoch_count'] for b in blocks),
                         class_counts={str(label):sum(b['class_counts'][str(label)] for b in blocks) for label in (1,2)}))
    result=dict(status='metadata_only_testphase_task_panel_draft_not_model_freeze',
                phase='session1 test',targets=list(range(17,25)),maximum_blocks=8,
                block_rule='phase sample0; firstmin(8,complete112sblocks); fixed chronological origins',
                scoring='five8sSTARTS(8,24,40,56,72);40sscored48svisibleperblock',
                task='calibratepersonmodelusingtrainphase80/20seed191;freezethenpredicttestphase',
                attribution_primary='separatetrainphasefirstcue112sunchanged',
                people=rows,total_epochs=sum(r['n_epochs'] for r in rows),
                independent_people=8,new_EEG_decoded=False,receiver_predictions=0,task_predictions=0)
    (HERE/'MULTIBLOCK_TEST_PHASE_METADATA.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(people=8,total_epochs=result['total_epochs'],counts={r['subject']:r['n_epochs'] for r in rows})),flush=True)


if __name__=='__main__':main()
