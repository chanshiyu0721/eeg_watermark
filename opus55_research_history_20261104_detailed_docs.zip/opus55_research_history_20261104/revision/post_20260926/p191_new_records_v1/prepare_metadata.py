"""P191 metadata-only preparation; EEG matrices are byte-skipped.

Run after or during acquisition. Only sources with complete byte receipts are
inspected; this module never imports a receiver or task model.
"""
from pathlib import Path
import argparse
import datetime
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
BASE = HERE.parent
SOURCE_HELPER = BASE / 'p190_source_history_v1/acquisition/prepare_metadata.py'


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as file:
        for chunk in iter(lambda: file.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--subjects', type=int, nargs='*')
    args = parser.parse_args()
    plan = json.loads((HERE / 'ACQUISITION_PLAN.json').read_text(encoding='utf-8'))
    expected = plan['confirmation_people'] + plan['independent_wrong_people']
    subjects = args.subjects or expected
    assert set(subjects) <= set(expected)
    spec = importlib.util.spec_from_file_location('_p191_inherited_metadata_only', SOURCE_HELPER)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.HERE = HERE
    (HERE / 'metadata').mkdir(exist_ok=True)
    rows, pending = [], []
    for subject in subjects:
        receipt = HERE / 'acquisition' / f'subject{subject:03d}_acquisition.json'
        if not receipt.exists():
            pending.append(subject)
            continue
        source = json.loads(receipt.read_text(encoding='utf-8'))
        assert source['status'] == 'complete'
        rows.append(module.prepare(source))
    report = dict(status='all12_metadata_prepared_effects_unopened' if len(rows) == 12 else 'partial_metadata_prepared',
                  created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  plan_sha256=sha(HERE / 'ACQUISITION_PLAN.json'),
                  inherited_helper_sha256=sha(SOURCE_HELPER), parser_sha256=sha(module.PARSER),
                  records=rows, pending_people=pending,
                  confirmation_people=plan['confirmation_people'], wrong_source_people=plan['independent_wrong_people'],
                  qualified_train_people=[r['subject'] for r in rows if r['qualified']],
                  no_signal_values_decoded=True, receiver_predictions=0, task_predictions=0)
    target = HERE / ('METADATA_PREPARATION.json' if len(rows) == 12 else 'METADATA_PARTIAL.json')
    temporary = target.with_suffix('.json.writing')
    temporary.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temporary.replace(target)
    print(json.dumps(dict(status=report['status'], records=len(rows), pending=pending)), flush=True)


if __name__ == '__main__':
    main()
