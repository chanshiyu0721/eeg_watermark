"""Reference-library lookup after removing external EEG copy metadata."""
import hashlib
import json

import numpy as np

from revision.post_20260926.run_p7_stage import HERE, data_for, raw_scores, decision
from revision.post_20260926.p7d_orthocode import orthophase

OUT = HERE / 'p16_source_registry_v1'


def main():
    OUT.mkdir(exist_ok=True)
    target = OUT / 'results.json'
    if target.exists():
        raise RuntimeError('P16 output exists; refusing overwrite')
    rows, sources = [], {}
    for seconds in (1, 2):
        refs, ids, seeds = [], [], []
        for subject in range(37, 49):
            _, _, xv, _, names, digests = data_for(subject, seconds * 160)
            sources.update({f'S{subject:03d}/{name}': digest for name, digest in digests.items()})
            for i, (x, trial) in enumerate(zip(xv, names)):
                refs.append(x)
                ids.append(trial)
                seeds.append(20261006 + subject * 100 + i)
        refs = np.asarray(refs)
        queries, own_templates = [], []
        for x, seed in zip(refs, seeds):
            ys, es, _ = orthophase(x, seed)
            queries.append(ys[0])
            own_templates.append(es)
        queries = np.asarray(queries)
        flat_refs = refs.reshape(len(refs), -1)
        flat_queries = queries.reshape(len(queries), -1)
        squared = (np.sum(flat_refs**2, axis=1)[:, None]
                   + np.sum(flat_queries**2, axis=1)[None, :]
                   - 2 * flat_refs @ flat_queries.T)
        for i, y in enumerate(queries):
            order = np.argsort(squared[:, i])
            top, second = map(int, order[:2])
            if top == i:
                templates = own_templates[i]
            else:
                templates = orthophase(refs[top], seeds[top])[1]
            correct_recipient = decision(raw_scores(y, refs[top], templates))
            wrong_templates = orthophase(refs[second], seeds[second])[1]
            wrong_recipient = decision(raw_scores(y, refs[second], wrong_templates))
            rows.append(dict(seconds=seconds, true_trial_id=ids[i], found_trial_id=ids[top],
                             second_trial_id=ids[second], source_correct=top == i,
                             nearest_squared=float(squared[top, i]),
                             second_squared=float(squared[second, i]),
                             distance_ratio=float(squared[top, i] / squared[second, i]),
                             recipient=correct_recipient, wrong_source_recipient=wrong_recipient))
        print(f'{seconds}s registry={len(refs)} queries={len(queries)} done', flush=True)
    target.write_text(json.dumps(dict(rows=rows, sources=sources)), encoding='utf-8')
    hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
              for p in (HERE / 'run_p16_source_registry.py',
                        HERE / 'P16_SOURCE_REGISTRY_PROTOCOL_2026-10-06.md')}
    (OUT / 'manifest.json').write_text(json.dumps(hashes, indent=2), encoding='utf-8')
    print(f'queries={len(rows)}', flush=True)


if __name__ == '__main__':
    main()
