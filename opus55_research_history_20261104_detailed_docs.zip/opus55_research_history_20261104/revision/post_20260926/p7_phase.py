"""Experimental Fourier phase fingerprints; source reference is required."""
import numpy as np
from revision.post_20260926.run_p6_fingerprint_pilot import basis,q16
from revision.post_20260926.run_p6c_task import bandprd,acprd
from revision.lightweight_qc_validation.qc import output_qc

def phase_marks(x,low,high,seed,recipients=16):
    x=np.asarray(x,dtype=float)
    b=basis(x.shape[1],low,high)
    assert b.shape[1]%2==0
    z=x@b
    angles=np.random.default_rng(seed).uniform(-.005,.005,size=(recipients,b.shape[1]//2))
    outputs=[];marks=[];scales=[]
    for angle in angles:
        factor=.95
        for _ in range(100):
            a=angle*factor
            c=np.cos(a);s=np.sin(a)
            zr=z.copy()
            zr[:,0::2]=z[:,0::2]*c-z[:,1::2]*s
            zr[:,1::2]=z[:,0::2]*s+z[:,1::2]*c
            e=(zr-z)@b.T
            y=q16(x+e)
            if acprd(x,y)<=.5 and bandprd(x,y)<=1 and output_qc(x,y)['pass']:
                outputs.append(y);marks.append(e);scales.append(factor);break
            factor*=.95
        else:raise ValueError('phase fingerprint cannot meet storage budget')
    return np.asarray(outputs),np.asarray(marks),np.asarray(scales)
