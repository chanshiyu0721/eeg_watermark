# Frozen P190 confirmation numbers

Eight new target people; four shared wrong-source people. Main system: smooth, candidate-conditioned FIR, level 1. All entries are generated from the once-frozen results.

|Calibration|Correct registered|Registered rejects|Misattributed|0.025 accepted|0.0125 accepted|Clean accepted|Wrong accepted|
|---|---:|---:|---:|---:|---:|---:|---:|
|Pooled original|192/192|0|0|0/384|30/192|0/24|0/96|
|Fixed weak, pooled|192/192|0|0|0/384|30/192|0/24|0/96|
|Split max coverage|192/192|0|0|0/384|30/192|0/24|0/96|
|Fixed weak, split|192/192|0|0|0/384|30/192|0/24|0/96|
|Source stable|192/192|0|0|0/384|30/192|0/24|0/96|
|Historical freeze|192/192|0|0|0/384|41/192|0/24|0/96|

Unknown rates use evaluated denominators; every infeasible planned item is separately retained in the machine-readable table. Missing items do not count as receiver rejection. Repeated identities/processing do not increase independent n.

## Prespecified decision

Full success: **FAIL**.
- pooled_original:observed_primary_reduction_at_least_05
- pooled_original:strict_improvement_at_least_2
- fixed_weak_pooled:observed_primary_reduction_at_least_05
- fixed_weak_pooled:strict_improvement_at_least_2
- fixed_weak_pooled:Holm_IUT
- pooled_original:Holm_IUT

## Paired primary effects

|Baseline|Coverage difference, pp [95% CI]|0.025 difference, pp [95% CI]|IUT p|Holm p|
|---|---:|---:|---:|---:|
|Pooled original|0.00 [0.00, 0.00]|0.00 [0.00, 0.00]|1|1|
|Fixed weak, pooled|0.00 [0.00, 0.00]|0.00 [0.00, 0.00]|1|1|

Differences are source-stable minus baseline. Practical observed reduction >=5 pp is separate from the superiority test against zero. Collapsed empirical intervals and sign-flip sensitivity are retained in the result JSON.

## Development-only operating points

|Carrier|Calibration|Selected level|Confirmation coverage|Primary-unknown acceptance|
|---|---|---:|---:|---:|
|smooth|Pooled original|0.5|97.40%|0.00%|
|smooth|Fixed weak, pooled|0.5|97.40%|0.00%|
|smooth|Split max coverage|0.5|97.40%|0.00%|
|smooth|Fixed weak, split|0.5|97.40%|0.00%|
|smooth|Source stable|0.5|97.40%|0.00%|
|direct|Pooled original|1.0|100.00%|0.00%|
|direct|Fixed weak, pooled|1.0|100.00%|0.00%|
|direct|Split max coverage|1.0|100.00%|0.00%|
|direct|Fixed weak, split|1.0|100.00%|0.00%|
|direct|Source stable|1.0|100.00%|0.00%|
|hybrid05|Pooled original|0.75|100.00%|0.00%|
|hybrid05|Fixed weak, pooled|0.75|100.00%|0.00%|
|hybrid05|Split max coverage|0.75|100.00%|0.00%|
|hybrid05|Fixed weak, split|0.75|100.00%|0.00%|
|hybrid05|Source stable|0.75|100.00%|0.00%|
|spatial|Pooled original|0.5|97.92%|4.69%|
|spatial|Fixed weak, pooled|0.5|97.92%|4.69%|
|spatial|Split max coverage|1.0|96.35%|0.00%|
|spatial|Fixed weak, split|1.0|96.35%|0.00%|
|spatial|Source stable|1.0|96.35%|0.00%|
|qid|Pooled original|0.5|100.00%|0.00%|
|qid|Fixed weak, pooled|0.5|100.00%|0.00%|
|qid|Split max coverage|0.5|100.00%|0.00%|
|qid|Fixed weak, split|0.5|100.00%|0.00%|
|qid|Source stable|0.5|100.00%|0.00%|
