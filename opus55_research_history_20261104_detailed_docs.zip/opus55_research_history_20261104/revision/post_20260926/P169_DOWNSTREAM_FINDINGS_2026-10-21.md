# P169 下游任务效用：冻结发行数据的公平比较

## 路线决策

**优先主线：面向预处理与开放身份的任务保持型 EEG 接收方指纹——差分相位载体、参考辅助同步与身份子空间拒判。平滑差分作为优先实现，直接差分保留为核心消融，空间编码保留为强归属对照。**
本轮支持差分路线的任务输出稳定性优势，尚不支持准确率普遍提高，也没有证明平滑优于直接差分的独立核心创新。
0.25%无额外处理时，平滑相对空间的概率MAE在CSP中降低87.72%（约8.15倍），在带功率模型中降低64.13%（约2.79倍）；六人两模型均更稳定。CSP平衡准确率平滑66.865%、空间66.716%，差+0.149个百分点，受试者bootstrap区间[-0.893,+1.190]个百分点；带功率模型平滑65.079%、空间65.402%，空间的两次翻转均改善预测。Brier损失也没有一致优势，不能把稳定性写成准确率或校准性能提升。
直接和平滑差分在两个预算、六处理、两模型中均无分类翻转；空间在0.10%下1次、0.25%下18次（每预算每臂7488次重复预测）。这些计数来自78个独立片段及多个副本/处理/模型，不能当成7488个独立样本。
平滑比直接差分的无处理概率MAE降低约4.81%（CSP）和5.80%（带功率）。CSP配对差区间跨零，带功率六人方向一致但幅度小；两者硬分类完全相同。这是选择平滑作为默认实现的初步依据，不能作为独占任务优势的证据。
结构指标也需准确定位：平滑的Gram扰动小于空间，但直接差分的Gram扰动更小；不能声称平滑在所有结构指标上最优。

### 与冻结新拒判结果并列（P168，0.25%）

|路线|正确归属/1440|全部阴性误接收/13680|未登记码误接收/13320|
|---|---:|---:|---:|
|空间编码|1440|4|4|
|直接差分|1393|3|3|
|平滑差分|1403|4|4|

空间归属更高；平滑比直接多正确10次、也多1次误接收。新规则没有因本轮任务结果再调节。任务与归属观察共同支持鲁棒归属和任务保持的折中研究，不能宣称平滑全面支配其他路线。

### 论文贡献边界与下一步

建议工作题目：**面向预处理与开放身份的任务保持型 EEG 接收方指纹：差分相位与身份子空间拒判**。核心实证链为：公平预算下更稳定的任务输出、滤波失配下恢复归属、近邻未登记码约束下低误接收。若以平滑为核心创新，当前证据不足；应优先围绕联合编码/同步/拒判设计及其可验证机制展开。
子空间检测已有经典工作，不能把投影或系数方向本身当作新原理。需对照 [Scharf与Friedlander的Matched Subspace Detectors](https://www.mssc.mu.edu/~daniel/mscs6960/spring2010/ScharfFriedlanderTSP94.pdf)，补标准匹配子空间/归一化检测器、同步与拒判组件消融，并验证真实EDF量化条件下的增量贡献。
下一阶段应预先固定样本量与任务等效界限，扩大独立受试者及第二数据集/模型；保持直接差分、空间强基线，同时追加未参与开发的处理与更近身份码。当前只有六人一个数据集，不能凭本轮保证CCF-B录用，也不能把零翻转bootstrap的[0,0]视为总体等效证明。

## 评价设置

训练为 S055–S060 各自 R04/R08，测试为既有 R12 前112秒。左右手运动想象；沿用 P164 两分类器，无调参。
复用 P168 八登记码发行文件、0.10%/0.25%预算及新拒判结果。滤波后任务评价在内存进行，未额外量化。各臂、干净对照同等参考辅助自动同步。
独立测试片段 78，6名受试者；八码副本不是独立样本。完整性校验 319 个文件通过，逐条预测重算通过。

## 主要结果：无额外处理

|预算%|模型|路线|干净BA%|发行BA%|变化pp [受试者bootstrap 95%区间]|翻转/副本预测|概率MAE|Brier变化|
|---:|---|---|---:|---:|---|---:|---:|---:|
|0.10|csp|spatial|66.865|66.716|-0.149 [-0.446, +0.000]|1/624|0.00132107|+0.00000601|
|0.10|csp|differential_rect|66.865|66.865|+0.000 [+0.000, +0.000]|0/624|0.00022192|+0.00001464|
|0.10|csp|differential_taper|66.865|66.865|+0.000 [+0.000, +0.000]|0/624|0.00020443|+0.00000818|
|0.10|power|spatial|65.079|65.079|+0.000 [+0.000, +0.000]|0/624|0.00043707|+0.00000583|
|0.10|power|differential_rect|65.079|65.079|+0.000 [+0.000, +0.000]|0/624|0.00018780|+0.00001559|
|0.10|power|differential_taper|65.079|65.079|+0.000 [+0.000, +0.000]|0/624|0.00017613|+0.00001583|
|0.25|csp|spatial|66.865|66.716|-0.149 [-1.190, +0.893]|5/624|0.00305113|+0.00000853|
|0.25|csp|differential_rect|66.865|66.865|+0.000 [+0.000, +0.000]|0/624|0.00039343|+0.00001616|
|0.25|csp|differential_taper|66.865|66.865|+0.000 [+0.000, +0.000]|0/624|0.00037453|+0.00001812|
|0.25|power|spatial|65.079|65.402|+0.322 [+0.000, +0.670]|2/624|0.00097242|+0.00000259|
|0.25|power|differential_rect|65.079|65.079|+0.000 [+0.000, +0.000]|0/624|0.00037030|+0.00001977|
|0.25|power|differential_taper|65.079|65.079|+0.000 [+0.000, +0.000]|0/624|0.00034882|+0.00001781|

## 六处理完整结果

BA变化均相对于同处理干净对照，不代表相对于原始干净数据的总损失。区间仅为6人探索性描述，不是等效性证明。

|预算%|处理|模型|路线|干净BA%|发行BA%|翻转|概率MAE|
|---:|---|---|---|---:|---:|---:|---:|
|0.10|reexport|csp|spatial|66.865|66.716|1|0.00132107|
|0.10|reexport|csp|differential_rect|66.865|66.865|0|0.00022192|
|0.10|reexport|csp|differential_taper|66.865|66.865|0|0.00020443|
|0.10|reexport|power|spatial|65.079|65.079|0|0.00043707|
|0.10|reexport|power|differential_rect|65.079|65.079|0|0.00018780|
|0.10|reexport|power|differential_taper|65.079|65.079|0|0.00017613|
|0.10|car|csp|spatial|68.849|68.849|0|0.00123095|
|0.10|car|csp|differential_rect|68.849|68.849|0|0.00014300|
|0.10|car|csp|differential_taper|68.849|68.849|0|0.00013155|
|0.10|car|power|spatial|60.913|60.913|0|0.00101284|
|0.10|car|power|differential_rect|60.913|60.913|0|0.00018287|
|0.10|car|power|differential_taper|60.913|60.913|0|0.00016185|
|0.10|butter_zero_car|csp|spatial|68.849|68.849|0|0.00123198|
|0.10|butter_zero_car|csp|differential_rect|68.849|68.849|0|0.00013806|
|0.10|butter_zero_car|csp|differential_taper|68.849|68.849|0|0.00012652|
|0.10|butter_zero_car|power|spatial|60.913|60.913|0|0.00101799|
|0.10|butter_zero_car|power|differential_rect|60.913|60.913|0|0.00018038|
|0.10|butter_zero_car|power|differential_taper|60.913|60.913|0|0.00015560|
|0.10|elliptic_zero_car|csp|spatial|63.095|63.095|0|0.00110022|
|0.10|elliptic_zero_car|csp|differential_rect|63.095|63.095|0|0.00011690|
|0.10|elliptic_zero_car|csp|differential_taper|63.095|63.095|0|0.00011069|
|0.10|elliptic_zero_car|power|spatial|57.540|57.540|0|0.00097522|
|0.10|elliptic_zero_car|power|differential_rect|57.540|57.540|0|0.00017144|
|0.10|elliptic_zero_car|power|differential_taper|57.540|57.540|0|0.00014730|
|0.10|elliptic_causal_car|csp|spatial|70.238|70.238|0|0.00117142|
|0.10|elliptic_causal_car|csp|differential_rect|70.238|70.238|0|0.00012599|
|0.10|elliptic_causal_car|csp|differential_taper|70.238|70.238|0|0.00011818|
|0.10|elliptic_causal_car|power|spatial|59.722|59.722|0|0.00100400|
|0.10|elliptic_causal_car|power|differential_rect|59.722|59.722|0|0.00018308|
|0.10|elliptic_causal_car|power|differential_taper|59.722|59.722|0|0.00015901|
|0.10|fir_causal_car|csp|spatial|68.849|68.849|0|0.00123658|
|0.10|fir_causal_car|csp|differential_rect|68.849|68.849|0|0.00013803|
|0.10|fir_causal_car|csp|differential_taper|68.849|68.849|0|0.00012625|
|0.10|fir_causal_car|power|spatial|60.913|60.913|0|0.00101779|
|0.10|fir_causal_car|power|differential_rect|60.913|60.913|0|0.00017950|
|0.10|fir_causal_car|power|differential_taper|60.913|60.913|0|0.00015476|
|0.25|reexport|csp|spatial|66.865|66.716|5|0.00305113|
|0.25|reexport|csp|differential_rect|66.865|66.865|0|0.00039343|
|0.25|reexport|csp|differential_taper|66.865|66.865|0|0.00037453|
|0.25|reexport|power|spatial|65.079|65.402|2|0.00097242|
|0.25|reexport|power|differential_rect|65.079|65.079|0|0.00037030|
|0.25|reexport|power|differential_taper|65.079|65.079|0|0.00034882|
|0.25|car|csp|spatial|68.849|68.502|2|0.00287724|
|0.25|car|csp|differential_rect|68.849|68.849|0|0.00027739|
|0.25|car|csp|differential_taper|68.849|68.849|0|0.00026254|
|0.25|car|power|spatial|60.913|60.913|0|0.00228114|
|0.25|car|power|differential_rect|60.913|60.913|0|0.00034773|
|0.25|car|power|differential_taper|60.913|60.913|0|0.00031523|
|0.25|butter_zero_car|csp|spatial|68.849|69.196|2|0.00288043|
|0.25|butter_zero_car|csp|differential_rect|68.849|68.849|0|0.00026685|
|0.25|butter_zero_car|csp|differential_taper|68.849|68.849|0|0.00025278|
|0.25|butter_zero_car|power|spatial|60.913|60.913|0|0.00229215|
|0.25|butter_zero_car|power|differential_rect|60.913|60.913|0|0.00034096|
|0.25|butter_zero_car|power|differential_taper|60.913|60.913|0|0.00030138|
|0.25|elliptic_zero_car|csp|spatial|63.095|63.095|0|0.00258517|
|0.25|elliptic_zero_car|csp|differential_rect|63.095|63.095|0|0.00023653|
|0.25|elliptic_zero_car|csp|differential_taper|63.095|63.095|0|0.00022535|
|0.25|elliptic_zero_car|power|spatial|57.540|57.837|2|0.00220456|
|0.25|elliptic_zero_car|power|differential_rect|57.540|57.540|0|0.00032876|
|0.25|elliptic_zero_car|power|differential_taper|57.540|57.540|0|0.00028926|
|0.25|elliptic_causal_car|csp|spatial|70.238|70.585|2|0.00274754|
|0.25|elliptic_causal_car|csp|differential_rect|70.238|70.238|0|0.00025073|
|0.25|elliptic_causal_car|csp|differential_taper|70.238|70.238|0|0.00023808|
|0.25|elliptic_causal_car|power|spatial|59.722|59.573|1|0.00226352|
|0.25|elliptic_causal_car|power|differential_rect|59.722|59.722|0|0.00034738|
|0.25|elliptic_causal_car|power|differential_taper|59.722|59.722|0|0.00030867|
|0.25|fir_causal_car|csp|spatial|68.849|68.502|2|0.00289095|
|0.25|fir_causal_car|csp|differential_rect|68.849|68.849|0|0.00026735|
|0.25|fir_causal_car|csp|differential_taper|68.849|68.849|0|0.00025208|
|0.25|fir_causal_car|power|spatial|60.913|60.913|0|0.00229198|
|0.25|fir_causal_car|power|differential_rect|60.913|60.913|0|0.00033927|
|0.25|fir_causal_car|power|differential_taper|60.913|60.913|0|0.00030000|

## 统计与复现

analysis.json 保存逐受试者指标与平滑差分减去另外两臂的配对差及5000次受试者bootstrap区间（种子169）。S055.json 至 S060.json 保存标签、片段起点、基线/发行概率、自动同步延迟；frozen_before_predictions.json 保存评价前哈希。
任务片段和归属窗口不同，不计算混合分母的联合成功率，不删除拒判副本。概率变化小只能支持预测稳定性；准确率优势需要真实标签下的性能差支持。
本轮六受试者不足以证明跨人群、跨分类器或跨任务普适优势。两模型结果都报告。

数据：[PhysioNet EEG Motor Movement/Imagery](https://www.physionet.org/content/eegmmidb/1.0.0/)。
