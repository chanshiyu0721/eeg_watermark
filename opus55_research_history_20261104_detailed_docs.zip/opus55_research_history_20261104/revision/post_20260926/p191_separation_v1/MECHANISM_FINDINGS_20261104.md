# P191 first mechanism results

## Finding

The elliptic .0125 failure is principally consistent with a response-model residual floor masking identity deviations in the compatibility ratio. The first controlled records show little effect from removing alignment changes or candidate-specific response fitting. A known true operator and an adequately supported FIR expose substantially larger identity separation.

## Evidence completed

1. **Saved-score strong control, all observed P190 people.** A weak-ridge compatibility threshold fitted to D_fit with .0125 negatives is 0.9987280466974421. It gives 95/96 correct and zero pressure acceptance on fit, 94/96 and zero on select, and 191/192 correct with 0/192 pressure and 0/384 primary acceptance on observed targets005-012. This is the required pressure-aware scalar baseline. The original P190 threshold and pressure-exclusion policy remain historical.
2. **Factor isolation, observed005/012 elliptic.** The original branch gives16/16 registered and7/16 pressure accepts. Replacing only the common lag with paired-clean estimates leaves these counts unchanged. Freezing the response to the ordinary paired-clean estimate also leaves7/16. The true forward-operator branch gives16/16 registered,0/16 pressure and0/32 primary acceptance. Registered predictions retain query EDF quantization noise: the oracle templates are not quantized a second time. Every query byte hash and reconstructed blind score matches P190 (maximum score error0.0).
3. **FIR capacity, same EDFs and scored samples.** Extending129 taps to257 gives16/16 registered,0/16 pressure and0/32 primary at the old threshold.513 adds no correct decisions. For005, mean registered held RSS falls from0.129910675 to0.000807806, about160.8-fold. Mean pressure fixed-minus-unrestricted identity residual is0.000399325 versus0.000401587: the identity mismatch energy remains while response background shrinks. The pressure-score upper bound falls from0.99774469 to0.92966927.
4. **Actual waveform distinction, all8 observed targets.** Existing received EDF queries were reconstructed with792/792 exact original byte hashes. No .0125 or .025 unknown/parent pair has identical scored samples. Elliptic pressure differences have median RMS0.903075 query LSB and median changed-sample fraction0.471318. Code angle and post-EDF waveform distance are distinct quantities.

## Mechanistic reading

For a fixed response and enrollment span T, the fixed-identity residual decomposes into the unrestricted residual plus the projected identity mismatch. Writing R for the fixed residual, U for the unrestricted residual and D=R-U, compatibility is

    C = U/R = 1 - D/R.

An increase in response error orthogonal to the identity span raises the denominator/background without proportionally increasing D. The resulting score approaches one for both registered and close independent identities. The finite-menu candidate-conditioned implementation also minimizes U across its conditional fits; its exact stored scores and conditional quantities are retained in the implementation rather than replacing them with a common-response theorem.

The joint evidence distinguishes three explanations: an alignment-only correction does not explain the selected failures; candidate-specific fitting is not their dominant cause; physically distinct near identities remain recoverably separated when the processing model is sufficiently accurate. The broader role of nuisance-tangent overlap remains testable through the effective identity metric.

## Two active development routes

**Response adequacy.**257-tap FIR is the immediate strong capacity baseline and candidate for further testing. It uses extra owner-reference context, while the query retains the original48 visible seconds. Development now extends to the original fit/select people, all three conditions, controls and both ridge values. The fixed pressure-aware129-tap procedure remains a mandatory comparator.513 is not expanded further after saturation in the paired pilot.

**Identity-energy readout.** A first proxy normalizes D by the optimized clean-null gain R0-R. Its fixed D_fit-only threshold gives full fit/select coverage and rejection, but on the observed transfer panel it accepts47/192 pressure and1/384 primary identities, worse than the pressure-aware compatibility control. One specific explanation is that optimized H0 gain is an unreliable proxy for actual template energy. The next and final local check uses conditional U and G_ii directly; it adds no response fits. If it does not transfer, this readout is dropped in favor of the response-adequacy route.

The speculative ARX/IIR route is deferred because the capacity experiment already tests the supported explanation with a simple strong control. These are development results, not a new untouched confirmation.

## Source artifacts

- `runs/pilot01/SUMMARY.json`: controlled alignment/response/true-operator diagnostic.
- `../p191_fir_capacity_v1/CAPACITY_REPORT.md` and `runs/pilot01/SUMMARY.json`: capacity and computation.
- `../p191_saved_evidence_v1/PRESSURE_AWARE_FIXED_CONTROL.json`: fit-only simple threshold control.
- `../p191_saved_evidence_v1/ACTUAL_EDF_DISTANCES.json`: decoded-sample geometry and query lineage.
- `energy_score_pilot/RESULT.json`: failed gain-normalized readout proxy, retained as implemented.
- `../p191_identity_v1/IDENTITY_POLICY_AND_IDENTIFIABILITY.md`: separate independent-code and damaged-copy semantics.
