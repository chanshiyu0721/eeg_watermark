# P191: identity spacing and nuisance-response separation

Started 2026-11-04. P190 final results, original freezes and the overview revision are inherited. All P190 participants and queries are observed development material for P191.

The initial directly relevant read located actual source/issued EDFs, P190 residual/identity statistics and the candidate-conditioned FIR implementation. P190 saved scores do not retain response kernels. No passed signal/EDF experiment is rerun as a general audit.

The first controlled diagnostic contrasts OpenBMI005 (seven elliptic pressure accepts) and OpenBMI012 (none), using the identical level-1 smooth issued EDFs and query ranges. New query bytes and the reconstructed blind candidate score must match the saved P190 values. Four controlled modes isolate a clean-derived lag, a response frozen from the paired transformed-clean query, their combination, and the true forward operator. Truth information is confined to diagnostics. Raw kernels and per-window response displacement are saved for the elliptic registered/pressure queries.

The first saved-score result also establishes a strong control requirement: this observed P190 panel has a scalar compatibility gap between registered and .0125 identities. Pressure-aware threshold calibration must be included before attributing an improvement to a new estimator. The independent saved-evidence output records that control using fit-only data; no threshold is selected from the old confirmation panel.

New method development is limited to at most two candidate routes after these diagnostics. Modern-carrier training, identity semantics and literature comparison have separate output directories. Fresh confirmation is deferred until the full identity policy, method/threshold choices, source roster and endpoints are frozen.
