"""Fixed, fit-only pilot of identity mismatch energy on observed P190 scores."""
from pathlib import Path
import gzip,json
import numpy as np

HERE=Path(__file__).resolve().parent
OLD=HERE.parent/'p190_experiment_v1'
ROLES=dict(fit=('OpenBMI001','OpenBMI002','A02T','A03E'),
           select=('OpenBMI003','OpenBMI004','A05E','A07E'),
           observed_transfer=tuple(f'OpenBMI{i:03d}' for i in range(5,13)))


def read(role):
    rr=[]
    for person in ROLES[role]:
        folder='confirm' if role=='observed_transfer' else role
        z=json.loads(gzip.decompress((OLD/'raw'/folder/person/'level100/smooth.json.gz').read_bytes()))
        for row in z['rows']:
            v=row['receiver']['methods']['candidate_FIR_GLRT']['by_ridge']['1e-06']
            top=v['top'];R=v['candidate_RSS'][top];U=v['unrestricted_RSS'];R0=v['clean_RSS']
            energy=max(0.,R-U);gain=max(R0-R,1e-30)
            scores=dict(compatibility=v['compatibility'],identity_energy=-energy/gain,
                        beta_distance=-float(np.sum((np.asarray(v['beta'])-np.eye(8)[top])**2)))
            rr.append(dict(source=person,role=role,condition=row['condition'],kind=row['kind'],
                pressure=row['pressure'],angle=row.get('angle'),identity=row.get('identity'),
                top=top,eligible=v['eligible'] and v['support']>=1 and v['presence']>=.25,
                scores=scores,raw_identity_energy=energy,estimated_fingerprint_gain=gain))
    return rr


def summary(rows,name,t):
    out={}
    for family,pred in (('registered',lambda r:r['kind']=='enrolled'),
        ('pressure',lambda r:r['pressure']),('near025',lambda r:r['angle']==.025),
        ('clean_wrong',lambda r:r['kind'] in ('clean','wrong_source'))):
        zz=[r for r in rows if pred(r)]
        accept=lambda r:r['eligible'] and r['scores'][name]>=t
        out[family]=dict(n=len(zz),accepted=sum(accept(r) for r in zz),
            correct=sum(accept(r) and r['top']==r['identity'] for r in zz) if family=='registered' else None,
            minimum_eligible_score=min((r['scores'][name] for r in zz if r['eligible']),default=None),
            maximum_eligible_score=max((r['scores'][name] for r in zz if r['eligible']),default=None))
    return out


def main():
    rows={role:read(role) for role in ROLES}
    results={}
    for name in ('compatibility','identity_energy','beta_distance'):
        negative=[r['scores'][name] for r in rows['fit'] if r['kind']!='enrolled' and r['eligible']]
        t=float(np.nextafter(max(negative),np.inf))
        results[name]=dict(fit_only_threshold=t,panels={role:summary(rr,name,t) for role,rr in rows.items()})
    result=dict(status='observed_development_energy_readout_pilot_complete',
        hypothesis='Normalize identity mismatch energy by estimated fingerprint gain rather than unexplained response residual.',
        identity_energy_definition='-(R_top - R_U)/(R0 - R_top), with nonnegative numerator and presence >= .25',
        fixed_config=dict(ridge=1e-6,support=1,presence=.25),results=results,
        threshold_fit='P190 D_fit only, including pressure and other negatives',
        observed_transfer_is_not_new_confirmation=True,new_signal_scoring=False)
    out=HERE/'energy_score_pilot';out.mkdir(exist_ok=True)
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    lines=['# Identity-energy readout development pilot','',
        'Fixed weak-ridge response evidence and presence gate; each scalar threshold uses D_fit pressure/near/control negatives only.', '',
        '|Head|Panel|Correct registered|.0125 accepted|.025 accepted|Clean/wrong accepted|',
        '|---|---|---:|---:|---:|---:|']
    for name,v in results.items():
        for role,s in v['panels'].items():
            cells=[f"{s[k]['correct' if k=='registered' else 'accepted']}/{s[k]['n']}" for k in ('registered','pressure','near025','clean_wrong')]
            lines.append('|'+name+'|'+role+'|'+'|'.join(cells)+'|')
    lines+=['','All panels are observed development material. This is one fixed hypothesis and two named simple controls, not an independent confirmation.']
    (out/'RESULT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print('\n'.join(lines))


if __name__=='__main__':main()
