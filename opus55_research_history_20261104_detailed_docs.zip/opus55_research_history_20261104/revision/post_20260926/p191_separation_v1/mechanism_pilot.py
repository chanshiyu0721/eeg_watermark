"""Factor-isolating diagnostics on observed P190 EDFs; no new confirmation.

Only diagnostic branches see transformed clean queries or true operators.
P190 scoring/serialization primitives are imported without its collector.
"""
from pathlib import Path
import os,sys
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
P190=HERE.parent/'p190_experiment_v1'
sys.dont_write_bytecode=True
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[key]='1'
for key in ('TEMP','TMP','TMPDIR','MPLCONFIGDIR','NUMBA_CACHE_DIR','TORCH_HOME','_MNE_FAKE_HOME_DIR'):
    folder=HERE/'cache'/key.lower();folder.mkdir(parents=True,exist_ok=True);os.environ[key]=str(folder)
sys.path[:0]=[str(ROOT),str(HERE.parent/'p188_glrt_v1')]
import argparse,gzip,hashlib,json,time
import numpy as np
from threadpoolctl import threadpool_limits
import receiver_api as api
from revision.post_20260926 import run_p181_data as edf
from revision.post_20260926 import p181_common as common

RHO=1e-6
THRESHOLD=.9957274054693162
PRESSURE_THRESHOLD=.9987280466974421
CHANNELS=('FC3','FC4','C3','C4','Cz','CP3','CP4','Pz')
MODES=('blind_candidate','clean_lag','clean_response','clean_lag_and_response','known_operator')


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load(path):
    raw=Path(path).read_bytes()
    if str(path).endswith('.gz'):raw=gzip.decompress(raw)
    return json.loads(raw)
def read_edf(path):return edf.parse_edf(gzip.decompress(Path(path).read_bytes()),CHANNELS)[0]
def save(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():raise FileExistsError(path)
    tmp=path.with_suffix(path.suffix+'.partial')
    raw=(json.dumps(obj,ensure_ascii=False,allow_nan=False,separators=(',',':'))+'\n').encode()
    if str(path).endswith('.gz'):raw=gzip.compress(raw,compresslevel=5,mtime=0)
    tmp.write_bytes(raw);tmp.replace(path)


def summarize_stats(stats,clean_rss,folds):
    """Exact weak-ridge candidate-conditional P190 score conventions."""
    pooled=[tuple(sum(row[i][j] for row in stats) for j in range(3)) for i in range(8)]
    rss=[];full=[];gains=[];betas=[]
    for i,(G,b,d) in enumerate(pooled):
        beta=np.linalg.lstsq(G,b,rcond=1e-7)[0]
        rss.append(max(0.,float(d+G[i,i]-2*b[i])))
        full.append(max(0.,float(d-b@beta)))
        gains.append(float(2*b[i]-G[i,i]));betas.append(beta)
    order=np.argsort(rss,kind='stable');top=int(order[0]);R=rss[top];R2=rss[order[1]]
    RU=min(full)
    scale=max(sum(t[2] for t in pooled),sum(np.trace(t[0]) for t in pooled),1e-30)
    floor=64*np.finfo(float).eps*scale
    compatibility=1. if R<=floor else RU/R
    presence=1.-R/max(sum(clean_rss),floor)
    gap=(R2-R)/max(R2,floor)
    windowrss=[]
    for row in stats:
        windowrss.append([max(0.,float(d+G[i,i]-2*b[i])) for i,(G,b,d) in enumerate(row)])
    support=int((np.argmin(windowrss,axis=1)==top).sum())
    eligible=bool(gains[top]>0 and np.median([f['peak'] for f in folds])>=0)
    beta=betas[top]
    return dict(top=top,compatibility=float(np.clip(compatibility,0,1)),
        relative_gap=float(np.clip(gap,0,1)),presence=float(np.clip(presence,0,1)),
        support=support,eligible=eligible,candidate_RSS=rss,unrestricted_RSS=RU,
        clean_RSS=float(sum(clean_rss)),beta=beta.tolist(),beta_distance_to_top=float(np.linalg.norm(beta-np.eye(8)[top])),
        fold_RSS=windowrss,folds=folds)


class DiagnosticReceiver(api.MatchedFIRReceivers):
    def __init__(self,x,book,clean_query):
        super().__init__(x,book)
        self.clean_query=clean_query
        _,self.clean_lags,self.clean_peaks,self.clean_errors=api.old.blind_match(self.receiver.refs,clean_query)
        self.clean_buffers=[api.p.filt(api.p.center(clean_query[:,st*160-128:(st+8)*160+128])) for st in api.p.STARTS]

    def controlled(self,y):
        _,lags,peaks,errors=api.old.blind_match(self.receiver.refs,y)
        chosen=np.asarray([np.argmin(np.sum(errors[:,[j for j in range(5) if j!=w]],axis=1)) for w in range(5)])
        buffers=[api.p.filt(api.p.center(y[:,st*160-128:(st+8)*160+128])) for st in api.p.STARTS]
        prep={};fits={};results={};saved_kernels={}
        for mode in MODES[:-1]:
            freeze_response=mode in ('clean_response','clean_lag_and_response')
            fix_lag=mode in ('clean_lag','clean_lag_and_response')
            stats=[];nulls=[];folds=[];biases=[];mode_kernels=[]
            for w in range(5):
                ids=[j for j in range(5) if j!=w];k=int(chosen[w])
                delay=api.recv.lower_median((self.clean_lags if fix_lag else lags)[k,ids]);key=(k,delay)
                if key not in prep:
                    data,cw=self.design(k)
                    ys=[buf[:,128+delay:1408+delay] for buf in buffers]
                    vs,bx,bt,cb=self._prepare(data,ys,cw)
                    clean_ys=[buf[:,128+delay:1408+delay] for buf in self.clean_buffers]
                    clean_bx=[z['X'].T@(api.old.vector(yy-z['x'])/data['scale'])
                              for z,yy in zip(data['windows'],clean_ys)]
                    prep[key]=(data,cw,ys,bx,cb,clean_bx)
                data,cw,ys,bx,cb,clean_bx=prep[key];z=data['windows'][w]
                fit_key=(k,delay,w)
                if fit_key not in fits:
                    BB=sum(bx[j] for j in ids)
                    ho=z['inverse'][RHO,False]@BB
                    hc=np.einsum('nij,nj->ni',cw[w]['inverse'][RHO],sum(cb[j] for j in ids))
                    hclean=z['inverse'][RHO,False]@sum(clean_bx[j] for j in ids)
                    null=self._stats(z,data,ys[w],ho)[2]
                    fits[fit_key]=(hc,hclean,null)
                hc,hclean,null=fits[fit_key]
                kernels=np.repeat(hclean[None],8,axis=0) if freeze_response else hc
                if freeze_response:
                    one=self._stats(z,data,ys[w],hclean);entries=[one]*8
                else:entries=[self._stats(z,data,ys[w],h) for h in kernels]
                dd=[]
                for h in kernels:
                    displacement=z['X']@(h-hclean)
                    dd.append(dict(kernel_delta_l2=float(np.linalg.norm(h-hclean)),
                        clean_prediction_delta=float(np.linalg.norm(displacement)/max(np.linalg.norm(api.old.vector(z['x'])/data['scale']),1e-30)),
                        identity_projection=np.linalg.lstsq(z['T'],displacement,rcond=1e-8)[0].tolist()))
                biases.append(dd);stats.append(entries);nulls.append(null)
                folds.append(dict(model=k,delay=delay,baseline_delay=api.recv.lower_median(lags[k,ids]),
                                  clean_delay=api.recv.lower_median(self.clean_lags[k,ids]),peak=float(peaks[k,w])))
                mode_kernels.append(kernels)
            value=summarize_stats(stats,nulls,folds);top=value['top']
            value['response_diagnostics']={metric:float(np.mean([d[top][metric] for d in biases]))
                for metric in ('kernel_delta_l2','clean_prediction_delta')}
            value['response_diagnostics']['identity_projection']=np.mean([d[top]['identity_projection'] for d in biases],axis=0).tolist()
            value['nominal_response_fit_count']=5 if freeze_response else 40
            results[mode]=value;saved_kernels[mode]=np.asarray(mode_kernels)
        return results,saved_kernels


def oracle_stats(query,transformed_clean,transformed_book):
    stats=[];nulls=[];folds=[]
    for st in api.p.STARTS:
        sl=slice(st*160-128,(st+8)*160+128)
        x=api.p.filt(api.p.center(transformed_clean[:,sl]))[:,128:1408]
        yy=api.p.filt(api.p.center(query[:,sl]))[:,128:1408]
        templates=np.asarray([api.p.filt(api.p.center(b[:,sl]))[:,128:1408] for b in transformed_book])
        T=np.column_stack([api.old.vector(b-x) for b in templates])
        v=api.old.vector(yy-x)
        scale=max(float(np.sum(T*T)),1e-40)
        G=T.T@T/scale;b=T.T@v/scale;d=float(v@v)/scale
        stats.append([(G,b,d)]*8);nulls.append(d)
        folds.append(dict(model='known_true_forward_operator',delay=0,peak=1.))
    z=summarize_stats(stats,nulls,folds);z['nominal_response_fit_count']=0
    return z


def decision(value,threshold=THRESHOLD):
    return value['top'] if value['eligible'] and value['support']>=1 and value['presence']>=.25 and value['compatibility']>=threshold else -1


def run(source,arm,condition,label):
    dest=HERE/'runs'/label/f'{source}_{arm}_{condition}.json.gz'
    if dest.exists():return load(dest)
    source_dir=P190/'sources'/source
    x=read_edf(source_dir/'clean.edf.gz')
    folder=P190/'issuance'/source/'level100'
    issue=load(folder/'issuance_summary.json');meta=issue['metadata'][arm]
    copies=[read_edf(folder/f'{arm}_r{i}_issued.edf.gz') for i in range(len(meta))]
    wrong_names=tuple(f'OpenBMI{i:03d}' for i in range(13,17))
    wrongs=[read_edf(P190/'sources'/name/'clean.edf.gz') for name in wrong_names]
    raw=load(P190/'raw'/'confirm'/source/'level100'/f'{arm}.json.gz')
    limits=tuple(np.asarray(v) for v in raw['query_limits_uv'][condition])
    values=copies+[x]+wrongs
    infos=meta+[dict(kind='clean',identity=None,parent=None,pressure=False)]+[
        dict(kind='wrong_source',identity=None,parent=None,pressure=False,negative_source=n) for n in wrong_names]
    receipts=[];queries=[];transformed=[]
    for index,value in enumerate(values):
        actual=common.transform(value,condition);transformed.append(actual)
        query,_=edf.edf_roundtrip(actual,limits,f'{source}_level100_{arm}_q{index}_{condition}.edf',
            dest.parent,receipts,False,CHANNELS)
        previous=next(r for r in raw['rows'] if r['query_index']==index and r['condition']==condition)
        assert previous['query_raw_sha256']==receipts[-1]['raw_sha256'],('P190 query bytes differ',source,index,condition)
        queries.append(query)
    receiver=DiagnosticReceiver(x,np.asarray(copies[:8]),queries[len(meta)])
    rows=[];parity_error=0.;started=time.monotonic()
    for index,(query,info) in enumerate(zip(queries,infos)):
        tick=time.monotonic();out,kernels=receiver.controlled(query)
        out['known_operator']=oracle_stats(query,transformed[len(meta)],transformed[:8])
        oldrow=next(r for r in raw['rows'] if r['query_index']==index and r['condition']==condition)
        oldscore=oldrow['receiver']['methods']['candidate_FIR_GLRT']['by_ridge']['1e-06']
        for key in ('compatibility','presence','relative_gap'):
            error=abs(out['blind_candidate'][key]-oldscore[key]);parity_error=max(parity_error,error)
            assert error<1e-10,('Baseline score parity failed',source,condition,index,key,error)
        assert out['blind_candidate']['top']==oldscore['top']
        for value in out.values():
            value['legacy_threshold_decision']=decision(value)
            value['pressure_control_threshold_decision']=decision(value,PRESSURE_THRESHOLD)
        if condition=='elliptic_new_causal' and (info['kind']=='enrolled' or info.get('pressure',False)):
            kd=dest.parent/'kernels';kd.mkdir(parents=True,exist_ok=True)
            np.savez_compressed(kd/f'{source}_{arm}_{index}.npz',**kernels)
        rows.append(dict(source=source,arm=arm,condition=condition,query_index=index,
                         metadata=info,features=out,seconds=time.monotonic()-tick))
        if index%8==7:print(json.dumps(dict(event='diagnostic_progress',source=source,condition=condition,queries=index+1)),flush=True)
    result=dict(status='complete',role='observed_P190_mechanism_development',source=source,arm=arm,condition=condition,
        baseline_score_max_abs_error=parity_error,all_query_EDF_hashes_match_P190=True,rows=rows,
        code_sha256=sha(__file__),inputs=dict(raw_scores_sha256=sha(P190/'raw'/'confirm'/source/'level100'/f'{arm}.json.gz'),
        issuance_sha256=sha(folder/'issuance_summary.json')),seconds=time.monotonic()-started,
        diagnostic_only_information=dict(clean_lag='paired transformed-clean query lags at unchanged selected coarse models',
            clean_response='ordinary FIR fitted to paired transformed-clean query, shared across identity candidates',
            known_operator='true linear processing of archived actual issued references, no second prediction quantization'),
        threshold_interpretation='Legacy and pressure-aware thresholds replayed descriptively; diagnostic branches are not calibrated deployment methods')
    save(dest,result);return result


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--sources',default='OpenBMI005,OpenBMI012')
    parser.add_argument('--conditions',default='elliptic_new_causal')
    parser.add_argument('--arms',default='smooth');parser.add_argument('--label',default='pilot01')
    args=parser.parse_args();files=[]
    with threadpool_limits(limits=1):
        for source in args.sources.split(','):
            for arm in args.arms.split(','):
                for condition in args.conditions.split(','):
                    result=run(source,arm,condition,args.label)
                    summary={}
                    for mode in MODES:
                        zz={}
                        for family,pred in (('registered',lambda m:m['kind']=='enrolled'),
                            ('pressure',lambda m:m.get('pressure',False)),
                            ('near025',lambda m:m.get('angle')==.025),
                            ('clean_wrong',lambda m:m['kind'] in ('clean','wrong_source'))):
                            rr=[r for r in result['rows'] if pred(r['metadata'])]
                            zz[family]=dict(n=len(rr),accepted=sum(r['features'][mode]['legacy_threshold_decision']>=0 for r in rr),
                                correct=sum(r['features'][mode]['legacy_threshold_decision']==r['metadata']['identity'] for r in rr) if family=='registered' else None,
                                min_score=min(r['features'][mode]['compatibility'] for r in rr),max_score=max(r['features'][mode]['compatibility'] for r in rr))
                        summary[mode]=zz
                    item=dict(source=source,arm=arm,condition=condition,summary=summary,
                              baseline_score_max_abs_error=result['baseline_score_max_abs_error'])
                    files.append(item);print(json.dumps(item),flush=True)
    save(HERE/'runs'/args.label/'SUMMARY.json',dict(status='complete',sources=args.sources,conditions=args.conditions,groups=files,
        no_unobserved_confirmation_used=True,new_deployment_policy_selected=False))


if __name__=='__main__':main()
