"""P164: paired developmental comparison; no unknown-processing oracle."""
from __future__ import annotations

import os
for _key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[_key] = '1'
import argparse
import csv
import hashlib
import itertools
import json
import platform
import time
from pathlib import Path

import edfio
import mne
import numpy as np
import scipy
from scipy.linalg import expm, hadamard, null_space
from scipy.signal import butter, ellip, firwin, lfilter, sosfilt, sosfiltfilt
from scipy.signal.windows import hann, tukey
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from mne.decoding import CSP

mne.set_log_level('ERROR')
ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
DATA = ROOT / 'datasets/physionet_eegbci/MNE-eegbci-data/files/eegmmidb/1.0.0'
PLAN = HERE / 'P164_SPATIAL_VS_DIFFERENTIAL_PILOT_PROTOCOL_2026-10-21.md'
HZ, SECONDS, BLOCK, QUERY = 160, 112, 640, 1280
PICKS = ('F3', 'F4', 'C3', 'C4', 'Cz', 'P3', 'P4', 'Pz')
DEV, EVAL = (19, 20), tuple(range(43, 49))
ARMS = ('spatial', 'differential_rect', 'differential_taper')
BUDGETS = (.10, .25)
STARTS = (8, 24, 40, 56, 72)
CONDITIONS = ('reexport', 'car', 'butter_zero_car', 'elliptic_zero_car',
              'elliptic_causal_car', 'fir_causal_car', 'channelwise_stress')
CAL_CONDITIONS = CONDITIONS[:3]
TASK_SOS = butter(4, [8, 30], btype='bandpass', fs=HZ, output='sos')
N_ID = 8


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2,
                               allow_nan=False), encoding='utf-8')


def load_run(subject, run):
    p = DATA / f'S{subject:03d}' / f'S{subject:03d}R{run:02d}.edf'
    raw = mne.io.read_raw_edf(p, preload=True, verbose='ERROR')
    lookup = {n.replace('.', '').casefold(): n for n in raw.ch_names}
    names = [lookup[n.casefold()] for n in PICKS]
    x = raw.get_data(picks=names)
    assert raw.info['sfreq'] == HZ and x.shape[0] == len(PICKS)
    return x, list(raw.annotations), names


def center(x):
    return x - x.mean(axis=-2, keepdims=True)


def ac(x):
    return x - x.mean(axis=-1, keepdims=True)


def filt(x):
    return sosfiltfilt(TASK_SOS, x, axis=-1)


def quality(x, y):
    e = y-x
    g = 100*np.linalg.norm(e)/np.linalg.norm(ac(x))
    c = 100*np.max(np.linalg.norm(e, axis=1)/np.linalg.norm(ac(x), axis=1))
    b = 100*np.linalg.norm(filt(e))/np.linalg.norm(filt(x))
    gram = ac(x) @ ac(x).T
    marked = ac(y) @ ac(y).T
    return dict(global_ac_prd=float(g), max_channel_ac_prd=float(c),
                band_prd=float(b), gram_relative=float(np.linalg.norm(marked-gram)/np.linalg.norm(gram)),
                qc=bool(c<=.5 and b<=1 and g<=1))


def ranges(x):
    lo, hi = np.min(x, axis=1)*1e6, np.max(x, axis=1)*1e6
    margin = np.maximum(5., .05*(hi-lo))
    return np.floor(lo-margin), np.ceil(hi+margin)


def virtual_edf(x, limits):
    lo, hi = (z[:, None]*1e-6 for z in limits)
    h = (hi-lo)/65535
    clipped = np.clip(x, lo, hi)
    return lo + np.rint((clipped-lo)/h)*h


def roundtrip(x, limits, path, artifacts):
    lo, hi = limits
    clipped = int(np.count_nonzero((x < lo[:, None]*1e-6) | (x > hi[:, None]*1e-6)))
    if clipped:
        raise RuntimeError(f'EDF range clips {clipped} values: {path.name}')
    if not path.exists():
        signals = [edfio.EdfSignal(x[i]*1e6, HZ, label=PICKS[i],
                   physical_dimension='uV', physical_range=(float(lo[i]), float(hi[i])))
                   for i in range(len(PICKS))]
        edfio.Edf(signals).write(path)
    doc = edfio.read_edf(path)
    y = np.asarray([s.data*1e-6 for s in doc.signals])
    h = (hi-lo)*1e-6/65535
    if y.shape != x.shape or np.max(np.abs(y-x)/h[:, None]) > .50001:
        raise RuntimeError('EDF physical range/roundtrip mismatch')
    artifacts[path.name] = dict(sha256=sha(path), bytes=path.stat().st_size,
                                clipped=clipped, max_rounding_lsb=float(np.max(np.abs(y-x)/h[:, None])))
    return y, h


def vectors():
    codes = list(hadamard(8).astype(float)/np.sqrt(8))
    rng = np.random.default_rng(2026102101)
    codes += list(rng.normal(size=(2, 8)))
    return np.asarray([v/np.linalg.norm(v) for v in codes])


def spatial_generator(code, channels=8):
    q = null_space(np.ones((1, channels)))
    k = np.zeros((channels-1, channels-1))
    for value, (i, j) in zip(code, itertools.combinations(range(channels-1), 2)):
        k[i, j] = value
        k[j, i] = -value
    return q @ k @ q.T


def embedding(x, arm, code, alpha):
    if arm == 'spatial':
        return expm(alpha*spatial_generator(code)) @ ac(x) + x.mean(axis=1, keepdims=True)
    chunks = x.reshape(len(PICKS), -1, BLOCK).copy()
    z = np.fft.rfft(chunks, axis=-1)
    f = np.fft.rfftfreq(BLOCK, 1/HZ)
    band = (f>=8) & (f<=30)
    group = np.minimum(((f[band]-8)/(22/8)).astype(int), 7)
    phase = np.zeros(len(f))
    phase[band] = code[group]*alpha
    signs = np.where(np.arange(chunks.shape[1])%2==0, 1., -1.)
    marked = np.fft.irfft(z*np.exp(1j*signs[None, :, None]*phase[None, None, :]), n=BLOCK, axis=-1)
    if arm == 'differential_taper':
        marked = chunks + (marked-chunks)*tukey(BLOCK, alpha=.25/2)[None, None, :]
    return marked.reshape(x.shape)


def choose_scales(x, code, budget, limits):
    # Compare at a shared feasible global error, rather than unequal max-channel caps.
    alphas, attainable = {}, []
    for arm in ARMS:
        probe = embedding(x, arm, code, .001)
        q = quality(x, probe)
        alpha = .001*budget/max(q['global_ac_prd'], 1e-12)
        z = embedding(x, arm, code, alpha)
        qq = quality(x, z)
        cap = min(1., .48/max(qq['max_channel_ac_prd'], 1e-12), .96/max(qq['band_prd'], 1e-12))
        attainable.append(budget*cap)
        alphas[arm] = alpha
    target = min(attainable)
    result = {}
    for arm in ARMS:
        alpha = alphas[arm]*target/budget
        for _ in range(3):
            y = virtual_edf(embedding(x, arm, code, alpha), limits)
            measured = quality(x, y)['global_ac_prd']
            alpha *= target/max(measured, 1e-12)
        result[arm] = alpha
    return target, result


def transform(x, name):
    if name == 'reexport':
        return x.copy()
    if name == 'car':
        return center(x)
    if name == 'butter_zero_car':
        y = sosfiltfilt(butter(4, [2, 35], btype='bandpass', fs=HZ, output='sos'), x, axis=-1)
    elif name == 'elliptic_zero_car':
        y = sosfiltfilt(ellip(4, 1, 40, [2, 35], btype='bandpass', fs=HZ, output='sos'), x, axis=-1)
    elif name == 'elliptic_causal_car':
        y = sosfilt(ellip(4, 1, 40, [2, 35], btype='bandpass', fs=HZ, output='sos'), x, axis=-1)
    elif name == 'fir_causal_car':
        y = lfilter(firwin(129, [2, 35], pass_zero=False, fs=HZ), [1.], x, axis=-1)
    elif name == 'channelwise_stress':
        y = np.asarray([sosfiltfilt(ellip(4, 1, 40, [2+.3*(c%3), 35-.5*(c%3)],
                         btype='bandpass', fs=HZ, output='sos'), v) for c, v in enumerate(x)])
    else:
        raise ValueError(name)
    return center(y)


def spectra(x, n):
    # This helper has channels on axis 0 for both (C,N) and (C,blocks,N).
    z = np.fft.rfft((x-x.mean(axis=0, keepdims=True))*hann(n, sym=False), axis=-1)
    f = np.fft.rfftfreq(n, 1/HZ)
    # Avoid sub-band transitions for the differential-phase readout.
    mask = (f>=8.5) & (f<=29.5)
    distance = ((f-8) % (22/8))
    mask &= (distance>=.5) & (distance<=22/8-.5)
    return z[..., mask]


def projectors(x):
    z = spectra(x, QUERY).T
    e = np.sum(np.abs(z)**2, axis=1)
    return z[:, :, None]*z[:, None, :].conj()/np.maximum(e[:, None, None], 1e-40), e


def differential(x, reference):
    xx = center(x).reshape(len(PICKS), 2, BLOCK)
    rr = center(reference).reshape(len(PICKS), 2, BLOCK)
    z, r = spectra(xx, BLOCK), spectra(rr, BLOCK)
    cross = np.sum(z*r.conj(), axis=0)
    a = cross[0]*cross[1].conj()
    feature = a/np.maximum(np.abs(a), 1e-40)
    energy = np.min(np.sum(np.abs(z)**2, axis=0), axis=0)
    return feature, energy


def reliability(e, ref_e, qstep, ref_step, n):
    # Deterministic Fourier-vector rounding bounds, not an iid noise assumption.
    window_sum = float(hann(n, sym=False).sum())
    eps = .5*np.linalg.norm(qstep)*window_sum
    ref_eps = .5*np.linalg.norm(ref_step)*window_sum
    a = np.maximum(0., 1-eps/np.sqrt(np.maximum(e, 1e-40)))
    b = np.maximum(0., 1-ref_eps/np.sqrt(np.maximum(ref_e, 1e-40)))
    w = a*a*b*b*np.sqrt(np.maximum(ref_e, 0))
    if w.sum()<=0:
        return np.zeros_like(w)
    return w/w.sum()


def native_distances(y, reference, book, arm, query_step, ref_step, cache):
    if arm == 'spatial':
        p, e = projectors(y)
        p0, e0, ps = cache
        w = reliability(e, e0, query_step, ref_step, QUERY)
        distance = lambda other: float(np.sum(w[:, None, None]*np.abs(p-other)**2))
    else:
        p, e = differential(y, reference)
        p0, e0, ps = cache
        w = reliability(e, e0, query_step, ref_step, BLOCK)
        distance = lambda other: float(np.sum(w*np.abs(p-other)**2))
    return np.asarray([distance(p0)]+[distance(z) for z in ps])


def build_cache(reference, book, arm):
    if arm == 'spatial':
        p0, e0 = projectors(reference)
        ps = [projectors(x)[0] for x in book]
    else:
        p0, e0 = differential(reference, reference)
        ps = [differential(x, reference)[0] for x in book]
    return p0, e0, ps


def archive_distances(y, reference, book):
    query = center(ac(y)).reshape(-1)
    refs = center(ac(np.concatenate([reference[None], book]))).reshape(N_ID+1, -1)
    scale = (refs@query)/np.maximum(np.sum(refs*refs, axis=1), 1e-40)
    return np.sum((query[None]-scale[:, None]*refs)**2, axis=1)


def rank(dist):
    d0, ds = float(dist[0]), dist[1:]
    order = np.argsort(ds)
    best, second = float(ds[order[0]]), float(ds[order[1]])
    score = (d0-best)/max(d0, 1e-30)
    gap = (second-best)/max(second, 1e-30)
    return int(order[0]), float(score), float(gap)


def epochs(x, annotations):
    windows, labels = [], []
    for a in annotations:
        if a['description'] not in ('T1', 'T2'):
            continue
        start = round((float(a['onset'])+.5)*HZ)
        if start+320<=x.shape[1]:
            windows.append(x[:, start:start+320])
            labels.append(int(a['description']=='T2'))
    return np.asarray(windows), np.asarray(labels)


def train_models(subject):
    xs, ys = [], []
    for run in (4, 8):
        raw, annotations, _ = load_run(subject, run)
        x, y = epochs(raw, annotations)
        xs.extend(x); ys.extend(y)
    x, y = np.asarray(xs), np.asarray(ys)
    csp = make_pipeline(CSP(n_components=4, reg='ledoit_wolf', log=True, norm_trace=False),
                        LinearDiscriminantAnalysis(solver='lsqr', shrinkage='auto'))
    csp.fit(filt(x), y)
    power = make_pipeline(StandardScaler(), LogisticRegression(C=1, max_iter=1000, random_state=20261021))
    power.fit(np.log(np.mean(filt(x)**2, axis=-1)+1e-30), y)
    return {'csp': csp, 'power': power}


def task_predictions(models, x, annotations):
    xx, yy = epochs(x, annotations)
    z = filt(xx)
    return yy, {'csp': models['csp'].predict_proba(z)[:, 1],
                'power': models['power'].predict_proba(np.log(np.mean(z*z, axis=-1)+1e-30))[:, 1]}


def evaluate_subject(subject, out):
    folder = out / f'S{subject:03d}'
    folder.mkdir(exist_ok=True)
    final = folder / 'results.json'
    if final.exists():
        return json.loads(final.read_text(encoding='utf-8'))
    x0, annotations, channel_names = load_run(subject, 12)
    x0 = x0[:, :SECONDS*HZ]
    wrong_source, _, _ = load_run(subject, 8)
    wrong_source = wrong_source[:, :SECONDS*HZ]
    assert x0.shape == wrong_source.shape == (8, SECONDS*HZ)
    artifacts = {}
    limits = ranges(x0)
    x, base_step = roundtrip(x0, limits, folder/'clean_issued.edf', artifacts)
    codes = vectors()
    t = time.perf_counter()
    models = train_models(subject)
    truth, base_prob = task_predictions(models, x, annotations)
    model_seconds = time.perf_counter()-t
    rows, qualities, task_rows, pairings = [], [], [], []
    processed_clean = {name: transform(x, name) for name in CONDITIONS}
    query_ranges = {name: ranges(np.concatenate([processed_clean[name], transform(wrong_source, name)], axis=1))
                    for name in CONDITIONS}
    for budget in BUDGETS:
        books = {arm: [] for arm in ARMS}
        targets = []
        for recipient, code in enumerate(codes):
            target, scales = choose_scales(x, code, budget, limits)
            targets.append(target)
            measured = []
            for arm in ARMS:
                ideal = embedding(x, arm, code, scales[arm])
                name = f'b{budget:g}_{arm}_r{recipient}_issued.edf'
                issued, _ = roundtrip(ideal, limits, folder/name, artifacts)
                books[arm].append(issued)
                q = quality(x, issued)
                measured.append(q['global_ac_prd'])
                qualities.append(dict(subject=subject, budget=budget, arm=arm,
                                      recipient=recipient, target=target, **q))
                if recipient<N_ID:
                    labels, probs = task_predictions(models, issued, annotations)
                    assert np.array_equal(labels, truth)
                    for model, pp in probs.items():
                        bp = base_prob[model]
                        task_rows.append(dict(subject=subject, budget=budget, arm=arm, recipient=recipient,
                                              model=model, n=len(labels), base_ba=float(balanced_accuracy_score(labels, bp>=.5)),
                                              marked_ba=float(balanced_accuracy_score(labels, pp>=.5)),
                                              flips=int(np.sum((pp>=.5)!=(bp>=.5))),
                                              probability_mae=float(np.mean(np.abs(pp-bp))),
                                              probability_p95=float(np.quantile(np.abs(pp-bp), .95))))
            pairings.append(dict(subject=subject, budget=budget, recipient=recipient,
                                 target=target, measured=measured,
                                 relative_spread=float((max(measured)-min(measured))/max(min(measured), 1e-30))))
        for arm in ARMS:
            books[arm] = np.asarray(books[arm])
            caches = {}
            for start in STARTS:
                a, b = start*HZ, (start+8)*HZ
                caches[start] = build_cache(x[:, a:b], books[arm][:N_ID, :, a:b], arm)
            for condition in CONDITIONS:
                inputs = list(books[arm])+[x, wrong_source]
                for index, issued in enumerate(inputs):
                    recipient = index if index<10 else (-1 if index==10 else -2)
                    kind = 'enrolled' if recipient in range(N_ID) else (
                           'unregistered' if recipient>=N_ID else 'clean' if recipient==-1 else 'wrong_source')
                    processed = transform(issued, condition)
                    name = f'b{budget:g}_{arm}_{condition}_q{recipient}.edf'
                    query, query_step = roundtrip(processed, query_ranges[condition], folder/name, artifacts)
                    for start in STARTS:
                        a, b = start*HZ, (start+8)*HZ
                        reference, book = x[:, a:b], books[arm][:N_ID, :, a:b]
                        for detector in ('native', 'archive_gain'):
                            t = time.perf_counter()
                            if detector=='native':
                                ds = native_distances(query[:, a:b], reference, book, arm,
                                                      query_step, base_step, caches[start])
                            else:
                                ds = archive_distances(query[:, a:b], reference, book)
                            top, score, gap = rank(ds)
                            elapsed = (time.perf_counter()-t)*1000
                            rows.append(dict(subject=subject, budget=budget, arm=arm,
                                             condition=condition, recipient=recipient, kind=kind,
                                             start=start, detector=detector, top=top, score=score,
                                             gap=gap, scoring_ms=elapsed))
                print(f'P164 S{subject:03d} budget={budget:g} {arm} {condition} scored', flush=True)
    result = dict(subject=subject, role='calibration' if subject in DEV else 'mechanism_evaluation',
                  channels=channel_names, model_fit_seconds=model_seconds,
                  rows=rows, qualities=qualities, pairings=pairings, task=task_rows, artifacts=artifacts)
    write_json(final, result)
    return result


def calibrate(results):
    thresholds = []
    for budget, arm, detector in itertools.product(BUDGETS, ARMS, ('native', 'archive_gain')):
        rr = [r for result in results for r in result['rows'] if result['subject'] in DEV
              and r['budget']==budget and r['arm']==arm and r['detector']==detector
              and r['condition'] in CAL_CONDITIONS]
        negative = [r['score'] for r in rr if r['kind']!='enrolled' and r['gap']>=.05]
        threshold = max([0.]+negative)+1e-6
        thresholds.append(dict(budget=budget, arm=arm, detector=detector, threshold=threshold,
                               calibration_queries=len(rr), calibration_negatives=sum(r['kind']!='enrolled' for r in rr)))
    return thresholds


def summarize(results, thresholds, out):
    rows = []
    for result in results:
        for row in result['rows']:
            r = dict(row)
            t = next(t['threshold'] for t in thresholds if all(t[k]==r[k] for k in ('budget', 'arm', 'detector')))
            r['found'] = r['top'] if r['score']>=t and r['gap']>=.05 else -1
            rows.append(r)
    groups = []
    for subject, budget, arm, condition, detector in itertools.product(EVAL, BUDGETS, ARMS, CONDITIONS, ('native', 'archive_gain')):
        rr = [r for r in rows if r['subject']==subject and r['budget']==budget and r['arm']==arm
              and r['condition']==condition and r['detector']==detector]
        positive, negative = [r for r in rr if r['kind']=='enrolled'], [r for r in rr if r['kind']!='enrolled']
        groups.append(dict(subject=subject, budget=budget, arm=arm, condition=condition, detector=detector,
                           correct=sum(r['found']==r['recipient'] for r in positive),
                           wrong=sum(r['found']>=0 and r['found']!=r['recipient'] for r in positive),
                           reject=sum(r['found']<0 for r in positive), positive_n=len(positive),
                           negative_accept=sum(r['found']>=0 for r in negative), negative_n=len(negative),
                           closed_set_correct=sum(r['top']==r['recipient'] for r in positive),
                           score_ms_median=float(np.median([r['scoring_ms'] for r in rr]))))
    write_json(out/'summary.json', dict(thresholds=thresholds, groups=groups,
               qualities=[q for result in results for q in result['qualities']],
               pairings=[q for result in results for q in result['pairings']],
               task=[q for result in results for q in result['task']]))
    with (out/'queries.csv').open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    with (out/'subject_groups.csv').open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(groups[0])); w.writeheader(); w.writerows(groups)


def selfcheck():
    rng = np.random.default_rng(7)
    z = rng.normal(size=8)+1j*rng.normal(size=8)
    z -= z.mean()
    p = lambda v: np.outer(v, v.conj())/np.vdot(v, v)
    assert np.allclose(p(z), p((.4+.7j)*z))
    assert np.allclose(p(z), p(np.exp(.2j)*z))
    for value in (1+2j, -3+.1j):
        assert np.allclose(p(np.array([value, -value])), .5*np.array([[1.,-1.],[-1.,1.]]))
    r = expm(.02*spatial_generator(vectors()[0]))
    assert np.allclose(r.T@r, np.eye(8)) and np.allclose(r@np.ones(8), 1)
    x = rng.normal(size=(8, 4*BLOCK))*1e-5
    assert np.allclose(np.linalg.norm(x), np.linalg.norm(r@x))
    h = .4+.3j
    phase = .01*vectors()[0]
    a, b = h*np.exp(1j*phase), h*np.exp(-1j*phase)
    assert np.allclose(np.angle(a*b.conj()), 2*phase)
    # spectra must center over the true channel axis, including 3-D block input.
    xx = x[:, :QUERY]
    d, _ = differential(xx, xx)
    assert np.allclose(d, 1.)
    block_view = xx.reshape(8, 2, BLOCK)
    assert np.allclose(spectra(block_view, BLOCK)[:, 0], spectra(block_view[:, 0], BLOCK))
    for arm in ARMS:
        y = embedding(x, arm, vectors()[0], .01)
        assert y.shape==x.shape and np.isfinite(y).all()
    print('P164 mathematical/shape selfchecks passed', flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default='p164_spatial_differential_pilot_v1')
    ap.add_argument('--selfcheck', action='store_true')
    args = ap.parse_args()
    selfcheck()
    if args.selfcheck:
        return
    out = HERE/args.out
    out.mkdir(exist_ok=True)
    sources = {str((DATA/f'S{s:03d}'/f'S{s:03d}R{r:02d}.edf').relative_to(ROOT)):
               sha(DATA/f'S{s:03d}'/f'S{s:03d}R{r:02d}.edf') for s in DEV+EVAL for r in (4,8,12)}
    state = dict(protocol_sha256=sha(PLAN), code_sha256=sha(__file__), sources=sources,
                 python=platform.python_version(), numpy=np.__version__, scipy=scipy.__version__,
                 mne=mne.__version__, edfio=edfio.__version__, subjects=dict(calibration=DEV, evaluation=EVAL),
                 channels=PICKS, budgets=BUDGETS, conditions=CONDITIONS, starts=STARTS)
    manifest = out/'frozen_manifest.json'
    if manifest.exists():
        if json.loads(manifest.read_text(encoding='utf-8')) != json.loads(json.dumps(state)):
            raise RuntimeError('P164 frozen code/data drift; use separate amended output')
    else:
        write_json(manifest, state)
    if (out/'summary.json').exists():
        raise FileExistsError('P164 completed output exists')
    results = [evaluate_subject(s, out) for s in DEV]
    thresholds = calibrate(results)
    write_json(out/'calibrated_thresholds_before_evaluation.json', thresholds)
    results.extend(evaluate_subject(s, out) for s in EVAL)
    summarize(results, thresholds, out)
    print(f'P164 complete: {out}', flush=True)


if __name__=='__main__':
    main()
