"""Frozen A400 finite-registry encoder in the common unknown-response receiver.

Observed P190 sources are development only. Native Hamming-neighbour messages
are independently encoded legal 30-bit messages, not phase-angle unknowns.
"""
from pathlib import Path
import os, sys
HERE = Path(__file__).resolve().parent
BASE = HERE.parent
ROOT = HERE.parents[2]
OUT = HERE / 'common_owner01'
P190 = BASE / 'p190_experiment_v1'
sys.dont_write_bytecode = True
for key in ('TEMP', 'TMP', 'TMPDIR', 'TORCH_HOME', 'NUMBA_CACHE_DIR', 'MPLCONFIGDIR'):
    folder = OUT / 'cache' / key.lower()
    folder.mkdir(parents=True, exist_ok=True)
    os.environ[key] = str(folder)
for key in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS'):
    os.environ[key] = '1'
sys.path[:0] = [str(HERE / 'vendor'), str(BASE / 'p188_glrt_v1'),
                str(BASE / 'p191_fir_capacity_v1'), str(ROOT)]
import argparse, ctypes, gzip, hashlib, json, time
import numpy as np
import torch
from threadpoolctl import threadpool_limits
from rpw_adapter import PublicEncoder, ModelConfig
import receiver_api as api
from capacity_pilot import CapacityReceiver
from revision.post_20260926 import run_p181_data as edf
from revision.post_20260926 import p181_common as common

CHANNELS = ('FC3', 'FC4', 'C3', 'C4', 'Cz', 'CP3', 'CP4', 'Pz')
CONDITIONS = ('reexport', 'elliptic_new_causal', 'bessel_shifted_causal')
SOURCES = {'OpenBMI001': 'fit', 'OpenBMI003': 'select'}
CHECKPOINT = HERE / 'owner_train02' / 'checkpoint_400.pt'
CONFIGS = list(api.CONFIGS)
METHODS = (*api.METHODS, 'candidate_FIR257')


def load(path):
    path = Path(path)
    raw = path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.suffix == '.gz' else raw)


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = (json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(',', ':')) + '\n').encode()
    if path.suffix == '.gz':
        raw = gzip.compress(raw, compresslevel=5, mtime=0)
    partial = path.with_suffix(path.suffix + '.partial')
    partial.write_bytes(raw)
    partial.replace(path)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return edf.parse_edf(gzip.decompress(Path(path).read_bytes()), CHANNELS)[0]


def event(**value):
    print(json.dumps(dict(utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), **value)), flush=True)


def codebook(checkpoint):
    enrolled = checkpoint['codebook'].int().numpy()
    result = [row.copy() for row in enrolled]
    metadata = [dict(kind='enrolled', identity=i, parent=i, hamming_to_parent=0,
                     phase_angle=None, pressure=False) for i in range(8)]
    for distance in (1, 2):
        for identity, row in enumerate(enrolled):
            value = row.copy()
            value[:distance] = 1 - value[:distance]
            assert not np.any(np.all(enrolled == value, axis=1))
            assert np.min(np.count_nonzero(enrolled != value, axis=1)) == distance
            result.append(value)
            metadata.append(dict(kind='native_hamming_unknown', identity=None, parent=identity,
                                 hamming_to_parent=distance, phase_angle=None, pressure=False,
                                 generation='independently encoded legal native30 message'))
    result = np.asarray(result)
    assert len(np.unique(result, axis=0)) == 24
    distances = np.count_nonzero(enrolled[:, None] != enrolled[None], axis=2)
    return result, metadata, int(distances[np.triu_indices(8, 1)].min())


def protocol(codes, metadata, minimum):
    inputs = {str(CHECKPOINT): sha(CHECKPOINT), str(Path(__file__)): sha(__file__)}
    for source, split in SOURCES.items():
        for path in (P190 / 'sources' / source / 'source.json',
                     P190 / 'sources' / source / 'clean.edf.gz',
                     P190 / 'issuance' / source / 'level100' / 'issuance_summary.json',
                     P190 / 'raw' / split / source / 'level100' / 'smooth.json.gz'):
            inputs[str(path)] = sha(path)
    value = dict(role='observed-source modern-carrier common-access development pilot',
                 source_roles=SOURCES, input_sha256=inputs,
                 model='fixed A400 RPW public-structure owner-adapted finite-eight encoder',
                 train_sources=['A01T', 'A02T'], prior_development_source='A03T',
                 encoder_learning_steps=400, encoder_window_adaptation='28 nonoverlapping 4s blocks; fixed weights',
                 reference_seconds=112, sample_rate=160, channels=list(CHANNELS),
                 query_visible_context_seconds=48, scored_seconds=40, score_starts_seconds=list(api.p.STARTS),
                 actual_EDF=True, caps_percent=[.25, .5, 1.],
                 actual_global_PRD_target='same-source, same-rid actual P190 smooth level1 EDF',
                 allowed_relative_registered_spread=.001,
                 scale_selection='one source-message scalar after blockwise temporal-DC removal; quantized global-PRD bisection',
                 unknown_response_access='common blind coarse-model/alignment and cross-fitted FIR; no true response or paired processed-clean query',
                 receivers=dict(FIR129=list(api.METHODS), FIR257=['candidate_FIR257']),
                 parameters_menu=CONFIGS, presence_min=.25,
                 fit_threshold='nextafter(max eligible mini-fit negative score,+inf), including all native Hamming unknowns and clean/wrong',
                 select_policy='min mini-select false accepts, then max correct registered, then lowest configuration index',
                 conditions=list(CONDITIONS),
                 native_legal_message_domain='all binary 30-bit messages', native_registered_codebook=codes[:8].tolist(),
                 native_registered_min_hamming=minimum, query_codes=codes.tolist(), query_metadata=metadata,
                 unknown_semantics='one/two-bit distinct legal encoder inputs; no phase-angle 0.025 or 0.0125 equivalence',
                 native_random30_full_payload_gate='B800 failed and retained separately',
                 known_response_fixed_eight_gate='A400 passed; independent common-receiver pilot reported here',
                 independent_confirmation=False, downstream_task_training=False,
                 primary_thresholds_from_P190='descriptive replay only; carrier-specific pilot calibration is separate')
    path = OUT / 'PROTOCOL.json'
    if path.exists():
        assert load(path) == value, 'Protocol changed during an existing pilot'
    else:
        save(path, value)
    return value


def raw_delta(x, bits, encoder, normalization):
    block = torch.from_numpy(x.reshape(8, 28, 640).transpose(1, 0, 2).copy())
    mean = normalization['mean_v'].reshape(1, 8, 1)
    scale = normalization['scale_v'].reshape(1, 8, 1)
    message = torch.tensor(bits, dtype=torch.float32)[None].repeat(28, 1)
    with torch.no_grad():
        xn = ((block - mean) / scale).unsqueeze(1).float()
        delta = encoder(xn, message)[:, 0].double() * scale
        delta -= delta.mean(-1, keepdim=True)
    return delta.numpy().transpose(1, 0, 2).reshape(8, 17920)


def match(x, delta, limits, target):
    denominator = np.linalg.norm(api.p.ac(x))
    norm = np.linalg.norm(delta)
    assert norm > 0
    lo_uv, hi_uv = limits
    with np.errstate(divide='ignore', invalid='ignore'):
        room = np.where(delta > 0, (hi_uv[:, None] * 1e-6 - x) / delta,
                        np.where(delta < 0, (x - lo_uv[:, None] * 1e-6) / (-delta), np.inf))
    maximum = float(np.min(room)) * (1 - 1e-12)
    low, high = 0., min(maximum, 2 * target / 100 * denominator / norm)
    def evaluate(scale):
        y = api.p.virtual_edf(x + delta * scale, limits)
        return y, 100 * np.linalg.norm(y - x) / denominator
    y, value = evaluate(high)
    if value < target / 1.001:
        return None, dict(status='infeasible_range', target=target, highest_PRD=value)
    history = []
    answer = None
    for _ in range(48):
        middle = (low + high) / 2
        y, value = evaluate(middle)
        history.append(dict(scale=middle, global_ac_prd=value))
        if target / 1.001 <= value <= target:
            answer = (middle, y)
            break
        if value > target:
            high = middle
        else:
            low = middle
    if answer is None:
        return None, dict(status='unmatched_quantization', target=target, history=history)
    scale, y = answer
    quality = api.p.quality(x, y)
    feasible = quality['global_ac_prd'] <= .25 and quality['max_channel_ac_prd'] <= .5 and quality['band_prd'] <= 1.
    return (x + delta * scale if feasible else None), dict(
        status='matched' if feasible else 'caps_infeasible_at_matched_global_PRD',
        target=target, scale=scale, quality=quality, history=history)


def issue(source, encoder, normalization, codes, metadata):
    folder = OUT / 'issuance' / source
    path = folder / 'ISSUANCE.json'
    if path.exists():
        result = load(path)
        copies = [read(folder / f'r{i:02d}_issued.edf.gz') if r['feasible'] else None
                  for i, r in enumerate(result['rows'])]
        return read(P190 / 'sources' / source / 'clean.edf.gz'), copies, result
    folder.mkdir(parents=True, exist_ok=True)
    x = read(P190 / 'sources' / source / 'clean.edf.gz')
    limits = tuple(np.asarray(v) for v in load(P190 / 'sources' / source / 'source.json')['limits_uv'])
    targets = []
    for identity in range(8):
        smooth = read(P190 / 'issuance' / source / 'level100' / f'smooth_r{identity}_issued.edf.gz')
        targets.append(float(api.p.quality(x, smooth)['global_ac_prd']))
    rows, copies, receipts = [], [], []
    start = time.monotonic()
    for index, (bits, info) in enumerate(zip(codes, metadata)):
        delta = raw_delta(x, bits, encoder, normalization)
        ideal, detail = match(x, delta, limits, targets[info['parent']])
        actual = None
        if ideal is not None:
            actual, _ = edf.edf_roundtrip(ideal, limits, f'r{index:02d}_issued.edf', folder, receipts, True, CHANNELS)
            quality = api.p.quality(x, actual)
            target = targets[info['parent']]
            assert target / 1.001 <= quality['global_ac_prd'] <= target
            assert quality['global_ac_prd'] <= .25 and quality['max_channel_ac_prd'] <= .5 and quality['band_prd'] <= 1.
            detail['actual_quality'] = quality
            if index < 8:
                detail['registered_pair_relative_spread'] = (target - quality['global_ac_prd']) / quality['global_ac_prd']
                assert detail['registered_pair_relative_spread'] <= .001
        copies.append(actual)
        rows.append(dict(index=index, bits=bits.tolist(), metadata=info, feasible=actual is not None, matching=detail))
        event(event='issuance_progress', source=source, index=index, feasible=actual is not None)
    registered_valid = all(c is not None for c in copies[:8])
    result = dict(status='complete', source=source, rows=rows, EDF_receipts=receipts,
                  registered_group_valid=registered_valid, smooth_actual_targets=targets,
                  limits_uv=[v.tolist() for v in limits], seconds=time.monotonic()-start,
                  checkpoint_sha256=sha(CHECKPOINT), protocol_sha256=sha(OUT / 'PROTOCOL.json'))
    save(path, result)
    return x, copies, result


def collect(source, x, copies, issuance, metadata):
    split = SOURCES[source]
    dest = OUT / 'raw' / f'{source}.json.gz'
    if dest.exists():
        return load(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    old = load(P190 / 'raw' / split / source / 'level100' / 'smooth.json.gz')
    names = sorted({r['negative_source'] for r in old['rows'] if r['kind'] == 'wrong_source'})
    wrongs = [read(P190 / 'sources' / name / 'clean.edf.gz') for name in names]
    infos = metadata + [dict(kind='clean', identity=None, parent=None, pressure=False)] + [
        dict(kind='wrong_source', identity=None, parent=None, pressure=False, negative_source=n) for n in names]
    values = copies + [x] + wrongs
    receiver = api.MatchedFIRReceivers(x, np.asarray(copies[:8])) if issuance['registered_group_valid'] else None
    receiver257 = CapacityReceiver(x, np.asarray(copies[:8]), 257) if receiver is not None else None
    rows, receipts = [], []
    start = time.monotonic()
    for index, (value, info) in enumerate(zip(values, infos)):
        for condition in CONDITIONS:
            row = dict(source=source, split=split, query_index=index, condition=condition, **info)
            if value is None or receiver is None:
                rows.append(dict(**row, issuance_feasible=False, receiver=None))
                continue
            limits = tuple(np.asarray(v) for v in old['query_limits_uv'][condition])
            query, _ = edf.edf_roundtrip(common.transform(value, condition), limits,
                f'{source}_modern_q{index}_{condition}.edf', dest.parent, receipts, True, CHANNELS)
            tick = time.monotonic()
            features = receiver.extract(query)
            baseline_seconds = time.monotonic() - tick
            value257 = receiver257.extract_candidate(query)
            by_ridge = value257['by_ridge']
            configs = [dict(score=by_ridge[str(c['ridge'])][c['head']],
                            top=by_ridge[str(c['ridge'])]['top'],
                            eligible=by_ridge[str(c['ridge'])]['eligible'] and
                            by_ridge[str(c['ridge'])]['support'] >= c['support']) for c in CONFIGS]
            features['methods']['candidate_FIR257'] = dict(by_ridge=by_ridge, configs=configs)
            if info['kind'] in ('clean', 'wrong_source'):
                oldrow = next(r for r in old['rows'] if r['kind'] == info['kind'] and r['condition'] == condition
                    and (info['kind'] == 'clean' or r['negative_source'] == info['negative_source']))
                assert oldrow['query_raw_sha256'] == receipts[-1]['raw_sha256'], 'Shared negative query bytes changed'
            rows.append(dict(**row, issuance_feasible=True, receiver=features,
                             query_raw_sha256=receipts[-1]['raw_sha256'],
                             receiver_seconds=dict(FIR129_all_three=baseline_seconds,
                                                   candidate_FIR257=value257['seconds'])))
        if index % 4 == 3:
            save(dest.with_suffix('.partial.json.gz'), dict(status='running', rows=rows, EDF_receipts=receipts))
            event(event='query_progress', source=source, identities=index+1, rows=len(rows))
    result = dict(status='complete', source=source, split=split, rows=rows, EDF_receipts=receipts,
                  seconds=time.monotonic()-start, independent_confirmation=False,
                  protocol_sha256=sha(OUT / 'PROTOCOL.json'),
                  registered_group_valid=issuance['registered_group_valid'],
                  query_limits_identical_to_P190=True, shared_negative_EDF_hashes_match=True)
    save(dest, result)
    # JSON normalizes ridge keys from floats to strings. Keep the fresh-run
    # analysis on the same representation as resumed saved-score analysis.
    return load(dest)


def evaluate(rows, method, index, threshold):
    counts = {key: dict(n=0, accepted=0, correct=0) for key in ('enrolled', 'native_hamming_unknown', 'clean', 'wrong_source')}
    per_condition = {}
    for row in rows:
        v = counts[row['kind']]
        v['n'] += 1
        if row['receiver'] is None:
            continue
        a = row['receiver']['methods'][method]['configs'][index]
        c = row['receiver']['methods'][method]['by_ridge'][str(CONFIGS[index]['ridge'])]
        accept = a['eligible'] and c['presence'] >= .25 and a['score'] >= threshold
        v['accepted'] += int(accept)
        v['correct'] += int(accept and row['kind'] == 'enrolled' and a['top'] == row['identity'])
        per_condition.setdefault(row['condition'], {}).setdefault(row['kind'], dict(n=0, accepted=0, correct=0))
        q = per_condition[row['condition']][row['kind']]
        q['n'] += 1; q['accepted'] += int(accept)
        q['correct'] += int(accept and row['kind'] == 'enrolled' and a['top'] == row['identity'])
    return dict(counts=counts, per_condition=per_condition)


def analyze(groups):
    fit, select = groups['OpenBMI001']['rows'], groups['OpenBMI003']['rows']
    outputs = {}
    for method in METHODS:
        candidates = []
        for index, config in enumerate(CONFIGS):
            negative = []
            for row in fit:
                if row['kind'] == 'enrolled' or row['receiver'] is None:
                    continue
                a = row['receiver']['methods'][method]['configs'][index]
                b = row['receiver']['methods'][method]['by_ridge'][str(config['ridge'])]
                if a['eligible'] and b['presence'] >= .25:
                    negative.append(a['score'])
            threshold = float(np.nextafter(max(negative), np.inf)) if negative else 0.
            f, s = evaluate(fit, method, index, threshold), evaluate(select, method, index, threshold)
            fa = sum(v['accepted'] for k,v in s['counts'].items() if k != 'enrolled')
            candidates.append(dict(index=index, config=config, threshold=threshold, fit=f, select=s,
                                   select_false_accepts=fa, select_registered_correct=s['counts']['enrolled']['correct']))
        chosen = min(candidates, key=lambda z:(z['select_false_accepts'], -z['select_registered_correct'], z['index']))
        outputs[method] = dict(selected=chosen, candidates=candidates,
            historical_threshold_replay={source: evaluate(group['rows'], method, 6, .9987280466974421)
                                         for source,group in groups.items()})
    save(OUT / 'SUMMARY.json', dict(status='complete', methods=outputs, source_roles=SOURCES,
        independent_confirmation=False, unknown_semantics='native Hamming1/2 legal messages, phase angle not applicable',
        attribution_common_access_and_duration=True,
        source_issuance={s:load(OUT / 'issuance' / s / 'ISSUANCE.json') for s in SOURCES}))
    event(event='pilot_complete', summary=str(OUT / 'SUMMARY.json'))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--only-source', choices=list(SOURCES))
    args = parser.parse_args()
    torch.set_num_threads(1); torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    checkpoint = torch.load(CHECKPOINT, map_location='cpu', weights_only=False)
    codes, metadata, minimum = codebook(checkpoint)
    protocol(codes, metadata, minimum)
    encoder = PublicEncoder(ModelConfig(native_input_scale=1.))
    encoder.load_state_dict(checkpoint['encoder']); encoder.eval()
    groups = {}
    with threadpool_limits(limits=1):
        for source in ([args.only_source] if args.only_source else list(SOURCES)):
            x, copies, issuance = issue(source, encoder, checkpoint['normalizer'], codes, metadata)
            groups[source] = collect(source, x, copies, issuance, metadata)
        if not args.only_source:
            analyze(groups)


if __name__ == '__main__':
    awake = ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
    try:
        main()
    finally:
        if awake:
            ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
