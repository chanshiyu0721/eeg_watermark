"""Full eight-source modern-carrier DEV, reusing the first two issuances."""
from pathlib import Path
import argparse, copy, hashlib, json, time
import numpy as np
import torch
import common_owner_comparison as m
from dev_capacity import DevelopmentReceiver, ROLES

HERE = Path(__file__).resolve().parent
OLD = HERE / 'common_owner01'
OUT = HERE / 'common_owner_dev01'
SOURCES = {source:role for role,names in ROLES.items() for source in names}
EXACT_MENU = [dict(ridge=r,support=s) for r in (1e-4,1e-6) for s in (1,3)]


def source_issuance(source, encoder, normalization, codes, metadata):
    if source in ('OpenBMI001','OpenBMI003'):
        folder=OLD/'issuance'/source
        issue=m.load(folder/'ISSUANCE.json')
        x=m.read(m.P190/'sources'/source/'clean.edf.gz')
        return x,[m.read(folder/f'r{i:02d}_issued.edf.gz') for i in range(24)],issue,folder
    m.OUT=OUT
    x,copies,issue=m.issue(source,encoder,normalization,codes,metadata)
    return x,copies,issue,OUT/'issuance'/source


def protocol(codes,metadata,minimum):
    inputs={str(m.CHECKPOINT):m.sha(m.CHECKPOINT),str(Path(__file__)):m.sha(__file__),
            str(Path(m.__file__)):m.sha(m.__file__)}
    for source,role in SOURCES.items():
        for path in (m.P190/'sources'/source/'source.json',m.P190/'raw'/role/source/'level100/smooth.json.gz'):
            inputs[str(path)]=m.sha(path)
    obj=dict(status='full modern-carrier DEV protocol before expanded scoring',source_roles=SOURCES,
        inputs_sha256=inputs,fixed_checkpoint='A400 finite-eight public-structure owner-adapted RPW encoder',
        checkpoint_sha256=m.sha(m.CHECKPOINT),native_random30_failure_preserved=True,
        actual_EDF=True,reference_seconds=112,scored_seconds=40,query_context_seconds=48,
        actual_global_PRD_match='each source/rid P190 smooth actual EDF global PRD; relative spread <=.001',
        configured_caps_percent=[.25,.5,1.],unknown_response=True,
        legacy_menu=list(m.CONFIGS),exact_menu=EXACT_MENU,presence_gate=.25,
        thresholds='D_fit only nextafter maximum eligible negative, native H1/H2+clean+wrong included',
        selection='D_select minimum false accepts then maximum registered correct then lowest menu index',
        conditions=list(m.CONDITIONS),query_codes=codes.tolist(),query_metadata=metadata,
        registered_min_native_hamming=minimum,native_unknowns_not_phase_angle_tests=True,
        reused_issuance_sources=['OpenBMI001','OpenBMI003'],
        existing_two_source_legacy129_reused=True,
        existing_two_source257_recomputed_only_for_missing_exact_sufficient_statistics=True,
        no_new_confirmation_data_used=True)
    target=OUT/'PROTOCOL.json'
    if target.exists():assert m.load(target)==obj,'Expanded DEV protocol differs'
    else:m.save(target,obj)


def collect(source,x,copies,issue,metadata,issuefolder):
    role=SOURCES[source];dest=OUT/'raw'/f'{source}.json.gz'
    dest.parent.mkdir(parents=True,exist_ok=True)
    if dest.exists() and m.load(dest).get('status')=='complete':return m.load(dest)
    old=m.load(m.P190/'raw'/role/source/'level100/smooth.json.gz')
    names=sorted({r['negative_source']for r in old['rows']if r['kind']=='wrong_source'})
    wrongs=[m.read(m.P190/'sources'/n/'clean.edf.gz')for n in names]
    values=copies+[x]+wrongs
    infos=metadata+[dict(kind='clean',identity=None,parent=None,pressure=False)]+[
        dict(kind='wrong_source',identity=None,parent=None,pressure=False,negative_source=n)for n in names]
    prior=m.load(OLD/'raw'/f'{source}.json.gz')if source in ('OpenBMI001','OpenBMI003')else None
    old129=m.api.MatchedFIRReceivers(x,np.asarray(copies[:8]))if prior is None else None
    new257=DevelopmentReceiver(x,np.asarray(copies[:8]),257)
    state=m.load(dest)if dest.exists()else dict(rows=[],EDF_receipts=[],seconds=0.)
    rows=state['rows'];receipts=state['EDF_receipts'];done={(r['query_index'],r['condition'])for r in rows}
    start=time.monotonic()
    for index,(value,info)in enumerate(zip(values,infos)):
        for condition in m.CONDITIONS:
            if (index,condition)in done:continue
            if prior is not None:
                prev=next(r for r in prior['rows']if r['query_index']==index and r['condition']==condition)
                row=copy.deepcopy(prev)
                queryfile=OLD/'raw'/f'{source}_modern_q{index}_{condition}.edf.gz'
                query=m.read(queryfile)
                assert hashlib.sha256(__import__('gzip').decompress(queryfile.read_bytes())).hexdigest()==row['query_raw_sha256']
                row['legacy129_inherited']=True
            else:
                limits=tuple(np.asarray(v)for v in old['query_limits_uv'][condition])
                query,_=m.edf.edf_roundtrip(m.common.transform(value,condition),limits,
                    f'{source}_modern_q{index}_{condition}.edf',dest.parent,receipts,True,m.CHANNELS)
                row=dict(source=source,split=role,query_index=index,condition=condition,**info,
                    issuance_feasible=True,receiver=old129.extract(query),query_raw_sha256=receipts[-1]['raw_sha256'])
                # Normalize float ridge keys once at the data boundary.
                row=json.loads(json.dumps(row))
                if info['kind']in('clean','wrong_source'):
                    z=next(r for r in old['rows']if r['kind']==info['kind']and r['condition']==condition
                        and(info['kind']=='clean'or r['negative_source']==info['negative_source']))
                    assert z['query_raw_sha256']==row['query_raw_sha256']
            features=new257.extract_all(query)
            row['receiver257']=features
            row['issued_folder']=str(issuefolder)
            row['native_phase_angle_not_applicable']=True
            rows.append(row)
            m.save(dest,dict(status='running',source=source,role=role,rows=rows,EDF_receipts=receipts,
                seconds=state['seconds']+time.monotonic()-start,protocol_sha256=m.sha(OUT/'PROTOCOL.json')))
        if index%4==3:m.event(event='modern_full_DEV',source=source,queries=len(rows),total=81)
    result=dict(status='complete',source=source,role=role,rows=rows,EDF_receipts=receipts,
        seconds=state['seconds']+time.monotonic()-start,protocol_sha256=m.sha(OUT/'PROTOCOL.json'),
        owner_reference_seconds=112,query_context_seconds=48,scored_seconds=40,
        actual_PRD_matched=True,native_unknown_semantics='legal Hamming1/2 encoder inputs',
        existing_129_reused=prior is not None,independent_confirmation=False)
    m.save(dest,result);m.event(event='modern_source_complete',source=source,queries=len(rows),seconds=result['seconds'])
    return result


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--sources',default=','.join(SOURCES));args=parser.parse_args()
    torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
    checkpoint=torch.load(m.CHECKPOINT,map_location='cpu',weights_only=False)
    codes,metadata,minimum=m.codebook(checkpoint);protocol(codes,metadata,minimum)
    encoder=m.PublicEncoder(m.ModelConfig(native_input_scale=1.))
    encoder.load_state_dict(checkpoint['encoder']);encoder.eval()
    for source in args.sources.split(','):
        assert source in SOURCES
        x,copies,issue,folder=source_issuance(source,encoder,checkpoint['normalizer'],codes,metadata)
        assert issue['registered_group_valid']
        collect(source,x,copies,issue,metadata,folder)


if __name__=='__main__':main()
