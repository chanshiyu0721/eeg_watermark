"""One fixed-evidence test of blind versus reference-conditioned RPW readout.

The source encoder/actual EDFs are an already completed, training-only P187
experiment. Only two fresh copies of its public decoder are trained here.
"""
from pathlib import Path
import os,sys
HERE=Path(__file__).resolve().parent
BASE=HERE.parent
OUT=HERE/'readout_run01'
OUT.mkdir(parents=True,exist_ok=False)
sys.dont_write_bytecode=True
for key in ('TEMP','TMP','TMPDIR','MPLCONFIGDIR','TORCH_HOME','NUMBA_CACHE_DIR'):
    p=OUT/'cache'/key.lower();p.mkdir(parents=True,exist_ok=True);os.environ[key]=str(p)
for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[key]='2'
sys.path.insert(0,str(BASE/'p183_rpw_adaptation_v1'))
import copy,hashlib,json,time,random,ctypes,traceback
import numpy as np
import torch
from torch.nn import functional as F
import edfio
from rpw_adapter import PublicDecoder,ModelConfig,PhysicalBudgetProjector
torch.set_num_threads(2);torch.set_num_interop_threads(1)
torch.use_deterministic_algorithms(True)
OLD=BASE/'p187_rpw_convergence_v1'


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,z):
    p=OUT/name;t=p.with_suffix(p.suffix+'.tmp')
    t.write_text(json.dumps(z,indent=2,allow_nan=False)+'\n',encoding='utf-8');t.replace(p)
def log(**z):
    print(json.dumps(z,allow_nan=False),flush=True)
    with (OUT/'events.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(z,allow_nan=False)+'\n')
def metrics(logits,bits):
    hard=logits>=0
    return dict(bit_correct=int((hard==bits.bool()).sum()),bit_n=bits.numel(),
        exact=int((hard==bits.bool()).all(1).sum()),messages=len(bits),
        bce=float(F.binary_cross_entropy_with_logits(logits,bits)),
        unique_hard_codes=int(len(torch.unique(hard,dim=0))))
def geometry(z):
    a=z.flatten(1).double();a=a-a.mean(0,keepdim=True)
    s=torch.linalg.svdvals(a)
    return dict(singular_values=s.tolist(),stable_rank=float(s.square().sum()/s[0].square()),
                rank_relative_1e5=int((s>s[0]*1e-5).sum()),mean_message_sd=float(a.square().mean().sqrt()))


def main():
    start=time.monotonic();seed=19141
    inputs=OLD/'tiny_run01/fixed_training_inputs.npz'
    cp=OLD/'tiny_finish01/blend10_bce_bn_recalibrated.pt'
    edfs=[OLD/'tiny_finish01'/f'blend10_bce_bn_after_m{i}.edf' for i in range(8)]
    parents=[inputs,cp,BASE/'p183_rpw_adaptation_v1/rpw_adapter.py',Path(__file__),*edfs]
    save('PROTOCOL.json',dict(status='fixed_before_training',input_sha256={str(p):sha(p) for p in parents},
        scope='training-only frozen-encoder readout diagnostic',seed=seed,steps_each=200,
        cases=['blind_centered','owner_residual_centered'],decoder='same public ConvBNReLU/GAP/FC',
        messages=8,bits=30,clean_windows=1,reference_conditioned_gain=400,
        no_development_selection=True,no_new_signal_access=True,
        followup_gate='owner final bit>=95% and exact>=4/8 after fixed200 steps',
        downstream_task_training=False,upstream='https://github.com/qintianyang/RPW-EEG'))
    with np.load(inputs) as z:
        x=torch.from_numpy(z['x'].copy());bits=torch.from_numpy(z['bits'].copy())
        low=torch.from_numpy(z['low_uv'].copy()*1e-6);high=torch.from_numpy(z['high_uv'].copy()*1e-6)
    original=torch.load(cp,map_location='cpu',weights_only=False)['model']
    mean=original['normalizer.mean_v'];scale=original['normalizer.scale_v']
    y=torch.from_numpy(np.stack([np.stack([s.data*1e-6 for s in edfio.read_edf(p).signals]) for p in edfs]))
    blind=(y-mean)/scale
    residual=(y-x)/scale/.0025
    blind=blind-blind.mean(-1,keepdim=True)
    residual=residual-residual.mean(-1,keepdim=True)
    projector=PhysicalBudgetProjector(1280,low,high)
    quality=projector.metrics(x,y)
    capmax={k:float(v.max()) for k,v in quality.items() if k.endswith('prd_percent')}
    assert capmax['global_ac_prd_percent']<=.25 and capmax['max_channel_ac_prd_percent']<=.5 and capmax['band_8_30_prd_percent']<=1.
    report=dict(actual_EDF_inputs=True,zero_mean_decoder_inputs=True,quality_caps=capmax,
        blind=geometry(blind),reference_residual=geometry(residual),
        residual_host_RMS_ratio=float((y-x).square().mean().sqrt()/(x-x.mean(-1,keepdim=True)).square().mean().sqrt()),
        distinct_readback_arrays=len({hashlib.sha256(t.numpy().tobytes()).hexdigest() for t in y}))
    save('initial_geometry.json',report);log(event='geometry',**report)
    random.seed(seed);np.random.seed(seed);torch.manual_seed(seed)
    initial=PublicDecoder(ModelConfig()).state_dict()
    cases=[]
    for name,value in [('blind_centered',blind),('owner_residual_centered',residual)]:
        model=PublicDecoder(ModelConfig());model.load_state_dict(copy.deepcopy(initial))
        inp=value.unsqueeze(1).float();opt=torch.optim.Adam(model.parameters(),lr=.001)
        history=[]
        for step in range(1,201):
            model.train();opt.zero_grad(set_to_none=True)
            logits=model(inp);loss=F.binary_cross_entropy_with_logits(logits,bits)
            loss.backward();opt.step()
            if step in (1,25,100,200):
                model.eval()
                with torch.no_grad():score=metrics(model(inp),bits)
                row=dict(case=name,step=step,train=metrics(logits.detach(),bits),eval=score,seconds=time.monotonic()-start)
                history.append(row);save(name+'_progress.json',row);log(event='checkpoint',**row)
        # Refit only BN buffers on the same declared training inputs; parameters fixed.
        for m in model.modules():
            if isinstance(m,torch.nn.modules.batchnorm._BatchNorm):m.momentum=1.
        model.train()
        with torch.no_grad():model(inp)
        model.eval()
        with torch.no_grad():score=metrics(model(inp),bits)
        torch.save(dict(model=model.state_dict(),case=name,steps=200),OUT/(name+'.pt'))
        item=dict(case=name,history=history,final_training_EDF=score)
        cases.append(item);save(name+'_results.json',item)
    owner=cases[1]['final_training_EDF']
    result=dict(status='complete',fixed_evidence_geometry=report,cases=cases,
        owner_followup_gate=owner['bit_correct']>=228 and owner['exact']>=4,
        source_encoder_frozen=True,training_only=True,new_payload_validation=False,
        runtime_seconds=time.monotonic()-start,torch=torch.__version__,cpu_threads=2)
    save('RESULT.json',result);log(event='complete',gate=result['owner_followup_gate'],cases=[c['final_training_EDF'] for c in cases],seconds=result['runtime_seconds'])


if __name__=='__main__':
    awake=ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
    try:main()
    except BaseException:save('FAILURE.json',dict(traceback=traceback.format_exc()));raise
    finally:
        if awake:ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
