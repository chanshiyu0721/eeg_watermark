"""One training-only decoder BN check; preserves the declared joint-run result.

The original stage-B checkpoint calibrates BatchNorm using the eight fixed
stage-A messages even though stage B trains on random native-30 messages. This
diagnostic changes only decoder BN buffers, using fixed random training messages,
and reuses the already issued and observed actual DEV EDF files.
"""
from pathlib import Path
import os, sys
HERE = Path(__file__).resolve().parent
RUN = HERE / 'owner_train02'
OUT = RUN / 'decoder_BN_random_message_diagnostic'
sys.dont_write_bytecode = True
for key in ('TEMP', 'TMP', 'TMPDIR', 'TORCH_HOME'):
    path = RUN / 'cache' / key.lower()
    path.mkdir(parents=True, exist_ok=True)
    os.environ[key] = str(path)
for key in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS'):
    os.environ[key] = '2'
sys.path.insert(0, str(HERE / 'vendor'))
import hashlib, json, time
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
import edfio
from scipy.signal import ellip, sosfilt
from rpw_adapter import BudgetAdaptedRPW, FrozenNormalization, ModelConfig, EDF16STE
from fast_projector import FixedTrainingProjector


def stats(logits, bits):
    predicted = logits >= 0
    return dict(bit_correct=int((predicted == bits.bool()).sum()), bit_n=bits.numel(),
                exact=int((predicted == bits.bool()).all(1).sum()), messages=len(bits),
                bce=float(F.binary_cross_entropy_with_logits(logits, bits)))


def attack(x, condition, matrix):
    y = x if condition == 'identity' else x @ matrix
    return y - y.mean(dim=-2, keepdim=True)


def features(y, clean, scale):
    z = (y - clean) / scale / .0025
    return (z - z.mean(-1, keepdim=True)).unsqueeze(1).float()


def edf_read(path):
    return torch.from_numpy(np.stack([s.data * 1e-6 for s in edfio.read_edf(path).signals]))


def main():
    start = time.monotonic()
    assert not OUT.exists(), 'Never overwrite a completed or partial diagnostic'
    original = json.loads((RUN / 'RESULT.json').read_text(encoding='utf-8'))
    assert original['status'] == 'complete' and original['stageB'] is not None
    OUT.mkdir()
    old = HERE.parent / 'p185_rpw_native30_real_dev_v1'
    with np.load(old / 'train_common_prepared.npz') as z:
        clean = torch.from_numpy(z['clean'].copy())
        low = torch.from_numpy(z['low_uv'].copy() * 1e-6)
        high = torch.from_numpy(z['high_uv'].copy() * 1e-6)
    with np.load(old / 'development_prepared.npz') as z:
        dev = torch.from_numpy(z['clean'].copy())
    norm_values = json.loads((old / 'carrier_normalization.json').read_text(encoding='utf-8'))
    norm = FrozenNormalization(norm_values['mean_v'], norm_values['std_centered_rms_v'], ['A01T', 'A02T'])
    projector = FixedTrainingProjector(clean, low, high)
    model = BudgetAdaptedRPW(norm, projector, ModelConfig(native_input_scale=1.))
    checkpoint = torch.load(RUN / 'checkpoint_800.pt', map_location='cpu', weights_only=False)
    model.encoder.load_state_dict(checkpoint['encoder'])
    model.decoder.load_state_dict(checkpoint['decoder'])
    model.normalizer.load_state_dict(checkpoint['normalizer'])
    model.eval()
    original_parameters = {name: p.detach().clone() for name, p in model.named_parameters()}
    encoder_buffers = {name: p.detach().clone() for name, p in model.encoder.named_buffers()}
    meta = json.loads((RUN / 'run_metadata.json').read_text(encoding='utf-8'))
    qlo, qhi = meta['train_query_range_v']
    query_grid = EDF16STE(torch.tensor(qlo, dtype=torch.float64), torch.tensor(qhi, dtype=torch.float64))
    sos = ellip(5, 1.3, 50, [1.7, 32.5], btype='bandpass', fs=160, output='sos')
    matrix = torch.from_numpy(sosfilt(sos, np.eye(1280), axis=-1).copy())
    # Only decoder BatchNorm buffers are recalibrated; encoder stays frozen/eval.
    model.decoder.train()
    for module in model.decoder.modules():
        if isinstance(module, nn.modules.batchnorm._BatchNorm):
            module.momentum = 1 / 16
    rng = np.random.default_rng(19154)
    with torch.no_grad():
        for n in range(16):
            ids = np.arange(n * 8, (n + 1) * 8) % len(clean)
            x = clean[ids]
            bits = torch.from_numpy(rng.integers(0, 2, (8, 30)).astype(np.float32))
            projector.set_context(ids)
            xn = norm.normalize(x)
            native = norm.inverse(xn + model.encoder(xn, bits))
            released = projector(x, native)['released_v']
            condition = 'identity' if n % 2 else 'elliptic'
            observed = query_grid(attack(released, condition, matrix))
            model.decoder(features(observed, attack(x, condition, matrix), norm.scale_v))
    model.decoder.eval()
    assert all(torch.equal(value, dict(model.named_parameters())[name]) for name, value in original_parameters.items())
    assert all(torch.equal(value, dict(model.encoder.named_buffers())[name]) for name, value in encoder_buffers.items())
    bits = torch.from_numpy(np.random.default_rng(19153).integers(0, 2, (64, 30)).astype(np.float32))
    ix = np.repeat(np.arange(8), 8)
    results = {}
    files = {}
    with torch.no_grad():
        for condition in ('identity', 'elliptic'):
            values = []
            for first in range(0, 64, 8):
                paths = [RUN / 'DEV_800' / f'{condition}_{i:03d}.edf' for i in range(first, first + 8)]
                observed = torch.stack([edf_read(path) for path in paths])
                files.update({str(path.relative_to(RUN)): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths})
                reference = attack(dev[ix[first:first + 8]], condition, matrix)
                values.append(model.decoder(features(observed, reference, norm.scale_v)))
            results[condition] = stats(torch.cat(values), bits)
    torch.save(model.decoder.state_dict(), OUT / 'decoder_buffers_calibrated.pt')
    output = dict(status='complete',analysis_role='single post-training mechanism diagnostic',
                  declaration=str(RUN / 'BN_DIAGNOSTIC_DECLARATION.json'),
                  all_trainable_parameters_bit_identical=True,encoder_buffers_bit_identical=True,
                  update='decoder BatchNorm running statistics only',train_sources=['A01T','A02T'],
                  calibration_batches=16,calibration_exposures=128,calibration_seed=19154,
                  no_optimizer_steps=True,reused_actual_EDF=True,conditions=results,
                  original_conditions=original['stageB']['conditions'],
                  replaces_original_result=False,source='A03T observed development',
                  independent_confirmation=False,downstream_task_training=False,
                  seconds=time.monotonic()-start,received_EDF_sha256=files)
    (OUT / 'RESULT.json').write_text(json.dumps(output, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k:v for k,v in output.items() if k != 'received_EDF_sha256'}, indent=2))


if __name__ == '__main__':
    torch.set_num_threads(2)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    main()
