"""Finite public-structure RPW encoder training for reference-assisted identity.

Eight registered native 30-bit codewords are learned first. A predeclared
usability gate controls a second random-30-bit stage. True EDF scoring is used
at checkpoints; this is development, not the 112s/40s attribution confirmation.
"""
from pathlib import Path
import os,sys
HERE=Path(__file__).resolve().parent;BASE=HERE.parent
OUT=HERE/'owner_train02'
# A prior interrupted launch created this empty directory before training began.
# Reuse only an empty directory, and never overwrite an actual run.
if OUT.exists():
    assert not any(p.is_file() for p in OUT.rglob('*')),f'Existing nonempty run: {OUT}'
else:
    OUT.mkdir(parents=True)
sys.dont_write_bytecode=True
for k in ('TEMP','TMP','TMPDIR','MPLCONFIGDIR','TORCH_HOME','NUMBA_CACHE_DIR'):
    d=OUT/'cache'/k.lower();d.mkdir(parents=True,exist_ok=True);os.environ[k]=str(d)
for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[k]='2'
sys.path.insert(0,str(HERE/'vendor'))
import copy,ctypes,hashlib,json,random,time,traceback
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from scipy.signal import ellip,sosfilt
import edfio
from rpw_adapter import (BudgetAdaptedRPW,FrozenNormalization,ModelConfig,native_recipient_codebook,EDF16STE)
from fast_projector import FixedTrainingProjector
torch.set_num_threads(2);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
OLD=BASE/'p185_rpw_native30_real_dev_v1'
SEED=19151;GAIN=.0025;START=time.monotonic()


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,z):
    p=OUT/name;t=p.with_suffix(p.suffix+'.writing');t.write_text(json.dumps(z,indent=2,allow_nan=False)+'\n',encoding='utf-8');t.replace(p)
def log(**z):
    row=dict(time_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),**z)
    print(json.dumps(row,allow_nan=False),flush=True)
    with (OUT/'events.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(row,allow_nan=False)+'\n')
def seed():random.seed(SEED);np.random.seed(SEED);torch.manual_seed(SEED)
def stat(logits,bits,codes):
    hard=logits>=0
    cls=(logits@(2*codes-1).T).argmax(1)
    truth=(bits[:,None,:]==codes[None,:,:]).all(2)
    registered=truth.any(1)
    return dict(bit_correct=int((hard==bits.bool()).sum()),bit_n=bits.numel(),
        exact=int((hard==bits.bool()).all(1).sum()),messages=len(bits),
        registered_ID_correct=int((cls[registered]==truth[registered].float().argmax(1)).sum()),
        registered_ID_n=int(registered.sum()),bce=float(F.binary_cross_entropy_with_logits(logits,bits)))
def attack(x,condition,matrix):
    y=x if condition=='identity' else x@matrix
    return y-y.mean(dim=-2,keepdim=True)
def ranges(x,matrix):
    z=torch.cat((attack(x,'identity',matrix),attack(x,'elliptic',matrix)))
    mn=z.amin((0,2));mx=z.amax((0,2));margin=torch.maximum(torch.full_like(mn,5e-6),.05*(mx-mn))
    return torch.floor((mn-margin)*1e6)/1e6,torch.ceil((mx+margin)*1e6)/1e6
def features(y,clean,scale):
    z=(y-clean)/scale/GAIN
    return (z-z.mean(-1,keepdim=True)).unsqueeze(1).float()
def generate(model,x,bits):
    xn=model.normalizer.normalize(x)
    native=model.normalizer.inverse(xn+model.encoder(xn,bits))
    return model.projector(x,native)
def actual_edf(v,lo,hi,path):
    edfio.Edf([edfio.EdfSignal(v[c].numpy()*1e6,160,label=f'EEG{c}',physical_dimension='uV',
        physical_range=(float(lo[c]*1e6),float(hi[c]*1e6))) for c in range(8)]).write(path)
    return torch.from_numpy(np.stack([s.data*1e-6 for s in edfio.read_edf(path).signals]))


def evaluate(model,clean,low,high,matrix,qlo,qhi,codes,label,random_messages=False):
    folder=OUT/label;folder.mkdir(exist_ok=False)
    # Eight fixed unseen-carrier DEV windows and all eight registered identities.
    ix=np.repeat(np.arange(8),8);x=clean[ix]
    if random_messages:
        rng=np.random.default_rng(19153);bits=torch.from_numpy(rng.integers(0,2,(64,30)).astype(np.float32))
    else:bits=codes.repeat(8,1)
    projector=FixedTrainingProjector(clean,low,high)
    prior=model.projector;model.projector=projector;model.eval()
    results={c:[] for c in ('identity','elliptic')};qualities=[];max_parity=0.;stored=[]
    with torch.no_grad():
        for start in range(0,64,8):
            ids=ix[start:start+8];projector.set_context(ids)
            r=generate(model,x[start:start+8],bits[start:start+8]);ys=[]
            for j in range(8):
                p=folder/f'issued_{start+j:03d}.edf';y=actual_edf(r['projected_v'][j],low,high,p);ys.append(y)
                max_parity=max(max_parity,float((y-r['released_v'][j]).abs().max()))
                stored.append(dict(path=str(p.relative_to(OUT)),sha256=sha(p)))
            ys=torch.stack(ys)
            qm=projector.metrics(x[start:start+8],ys)
            qualities.append({k:float(v.max()) for k,v in qm.items() if k.endswith('prd_percent')})
            for condition in results:
                raw=attack(ys,condition,matrix);pred=attack(x[start:start+8],condition,matrix)
                obs=torch.stack([actual_edf(raw[j],qlo,qhi,folder/f'{condition}_{start+j:03d}.edf') for j in range(8)])
                results[condition].append(model.decoder(features(obs,pred,model.normalizer.scale_v)))
    model.projector=prior
    assert max_parity<1e-14,max_parity
    capmax={k:max(v[k] for v in qualities) for k in qualities[0]}
    assert capmax['global_ac_prd_percent']<=.25 and capmax['max_channel_ac_prd_percent']<=.5 and capmax['band_8_30_prd_percent']<=1.
    answer=dict(actual_EDF=True,oracle_processed_clean_reference=True,
        native_blind_decode=False,reference_cancellation='known diagnostic response; not unknown-response deployment',
        zero_DC_features=True,source='BCI2a/A03T development',independent_confirmation=False,
        max_EDF_STE_parity_v=max_parity,cap_max=capmax,
        conditions={c:stat(torch.cat(v),bits,codes) for c,v in results.items()},issued_files=stored)
    save(label+'_results.json',answer)
    return answer


def main():
    seed()
    parents=[OLD/'train_common_prepared.npz',OLD/'development_prepared.npz',OLD/'carrier_normalization.json',
             HERE/'vendor/rpw_adapter.py',HERE/'vendor/fast_projector.py',Path(__file__)]
    protocol=dict(status='declared_before_joint_training',input_sha256={str(p):sha(p) for p in parents},
        upstream='https://github.com/qintianyang/RPW-EEG',model='public repaired Dvmark encoder and Hidden decoder width32 depth4',
        changes=['native_input_scale=1 residual form','zero temporal DC projection',
                 'readout common-average reference across channels at each time (CAR)',
                 'owner-assisted amplified residual decoder with known training attack response',
                 'BCE native30 + .25 registry-codeword CE at stageA'],
        seed=SEED,training_sources=['A01T','A02T'],development_sources=['A03T'],
        native_bits=30,registered_codebook_seed=183,stageA_steps=400,stageB_steps=400,
        microbatch=8,optim='Adam1e-3',cpu_threads=2,no_GPU=True,
        channels=8,sampling_rate=160,training_window_seconds=8,caps_percent=[.25,.5,1.],
        decoder_feature_gain=400,training_attacks=['identity','causal_elliptic_order5_rp1.3_rs50_1.7to32.5Hz'],
        stageB_gate='Both DEV conditions: bit>=.95, exact>=.5, registryID>=.95; else stop atA400',
        checkpoint_selection='Only declared A400 and, if gate permits,B800; DEV exact then bit then earlier',
        scope='Carrier-learning development; whole112s issuance/common40s/48s attribution not yet evaluated',
        corrected_interrupted_run='owner_train01 stopped before DEV after actual CAR operator was identified',
        raw_new_confirmation_access=False,downstream_task_training=False)
    save('PROTOCOL.json',protocol)
    with np.load(OLD/'train_common_prepared.npz') as z:
        train=torch.from_numpy(z['clean'].copy());low=torch.from_numpy(z['low_uv'].copy()*1e-6);high=torch.from_numpy(z['high_uv'].copy()*1e-6)
    with np.load(OLD/'development_prepared.npz') as z:
        dev=torch.from_numpy(z['clean'].copy());dlo=torch.from_numpy(z['low_uv'].copy()*1e-6);dhi=torch.from_numpy(z['high_uv'].copy()*1e-6)
    nr=json.loads((OLD/'carrier_normalization.json').read_text(encoding='utf-8'))
    norm=FrozenNormalization(nr['mean_v'],nr['std_centered_rms_v'],['A01T','A02T'])
    projector=FixedTrainingProjector(train,low,high)
    model=BudgetAdaptedRPW(norm,projector,ModelConfig(native_input_scale=1.))
    sos=ellip(5,1.3,50,[1.7,32.5],btype='bandpass',fs=160,output='sos')
    matrix=torch.from_numpy(sosfilt(sos,np.eye(1280),axis=-1).copy())
    qlo,qhi=ranges(train,matrix);dqlo,dqhi=ranges(dev,matrix)
    query_grid=EDF16STE(qlo,qhi)
    codes=native_recipient_codebook(183)
    opt=torch.optim.Adam(list(model.encoder.parameters())+list(model.decoder.parameters()),lr=.001)
    rng=np.random.default_rng(19152);history=[];stageA=None;stageB=None
    save('run_metadata.json',dict(encoder_parameters=sum(p.numel() for p in model.encoder.parameters()),
        decoder_parameters=sum(p.numel() for p in model.decoder.parameters()),
        train_windows=len(train),dev_windows=len(dev),train_query_range_v=[qlo.tolist(),qhi.tolist()],
        dev_query_range_v=[dqlo.tolist(),dqhi.tolist()],codebook=codes.int().tolist()))
    for step in range(1,801):
        assert time.monotonic()-START<2400,'Bounded learning wall limit'
        ids=rng.integers(0,len(train),8);x=train[ids];projector.set_context(ids)
        bits=codes if step<=400 else torch.from_numpy(rng.integers(0,2,(8,30)).astype(np.float32))
        condition='identity' if step%2 else 'elliptic'
        model.train();opt.zero_grad(set_to_none=True)
        r=generate(model,x,bits)
        observed=query_grid(attack(r['released_v'],condition,matrix))
        clean_pred=attack(x,condition,matrix)
        logits=model.decoder(features(observed,clean_pred,norm.scale_v))
        loss=F.binary_cross_entropy_with_logits(logits,bits)
        if step<=400:loss=loss+.25*F.cross_entropy(logits@(2*codes-1).T/30,torch.arange(8))
        loss.backward();opt.step()
        if step in (1,25,100,200,400,500,600,800):
            row=dict(step=step,condition=condition,train=stat(logits.detach(),bits,codes),loss=float(loss.detach()),seconds=time.monotonic()-START)
            history.append(row);save('progress.json',row);log(event='checkpoint',**row)
        if step%50==0:
            temp=OUT/'last.writing.pt';torch.save(dict(model=model.state_dict(),optimizer=opt.state_dict(),step=step),temp);temp.replace(OUT/'last.pt')
        if step in (400,800):
            # Same declared training-only BN calibration, no DEV buffer fitting.
            for m in model.modules():
                if isinstance(m,nn.modules.batchnorm._BatchNorm):m.momentum=1/16
            model.train()
            with torch.no_grad():
                for n in range(16):
                    ii=np.arange(n*8,(n+1)*8)%len(train);projector.set_context(ii);xx=train[ii]
                    bb=codes;rr=generate(model,xx,bb);cc='identity' if n%2 else 'elliptic'
                    oo=query_grid(attack(rr['released_v'],cc,matrix))
                    model.decoder(features(oo,attack(xx,cc,matrix),norm.scale_v))
            for m in model.modules():
                if isinstance(m,nn.modules.batchnorm._BatchNorm):m.momentum=.1
            cp=dict(encoder=model.encoder.state_dict(),decoder=model.decoder.state_dict(),normalizer=norm.state_dict(),step=step,
                cfg=dict(bits=30,channels=32,depth=4,encoder='dvmark',native_input_scale=1.,native_watermark_scale=1.),codebook=codes)
            torch.save(cp,OUT/f'checkpoint_{step}.pt')
            evaluated=evaluate(model,dev,dlo,dhi,matrix,dqlo,dqhi,codes,f'DEV_{step}',random_messages=step==800)
            log(event='actual_DEV',step=step,conditions=evaluated['conditions'],capmax=evaluated['cap_max'])
            if step==400:
                stageA=evaluated
                gate=all(z['bit_correct']/z['bit_n']>=.95 and z['exact']/z['messages']>=.5 and z['registered_ID_correct']/z['registered_ID_n']>=.95
                         for z in stageA['conditions'].values())
                save('stageA_gate.json',dict(pass_gate=gate,criteria=protocol['stageB_gate'],conditions=stageA['conditions']))
                if not gate:break
            else:stageB=evaluated
    result=dict(status='complete',stageA=stageA,stageB=stageB,history=history,
        stageB_started=stageB is not None,steps=history[-1]['step'],train_window_exposures=history[-1]['step']*8,
        runtime_seconds=time.monotonic()-START,usable_native_blind_SOTA_comparison=False,
        learned_owner_assisted_carrier=True,independent_confirmation=False)
    save('RESULT.json',result);log(event='complete',steps=result['steps'],seconds=result['runtime_seconds'])


if __name__=='__main__':
    awake=ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
    try:main()
    except BaseException:save('FAILURE.json',dict(traceback=traceback.format_exc()));raise
    finally:
        if awake:ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
