"""Fixed A400 encoder for 112-s issuance or arbitrary longer task epochs.

Input EEG uses the fixed eight-channel order in physical volts. The caller
supplies a clean actual-EDF readback, shared physical limits in microvolts and
the actual PRD of its same-source comparison carrier. No model fitting occurs.
"""
from pathlib import Path
import gzip,hashlib,io,math
import edfio
import numpy as np
import torch
import common_owner_comparison as m

CHECKPOINT_SHA256='ad1197faded4562adf55fc1ad1e270e21ad2742b825da3dac3d062ddc338a18a'


class FixedA400Carrier:
    def __init__(self, checkpoint=None):
        self.checkpoint=Path(checkpoint)if checkpoint else m.CHECKPOINT
        assert m.sha(self.checkpoint)==CHECKPOINT_SHA256,'Expected the fixed A400 checkpoint'
        state=torch.load(self.checkpoint,map_location='cpu',weights_only=False)
        self.encoder=m.PublicEncoder(m.ModelConfig(native_input_scale=1.))
        self.encoder.load_state_dict(state['encoder']);self.encoder.eval()
        self.normalization=state['normalizer']
        self.registered_bits=state['codebook'].int().numpy().copy()
        self.mean=self.normalization['mean_v'].reshape(1,8,1)
        self.scale=self.normalization['scale_v'].reshape(1,8,1)

    def _blocks(self, values, bits):
        tensor=torch.from_numpy(np.ascontiguousarray(values,dtype=np.float64))
        messages=torch.from_numpy(np.repeat(bits[None,:],len(values),axis=0).astype(np.float32))
        with torch.no_grad():
            xn=((tensor-self.mean)/self.scale).unsqueeze(1).float()
            delta=self.encoder(xn,messages)[:,0].double()*self.scale
            delta-=delta.mean(-1,keepdim=True)
        return delta.numpy()

    def residual(self, clean_v, bits, block_samples=640):
        """Encode fixed 4-s blocks; a final shorter block uses its real length."""
        clean=np.asarray(clean_v,dtype=np.float64)
        bits=np.asarray(bits,dtype=np.int64)
        assert clean.ndim==2 and clean.shape[0]==8 and clean.shape[1]>=64
        assert bits.shape==(30,)and np.all((bits==0)|(bits==1))
        assert np.isfinite(clean).all() and block_samples>=64
        n_full,remainder=divmod(clean.shape[1],block_samples)
        chunks=[]
        if n_full:
            blocks=clean[:,:n_full*block_samples].reshape(8,n_full,block_samples).transpose(1,0,2)
            delta=self._blocks(blocks,bits)
            chunks.append(delta.transpose(1,0,2).reshape(8,n_full*block_samples))
        if remainder:
            # A short final block is not padded or exposed as extra observation.
            chunks.append(self._blocks(clean[:,-remainder:][None],bits)[0])
        return np.concatenate(chunks,axis=1)

    def encode_at_matched_prd(self, clean_v, bits, physical_limits_uv, target_global_prd_percent):
        """Return the pre-EDF signal and matched virtual readback, or infeasibility."""
        x=np.asarray(clean_v,dtype=np.float64)
        limits=tuple(np.asarray(v,dtype=np.float64)for v in physical_limits_uv)
        assert float(target_global_prd_percent)>0
        ideal,detail=m.match(x,self.residual(x,bits),limits,float(target_global_prd_percent))
        if ideal is None:return dict(feasible=False,matching=detail)
        actual=m.api.p.virtual_edf(ideal,limits)
        return dict(feasible=True,pre_EDF_v=ideal,virtual_readback_v=actual,matching=detail,
                    checkpoint_sha256=CHECKPOINT_SHA256,block_samples=640,
                    message=np.asarray(bits).tolist(),native_phase_angle_not_applicable=True)

    def issue_actual_edf(self, clean_v, bits, physical_limits_uv, target_global_prd_percent,
                         folder, name='a400_issued.edf'):
        result=self.encode_at_matched_prd(clean_v,bits,physical_limits_uv,target_global_prd_percent)
        if not result['feasible']:return result
        folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
        receipts=[]
        if result['pre_EDF_v'].shape[-1]%160==0:
            actual,_=m.edf.edf_roundtrip(result['pre_EDF_v'],physical_limits_uv,name,folder,receipts,True,m.CHANNELS)
        else:
            # EDF's default one-second record cannot store e.g. a 400-sample
            # (2.5-s) task epoch. Use the exact common divisor without padding.
            ideal=result['pre_EDF_v'];low,high=physical_limits_uv
            duration=math.gcd(ideal.shape[-1],160)/160
            signals=[edfio.EdfSignal(ideal[c]*1e6,160,label=m.CHANNELS[c],physical_dimension='uV',
                physical_range=(float(low[c]),float(high[c])))for c in range(8)]
            buffer=io.BytesIO();edfio.Edf(signals,data_record_duration=duration).write(buffer)
            raw=buffer.getvalue();actual,_=m.edf.parse_edf(raw,m.CHANNELS)
            assert actual.shape==ideal.shape
            compressed=gzip.compress(raw,compresslevel=5,mtime=0);path=folder/(name+'.gz')
            if path.exists():assert path.read_bytes()==compressed,'Existing task EDF differs'
            else:path.write_bytes(compressed)
            receipts.append(dict(name=name,raw_sha256=hashlib.sha256(raw).hexdigest(),
                gzip_sha256=hashlib.sha256(compressed).hexdigest(),raw_bytes=len(raw),
                data_record_duration=duration,channels=list(m.CHANNELS),sampling_rate=160,
                no_padding=True,saved=True))
        assert np.max(np.abs(actual-result['virtual_readback_v']))<1e-14
        quality=m.api.p.quality(np.asarray(clean_v),actual)
        assert target_global_prd_percent/1.001<=quality['global_ac_prd']<=target_global_prd_percent
        assert quality['global_ac_prd']<=.25 and quality['max_channel_ac_prd']<=.5 and quality['band_prd']<=1.
        return dict(feasible=True,readback_v=actual,quality=quality,EDF_receipt=receipts[-1],
                    matching=result['matching'],checkpoint_sha256=CHECKPOINT_SHA256,
                    issued_file=str(folder/(name+'.gz')))
