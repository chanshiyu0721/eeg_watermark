"""Analyze the serialized common-receiver scores and issued-waveform geometry."""
from pathlib import Path
import numpy as np
import common_owner_comparison as m


def geometry(source):
    folder = m.OUT / 'issuance' / source
    record = m.load(folder / 'ISSUANCE.json')
    clean = m.read(m.P190 / 'sources' / source / 'clean.edf.gz')
    values = [m.read(folder / f'r{i:02d}_issued.edf.gz') for i in range(24)]
    residuals = np.asarray([y - clean for y in values])
    X = residuals[:8].reshape(8, -1)
    eig = np.linalg.eigvalsh(X @ X.T)
    distances = []
    for index in range(8, 24):
        parent = record['rows'][index]['metadata']['parent']
        a, b = residuals[parent].ravel(), residuals[index].ravel()
        cosine = float(a @ b / (np.linalg.norm(a) * np.linalg.norm(b)))
        distances.append(dict(index=index, parent=parent,
            native_hamming=record['rows'][index]['metadata']['hamming_to_parent'],
            actual_sample_identity=bool(np.array_equal(values[index], values[parent])),
            changed_sample_fraction=float(np.mean(values[index] != values[parent])),
            relative_residual_distance=float(np.linalg.norm(b-a) / np.linalg.norm(a)),
            waveform_residual_angle=float(np.arccos(np.clip(cosine,-1,1)))))
    registered_pairs = []
    for i in range(8):
        for j in range(i+1, 8):
            cosine = float(X[i] @ X[j] / (np.linalg.norm(X[i]) * np.linalg.norm(X[j])))
            registered_pairs.append(dict(left=i, right=j,
                actual_sample_identity=bool(np.array_equal(values[i], values[j])),
                waveform_residual_angle=float(np.arccos(np.clip(cosine,-1,1)))))
    return dict(source=source, native_registered_min_hamming=m.load(m.OUT/'PROTOCOL.json')['native_registered_min_hamming'],
        registered_residual_stable_rank=float(eig.sum()/eig[-1]),
        registered_residual_gram_eigenvalues=eig.tolist(),
        maximum_registered_pair_budget_relative_spread=max(
            r['matching']['registered_pair_relative_spread'] for r in record['rows'][:8]),
        registered_pairs=registered_pairs, independent_unknown_parent_distances=distances,
        all_messages_caps_pass=all(r['feasible'] for r in record['rows']),
        unknown_angles_are_waveform_measurements_not_phase_code_angles=True)


def main():
    groups = {source:m.load(m.OUT / 'raw' / f'{source}.json.gz') for source in m.SOURCES}
    assert all(g['status']=='complete' and len(g['rows'])==81 for g in groups.values())
    m.analyze(groups)
    distances = {source:geometry(source) for source in m.SOURCES}
    m.save(m.OUT / 'ACTUAL_ISSUED_GEOMETRY.json', dict(status='complete', sources=distances))
    summary = m.load(m.OUT / 'SUMMARY.json')
    small = {}
    for method, entry in summary['methods'].items():
        chosen = entry['selected']
        small[method] = dict(index=chosen['index'], config=chosen['config'], threshold=chosen['threshold'],
                            fit=chosen['fit'], select=chosen['select'])
    print(__import__('json').dumps(dict(status='complete', selected=small,
        geometry={source:{k:v for k,v in value.items() if k not in (
            'registered_pairs','independent_unknown_parent_distances','registered_residual_gram_eigenvalues')}
                  for source,value in distances.items()}), indent=2))


if __name__ == '__main__':
    main()
