"""Separate carrier learning, finite-ID readout and full native payload gates."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
RUN = HERE / 'owner_train02'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    result_path = RUN / 'RESULT.json'
    if not result_path.exists():
        raise SystemExit('Training has not produced a terminal RESULT.json')
    result = json.loads(result_path.read_text(encoding='utf-8'))
    protocol = json.loads((RUN / 'PROTOCOL.json').read_text(encoding='utf-8'))
    stages = {}
    for name in ('stageA', 'stageB'):
        stage = result.get(name)
        if stage is None:
            continue
        conditions = {}
        for condition, values in stage['conditions'].items():
            conditions[condition] = {
                **values,
                'bit_accuracy': values['bit_correct'] / values['bit_n'],
                'exact_message_rate': values['exact'] / values['messages'],
                'registered_ID_accuracy': (
                    values['registered_ID_correct'] / values['registered_ID_n']
                    if values['registered_ID_n'] else None
                ),
            }
        stages[name] = {
            'conditions': conditions,
            'actual_EDF': stage['actual_EDF'],
            'cap_max_percent': stage['cap_max'],
            'max_EDF_STE_parity_v': stage['max_EDF_STE_parity_v'],
            'payload_95pct_bits_50pct_exact': all(
                v['bit_accuracy'] >= .95 and v['exact_message_rate'] >= .5
                for v in conditions.values()
            ),
            # Descriptive finite-ID result; this does not replace the declared gate.
            'finite_registry_ID_at_least_95pct': (
                all(v['registered_ID_accuracy'] >= .95 for v in conditions.values())
                if all(v['registered_ID_accuracy'] is not None for v in conditions.values())
                else None
            ),
            'carrier_windows': 8,
            'registered_messages_per_window': 8 if name == 'stageA' else 0,
            'messages_per_window': 8,
            'message_distribution': (
                'all eight fixed registered native30 codewords' if name == 'stageA'
                else '64 unseen uniform random 30bit messages'
            ),
            'independent_people': 1,
            'source': 'BCI2a/A03T development',
        }
    output = {
        'run': str(RUN),
        'status': result['status'],
        'stages': stages,
        'steps': result['steps'],
        'window_exposures': result['train_window_exposures'],
        'runtime_seconds': result['runtime_seconds'],
        'seed': protocol['seed'],
        'access': 'owner-assisted with known diagnostic response',
        'native_blind_SOTA_comparison': False,
        'whole112s_issuance_and_common40s_attribution': False,
        'actual_PRD_matching_to_classical_arms': False,
        'unknown_response_deployment': False,
        'independent_frozen_confirmation': False,
        'downstream_task_training': False,
        'scope': 'bounded modern carrier-learning development experiment',
        'input_result_sha256': digest(result_path),
        'protocol_sha256': digest(RUN / 'PROTOCOL.json'),
        'checkpoints': {
            p.name: digest(p) for p in sorted(RUN.glob('checkpoint_*.pt'))
        },
    }
    path = RUN / 'ASSESSMENT.json'
    path.write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
