"""Enforce the all-carrier PRD interval, reusing unchanged EDFs and scores."""
from pathlib import Path
import argparse,copy,time
import numpy as np
import torch
import common_owner_dev as d
from a400_carrier import FixedA400Carrier
from dev_capacity import DevelopmentReceiver
import checkpoint_io
m=d.m
OUT=d.HERE/'common_owner_dev02'


def prior_folder(source):
    return(d.OLD if source in('OpenBMI001','OpenBMI003')else d.OUT)/'issuance'/source


def issue(source,carrier,codes,metadata):
    folder=OUT/'issuance'/source;folder.mkdir(parents=True,exist_ok=True);dest=folder/'ISSUANCE.json'
    if dest.exists():
        doc=m.load(dest)
        return[m.read(folder/f'r{i:02d}_issued.edf.gz')for i in range(24)],doc
    oldfolder=prior_folder(source);old=m.load(oldfolder/'ISSUANCE.json')
    original=m.load(m.P190/'issuance'/source/'level100/issuance_summary.json')
    x=m.read(m.P190/'sources'/source/'clean.edf.gz');limits=tuple(np.asarray(v)for v in m.load(m.P190/'sources'/source/'source.json')['limits_uv'])
    rows=[];values=[]
    for i,(bits,info)in enumerate(zip(codes,metadata)):
        row=copy.deepcopy(old['rows'][i]);parent=info['parent'];anchor=original['QID_anchors'][parent]
        q=row['matching']['actual_quality'];value=m.read(oldfolder/f'r{i:02d}_issued.edf.gz')
        reused=anchor/1.001<=q['global_ac_prd']<=anchor
        if reused:
            (folder/f'r{i:02d}_issued.edf.gz').write_bytes((oldfolder/f'r{i:02d}_issued.edf.gz').read_bytes())
        else:
            result=carrier.issue_actual_edf(x,bits,limits,anchor,folder,f'r{i:02d}_issued.edf')
            assert result['feasible'],(source,i,'Global shared-budget matching infeasible')
            value=result['readback_v'];q=result['quality'];row['matching']=result['matching']
            row['matching']['actual_quality']=q
        assert anchor/1.001<=q['global_ac_prd']<=anchor
        lo=anchor/(1+original['actual_registered_relative_spreads'][parent])
        spread=(anchor-min(lo,q['global_ac_prd']))/min(lo,q['global_ac_prd'])
        assert spread<=.001,(source,i,spread)
        row['matching']['registered_pair_relative_spread']=spread
        row['common_anchor']=anchor;row['actual_EDF_reused']=reused
        rows.append(row);values.append(value)
    doc=dict(status='complete',source=source,rows=rows,registered_group_valid=True,
        common_anchor_interval=True,registered_template_group_unchanged=all(r['actual_EDF_reused']for r in rows[:8]),
        protocol_sha256=m.sha(OUT/'PROTOCOL.json'))
    checkpoint_io.save(dest,doc)
    return values,doc


def collect(source,values,issue,metadata):
    dest=OUT/'raw'/f'{source}.json.gz';dest.parent.mkdir(parents=True,exist_ok=True)
    state=m.load(dest)if dest.exists()else dict(rows=[],seconds=0.,EDF_receipts=[])
    if state.get('status')=='complete':return
    role=d.SOURCES[source];p190=m.load(m.P190/'raw'/role/source/'level100/smooth.json.gz')
    oldpath=d.OUT/'raw'/f'{source}.json.gz'
    old=m.load(oldpath)if oldpath.exists()else None
    priorrows={(r['query_index'],r['condition']):r for r in old['rows']}if old else{}
    x=m.read(m.P190/'sources'/source/'clean.edf.gz')
    wrongs=sorted({r['negative_source']for r in p190['rows']if r['kind']=='wrong_source'})
    allvalues=values+[x]+[m.read(m.P190/'sources'/n/'clean.edf.gz')for n in wrongs]
    infos=metadata+[dict(kind='clean',identity=None,parent=None,pressure=False)]+[
        dict(kind='wrong_source',identity=None,parent=None,pressure=False,negative_source=n)for n in wrongs]
    r129=m.api.MatchedFIRReceivers(x,np.asarray(values[:8]));r257=DevelopmentReceiver(x,np.asarray(values[:8]),257)
    rows=state['rows'];done={(r['query_index'],r['condition'])for r in rows};receipts=state['EDF_receipts'];start=time.monotonic()
    for i,(value,info)in enumerate(zip(allvalues,infos)):
        for condition in m.CONDITIONS:
            if(i,condition)in done:continue
            previous=priorrows.get((i,condition))
            unchanged_query=i>=24 or issue['rows'][i]['actual_EDF_reused']
            if issue['registered_template_group_unchanged']and unchanged_query and previous is not None:
                row=copy.deepcopy(previous);row['shared_budget_score_reused']=True
            else:
                limits=tuple(np.asarray(v)for v in p190['query_limits_uv'][condition])
                query,_=m.edf.edf_roundtrip(m.common.transform(value,condition),limits,
                    f'{source}_modern_q{i}_{condition}.edf',dest.parent,receipts,True,m.CHANNELS)
                row=dict(source=source,split=role,query_index=i,condition=condition,**info,
                    issuance_feasible=True,receiver=r129.extract(query),receiver257=r257.extract_all(query),
                    query_raw_sha256=receipts[-1]['raw_sha256'],shared_budget_score_reused=False)
            rows.append(row)
            checkpoint_io.save(dest,dict(status='running',source=source,role=role,rows=rows,EDF_receipts=receipts,
                seconds=state['seconds']+time.monotonic()-start,protocol_sha256=m.sha(OUT/'PROTOCOL.json')))
        if i%4==3:m.event(event='modern_shared_budget_DEV',source=source,queries=len(rows),total=81)
    checkpoint_io.save(dest,dict(status='complete',source=source,role=role,rows=rows,EDF_receipts=receipts,
        seconds=state['seconds']+time.monotonic()-start,protocol_sha256=m.sha(OUT/'PROTOCOL.json'),
        all_carrier_relative_PRD_spread_le_001=True,independent_confirmation=False))
    m.event(event='modern_shared_budget_source_complete',source=source,queries=len(rows))


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--sources',default=','.join(d.SOURCES));args=parser.parse_args()
    torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
    carrier=FixedA400Carrier();codes,metadata,minimum=m.codebook({'codebook':torch.tensor(carrier.registered_bits)})
    protocol=dict(status='all-carrier matched PRD DEV correction before freeze',source_roles=d.SOURCES,
        code_sha256=m.sha(__file__),checkpoint_sha256=m.sha(m.CHECKPOINT),
        actual_PRD_interval='same existing common QID anchor /1.001 <= actual global PRD <= common anchor',
        reused_EDF_if_already_in_interval=True,reuse_scores_only_if_entire_registered_book_and_query_unchanged=True,
        exact_menu=d.EXACT_MENU,legacy_menu=list(m.CONFIGS),presence_gate=.25,
        threshold='D_fit-only nextafter maximum eligible native unknown/clean/wrong negative',
        selection='D_select minimum false accept, maximum registered correct, lowest menu index',
        prior_pairwise_comparison_retained=True,independent_confirmation=False)
    path=OUT/'PROTOCOL.json'
    if path.exists():assert m.load(path)==protocol
    else:checkpoint_io.save(path,protocol)
    for source in args.sources.split(','):
        values,issuefile=issue(source,carrier,codes,metadata);collect(source,values,issuefile,metadata)


if __name__=='__main__':main()
