"""Equal-menu full modern DEV rules: 129/257 legacy and 257 exact readout."""
from pathlib import Path
import argparse
import json
import numpy as np
import common_owner_dev as d
m=d.m
OUT=d.OUT


def family(row):
    if row['kind']=='enrolled':return 'registered'
    if row['kind']=='native_hamming_unknown':return f"native_H{row['hamming_to_parent']}"
    return 'wrong'if row['kind']=='wrong_source'else 'clean'


def value(row,method,rule):
    bank=row['receiver']if rule['taps']==129 else row['receiver257']
    v=bank['methods'][method]['by_ridge'][str(rule['ridge'])]
    eligible=bool(v['eligible']and v['support']>=rule['support']and v['presence']>=.25)
    score=-v['exact_normalized_identity_defect']if rule['readout']=='exact'else v[rule['head']]
    return float(score),eligible,int(v['top'])


def summary(rows,method,rule):
    out={k:dict(n=0,accepted=0)for k in ('registered','native_H1','native_H2','clean','wrong')}
    out['registered'].update(correct=0,misattributed=0)
    for row in rows:
        key=family(row);v=out[key];v['n']+=1
        score,eligible,top=value(row,method,rule)
        accept=eligible and score>=rule['threshold']
        v['accepted']+=int(accept)
        if key=='registered':
            v['correct']+=int(accept and top==row['identity'])
            v['misattributed']+=int(accept and top!=row['identity'])
    out['all_negative_accepted']=sum(v['accepted']for k,v in out.items()if k!='registered')
    return out


def budget_geometry(source):
    folder=OUT/'issuance'/source
    if not folder.exists():folder=(d.OLD if source in('OpenBMI001','OpenBMI003')else d.OUT)/'issuance'/source
    issue=m.load(folder/'ISSUANCE.json')
    detail=dict(source=source,all_24_messages_feasible=all(r['feasible']for r in issue['rows']),
        max_registered_relative_spread=max(r['matching']['registered_pair_relative_spread']for r in issue['rows'][:8]),
        max_actual_PRD={k:max(r['matching']['actual_quality'][k]for r in issue['rows'])for k in
            ('global_ac_prd','max_channel_ac_prd','band_prd')})
    if OUT==d.OUT and source in('OpenBMI001','OpenBMI003'):
        old=m.load(d.OLD/'ACTUAL_ISSUED_GEOMETRY.json')['sources'][source]
        detail['native_unknown_parent_distances']=old['independent_unknown_parent_distances']
    else:
        clean=m.read(m.P190/'sources'/source/'clean.edf.gz')
        values=[m.read(folder/f'r{i:02d}_issued.edf.gz')for i in range(24)]
        distances=[]
        for i in range(8,24):
            parent=issue['rows'][i]['metadata']['parent']
            a,b=(values[parent]-clean).ravel(),(values[i]-clean).ravel()
            cosine=float(a@b/(np.linalg.norm(a)*np.linalg.norm(b)))
            distances.append(dict(index=i,parent=parent,native_hamming=issue['rows'][i]['metadata']['hamming_to_parent'],
                actual_sample_identity=bool(np.array_equal(values[parent],values[i])),
                changed_sample_fraction=float(np.mean(values[parent]!=values[i])),
                relative_residual_distance=float(np.linalg.norm(a-b)/np.linalg.norm(a)),
                waveform_residual_angle=float(np.arccos(np.clip(cosine,-1,1)))))
        detail['native_unknown_parent_distances']=distances
    return detail


def main():
    global OUT
    parser=argparse.ArgumentParser();parser.add_argument('--data-root',type=Path,default=OUT);args=parser.parse_args()
    OUT=args.data_root.resolve()
    data={role:[]for role in d.ROLES};files={}
    for source,role in d.SOURCES.items():
        path=OUT/'raw'/f'{source}.json.gz';obj=m.load(path)
        assert obj['status']=='complete'and len(obj['rows'])==81,(source,obj['status'],len(obj['rows']))
        data[role].extend(obj['rows']);files[str(path)]=m.sha(path)
    outputs={}
    for taps,readout in ((129,'legacy'),(257,'legacy'),(257,'exact')):
        menu=list(m.CONFIGS)if readout=='legacy'else d.EXACT_MENU
        for method in m.api.METHODS:
            configs=[]
            for index,config in enumerate(menu):
                rule=dict(index=index,taps=taps,readout=readout,presence_gate=.25,**config)
                rule.setdefault('head','negative_exact_normalized_identity_defect')
                neg=[value(r,method,rule)[0]for r in data['fit']if r['kind']!='enrolled'and value(r,method,rule)[1]]
                rule['threshold']=(float(np.nextafter(max(neg),np.inf))if neg else
                    float(np.finfo(float).min)if readout=='exact'else 0.)
                rule['eligible_fit_negative_n']=len(neg)
                rule['fit']=summary(data['fit'],method,rule);rule['select']=summary(data['select'],method,rule)
                configs.append(rule)
            chosen=min(configs,key=lambda z:(z['select']['all_negative_accepted'],-z['select']['registered']['correct'],z['index']))
            panels={role:dict(total=summary(rows,method,chosen),
                people={s:summary([r for r in rows if r['source']==s],method,chosen)for s in d.ROLES[role]},
                processing={c:summary([r for r in rows if r['condition']==c],method,chosen)for c in m.CONDITIONS})
                for role,rows in data.items()}
            key=f'{taps}/{method}/{"compatibility"if readout=="legacy"else"exact"}'
            outputs[key]=dict(selected=chosen,candidates=configs,panels=panels,
                people={role:panel['people']for role,panel in panels.items()},
                processing={role:panel['processing']for role,panel in panels.items()})
    frozen_files={str(m.CHECKPOINT):m.sha(m.CHECKPOINT),str(OUT/'PROTOCOL.json'):m.sha(OUT/'PROTOCOL.json'),
                  str(Path(__file__)):m.sha(__file__),str(Path(d.__file__)):m.sha(d.__file__),
                  str(Path(m.__file__)):m.sha(m.__file__),str(d.HERE/'a400_carrier.py'):m.sha(d.HERE/'a400_carrier.py')}
    for path in (d.HERE/'vendor/rpw_adapter.py',d.HERE/'owner_train02/PROTOCOL.json',
                 d.HERE/'owner_train02/ASSESSMENT.json',d.HERE/'common_owner_repair_dev.py'):
        frozen_files[str(path)]=m.sha(path)
    obj=dict(status='full DEV rules fixed before fresh-person modern scoring',source_roles=d.ROLES,
        methods=outputs,selected_primary='257/candidate_FIR_GLRT/exact',
        original_A400_fixed=True,checkpoint_sha256=m.sha(m.CHECKPOINT),
        no_new_confirmation_used=True,phase_angle_025_0125_not_applicable_to_native_Hamming_tests=True,
        native_unknown_semantics='independently encoded legal 30bit Hamming1/2 messages',
        data_files_sha256=files,frozen_files=frozen_files,
        score_exact='-max(0,R_top-R_U_same_winning_response)/G_top_top',
        threshold_policy='D_fit-only nextafter(maximum eligible negative,+inf)',
        selection_policy='D_select minimum negative accepts, maximum correct registered, lower menu index')
    lock=OUT/'MODERN_DEV_LOCK.json'
    if lock.exists():assert m.load(lock)==obj,'Existing DEV lock differs'
    else:m.save(lock,obj)
    m.save(OUT/'ACTUAL_DEV_BUDGET_AND_GEOMETRY.json',dict(status='complete',
        sources={source:budget_geometry(source)for source in d.SOURCES},
        waveform_angles_not_phase_code_angles=True))
    for key,z in outputs.items():
        r=z['selected'];print(json.dumps(dict(receiver=key,rule={k:v for k,v in r.items()if k not in('fit','select')},
            fit=r['fit'],select=r['select'])),flush=True)


if __name__=='__main__':main()
