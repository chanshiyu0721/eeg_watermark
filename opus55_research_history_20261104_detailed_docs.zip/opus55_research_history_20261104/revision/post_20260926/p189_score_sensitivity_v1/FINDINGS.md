# P189 saved-score sensitivity: exploratory replay

The saved P188 scores reproduce every checked frozen decision exactly. The focused sensitivity exposes a material dependence on the deterministic DEV tie rule at smooth level 1.0, and confirms that the presence gate and DEV recalibration are distinct changes. No primary policy was changed. No EEG, EDF query, response fit, extraction or task model was regenerated.

`PROTOCOL.md` was written before computing these summaries on 2026-10-29. This is an exploratory posthoc analysis of retained scores, not a new confirmation experiment.

## Available raw evidence and exact replay

| Raw family | Files | Rows | Contents |
|---|---:|---:|---|
| GLRT bridge | 3 | 624 | A02T DEV 208; OpenBMI003/004 held 416 |
| GLRT direction extension | 2 | 384 | Two OpenBMI sources; angle .025 directions 0/1 and .0125 direction 0 |
| Frontier DEV and held | 45 | 3,870 | 810 DEV + 3,060 held; all five arms and three levels |
| Coupled BCI arm checkpoints | 135 | 3,726 | Nine E-session sources x three levels x five arms |
| Total | 185 | 8,604 | Every row has all three methods and twelve scores per method |

The joint final `results.json` is a decision export; its arm checkpoints retain `raw_rows` with the twelve scores, base eligibility, top identity, per-ridge presence/support, candidate RSS, unrestricted RSS, clean RSS and selected beta. Their `applied_rows` also exactly equal the final result rows. The frontier raw files retain the same score schema. Nothing required for this score-level sensitivity is missing. The original bridge raw files do not store a direction field, so their CSV angle groups explicitly say `direction_unsaved` rather than inventing a direction number.

Replay checks cover 612 frozen DEV candidate entries: bridge V1/V2 and every frontier level/arm/method. Original P188 calibration functions, loaded directly from their source definitions without importing the extraction graph, equal the independent implementation exactly. Original rule application and the independent implementation agree with 28,836 stored method decisions, including both bridge policies, both direction policies, frontier DEV/held and every joint checkpoint. There are zero mismatches. `input_manifest.json` records SHA-256 digests and verifies that all read inputs remain unchanged.

The sensitivity below focuses on smooth, as fixed in the protocol; other arms enter availability and frozen-policy replay only. Complete outcomes for all twelve smooth configurations are in `all_configuration_outcomes.csv`, including rejected rows and every specified cohort.

## DEV configuration choice and eligibility

Configuration order is ridge 1e-4 then 1e-6; within each ridge, compatibility, relative gap, presence; within each head, support 1 then 3. Thus indices 0/1 are compatibility at 1e-4 and 6/7 compatibility at 1e-6. Selection maximizes DEV registered-correct count and breaks ties by the smallest index. Neither the smallest threshold nor any held outcome breaks a tie.

| Smooth panel | Ordinary: index, DEV correct | Projected: index, DEV correct | Candidate: index, DEV correct | Candidate DEV ties |
|---|---|---|---|---|
| Original bridge | 10, 23/64 | 0, 64/64 | 0, 64/64 | 0, 1, 6, 7 |
| Frontier level .50 | 10, 16/24 | 0, 19/24 | 6, 24/24 | 6, 7 |
| Frontier level .75 | 10, 9/24 | 0, 23/24 | 6, 24/24 | 6, 7 |
| Frontier level 1.00 | 2, 8/24 | 0, 24/24 | 0, 24/24 | 0, 1, 6, 7 |

At the selected configurations, every DEV registered row is base-eligible and passes the .25 gate. The bridge has 80 nonpressure negatives: 72 base-eligible and 64 gate-eligible. Each smooth frontier level has 30 calibration negatives: 27 base-eligible and 24 gate-eligible. Thresholds are the next representable float above the maximum eligible nonpressure negative score. `DEV_twelve_configurations.csv` gives those counts and thresholds for every candidate, not only the winner.

The ties matter. On the bridge, candidate indices 0/1 and 6/7 all achieve 64/64 DEV and 128/128 held registered coverage, but their held .0125 false accepts are respectively 5/128 and 12/128. At frontier level 1.0, the frozen index 0 has BCI registered 72/72, .025 false accepts 16/72 and .0125 false accepts 59/72. The DEV-tied index 6 has 72/72, 0/72 and 0/72 on those same held scores. The observed level-1 nonmonotonicity is therefore sensitive to DEV-tie resolution and ridge choice. This is the behavior of a pipeline calibrated separately at each level, not a pure causal effect of increasing strength or an irreducible code-separation limit. Index 0 remains the reported frozen policy; choosing index 6 after seeing this table would be held-data selection. These alternatives are descriptive, not replacements.

`lowpoint_candidate_source_configuration_margins.csv` supplies 732 compact rows for the candidate smooth level-.50 panel, preserving each source, ridge, head and required support across all twelve configurations. It includes eligible score-margin ranges, nearest absolute margins, observed support, presence ranges and primary-selection flags. This keeps the low-point result inspectable at the source level rather than pooling all recipients into an apparent independent sample.

## Fixed-configuration threshold sensitivity

The candidate frozen thresholds are 0.9978518037133303 (bridge), 0.9985782652118516 (level .50), 0.9973119001007620 (level .75), and 0.9978748614782107 (level 1.00). The table keeps both configuration and .25 presence gate fixed. Cells report registered-correct / .025 accepts / .0125 accepts. Bridge denominators are 128 each; coupled BCI denominators are 72 each.

| Panel and held cohort | Threshold minus .001 | Frozen threshold | Threshold plus .001 |
|---|---|---|---|
| Bridge OpenBMI | 128 / 0 / 21 | 128 / 0 / 5 | 128 / 0 / 0 |
| Smooth .50, BCI E | 72 / 0 / 1 | 72 / 0 / 0 | 71 / 0 / 0 |
| Smooth .75, BCI E | 72 / 0 / 0 | 72 / 0 / 0 | 72 / 0 / 0 |
| Smooth 1.00, BCI E | 72 / 28 / 69 | 72 / 16 / 59 | 72 / 6 / 39 |

These are absolute score offsets, not relative percentage changes. All seven predeclared offsets, every receiver, DEV, direction extension, OpenBMI frontier and BCI E are retained in `fixed_configuration_threshold_sweep.csv`. Thresholds are clipped to [0,1]; the +.01 candidate points reach 1 and reject every registered row in these four held panels.

The candidate registered minimum positive margin is .001184 on the bridge and .000678/.002224/.001852 for BCI levels .50/.75/1.00. The nearest BCI .025 rejected margin is -.005503 at .50 and -.010429 at .75, whereas level 1.00 has both signs, including a nearest absolute margin of .00005367. Level-.50 .0125 is closer: its largest margin is -.00055893. Complete per-query margins, eligibility and score adjacency are saved. Across the focused 7,452 method/query margin rows, no score equals its selected threshold; DEV maximum negatives can equal the threshold's immediate predecessor, as intended by `nextafter`. A score margin alone does not override an eligibility failure.

## Presence gate: fixed threshold versus DEV recalibration

`presence_gate_sensitivity.csv` explicitly separates two analyses. `fixed_config_and_threshold` ANDs each gate with the original selected configuration and threshold. `DEV_recalibration_and_selection` refits all twelve thresholds and resolves configuration selection on DEV alone under each gate, then applies that rule unchanged to every held cohort. Pressure rows never set thresholds. Neither analysis changes the reported primary policies or operating-point level.

Across the focused saved panel, .1, .25 and .5 give identical eligibility, decisions, recalibrated thresholds and configuration choices. This is a plateau in the retained scores, not evidence that .1 is generally sufficient or a reason to replace .25. Gate 0 is different because presence is clipped to zero and the comparison is inclusive: `presence >= 0` supplies no extra exclusion. The distinction is also not merely positive versus zero: all 13 base-eligible bridge candidate wrong-source rows have positive presence between .00004432 and .00008645; the eight DEV wrong-source values are .0000008681 to .00004271. At BCI level .50, eight wrong-source rows have positive presence and one has zero, with maximum .00001891. A strict `presence>0` would therefore retain most of these controls. The data support positive-magnitude exclusion on these controls but do not privilege exactly .25. `presence_zero_diagnostic.csv` records the sign/magnitude separation for every focused selected policy and cohort.

| Candidate example | Gate 0, fixed V2 threshold | Gate 0, DEV recalibrated | Gate .1/.25/.5 |
|---|---|---|---|
| Bridge | 128/128 registered; 8/16 wrong source; 5/128 pressure | 127/128; 5/16; 0/128 | 128/128; 0/16; 5/128 |
| Smooth .50, BCI E | 72/72; 7/9 wrong source; 0/72 pressure | Same | 72/72; 0/9; 0/72 |
| Smooth .75, BCI E | 72/72; 8/9 wrong source; 0/72 pressure | 72/72; 7/9; 0/72 | 72/72; 0/9; 0/72 |
| Smooth 1.00, BCI E | 72/72; 7/9 wrong source; 59/72 pressure | Same | 72/72; 0/9; 59/72 |

Bridge candidate recalibration at gate 0 raises its threshold from .9978518037 to .9991366625; this recovers V1, whose gate-free frozen policy still accepts five wrong-source rows. At frontier .75, removing the gate raises the DEV candidate threshold from .9973119001 to .9975051844. The selected configuration does not change in these examples. This demonstrates why the original V1-to-V2 coverage/pressure changes cannot be attributed to the gate alone: filtering DEV negatives can lower the calibrated threshold as well as reject held controls.

## Exact numerical and serialization conventions

These are source-level facts from the unchanged files listed in the manifest, not newly recomputed waveform results.

- **Design and nuisance solver.** `p178_fir_prototype.design` uses 129 taps, five fixed windows and clean-reference RMS normalization `sqrt(mean(xx*xx))` with no added normalization floor. Each held-out fold fits on the other four. P188 selects coarse-bank index by summed matching error on those four windows and their lower-median integer delay. It symmetrizes each Gram matrix and explicitly forms `np.linalg.inv(G + lambda*I)`, then multiplies by the right-hand side. The ordinary matrix is clean `G`; projection is `P=G-C pinv(TT,rcond=1e-9) C.T`; every method uses the same absolute `lambda=rho*trace(clean_G)/129`. Candidate fitting uses eight separate archive-conditioned Grams with that clean-G scale. This is not the earlier trace(P)-scaled projected receiver.
- **Unrestricted identity residual.** The held-out identity coefficient is `np.linalg.lstsq(G,b,rcond=1e-7)[0]` on the pooled 8x8 Gram, not a tall-matrix least-squares solve. Candidate fitting supplies eight conditional nuisance fits; its unrestricted residual is the minimum across those fits, not a joint unconstrained nuisance optimum. Optional mechanism diagnostics use a separate tall-matrix `lstsq(...,rcond=1e-8)` and do not alter scores.
- **RSS and floors.** Fixed-identity residuals are `max(0,d+Gii-2*bi)`; unrestricted residuals are `max(0,d-b@beta)`. Let `R` and `R2` be the first and second candidate residuals under stable `argsort`, and `RU` the unrestricted value. Define `scale=max(sum(pooled_d),sum(trace(pooled_G)),1e-30)` and `floor=64*finfo(float).eps*scale`. Shared methods have one pooled triple; the candidate method sums all eight conditional triples for this floor. Compatibility is exactly 1 when `R<=floor`, otherwise `RU/R`. Relative gap is `(R2-R)/max(R2,floor)`. Presence is `1-R/max(ordinary_clean_RSS,floor)` with the same ordinary clean null for all branches. All three heads are clipped to [0,1]. Zero-RSS cases are therefore defined, not divided without a floor.
- **Equality and ties.** Base eligibility requires `gain[top]>0` strictly and `median(fold_peaks)>=0` inclusively. Support counts the five per-window minimum-RSS identities; eligibility adds `support>=1` or `>=3`. V2 adds `presence>=.25`. Acceptance is `score>=threshold`, not strict `>`. Calibration includes every non-enrolled, nonpressure eligible DEV negative; threshold is `nextafter(max_negative,+inf)`, or zero if none exists. Configuration ties use earliest index. Stable candidate RSS sorting chooses earliest identity for exact global RSS ties; per-window `argmin` likewise chooses its first minimum.
- **EDF range and quantization.** `run_p181_data.edf_roundtrip` creates actual 16-bit EDF through `edfio.EdfSignal`, physical dimension uV, 160 Hz and eight domain channel labels. Digital range defaults to [-32768,32767], giving 65535 steps. Queries use common per-channel limits computed from concatenated transformed clean and wrong-source references: `floor(min_uv-margin)` and `ceil(max_uv+margin)`, with `margin=max(5 uV,.05*peak_to_peak_uv)`. They are not fitted to an individual marked query. The writer rejects pre-serialization out-of-range samples. The inspected edfio 0.4.18 source quantizes `round(data/gain-offset)` to int16, using NumPy's tie-to-even rounding; `gain=(physical_max-physical_min)/65535` and `offset=physical_max/gain-32767`. Readback converts uV to volts, asserts the exact expected LSB to tight tolerance, and enforces error <=.50001 LSB. Existing query receipts bind serialized bytes by SHA-256. P189 reads those saved scores/receipts and does not rerun quantization. No BDF24 or virtual quantization is substituted in these panels.

`numerical_score_conventions.csv` checks the 51,624 method/ridge score entries in the 8,604 raw observations. None has compatibility exactly 1 or best RSS exactly zero; the minimum best RSS is 3.9576056565238105e-7. The frozen receiver source digests match the inspected source. Because that source returns exactly 1 whenever `R<=floor`, the exact-one near-zero compatibility branch is not activated in these saved entries. There is no evidence that a floor-induced exact-one convention explains the observed decisions.

Saved raw scores omit the full pooled G/b/d triples, fitted kernels and numerical floor values. Consequently this replay verifies decisions from the stored scores, not how a changed inversion tolerance, RSS convention, EDF range or quantizer would change extraction. Those sensitivities would require new extraction and are outside this authorized analysis. Numerical conventions are documented from source rather than inferred from the scores.

## Chronology and scope of the evidence

V1 froze at 2026-10-28 11:31:08 UTC and its wrong-source failure is retained: projected and candidate each accepted five of the 16 wrong-source rows, or five of 32 when clean and wrong-source controls are pooled. V2 froze a common .25 presence gate and A02T-only recalibration at 11:39:17 UTC. Its bridge panel replays previously seen V1 scores posthoc. An initial direction computation had already reached a progress message for 120 queries, but was stopped before either source checkpoint existed and before new numerical direction scores or decisions were viewed. V2 is accurately described as frozen before direction-output unblinding, not before all direction computation. The subsequent direction freeze is 11:40:16 UTC.

The frontier freeze at 11:47:28 UTC fixes each level/arm/method rule and the lowest DEV-feasible level before its OpenBMI frontier outputs. Joint BCI copies the exact frontier freeze and waits for terminal issuance markers before scoring. It performs no E-session threshold fitting or level selection. P189's alternative-config tables do not retrospectively change that chronology. Sources were retained and observed in earlier experiments; these are not newly acquired participants or a virgin-source benchmark.

Wrong-source support is narrow and panel-specific. A02T DEV and all coupled BCI E groups use the same A01T clean recording. Thus the 27 BCI wrong-source rows per arm across three levels do not represent 27 independent wrong-source identities. The OpenBMI bridge/frontier instead swap OpenBMI003 and OpenBMI004 as wrong source. Their two source identities also do not establish broad open-world false-accept behavior. Biological participants and repeated query copies remain distinct units; these descriptive counts introduce no independent-sample significance claims.

## Reproduce and artifact map

From the project root, run `.venv-rerun/Scripts/python.exe revision/post_20260926/p189_score_sensitivity_v1/analyze_saved_scores.py`. It overwrites only its own analysis outputs and asserts equality to the retained freezes and decisions. It never imports the receiver model or loads EEG. `results.json` provides replay checks and gate results; `input_manifest.json` binds exact inputs and runtime; `raw_score_inventory.csv` lists every raw file; `DEV_twelve_configurations.csv` and `all_configuration_outcomes.csv` cover alternatives; `primary_frozen_replay.csv` and its by-source companion retain primary counts; `presence_gate_rules.csv` separates DEV choices from `presence_gate_sensitivity.csv` outcomes; the three threshold/margin CSVs retain all sweep and per-query evidence. P188 code, freezes, results and primary thresholds remain untouched.

For a standalone reproduction, copy `replay_compact.py`, `compact_saved_scores.json.gz` and `compact_manifest.json` to any directory and run `python -I replay_compact.py --data-dir . --output-dir replay_output`. This requires only the Python standard library. Its 773,697-byte score export includes all twelve configurations and DEV rows for the 2,484 focused query observations, preserving source/parent/query coordinates and original serialized-query hashes. Input/script hashes and the canonical output digest are asserted. An isolated Python run passed exact parity for primary, all-configuration, threshold and presence tables against the bulk analysis; see `STANDALONE_REPLAY.md`. No project EEG, extraction code or model dependency is needed.
