"""Reproduce code-only geometry. Reads no EEG and invokes no receiver."""
from __future__ import annotations

import hashlib
import itertools
import json
import math
from pathlib import Path

def geometry() -> dict:
    source = Path(__file__).resolve().parent.parent / "p186_five_arm_bridge_v1" / "codes.json"
    code_bytes = source.read_bytes()
    codes = json.loads(code_bytes)["codes"][:8]
    norms = [math.sqrt(math.fsum(x * x for x in row)) for row in codes]
    unit = [[x / norm for x in row] for row, norm in zip(codes, norms)]
    offdiagonal = [math.fsum(a * b for a, b in zip(left, right))
                   for left, right in itertools.combinations(unit, 2)]
    pair_angles = [math.acos(max(-1.0, min(1.0, dot))) for dot in offdiagonal]
    chords = [math.sqrt(math.fsum((a - b) ** 2 for a, b in zip(left, right)))
              for left, right in itertools.combinations(unit, 2)]
    # Nonconstant Walsh characters on Z_2^5, each repeated 20 times.
    words = [[((row & col).bit_count() & 1) for col in range(32)] * 20
             for row in range(1, 32)]
    d_hamming = min(sum(a != b for a, b in zip(left, right))
                    for left, right in itertools.combinations(words, 2))
    return {
        "phase_registered_code_file": str(source),
        "sha256": hashlib.sha256(code_bytes).hexdigest(),
        "registered_count": len(codes),
        "dimension": len(codes[0]),
        "max_norm_error": max(abs(norm - 1) for norm in norms),
        "max_abs_offdiagonal_inner_product": max(abs(dot) for dot in offdiagonal),
        "minimum_registered_angle_radians": min(pair_angles),
        "minimum_registered_chord": float(min(chords)),
        "near_code_chord": {str(theta): 2 * math.sin(theta / 2)
                            for theta in (0.0125, 0.025)},
        "QIM_full_legal_walsh_rows": 31,
        "QIM_registered_rows": list(range(1, 9)),
        "QIM_held_legal_unknown_rows": list(range(9, 17)),
        "QIM_chips": len(words[0]),
        "QIM_minimum_Hamming_distance": d_hamming,
        "QIM_unique_bounded_distance_radius_chips": (d_hamming - 1) // 2,
        "notes": "Registered geometry computed from frozen source code only. No EEG read or re-score.",
    }


if __name__ == "__main__":
    print(json.dumps(geometry(), ensure_ascii=False, indent=2))
