"""New-record paired end-to-end EDF16 vs BDF24 second-storage evaluation."""

import argparse
import json
from pathlib import Path

import mne
import numpy as np

from revision.post_20260926 import run_p134_context_replay_development as p134
from revision.post_20260926 import run_p140_cross_dataset_adapter_pilot as adapter
from revision.post_20260926 import run_p144_continuous_filter_fit_development as p144
from revision.post_20260926 import run_p147_prospective_cross_dataset_filter_fit as p147
from revision.post_20260926 import run_p148_second_edf_offgrid_development as p148
from revision.post_20260926 import run_p155_continuous_unknown_family_development as p155
from revision.post_20260926 import run_p158_virtual_24bit_second_storage as p158
from revision.post_20260926 import run_p159_actual_bdf24_roundtrip as p159
from revision.post_20260926.run_p6_fingerprint_pilot import q16
from revision.lightweight_qc_validation.download_external_datasets import BASE, checksum
from revision.lightweight_qc_validation.download_independent_cohort import download_chunked
from revision.post_20260926.download_p51a_positive import official

HERE = Path(__file__).resolve().parent
OUT = HERE / 'p160_prospective_edf16_bdf24_v1'
PLAN = HERE / 'P160_PROSPECTIVE_EDF16_VS_BDF24_PROTOCOL_2026-10-19.md'
SOURCES = {'sleep': 'sleep-cassette/SC4821G0-PSG.edf',
           'chb': 'chb23/chb23_07.edf'}
FORMATS = ('edf16', 'bdf24')


def state_now():
    catalog = {d: official(d) for d in ('sleep-edfx', 'chbmit')}
    sources = {}
    for source, relative in SOURCES.items():
        dataset = 'sleep-edfx' if source == 'sleep' else 'chbmit'
        records, sums = catalog[dataset]
        if relative not in records or relative not in sums:
            raise RuntimeError(f'official source missing: {relative}')
        sources[source] = dict(dataset=dataset, relative=relative,
                               sha256=sums[relative])
    code = [Path(__file__), PLAN] + [HERE / name for name in (
        'run_p140_cross_dataset_adapter_pilot.py',
        'run_p144_continuous_filter_fit_development.py',
        'run_p147_prospective_cross_dataset_filter_fit.py',
        'run_p148_second_edf_offgrid_development.py',
        'run_p155_continuous_unknown_family_development.py',
        'run_p158_virtual_24bit_second_storage.py',
        'run_p159_actual_bdf24_roundtrip.py',
        'run_p134_context_replay_development.py',
        'run_p74_new_sleep_preprocessing.py')]
    return dict(sources=sources, formats=list(FORMATS),
                arms=list(p147.ARMS), recipients=list(p147.RECIPIENTS),
                slots=list(adapter.SLOTS), crops=list(range(6)),
                fit_families=list(p155.FAMILIES),
                true_families=list(p155.TRUE_FAMILIES),
                true_band=list(p144.TRUE_BAND), fit_initial=list(p144.INIT),
                fit_bounds=[list(x) for x in p144.BOUNDS],
                fit_mask_samples=int(p144.MASK.sum()),
                fit_gradient='3-point', fit_gradient_step=1e-4,
                cosine_threshold=0.915396283766543,
                ratio_thresholds={'phase': 0.5313351058763109,
                                  'qim': 0.48374798126088164},
                gate={'issued': 29, 'family_correct': 29,
                      'correct_crops': 23, 'wrong_crops': 0,
                      'clean_false_crops': 0},
                bdf_writer='edfio.BdfSignal',
                bdf_digital_range=[-8388608, 8388607],
                code_sha256={x.name: adapter.sha(x) for x in code})


def freeze():
    OUT.mkdir(exist_ok=True)
    path = OUT / 'frozen_manifest.json'
    state = state_now()
    if path.exists():
        if json.loads(path.read_bytes()) != state:
            raise RuntimeError('P160 frozen state drift')
    else:
        for row in state['sources'].values():
            if (BASE / row['dataset'] / row['relative']).exists():
                raise RuntimeError('P160 source existed before freeze')
        path.write_text(json.dumps(state, indent=2) + '\n', encoding='utf-8')
    return state


def guard(state):
    if state_now() != state:
        raise RuntimeError('P160 protocol/code drift')
    for row in state['sources'].values():
        if checksum(BASE / row['dataset'] / row['relative']) != row['sha256']:
            raise RuntimeError('P160 official source hash drift')


def download():
    state = freeze()
    target = OUT / 'downloads.json'
    if target.exists():
        raise FileExistsError(target)
    records = []
    for row in state['sources'].values():
        result = download_chunked(row['dataset'], row['relative'], row['sha256'])
        records.append(dict(result, **row))
        print('P160 downloaded', row['relative'], flush=True)
    guard(state)
    target.write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8')


def query_pair(processed, picks, prefix, artifacts):
    edf_path = OUT / f'{prefix}_edf16_second_full.edf'
    bdf_path = OUT / f'{prefix}_bdf24_second_full.bdf'
    if edf_path.exists():
        edf = p144.read(edf_path, picks)
    else:
        edf = adapter.export_import(processed, picks, edf_path)
    _, lo, hi, levels16 = p158.header(edf_path, picks)
    if bdf_path.exists():
        raw = mne.io.read_raw_bdf(bdf_path, preload=True, verbose='ERROR')
        if raw.ch_names != list(picks) or raw.info['sfreq'] != p144.HZ or \
                raw.n_times != processed.shape[1]:
            raise RuntimeError('BDF structure drift')
        bdf = raw.get_data(picks=list(picks))
        clipped = int(np.count_nonzero(
            np.clip(processed, lo[:, None], hi[:, None]) != processed))
    else:
        bdf, clipped = p159.export_bdf(processed, picks, lo, hi, bdf_path)
    artifacts[edf_path.name] = dict(sha256=adapter.sha(edf_path),
                                    lsb_volts=((hi-lo)/levels16).tolist())
    artifacts[bdf_path.name] = dict(sha256=adapter.sha(bdf_path),
                                    lsb_volts=((hi-lo)/((1<<24)-1)).tolist(),
                                    clipped_samples=clipped)
    return {'edf16': edf, 'bdf24': bdf}


def score_source(source, picks, issued_dir, artifacts):
    fits, rows = [], []
    for arm in p147.ARMS:
        prefix = f'{source}_{arm}'
        clean = p144.read(issued_dir / f'{prefix}_clean_full.edf', picks)
        archive = {r: p144.read(issued_dir / f'{prefix}_{r}_full.edf', picks)
                   for r in range(16)}
        for true_family in p155.TRUE_FAMILIES:
            for recipient in p147.RECIPIENTS + (-1,):
                original = clean if recipient < 0 else archive[recipient]
                processed = p155.transform(original, true_family,
                                           p144.TRUE_BAND)
                label = f'{prefix}_{true_family}_{recipient}'
                queries = query_pair(processed, picks, label, artifacts)
                for fmt in FORMATS:
                    query = queries[fmt]
                    for crop in range(6):
                        a, b = crop*p144.CROP, (crop+1)*p144.CROP
                        choices = [p155.fit(query[:, a:b], clean[:, a:b], family)
                                   for family in p155.FAMILIES]
                        selected = min(choices, key=lambda x: x['loss'])
                        fits.append(dict(source=source, arm=arm,
                                         true_family=true_family, format=fmt,
                                         recipient=recipient, crop=crop,
                                         choices=choices,
                                         selected_family=selected['family']))
                        family = selected['family']
                        band = selected['low'], selected['high']
                        reference = p155.transform(clean[:, a:b], family, band)
                        candidates = {r: p155.transform(x[:, a:b], family, band)
                                      for r, x in archive.items()}
                        for slot in range(5):
                            i = (30+slot*60)*p144.HZ
                            global_i = (crop*300+30+slot*60)*p144.HZ
                            if global_i != a+i or (crop>0 and global_i==i):
                                raise RuntimeError('query global index regression')
                            observed = q16(query[:, global_i:global_i+320])
                            mu = q16(reference[:, i:i+320])
                            codebook = np.asarray([q16(candidates[r][:, i:i+320])
                                                   for r in range(16)])
                            cosine, ratio, top, value = p134.score(
                                observed, mu, codebook, arm)
                            rows.append(dict(source=source, arm=arm,
                                             true_family=true_family, format=fmt,
                                             recipient=recipient, crop=crop,
                                             slot=slot, query_start=global_i,
                                             cosine_found=cosine, ratio_found=ratio,
                                             cosine_top=top, ratio_value=value))
            print('P160', source, arm, true_family, 'complete', flush=True)
    return fits, rows


def compute():
    state = freeze()
    guard(state)
    target = OUT / 'results.json'
    if target.exists():
        raise FileExistsError(target)
    issued_dir = OUT / 'issued'
    adapter.FILES = p147.specs(state['sources'])
    adapter.OUT = issued_dir
    if not issued_dir.exists():
        adapter.main()
    issued_file = issued_dir / 'results.json'
    issued = json.loads(issued_file.read_bytes())
    if len(issued['artifacts']) != 88 or len(issued['summary']) != 32:
        raise RuntimeError('issuance denominator drift')
    for item in issued['sources']:
        if item['source_sha256'] != state['sources'][item['name']]['sha256']:
            raise RuntimeError('issued source hash drift')
    for item in issued['artifacts']:
        if adapter.sha(issued_dir / item['file']) != item['sha256']:
            raise RuntimeError('issued artifact hash drift')
    artifacts, fits, rows = {}, [], []
    for source in SOURCES:
        ff, rr = score_source(source, adapter.FILES[source]['picks'],
                              issued_dir, artifacts)
        fits.extend(ff)
        rows.extend(rr)
    if len(artifacts) != 80 or len(fits) != 480 or len(rows) != 2400:
        raise RuntimeError(f'P160 count drift: {len(artifacts)}/{len(fits)}/{len(rows)}')
    summary = []
    for source in SOURCES:
        for arm in p147.ARMS:
            issued_slots = sum(r['issued'] for r in issued['preflight']
                               if r['source'] == source and r['arm'] == arm)
            for true_family in p155.TRUE_FAMILIES:
                for fmt in FORMATS:
                    ff = [r for r in fits if (r['source'], r['arm'],
                                             r['true_family'], r['format']) ==
                          (source, arm, true_family, fmt)]
                    family_correct = sum(r['selected_family'] == true_family
                                         for r in ff)
                    median_nfev = float(np.median(
                        [sum(c['nfev'] for c in r['choices']) for r in ff]))
                    for detector in ('cosine','ratio'):
                        field = f'{detector}_found'
                        rr = [r for r in rows if (r['source'], r['arm'],
                                                 r['true_family'], r['format']) ==
                              (source, arm, true_family, fmt)]
                        pos = [r for r in rr if r['recipient'] >= 0]
                        neg = [r for r in rr if r['recipient'] < 0]
                        decisions = [(recipient, p148.vote([r for r in rr if
                                                            r['recipient'] == recipient and
                                                            r['crop'] == crop], field))
                                     for recipient in p147.RECIPIENTS + (-1,)
                                     for crop in range(6)]
                        row = dict(source=source, arm=arm,
                                   true_family=true_family, format=fmt,
                                   detector=detector, issued_slots=issued_slots,
                                   family_correct=family_correct,
                                   fits_converged=sum(c['converged'] for r in ff
                                                      for c in r['choices']),
                                   median_nfev=median_nfev,
                                   correct_windows=sum(r[field]==r['recipient']
                                                       for r in pos),
                                   wrong_windows=sum(r[field]>=0 and
                                                     r[field]!=r['recipient']
                                                     for r in pos),
                                   clean_false_windows=sum(r[field]>=0 for r in neg),
                                   correct_crops=sum(w==t for t,w in decisions if t>=0),
                                   wrong_crops=sum(w>=0 and w!=t for t,w in decisions
                                                   if t>=0),
                                   clean_false_crops=sum(w>=0 for t,w in decisions
                                                         if t<0))
                        row['gate_pass'] = (issued_slots>=29 and
                                            family_correct>=29 and
                                            row['correct_crops']>=23 and
                                            row['wrong_crops']==0 and
                                            row['clean_false_crops']==0)
                        summary.append(row)
    guard(state)
    target.write_text(json.dumps(dict(prospective_new_files=True,
                                      manifest_sha256=adapter.sha(OUT /
                                                                  'frozen_manifest.json'),
                                      issuance_sha256=adapter.sha(issued_file),
                                      artifacts=artifacts, fits=fits, rows=rows,
                                      summary=summary,
                                      pass_by_format={fmt:sum(r['gate_pass'] for r in summary
                                                              if r['format']==fmt)
                                                      for fmt in FORMATS}),
                                 indent=2) + '\n', encoding='utf-8')
    for r in summary:
        print(r, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=('freeze','download','compute'))
    args = parser.parse_args()
    if args.command=='freeze':
        print('P160 manifest frozen', len(freeze()['sources']), flush=True)
    elif args.command=='download':
        download()
    else:
        compute()
