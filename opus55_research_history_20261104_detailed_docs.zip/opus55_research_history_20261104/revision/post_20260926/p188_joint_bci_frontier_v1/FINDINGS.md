# Same-waveform BCI attribution/task frontier: completed receiver matrix

All3726 planned queries were evaluated, covering27 source/strength groups
(nine BCI2a E-session run0 records x three declared levels), five carriers and
one prespecified causal-Bessel condition. Each query has the same112s reference,
40s scored/48s observed contract. Thresholds and operating points come only
from the pre-existing A02T DEV freeze. No BCI E fitting, source exclusion or
working-point selection occurred. Runtime was2570.2s with arm-level checkpoints.

The1080 registered Bessel query EDF hashes match the task utility table exactly
(9subjects x3levels x5arms x8recipient IDs). This proves that the coupled task
and attribution results use identical actual serialized query waveforms. See
query_hash_binding.json and registered_task_query_hash_binding.csv.

## DEV-fixed primary candidate-FIR working point

The declared lowest feasible DEV level is0.5 for every carrier. Its source-mean
actual registered PRD is approximately0.09986% for four phase carriers and
0.09991% for QIM-ID; all original caps and per-source/per-ID0.1% matching checks
are retained in the issuance producer's summaries.

|Carrier|Registered|Phase0.025 FA|Phase0.0125 FA|Legal QID FA|QID chip pressure FA|Controls FA|
|---|---:|---:|---:|---:|---:|---:|
|smooth|72/72|0/72|0/72|n/a|n/a|0/18|
|direct|72/72|0/72|0/72|n/a|n/a|0/18|
|hybrid05|72/72|0/72|0/72|n/a|n/a|0/18|
|spatial|72/72|7/72|67/72|n/a|n/a|0/18|
|QIM-ID|72/72|n/a|n/a|0/72|144/144|0/18|

The phase-angle and QID chip/valid-word geometries are separate. In particular,
the QID chip forgeries are outside the Walsh encoder's valid-word set and are
not equivalent to valid continuous phase-code neighbors.

## Retained nonmonotonicity and estimator tradeoffs

All45 carrier x method x level cells are retained in attribution_summary.csv.
Candidate-FIR registered coverage is72/72 for every carrier at all three levels.
At level0.75, smooth/direct/hybrid025 false accepts are0/20/14 out of72; at1.0,
all three yield16/72. Consequently, increasing nominal strength is not a monotone
improvement under independently DEV-calibrated cross-record thresholds. The
0.5 working point was fixed by the declared DEV rule before BCI E scores.

Projected FIR at0.5 yields smooth60/72 registered and6/72 near025 accepts;
ordinary FIR yields36/72 and36/72. Thus the stronger candidate-conditioned
response fit is retained in the primary coupled comparison. Faster projection
is a measured implementation-cost tradeoff, not the best observed receiver.

The current file reports attribution only. Task MAE/flips and source-level
uncertainty should be joined from the producer's same-level Bessel utility
table. Biological participants are the task statistical units; the72 copies
per cell do not represent72 independent people or independent replications.

## Reproduction entries

- PROTOCOL.json: exact planned scope and no-test-fitting contract.
- receiver_freeze.json: copied parent DEV rules/working points and source digest.
- groups/: per-arm raw scores, applied decisions and actual EDF receipts.
- results.json / completion.json: all3726 observations and terminal state.
- attribution_summary.csv: all method/carrier/strength/unknown-geometry cells.
- source_attribution_summary.csv: participant/source-preserving count table.
- DEV_fixed_operating_points.csv: fixed-point outcomes, including failed targets.
- query_hash_binding.json:1080 actual-query byte-equality assertions.
- run_joint.py: terminal-issuance consumer; export_joint.py: one-pass aggregation
  and hash binding. No task prediction, training or issuance is repeated here.
