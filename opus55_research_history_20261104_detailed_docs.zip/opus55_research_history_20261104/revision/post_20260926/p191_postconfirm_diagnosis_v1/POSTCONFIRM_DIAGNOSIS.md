# P191 后确认诊断：已知真实处理后的近身份拒识

OpenBMI018 的原 6 个 pressure0125 误接收，在诊断分支使用真实处理算子后全部仍被接受。三种处理的 pressure 接受总数由原 6/24 变为 8/24，同时登记正确数保持 24/24。真实响应显著降低整体残差，但没有恢复冻结 q 规则对这些近身份 query 的拒识。该结果将源 18 的失败定位到实际发行字典上的有效投影间距与冻结全局阈值的适配，而剩余未知响应估计不足以解释这 6 个误接收。

本报告属于 **post-confirmation diagnosis**。下列真实算子信息仅供机制诊断；主实验继续使用原冻结规则。本诊断不增加阈值、不重校准、不替换主结果。

## 同样本与计算定义

固定对象为 OpenBMI018、smooth、level100。三处理分别复用 8 登记、8 pressure0125、16 phase025，另保留每处理 1 clean 与 4 wrong，共 111 条已观测 query。32 个实际发行 EDF、clean/wrong EDF 均从 P191 原档案读取；发行 raw/gzip SHA 与 issuance receipt 匹配，source 样本 SHA 与 source.json 匹配。根据原 raw 的 `query_limits_uv` 还原实际 query，111/111 的 `query_raw_sha256` 与主实验原记录逐条一致。

诊断将该处理的真实算子同时应用到 clean 与八个实际登记发行参考，预测信号不再次量化；收到的 query 保持原实际 16-bit EDF。query、clean 与八参考采用相同的五个窗口、每窗 128 样本上下文、center/filter 与 1280 计分样本。五窗共用一个 transformed-clean RMS scale，保持窗间相对权重。

每个窗口构造实际参考差分字典 T、query-clean 差分 v，汇总 G=TᵀT、b=Tᵀv、d=vᵀv。以最小固定身份残差的 top 为赢家，保留：

- R = d + Gii − 2bi；U_samewinning = max(d − bᵀβ, 0)，β=lstsq(G,b,rcond=1e−7)。
- q = −max(R − U_samewinning, 0) / Gii。
- 沿用冻结阈值 −5.941561436978785e−5，以及原 eligible、support≥1、presence≥0.25 门槛。原候选接收器仍取冻结 order257、ridge1e−4；已知算子分支无需估计 FIR 响应。

actual q 从 P191 raw 的 `receivers_by_order['257']/methods/candidate_FIR_GLRT/by_ridge['0.0001']` 读取，并校验其 R/U/G 公式及冻结主判定。

冻结文件为 `p191_confirmation_v1/CONFIRMATION_FREEZE_FIX01.json`，SHA256：

`e181d74e991ef5cb2155cd41f60673dc3eaa8f1e0be449c8d6d77be1ef398fb8`

## 源 18 结果

|处理|原登记正确|真实算子登记正确|原 pressure 接受|真实算子 pressure 接受|原误接收被真实算子拒掉|
|---|---:|---:|---:|---:|---:|
|reexport|8/8|8/8|1/8|2/8|0/1|
|elliptic_new_causal|8/8|8/8|2/8|3/8|0/2|
|bessel_shifted_causal|8/8|8/8|3/8|3/8|0/3|
|合计|24/24|24/24|6/24|8/24|0/6|

phase025 在原与真实算子分支均为 0/48 接受；clean/wrong 均为 0/15。真实算子分支新增的两个 pressure 接受是 reexport query11/parent3 与 elliptic query9/parent1。

原 6 个误接收的 q 如下；q≥冻结阈值即满足该分数条件，六条均同时通过门槛。

|处理|query / parent|原 q|真实算子 q|
|---|---|---:|---:|
|reexport|9 / 1|−5.880698287e−5|−5.490550337e−5|
|elliptic|11 / 3|−5.125326085e−5|−4.981899595e−5|
|elliptic|12 / 4|−5.336506722e−5|−5.250369142e−5|
|Bessel|9 / 1|−4.823966479e−5|−4.638284871e−5|
|Bessel|11 / 3|−3.685973815e−5|−3.496038393e−5|
|Bessel|12 / 4|−3.188737974e−5|−2.983073013e−5|

两个指定 elliptic 失败的同响应细项为：

|query|分支|R|U_samewinning|Gii|R/Gii|U/Gii|赢家与次名 relative gap|
|---|---|---:|---:|---:|---:|---:|---:|
|11|原候选|0.04416270995|0.04401741269|2.834887994|0.015578291|0.015527038|0.9785251|
|11|真实算子|0.004252300628|0.004111375125|2.828750354|0.001503244|0.001453425|0.9977820|
|12|原候选|0.04489427205|0.04471705060|3.320926133|0.013518600|0.013465235|0.9821802|
|12|真实算子|0.004988042189|0.004814056513|3.313779889|0.001505242|0.001452739|0.9978830|

真实响应消除了大部分整体失配，但 R 与 U 同步下降，二者之差归一化后仍落在接受半径内。登记赢家和次名的 gap 很大，说明最近登记身份清楚；该 gap 对 query 是否属于登记集合的拒识帮助有限。

## G、β 与 code tangent 的数值描述

冻结 q 的有效距离为 √((β−ei)ᵀG(β−ei)/Gii)，对应冻结接受半径 0.00770815246。真实算子下 elliptic query11、12 的有效距离分别为 0.00705825729、0.00724594310，均在该半径内。

利用固定 code 和实际发行幅度可作一阶描述。设八登记 code 为正交基 C，`alpha_i = phase_matching.value_i × scales_i['differential_taper']`，则线性近似系数为 `beta_linear_j = alpha_query/alpha_registered_j × (C @ code_query)_j`。将该系数放入实际 G 度量，query11、12 在原 G 下的预测平方距离分别为 5.721959975e−5、5.757769918e−5；真实算子 G 下分别为 5.722038074e−5、5.757753694e−5，也都低于冻结平方半径 5.941561437e−5。

这一近似与实测方向一致。实际发行包含有限相位旋转、逐 code 幅度匹配和 EDF 量化，一阶 code 计算只作几何数值描述；机制判断以同样本真实算子结果为依据。

这里的 R−U 是字典张成空间中的投影失配。结果说明源 18 在冻结投影读出与阈值下有效分离不足；总信号差异同时体现在 R/Gii 与 U/Gii 中，不能把投影结果直接解释为信息论上的不可观测。

## 原 005–012 oracle 的共同 scale 修正

旧 `mechanism_pilot.py` 的 known_operator 分支按每窗模板总能量分别归一化，因而改变了五窗相对权重。为隔离这一混杂，本次仅重算原八人的 elliptic known_operator 分支，并在新目录另存；alignment、frozen-response 等原分支及原 P190 分数、provenance 保持原样。

296/296 条旧实际 query EDF SHA 匹配。先复算旧 windowwise oracle，与原档案的 compatibility/presence 最大绝对误差为 0，top/support/eligible 逐项一致，再比较共同 scale。

|原冻结 oracle 读出|原 windowwise|共同 scale|
|---|---:|---:|
|legacy 阈值登记正确|64/64|64/64|
|legacy 阈值 pressure 接受|0/64|0/64|
|legacy 阈值 phase025 接受|0/128|0/128|
|legacy 阈值 clean/wrong 接受|0/40|0/40|
|pressure-control 阈值登记正确|60/64|61/64|
|pressure-control 阈值 pressure 接受|0/64|0/64|

legacy 阈值下所有判定保持一致，故原八人的 oracle 改善可保留，窗口重权没有解释该改善。pressure-control 阈值只有 OpenBMI005 登记 query5 改变：compatibility 从 0.9986912248 变为 0.9987728233，由拒收变为正确接受。

原八人的结论针对原129响应模型及 compatibility 读出；新源18针对冻结257模型及 q 读出。两组诊断分别回答各自的失败，源18结果要求把新增近身份失败的解释落实到当前投影读出/全局阈值。

## 结果文件

- `OpenBMI018_smooth_KNOWN_OPERATOR.json.gz`：111 条 query 的原 q、真实算子 R/U/G/β/q、identity gap 与几何描述。
- `SUMMARY.json`：源18三处理计数。
- `legacy_common_scale/SUMMARY.json`：原八人的归一化修正计数、parity 与输入哈希；同目录保留逐人结果。
- `RUN_STATE.json`：源18完成，实际 Python PID37664，耗时 7.997 秒。
- `legacy_common_scale/RUN_STATE.json`：旧八人修正完成，实际 Python PID20488，耗时 34.151 秒。

源18冻结文件、原 raw 和 issuance 的 SHA 在运行前后相同；旧八人原结果、raw、issuance 的 SHA 在修正前后相同。所有新增输出位于 `p191_postconfirm_diagnosis_v1`。
