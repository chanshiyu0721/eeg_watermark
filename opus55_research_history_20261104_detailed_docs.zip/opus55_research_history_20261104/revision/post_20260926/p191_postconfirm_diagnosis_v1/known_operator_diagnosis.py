"""Post-confirmation diagnosis of the observed P191 source 18 smooth queries.

No frozen scientific inputs are edited. The true operator is diagnostic-only.
The actual serialized received query is reconstructed and its original SHA is
required to match. True-forward clean and actual issued references are never
quantized a second time. Frozen q threshold and gates are replayed descriptively.
"""
from pathlib import Path
import os
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
P191 = HERE.parent / "p191_confirmation_v1"
sys.dont_write_bytecode = True
for key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[key] = "1"
for key in ("TEMP", "TMP", "TMPDIR", "MPLCONFIGDIR", "NUMBA_CACHE_DIR", "TORCH_HOME", "_MNE_FAKE_HOME_DIR"):
    directory = HERE / "cache" / key.lower()
    directory.mkdir(parents=True, exist_ok=True)
    os.environ[key] = str(directory)
sys.path[:0] = [str(ROOT), str(HERE.parent / "p188_glrt_v1"), str(HERE.parent / "p188_neighbors_qim_v1")]

import gzip
import hashlib
import json
import time
from datetime import datetime, timezone
import numpy as np
from threadpoolctl import threadpool_limits
import receiver_api as api
import phase_geometry
from revision.post_20260926 import run_p181_data as edf
from revision.post_20260926 import p181_common as common

SOURCE = "OpenBMI018"
ARM = "smooth"
CONDITIONS = ("reexport", "elliptic_new_causal", "bessel_shifted_causal")
CHANNELS = ("FC3", "FC4", "C3", "C4", "Cz", "CP3", "CP4", "Pz")
FREEZE_SHA = "e181d74e991ef5cb2155cd41f60673dc3eaa8f1e0be449c8d6d77be1ef398fb8"
Q_THRESHOLD = -5.941561436978785e-5
RCOND = 1e-7


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    data = Path(path).read_bytes()
    return json.loads(gzip.decompress(data) if str(path).endswith(".gz") else data)


def write(path, value):
    path = Path(path)
    data = (json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(",", ":")) + "\n").encode()
    if str(path).endswith(".gz"):
        data = gzip.compress(data, compresslevel=5, mtime=0)
    partial = path.with_name(path.name + ".partial")
    partial.write_bytes(data)
    partial.replace(path)


def read_archive(path, artifact=None, source_metadata=None):
    packed = Path(path).read_bytes()
    raw = gzip.decompress(packed)
    values, _ = edf.parse_edf(raw, CHANNELS)
    hashes = dict(gzip_sha256=hashlib.sha256(packed).hexdigest(),
                  raw_sha256=hashlib.sha256(raw).hexdigest(),
                  samples_sha256=hashlib.sha256(values.tobytes()).hexdigest())
    if artifact is not None:
        assert hashes["raw_sha256"] == artifact["raw_sha256"]
        assert hashes["gzip_sha256"] == artifact["gzip_sha256"]
    if source_metadata is not None:
        assert hashes["gzip_sha256"] == source_metadata["clean_gzip_sha256"]
        assert hashes["samples_sha256"] == source_metadata["clean_samples_sha256"]
    return values, hashes


def decision(a):
    return int(a["top"]) if (a["eligible"] and a["support"] >= 1 and a["presence"] >= .25
                            and a["q"] >= Q_THRESHOLD) else -1


def geometry(a, code=None, parent=None, angle=None, tangent=None, alphas=None, index=None):
    G = np.asarray(a["pooled_winning_G"])
    beta = np.asarray(a["beta"])
    top = a["top"]
    delta = beta - np.eye(8)[top]
    effective = float(delta @ G @ delta / max(G[top, top], 1e-30))
    pair = [(float(G[top, top] + G[j, j] - 2*G[top, j]) / max(G[top, top], 1e-30), j)
            for j in range(8) if j != top]
    pair.sort()
    result = dict(beta_metric_squared_distance_to_top=effective,
                  total_fixed_residual_per_template_energy=a["top_held_RSS"]/max(G[top, top], 1e-30),
                  orthogonal_residual_per_template_energy=a["conditional_unrestricted_RSS"]/max(G[top, top], 1e-30),
                  beta_metric_distance_to_top=float(np.sqrt(max(effective, 0.))),
                  defect_vs_beta_metric_absolute_difference=abs(-a["q"] - effective),
                  beta_euclidean_distance_to_top=float(np.linalg.norm(delta)),
                  nearest_registered_metric_squared_distance=pair[0][0],
                  nearest_registered_identity=pair[0][1],
                  pooled_G_eigenvalues=np.linalg.eigvalsh((G+G.T)/2).tolist())
    if code is not None:
        coefficient = REGISTERED_CODES @ code
        nominal_delta = coefficient - np.eye(8)[top]
        result.update(nominal_code_coefficients=coefficient.tolist(),
                      nominal_code_predicted_squared_distance=float(nominal_delta @ G @ nominal_delta / max(G[top, top], 1e-30)),
                      beta_distance_to_nominal_code_coefficients=float(np.linalg.norm(beta-coefficient)))
        if alphas is not None:
            adjusted = alphas[index]/alphas[:8]*coefficient
            adjusted_delta = adjusted-np.eye(8)[top]
            result.update(alpha_adjusted_linear_code_coefficients=adjusted.tolist(),
                alpha_adjusted_linear_predicted_squared_distance=float(adjusted_delta@G@adjusted_delta/max(G[top,top],1e-30)),
                beta_distance_to_alpha_adjusted_linear_code=float(np.linalg.norm(beta-adjusted)))
    if tangent is not None:
        coeff = REGISTERED_CODES @ tangent
        result.update(code_tangent_coefficients=coeff.tolist(),
                      tangent_metric_ratio_to_parent=float(coeff @ G @ coeff / max(G[parent, parent], 1e-30)),
                      tangent_small_angle_squared_distance=float(angle**2 * coeff @ G @ coeff / max(G[parent, parent], 1e-30)))
    return result


def actual_feature(old):
    a = dict(old["receivers_by_order"]["257"]["methods"]["candidate_FIR_GLRT"]["by_ridge"]["0.0001"])
    a["q"] = -a["exact_normalized_identity_defect"]
    rebuilt = -max(a["top_held_RSS"] - a["conditional_unrestricted_RSS"], 0.) / max(a["winning_template_energy"], 1e-30)
    assert abs(a["q"]-rebuilt) < 1e-12
    a["frozen_threshold_decision"] = decision(a)
    assert a["frozen_threshold_decision"] == old["primary_decision"]
    return a


def prep_window(value, st):
    sl = slice(st*160-128, (st+8)*160+128)
    return api.p.filt(api.p.center(value[:, sl]))[:, 128:1408]


def known_operator_feature(query, clean, book):
    # One common scale preserves five-window relative weights; it cancels in q.
    scale = max(float(np.sqrt(np.mean(api.p.filt(api.p.center(clean))**2))), 1e-30)
    stats = []
    windowrss = []
    for st in api.p.STARTS:
        x = prep_window(clean, st)
        y = prep_window(query, st)
        templates = np.asarray([prep_window(b, st) for b in book])
        T = np.column_stack([api.old.vector(b-x) for b in templates]) / scale
        v = api.old.vector(y-x) / scale
        G, b, d = T.T@T, T.T@v, float(v@v)
        stats.append((G, b, d))
        windowrss.append([max(0., float(d+G[i, i]-2*b[i])) for i in range(8)])
    G, b, d = (sum(row[j] for row in stats) for j in range(3))
    beta = np.linalg.lstsq(G, b, rcond=RCOND)[0]
    rss = [max(0., float(d+G[i, i]-2*b[i])) for i in range(8)]
    order = np.argsort(rss, kind="stable")
    top = int(order[0])
    R, R2 = rss[top], rss[int(order[1])]
    U = max(0., float(d-b@beta))
    energy = float(G[top, top])
    floor = 64*np.finfo(float).eps*max(8*d, 8*np.trace(G), 1e-30)
    support = int(np.count_nonzero(np.argmin(windowrss, axis=1) == top))
    defect = max(R-U, 0.)
    return dict(top=top, q=-defect/max(energy, 1e-30),
                eligible=bool(2*b[top]-energy > 0), support=support,
                presence=float(np.clip(1.-R/max(d, floor), 0, 1)),
                relative_gap=float(np.clip((R2-R)/max(R2, floor), 0, 1)),
                compatibility=float(np.clip(1. if R <= floor else U/R, 0, 1)),
                candidate_RSS=rss, top_held_RSS=R, second_held_RSS=R2,
                conditional_unrestricted_RSS=U, unrestricted_RSS=U,
                winning_template_energy=energy, exact_identity_defect=defect,
                exact_normalized_identity_defect=defect/max(energy, 1e-30),
                clean_RSS=d, beta=beta.tolist(), pooled_winning_G=G.tolist(),
                pooled_winning_b=b.tolist(), pooled_winning_d=d,
                fold_RSS=windowrss, nominal_response_fit_count=0,
                response="known_true_forward_operator_no_prediction_quantization",
                alignment_delay=0, common_preprocess_scale=scale)


def family(row):
    if row["kind"] == "enrolled":
        return "registered"
    if row.get("pressure"):
        return "pressure0125"
    if row.get("angle") == .025:
        return "phase025"
    return "clean_wrong"


def summarize(rows):
    result = {}
    for condition in CONDITIONS:
        rr = [r for r in rows if r["condition"] == condition]
        result[condition] = {}
        for group in ("registered", "pressure0125", "phase025", "clean_wrong"):
            selected = [r for r in rr if family(r) == group]
            panel = dict(n=len(selected))
            for mode in ("actual", "known_operator"):
                values = [r["features"][mode] for r in selected]
                accepted = [r for r in selected if r["features"][mode]["frozen_threshold_decision"] >= 0]
                panel[mode] = dict(accepted=len(accepted),
                    correct=sum(r["features"][mode]["frozen_threshold_decision"] == r.get("identity") for r in accepted) if group == "registered" else None,
                    minimum_q=min(a["q"] for a in values), maximum_q=max(a["q"] for a in values))
            if group == "pressure0125":
                failures = [r for r in selected if r["features"]["actual"]["frozen_threshold_decision"] >= 0]
                panel["actual_false_accepts_rejected_with_known_operator"] = sum(r["features"]["known_operator"]["frozen_threshold_decision"] < 0 for r in failures)
                panel["actual_false_accepts_persist_with_known_operator"] = sum(r["features"]["known_operator"]["frozen_threshold_decision"] >= 0 for r in failures)
            result[condition][group] = panel
    return result


CODES, CODE_METADATA = phase_geometry.original_p181_pool()
REGISTERED_CODES = CODES[:8]


def main():
    tick = time.monotonic()
    freeze = P191 / "CONFIRMATION_FREEZE_FIX01.json"
    assert sha(freeze) == FREEZE_SHA
    raw_path = P191 / "raw/confirm" / SOURCE / "level100" / (ARM+".json.gz")
    issue_dir = P191 / "issuance" / SOURCE / "level100"
    issue_path = issue_dir / "issuance_summary.json"
    raw, issue = load(raw_path), load(issue_path)
    assert raw["status"] == "complete" and raw["confirmation_freeze_sha256"] == FREEZE_SHA
    assert sha(issue_path) == raw["issuance_sha256"]
    before = {str(p.relative_to(ROOT)).replace("\\", "/"):sha(p) for p in (freeze, raw_path, issue_path)}
    artifacts = {r["name"]:r for r in issue["artifacts"]}
    matched = {r["index"]:r for r in issue["phase_matching"] if r["arm"] == ARM and r["status"] == "matched"}
    alphas = np.asarray([matched[i]["value"]*matched[i]["scales"]["differential_taper"] for i in range(32)])
    input_archives = {}
    source_metadata = load(P191 / "sources" / SOURCE / "source.json")
    clean, hashes = read_archive(P191 / "sources" / SOURCE / "clean.edf.gz", source_metadata=source_metadata)
    input_archives["clean"] = hashes
    copies = []
    for i in range(32):
        name = f"{ARM}_r{i}_issued.edf"
        value, hashes = read_archive(issue_dir / (name+".gz"), artifact=artifacts[name])
        input_archives[name] = hashes
        copies.append(value)
        assert all(issue["metadata"][ARM][i][k] == CODE_METADATA[i][k] for k in ("kind", "parent", "angle", "direction", "pressure", "legacy_pool_index"))
    wrong = {}
    for old in raw["rows"]:
        if old["kind"] == "wrong_source" and old["negative_source"] not in wrong:
            name = old["negative_source"]
            metadata = load(P191 / "sources" / name / "source.json")
            wrong[name], hashes = read_archive(P191 / "sources" / name / "clean.edf.gz", source_metadata=metadata)
            input_archives[name] = hashes
    state = dict(status="running", pid=os.getpid(), started_utc=datetime.now(timezone.utc).isoformat(),
                 scope="post-confirmation diagnosis; bounded observed OpenBMI018 smooth only",
                 expected_n=len(raw["rows"]), freeze_sha256=FREEZE_SHA)
    write(HERE / "RUN_STATE.json", state)
    print(json.dumps(dict(event="diagnosis_started", pid=os.getpid(), output=str(HERE), queries=len(raw["rows"]))), flush=True)
    rows, receipts = [], []
    with threadpool_limits(limits=1):
        for condition in CONDITIONS:
            transformed_clean = common.transform(clean, condition)
            transformed_book = np.asarray([common.transform(v, condition) for v in copies[:8]])
            for old in [r for r in raw["rows"] if r["condition"] == condition]:
                i = old["query_index"]
                value = clean if old["kind"] == "clean" else wrong[old["negative_source"]] if old["kind"] == "wrong_source" else copies[i]
                query, _ = edf.edf_roundtrip(common.transform(value, condition),
                    tuple(np.asarray(v) for v in raw["query_limits_uv"][condition]),
                    f"{SOURCE}_level100_{ARM}_q{i}_{condition}.edf", HERE, receipts, False, CHANNELS)
                assert receipts[-1]["raw_sha256"] == old["query_raw_sha256"], (condition, i, "query bytes differ")
                actual = actual_feature(old)
                known = known_operator_feature(query, transformed_clean, transformed_book)
                known["frozen_threshold_decision"] = decision(known)
                meta = dict(code=CODES[i], alphas=alphas, index=i) if i < 32 else {}
                if old.get("angle"):
                    parent, angle = old["parent"], old["angle"]
                    tangent = (CODES[i]-np.cos(angle)*CODES[parent])/np.sin(angle)
                    meta.update(parent=parent, angle=angle, tangent=tangent)
                for feature in (actual, known):
                    feature["geometry"] = geometry(feature, **meta)
                row = {k:v for k,v in old.items() if k not in ("receivers_by_order", "decisions", "receiver_wall_seconds")}
                row.update(features=dict(actual=actual, known_operator=known), query_EDF_hash_matches=True,
                           query_samples_sha256=hashlib.sha256(query.tobytes()).hexdigest(),
                           q_known_minus_actual=known["q"]-actual["q"])
                rows.append(row)
                state.update(completed_n=len(rows), last_condition=condition, last_query_index=i,
                             seconds=time.monotonic()-tick)
                write(HERE / "RUN_STATE.json", state)
                if len(rows)%8 == 0:
                    print(json.dumps(dict(event="diagnosis_progress", n=len(rows), condition=condition)), flush=True)
    assert all(sha(ROOT/p) == digest for p,digest in before.items())
    summary = summarize(rows)
    result = dict(status="complete", role="post-confirmation diagnosis", source=SOURCE, arm=ARM,
        pid=os.getpid(), seconds=time.monotonic()-tick, rows=rows, summary=summary,
        query_EDF_hash_matches_n=len(rows), original_inputs_sha256=before, input_archive_hashes=input_archives,
        original_inputs_unchanged_after_diagnosis=True, code_sha256=sha(__file__),
        frozen_rule=dict(q_threshold=Q_THRESHOLD, ridge=1e-4, support=1, presence=.25),
        diagnostic_information="Known processing applied directly to archived actual clean and all eight actual enrolled copies; received query stays original serialized EDF. No second quantization of predictions.",
        window_contract=dict(starts=list(map(int,api.p.STARTS)), visible_context_samples=1536, scored_samples_each=1280,
            five_held_windows=True, same_window_center_filter_for_query_clean_and_templates=True,
            normalization="One common transformed-clean global RMS across all five windows; common factor cancels in q."),
        interpretation="Threshold/gates replayed descriptively on an uncalibrated diagnostic branch; no deployment policy or threshold is selected. Nominal code-tangent predictions assume a linear dictionary and are numerical descriptions only.",
        new_source_expansion=False, frozen_policy_changed=False)
    write(HERE / f"{SOURCE}_{ARM}_KNOWN_OPERATOR.json.gz", result)
    write(HERE / "SUMMARY.json", dict(status="complete", role=result["role"], source=SOURCE, summary=summary,
        query_EDF_hash_matches_n=len(rows), seconds=result["seconds"], frozen_rule=result["frozen_rule"]))
    state.update(status="complete", completed_n=len(rows), seconds=result["seconds"])
    write(HERE / "RUN_STATE.json", state)
    print(json.dumps(dict(event="diagnosis_complete", pid=os.getpid(), seconds=result["seconds"], summary=summary)), flush=True)


if __name__ == "__main__":
    main()
