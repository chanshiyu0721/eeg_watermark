"""Only reweight the old observed P190 known-operator diagnostic branch.

The P190 queries, provenance, scores, original diagnostic branches and thresholds
stay unchanged. Recomputed windowwise normalization must reproduce the old oracle
before the common-scale normalization is compared. No receiver refits are run.
"""
from pathlib import Path
import os
import time
import json
import numpy as np
from threadpoolctl import threadpool_limits
import known_operator_diagnosis as diag

HERE = Path(__file__).resolve().parent
P190 = HERE.parent / "p190_experiment_v1"
OLD = HERE.parent / "p191_separation_v1"
OUT = HERE / "legacy_common_scale"
CONDITION = "elliptic_new_causal"
LEGACY_THRESHOLD = .9957274054693162
PRESSURE_THRESHOLD = .9987280466974421


def windowwise_feature(query, clean, book):
    stats = []
    for st in diag.api.p.STARTS:
        x = diag.prep_window(clean, st)
        y = diag.prep_window(query, st)
        templates = np.asarray([diag.prep_window(v, st) for v in book])
        T = np.column_stack([diag.api.old.vector(v-x) for v in templates])
        v = diag.api.old.vector(y-x)
        energy = max(float(np.sum(T*T)), 1e-40)
        stats.append((T.T@T/energy, T.T@v/energy, float(v@v)/energy))
    G, b, d = (sum(row[j] for row in stats) for j in range(3))
    beta = np.linalg.lstsq(G,b,rcond=1e-7)[0]
    rss = [max(0.,float(d+G[i,i]-2*b[i])) for i in range(8)]
    top = int(np.argsort(rss,kind="stable")[0])
    R = rss[top]
    U = max(0.,float(d-b@beta))
    floor = 64*np.finfo(float).eps*max(8*d,8*np.trace(G),1e-30)
    fold_rss = [[max(0.,float(dd+gg[i,i]-2*bb[i])) for i in range(8)] for gg,bb,dd in stats]
    return dict(top=top, compatibility=float(np.clip(1. if R <= floor else U/R,0,1)),
        presence=float(np.clip(1.-R/max(d,floor),0,1)),
        support=int(np.count_nonzero(np.argmin(fold_rss,axis=1)==top)),
        eligible=bool(2*b[top]-G[top,top]>0),candidate_RSS=rss,unrestricted_RSS=U,
        clean_RSS=float(d),beta=beta.tolist())


def decision(a,threshold):
    return int(a["top"]) if a["eligible"] and a["support"]>=1 and a["presence"]>=.25 and a["compatibility"]>=threshold else -1


def summarize(rows):
    result = {}
    for name in ("registered","pressure0125","phase025","clean_wrong"):
        rr = [r for r in rows if diag.family(r)==name]
        result[name] = dict(n=len(rr))
        for mode in ("old_windowwise","common_scale"):
            result[name][mode] = {}
            for threshold_name in ("legacy","pressure_control"):
                accepted = [r for r in rr if r["features"][mode][threshold_name+"_decision"]>=0]
                result[name][mode][threshold_name] = dict(accepted=len(accepted),
                    correct=sum(r["features"][mode][threshold_name+"_decision"]==r.get("identity") for r in accepted) if name=="registered" else None)
    return result


def main():
    OUT.mkdir(exist_ok=True)
    tick=time.monotonic()
    state=dict(status="running",pid=os.getpid(),scope="Only old known-operator normalization confound",completed_sources=[])
    diag.write(OUT/"RUN_STATE.json",state)
    allrows=[]
    inputs={}
    max_parity=0.
    with threadpool_limits(limits=1):
        for number in range(5,13):
            source=f"OpenBMI{number:03d}"
            old_path=OLD/"runs"/("pilot01" if number in (5,12) else "all_observed_extension")/f"{source}_smooth_{CONDITION}.json.gz"
            raw_path=P190/"raw/confirm"/source/"level100/smooth.json.gz"
            issue_dir=P190/"issuance"/source/"level100"
            issue_path=issue_dir/"issuance_summary.json"
            for path in (old_path,raw_path,issue_path):inputs[str(path.relative_to(diag.ROOT)).replace("\\","/")]=diag.sha(path)
            old_diag=diag.load(old_path)
            raw=diag.load(raw_path)
            issue=diag.load(issue_path)
            assert old_diag["status"]==raw["status"]==issue["status"]=="complete"
            assert diag.sha(raw_path)==old_diag["inputs"]["raw_scores_sha256"]
            assert diag.sha(issue_path)==old_diag["inputs"]["issuance_sha256"]
            clean,_=diag.read_archive(P190/"sources"/source/"clean.edf.gz",source_metadata=diag.load(P190/"sources"/source/"source.json"))
            artifacts={a["name"]:a for a in issue["artifacts"]}
            copies=[]
            for i in range(32):
                name=f"smooth_r{i}_issued.edf"
                value,_=diag.read_archive(issue_dir/(name+".gz"),artifact=artifacts[name])
                copies.append(value)
            clean_forward=diag.common.transform(clean,CONDITION)
            book_forward=np.asarray([diag.common.transform(v,CONDITION) for v in copies[:8]])
            rows=[]
            receipts=[]
            for old in [r for r in raw["rows"] if r["condition"]==CONDITION]:
                i=old["query_index"]
                if old["kind"]=="clean":value=clean
                elif old["kind"]=="wrong_source":
                    name=old["negative_source"]
                    value,_=diag.read_archive(P190/"sources"/name/"clean.edf.gz",source_metadata=diag.load(P190/"sources"/name/"source.json"))
                else:value=copies[i]
                query,_=diag.edf.edf_roundtrip(diag.common.transform(value,CONDITION),
                    tuple(np.asarray(v) for v in raw["query_limits_uv"][CONDITION]),
                    f"{source}_level100_smooth_q{i}_{CONDITION}.edf",OUT,receipts,False,diag.CHANNELS)
                assert old["query_raw_sha256"]==receipts[-1]["raw_sha256"]
                archived=next(r for r in old_diag["rows"] if r["query_index"]==i)["features"]["known_operator"]
                windowwise=windowwise_feature(query,clean_forward,book_forward)
                for key in ("compatibility","presence"):
                    error=abs(windowwise[key]-archived[key]);max_parity=max(max_parity,error)
                    assert error<1e-9,(source,i,key,error)
                for key in ("top","support","eligible"):
                    assert windowwise[key]==archived[key],(source,i,key)
                common=diag.known_operator_feature(query,clean_forward,book_forward)
                features=dict(old_windowwise=windowwise,common_scale=common)
                for feature in features.values():
                    feature["legacy_decision"]=decision(feature,LEGACY_THRESHOLD)
                    feature["pressure_control_decision"]=decision(feature,PRESSURE_THRESHOLD)
                assert windowwise["legacy_decision"]==archived["legacy_threshold_decision"]
                row={k:old.get(k) for k in ("source","query_index","kind","identity","parent","angle","direction","pressure","condition","query_raw_sha256")}
                row.update(features=features,query_EDF_hash_matches=True)
                rows.append(row)
            allrows.extend(rows)
            diag.write(OUT/f"{source}_KNOWN_OPERATOR_SCALE_COMPARISON.json.gz",dict(status="complete",role="post-confirmation diagnostic normalization correction",source=source,condition=CONDITION,
                rows=rows,summary=summarize(rows),query_EDF_hash_matches_n=len(rows),
                original_oracle_parity_max_abs_error=max_parity,known_operator_only=True,no_original_branches_refitted=True))
            state["completed_sources"].append(source)
            diag.write(OUT/"RUN_STATE.json",state)
            print(json.dumps(dict(event="legacy_known_operator_source_complete",source=source,summary=summarize(rows))),flush=True)
    assert all(diag.sha(diag.ROOT/p)==digest for p,digest in inputs.items())
    summary=summarize(allrows)
    result=dict(status="complete",role="post-confirmation diagnostic normalization correction",summary=summary,
        condition=CONDITION,source_count=8,query_EDF_hash_matches_n=len(allrows),
        original_windowwise_oracle_parity_max_abs_error=max_parity,original_inputs_sha256=inputs,
        original_inputs_unchanged=True,known_operator_only=True,no_original_branches_refitted=True,
        seconds=time.monotonic()-tick,code_sha256=diag.sha(__file__),
        thresholds=dict(legacy=LEGACY_THRESHOLD,pressure_control=PRESSURE_THRESHOLD),
        interpretation="Old windowwise oracle is reproduced for parity. Common-scale oracle preserves five-window weights and only changes oracle normalization. Existing P190 and original mechanism outputs remain untouched.")
    diag.write(OUT/"SUMMARY.json",result)
    state.update(status="complete",seconds=result["seconds"])
    diag.write(OUT/"RUN_STATE.json",state)
    print(json.dumps(dict(event="legacy_scale_comparison_complete",summary=summary,seconds=result["seconds"])),flush=True)


if __name__=="__main__":main()
