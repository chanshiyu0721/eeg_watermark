"""Frozen local-quality rules for the post-development confirmation cohort."""
from __future__ import annotations

import numpy as np

MAX_RMS_RATIO = 100.0
MIN_AC_RMS_FRACTION = 0.01
MAX_CHANNEL_PRD_PCT = 1.0
MAX_GLOBAL_PRD_PCT = 1.0


def input_qc(signal: np.ndarray) -> dict[str, float | str | bool]:
    x = np.asarray(signal, dtype=np.float64)
    if x.ndim != 2 or x.size == 0 or not np.isfinite(x).all() or np.max(x) <= np.min(x):
        return {"pass": False, "reason": "invalid_or_constant", "max_rms_ratio": np.nan,
                "min_ac_rms_fraction": np.nan}
    rms = np.sqrt(np.mean(np.square(x), axis=1))
    ac = np.sqrt(np.mean(np.square(x - np.mean(x, axis=1, keepdims=True)), axis=1))
    median_rms, median_ac = float(np.median(rms)), float(np.median(ac))
    if median_rms <= 0 or median_ac <= 0:
        return {"pass": False, "reason": "near_flatline", "max_rms_ratio": np.nan,
                "min_ac_rms_fraction": 0.0}
    ratio = float(np.max(rms) / median_rms)
    ac_fraction = float(np.min(ac) / median_ac)
    reason = ("near_flatline" if ac_fraction < MIN_AC_RMS_FRACTION else
              "channel_rms_imbalance" if ratio > MAX_RMS_RATIO else "pass")
    return {"pass": reason == "pass", "reason": reason,
            "max_rms_ratio": ratio, "min_ac_rms_fraction": ac_fraction}


def output_qc(signal: np.ndarray, marked: np.ndarray) -> dict[str, float | str | bool]:
    x, y = np.asarray(signal, dtype=np.float64), np.asarray(marked, dtype=np.float64)
    if x.shape != y.shape or x.ndim != 2 or not np.isfinite(y).all():
        raise ValueError("invalid marked signal")
    error = y - x
    channel_norm = np.linalg.norm(x, axis=1)
    error_norm = np.linalg.norm(error, axis=1)
    channel_prd = np.divide(100 * error_norm, channel_norm,
                            out=np.full_like(channel_norm, np.inf), where=channel_norm > 0)
    global_norm = float(np.linalg.norm(x))
    global_prd = 100 * float(np.linalg.norm(error)) / global_norm if global_norm > 0 else np.inf
    maximum = float(np.max(channel_prd))
    reason = ("global_prd" if global_prd > MAX_GLOBAL_PRD_PCT else
              "max_channel_prd" if maximum > MAX_CHANNEL_PRD_PCT else "pass")
    return {"pass": reason == "pass", "reason": reason,
            "global_prd_pct": global_prd, "max_channel_prd_pct": maximum}
