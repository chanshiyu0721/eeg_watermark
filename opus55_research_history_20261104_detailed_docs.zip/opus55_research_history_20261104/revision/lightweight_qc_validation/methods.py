"""Mechanisms and deterministic stresses for phase-1 validation."""
from __future__ import annotations

import hashlib
import hmac
import struct
import time
from collections.abc import Callable

import numpy as np
import pywt
from scipy.signal import butter, sosfiltfilt

from revision.saw_core_v2 import (
    CapacityError,
    _block_location,
    _temporal_dwt,
    bit_error_rate,
    bits_to_bytes,
    build_authenticated_payload,
    bytes_to_bits,
    denormalize_signal,
    max_capacity,
    normalize_signal,
    qim_embed,
    qim_extract,
)

WAVELET = "haar"
METADATA_DOMAIN = b"EEG-QC-SCALE-v1\x00"


def qim_embed_nearest(value: float, bit: int, step: float) -> float:
    """Return the closest centre among all QIM bins carrying ``bit``.

    Valid centres are ``(2*k + bit + 0.5) * step``.  Ties are resolved toward
    the centre with larger k so behaviour is deterministic for signed values.
    """
    if not np.isfinite(step) or step <= 0:
        raise ValueError("step must be positive and finite")
    if bit not in (0, 1):
        raise ValueError("bit must be 0 or 1")
    coordinate = (float(value) / step - bit - 0.5) / 2.0
    k = int(np.floor(coordinate + 0.5))
    return float((2 * k + bit + 0.5) * step)


def encode_scale_metadata(signal: np.ndarray) -> bytes:
    """Encode a shared per-trial affine scale as two little-endian float32 values."""
    signal = np.asarray(signal, dtype=np.float64)
    min_v, max_v = float(np.min(signal)), float(np.max(signal))
    if not np.isfinite(min_v) or not np.isfinite(max_v) or max_v <= min_v:
        raise ValueError("signal must have a finite non-zero range")
    metadata = struct.pack("<ff", min_v, max_v)
    decoded_min, decoded_max = struct.unpack("<ff", metadata)
    if not np.isfinite(decoded_min) or not np.isfinite(decoded_max) or decoded_max <= decoded_min:
        raise ValueError("float32 scale metadata is not representable")
    return metadata


def decode_scale_metadata(metadata: bytes) -> tuple[float, float]:
    if len(metadata) < 8:
        raise ValueError("metadata must begin with an 8-byte scale")
    min_v, max_v = struct.unpack("<ff", metadata[:8])
    if not np.isfinite(min_v) or not np.isfinite(max_v) or max_v <= min_v:
        raise ValueError("invalid scale metadata")
    return float(min_v), float(max_v)


def encode_energy_mapping_metadata(signal: np.ndarray, bit_count: int = 208) -> bytes:
    """Encode scale plus a fixed top-energy channel subset for balanced mapping.

    At least half of the channels (and at least two when available) are used.
    Additional channels are included only when required for payload capacity.
    The selected channel indices are side information authenticated with the
    payload, so extraction never depends on re-ranking a perturbed signal.
    """
    signal = np.asarray(signal, dtype=np.float64)
    channels, samples = signal.shape
    if channels > 255:
        raise ValueError("energy mapping supports at most 255 channels")
    coefficient_length = pywt.dwt_coeff_len(samples, pywt.Wavelet(WAVELET).dec_len,
                                             mode="periodization")
    blocks_per_channel = coefficient_length // 4
    if blocks_per_channel <= 0:
        raise CapacityError("signal has no complete four-coefficient carrier block")
    required = int(np.ceil(bit_count / blocks_per_channel))
    selected_count = max(required, min(channels, max(2, int(np.ceil(channels / 2)))))
    if selected_count > channels:
        raise CapacityError(f"payload={bit_count} bits exceeds capacity={channels * blocks_per_channel} bits")
    energies = np.linalg.norm(signal, axis=1)
    order = np.lexsort((np.arange(channels), -energies))
    selected = order[:selected_count].astype(np.uint8).tobytes()
    return encode_scale_metadata(signal) + b"ET1" + bytes((channels, selected_count)) + selected


def decode_energy_mapping_metadata(metadata: bytes, channels: int) -> tuple[int, ...]:
    if len(metadata) < 13 or metadata[8:11] != b"ET1":
        raise ValueError("metadata does not contain an ET1 channel mapping")
    encoded_channels, selected_count = metadata[11], metadata[12]
    if encoded_channels != channels or selected_count < 1 or len(metadata) != 13 + selected_count:
        raise ValueError("energy mapping metadata shape mismatch")
    selected = tuple(int(value) for value in metadata[13:])
    if len(set(selected)) != selected_count or any(value >= channels for value in selected):
        raise ValueError("invalid channel mapping metadata")
    return selected


def build_metadata_authenticated_payload(signal: np.ndarray, *, metadata: bytes,
                                         device_id: str, timestamp: int, trial_id: str,
                                         secret_key: bytes) -> np.ndarray:
    """Build the existing 208-bit payload with its tag bound to scale metadata."""
    baseline = build_authenticated_payload(
        signal, device_id=device_id, timestamp=timestamp, trial_id=trial_id,
        secret_key=secret_key)
    body = bits_to_bytes(baseline)[:-8]
    tag = hmac.new(secret_key, METADATA_DOMAIN + body + metadata, hashlib.sha256).digest()[:8]
    return bytes_to_bits(body + tag)


def verify_metadata_authenticated_payload(bits: np.ndarray, *, metadata: bytes,
                                          secret_key: bytes) -> bool:
    try:
        raw = bits_to_bytes(bits)
    except ValueError:
        return False
    if len(raw) != 26 or len(metadata) < 8:
        return False
    body, supplied = raw[:-8], raw[-8:]
    expected = hmac.new(secret_key, METADATA_DOMAIN + body + metadata, hashlib.sha256).digest()[:8]
    return bool(body[0] == 2 and hmac.compare_digest(supplied, expected))


QUANTIZERS: dict[str, Callable[[float, int, float], float]] = {
    "legacy_upward": qim_embed,
    "nearest_codepoint": qim_embed_nearest,
}

VARIANTS = {
    "legacy_upward": ("legacy_upward", "sequential"),
    "nearest_codepoint": ("nearest_codepoint", "sequential"),
    "nearest_guarded": ("nearest_codepoint", "extrema_guarded"),
    "nearest_guarded_k16": ("nearest_codepoint", "rank_guarded:16"),
}


def _extrema_positions(signal: np.ndarray) -> tuple[tuple[int, int], tuple[int, int]]:
    signal = np.asarray(signal)
    return (tuple(int(x) for x in np.unravel_index(np.argmin(signal), signal.shape)),
            tuple(int(x) for x in np.unravel_index(np.argmax(signal), signal.shape)))


def _embedding_locations(signal: np.ndarray, c_a_length: int, mapping: str) -> list[tuple[int, int]]:
    channels = int(signal.shape[0])
    starts = range(0, (c_a_length // 4) * 4, 4)
    if mapping == "channel_balanced":
        # Round-robin across channels before advancing to the next temporal
        # block.  This keeps the carrier orthogonal while avoiding the spatial
        # concentration produced by channel-major sequential allocation.
        return [(channel, start) for start in starts for channel in range(channels)]
    if mapping.startswith("channel_subset:"):
        selected = tuple(int(value) for value in mapping.split(":", 1)[1].split(","))
        if not selected or len(set(selected)) != len(selected) or any(
                value < 0 or value >= channels for value in selected):
            raise ValueError("invalid channel subset mapping")
        return [(channel, start) for start in starts for channel in selected]
    locations = [(channel, start) for channel in range(channels) for start in starts]
    if mapping == "sequential":
        return locations
    if mapping == "extrema_guarded":
        guard_count = 1
    elif mapping.startswith("rank_guarded:"):
        guard_count = int(mapping.split(":", 1)[1])
        if guard_count < 1:
            raise ValueError("guard count must be positive")
    else:
        raise ValueError(f"unknown mapping: {mapping}")
    # For periodized Haar, cA[j] depends only on samples 2*j and 2*j+1.
    # Only cA indices 0,4,8,... carry payload bits in this benchmark.
    blocked = set()
    flat = np.asarray(signal).reshape(-1)
    order = np.argsort(flat, kind="stable")
    protected = np.unique(np.concatenate((order[:guard_count], order[-guard_count:])))
    for flat_index in protected:
        channel, sample = np.unravel_index(int(flat_index), signal.shape)
        coefficient = sample // 2
        if coefficient % 4 == 0:
            blocked.add((channel, coefficient))
    return [location for location in locations if location not in blocked]


def embed_core(normalized: np.ndarray, bits: np.ndarray, q_step: float, *,
               quantizer: str, mapping: str = "sequential", wavelet: str = WAVELET,
               carrier: str = "single", return_diagnostics: bool = False):
    bits = np.asarray(bits, dtype=np.int8).reshape(-1)
    normalized = np.asarray(normalized, dtype=np.float64)
    try:
        quantize = QUANTIZERS[quantizer]
    except KeyError as exc:
        raise ValueError(f"unknown quantizer: {quantizer}") from exc
    c_a, c_d = _temporal_dwt(normalized, wavelet)
    locations = _embedding_locations(normalized, c_a.shape[1], mapping)
    if bits.size > len(locations):
        raise CapacityError(f"payload={bits.size} bits exceeds mapped capacity={len(locations)} bits")
    embedded = c_a.copy()
    delta_sq = 0.0
    max_delta = 0.0
    if carrier == "block_dc" and quantizer == "nearest_codepoint":
        chosen = np.asarray(locations[:bits.size], dtype=np.int64)
        channels, starts = chosen[:, 0], chosen[:, 1]
        coefficient_indexes = starts[:, None] + np.arange(4, dtype=np.int64)
        selected = embedded[channels[:, None], coefficient_indexes]
        old_values = selected.sum(axis=1) * 0.5
        coordinates = (old_values / q_step - bits.astype(np.float64) - 0.5) / 2.0
        k = np.floor(coordinates + 0.5)
        new_values = (2.0 * k + bits + 0.5) * q_step
        deltas = new_values - old_values
        selected += deltas[:, None] * 0.5
        embedded[channels[:, None], coefficient_indexes] = selected
        delta_sq = float(np.dot(deltas, deltas))
        max_delta = float(np.max(np.abs(deltas))) if deltas.size else 0.0
    else:
      for (channel, start), bit in zip(locations[:bits.size], bits, strict=True):
        if carrier == "single":
            old = float(embedded[channel, start])
            new = quantize(old, int(bit), q_step)
            embedded[channel, start] = new
        elif carrier == "block_dc":
            unit = np.full(4, 0.5, dtype=np.float64)  # unit L2 norm
            block = embedded[channel, start:start + 4]
            old = float(np.dot(block, unit))
            new = quantize(old, int(bit), q_step)
            embedded[channel, start:start + 4] = block + (new - old) * unit
        else:
            raise ValueError(f"unknown carrier: {carrier}")
        delta = new - old
        delta_sq += delta * delta
        max_delta = max(max_delta, abs(delta))
    reconstructed = pywt.idwt(embedded, c_d, wavelet, mode="periodization", axis=-1)
    reconstructed = reconstructed[:, : normalized.shape[1]]
    if not return_diagnostics:
        return reconstructed
    return reconstructed, {
        "coefficient_delta_l2": float(np.sqrt(delta_sq)),
        "coefficient_delta_sq": float(delta_sq),
        "max_coefficient_delta": float(max_delta),
    }


def embed(signal: np.ndarray, bits: np.ndarray, q_step: float, *, variant: str) -> tuple[np.ndarray, dict]:
    signal = np.asarray(signal, dtype=np.float64)
    try:
        quantizer, mapping = VARIANTS[variant]
    except KeyError as exc:
        raise ValueError(f"unknown variant: {variant}") from exc
    extrema_before = _extrema_positions(signal)
    normalized, min_v, max_v = normalize_signal(signal)
    started = time.perf_counter_ns()
    wm_norm, diag = embed_core(normalized, bits, q_step, quantizer=quantizer, mapping=mapping,
                               return_diagnostics=True)
    watermarked = denormalize_signal(wm_norm, min_v, max_v)
    elapsed = time.perf_counter_ns() - started
    signal_l2 = float(np.linalg.norm(signal.reshape(-1)))
    scale = float((max_v - min_v) / 1000.0)
    diag.update({
        "predicted_prd_pct": 100.0 * scale * diag["coefficient_delta_l2"] / signal_l2,
        "embed_time_ns": int(elapsed),
        "original_min": min_v,
        "original_max": max_v,
        "extrema_positions_preserved": bool(_extrema_positions(watermarked) == extrema_before),
        "mapping_preserved": bool(
            _embedding_locations(signal, pywt.dwt_coeff_len(signal.shape[1], pywt.Wavelet(WAVELET).dec_len,
                                                           mode="periodization"), mapping)[:len(bits)]
            == _embedding_locations(watermarked, pywt.dwt_coeff_len(watermarked.shape[1], pywt.Wavelet(WAVELET).dec_len,
                                                                    mode="periodization"), mapping)[:len(bits)]),
    })
    return watermarked, diag


def embed_with_scale_metadata(signal: np.ndarray, bits: np.ndarray, q_step: float,
                              metadata: bytes, *, wavelet: str = WAVELET,
                              carrier: str = "single", mapping: str = "sequential") -> tuple[np.ndarray, dict]:
    """Nearest-codepoint direct DWT embedding under an explicit shared scale."""
    signal = np.asarray(signal, dtype=np.float64)
    min_v, max_v = decode_scale_metadata(metadata)
    if mapping == "authenticated_energy_top_half":
        selected = decode_energy_mapping_metadata(metadata, signal.shape[0])
        mapping = "channel_subset:" + ",".join(str(value) for value in selected)
    normalized = (signal - min_v) / (max_v - min_v) * 1000.0
    started = time.perf_counter_ns()
    wm_norm, diag = embed_core(normalized, bits, q_step, quantizer="nearest_codepoint",
                               mapping=mapping, wavelet=wavelet, carrier=carrier,
                               return_diagnostics=True)
    watermarked = denormalize_signal(wm_norm, min_v, max_v)
    diag.update({
        "predicted_prd_pct": 100.0 * ((max_v - min_v) / 1000.0)
        * diag["coefficient_delta_l2"] / float(np.linalg.norm(signal.reshape(-1))),
        "embed_time_ns": int(time.perf_counter_ns() - started),
        "metadata_bytes": len(metadata),
    })
    return watermarked, diag


def screen_and_embed_with_scale_metadata(signal: np.ndarray, bits: np.ndarray, q_step: float,
                                         metadata: bytes, prd_budget_pct: float, *,
                                         wavelet: str = WAVELET, carrier: str = "single",
                                         mapping: str = "sequential") -> dict:
    """Analytically reject over-budget embeddings before inverse DWT.

    For orthonormal Haar with periodization, the L2 norm of the modified
    approximation coefficients equals the time-domain error norm.  The shared
    affine scale converts that norm to physical units, so PRD is known before
    reconstructing the watermarked signal.
    """
    if not np.isfinite(prd_budget_pct) or prd_budget_pct < 0:
        raise ValueError("PRD budget must be finite and non-negative")
    signal = np.asarray(signal, dtype=np.float64)
    bits = np.asarray(bits, dtype=np.int8).reshape(-1)
    min_v, max_v = decode_scale_metadata(metadata)
    if mapping == "authenticated_energy_top_half":
        selected = decode_energy_mapping_metadata(metadata, signal.shape[0])
        mapping = "channel_subset:" + ",".join(str(value) for value in selected)
    started = time.perf_counter_ns()
    normalized = (signal - min_v) / (max_v - min_v) * 1000.0
    c_a, c_d = _temporal_dwt(normalized, wavelet)
    locations = _embedding_locations(normalized, c_a.shape[1], mapping)
    if bits.size > len(locations):
        raise CapacityError(f"payload={bits.size} bits exceeds mapped capacity={len(locations)} bits")
    embedded = c_a.copy()
    delta_sq = 0.0
    if carrier == "block_dc":
        chosen = np.asarray(locations[:bits.size], dtype=np.int64)
        channels, starts = chosen[:, 0], chosen[:, 1]
        coefficient_indexes = starts[:, None] + np.arange(4, dtype=np.int64)
        selected = embedded[channels[:, None], coefficient_indexes]
        old_values = selected.sum(axis=1) * 0.5
        coordinates = (old_values / q_step - bits.astype(np.float64) - 0.5) / 2.0
        k = np.floor(coordinates + 0.5)
        new_values = (2.0 * k + bits + 0.5) * q_step
        deltas = new_values - old_values
        selected += deltas[:, None] * 0.5
        embedded[channels[:, None], coefficient_indexes] = selected
        delta_sq = float(np.dot(deltas, deltas))
    else:
      for (channel, start), bit in zip(locations[:bits.size], bits, strict=True):
        if carrier == "single":
            old = float(embedded[channel, start])
            new = qim_embed_nearest(old, int(bit), q_step)
            embedded[channel, start] = new
        else:
            raise ValueError(f"unknown carrier: {carrier}")
        delta_sq += (new - old) ** 2
    predicted = 100.0 * ((max_v - min_v) / 1000.0) * np.sqrt(delta_sq) / float(
        np.linalg.norm(signal.reshape(-1)))
    accepted = bool(predicted <= prd_budget_pct)
    if accepted:
        wm_norm = pywt.idwt(embedded, c_d, wavelet, mode="periodization", axis=-1)
        watermarked = denormalize_signal(wm_norm[:, :signal.shape[1]], min_v, max_v)
        inverse_dwt_count = 1
    else:
        watermarked = None
        inverse_dwt_count = 0
    return {
        "accepted": accepted, "watermarked": watermarked,
        "predicted_prd_pct": float(predicted),
        "elapsed_ns": int(time.perf_counter_ns() - started),
        "forward_dwt_count": 1, "inverse_dwt_count": inverse_dwt_count,
    }


def extract_with_scale_metadata(signal: np.ndarray, bit_count: int, q_step: float,
                                metadata: bytes, *, wavelet: str = WAVELET,
                                carrier: str = "single", mapping: str = "sequential") -> tuple[np.ndarray, int]:
    signal = np.asarray(signal, dtype=np.float64)
    min_v, max_v = decode_scale_metadata(metadata)
    if mapping == "authenticated_energy_top_half":
        selected = decode_energy_mapping_metadata(metadata, signal.shape[0])
        mapping = "channel_subset:" + ",".join(str(value) for value in selected)
    normalized = (signal - min_v) / (max_v - min_v) * 1000.0
    c_a, _ = _temporal_dwt(normalized, wavelet)
    locations = _embedding_locations(normalized, c_a.shape[1], mapping)
    if bit_count > len(locations):
        raise CapacityError(f"payload={bit_count} bits exceeds mapped capacity={len(locations)} bits")
    started = time.perf_counter_ns()
    result = np.empty(bit_count, dtype=np.int8)
    if carrier == "block_dc":
        chosen = np.asarray(locations[:bit_count], dtype=np.int64)
        channels, starts = chosen[:, 0], chosen[:, 1]
        coefficient_indexes = starts[:, None] + np.arange(4, dtype=np.int64)
        blocks = c_a[channels[:, None], coefficient_indexes]
        values = blocks.sum(axis=1) * 0.5
        result[:] = (np.floor(values / q_step + 1e-10).astype(np.int64) & 1).astype(np.int8)
    else:
      for index, (channel, start) in enumerate(locations[:bit_count]):
        if carrier == "single":
            value = float(c_a[channel, start])
        else:
            raise ValueError(f"unknown carrier: {carrier}")
        result[index] = qim_extract(value, q_step)
    return result, int(time.perf_counter_ns() - started)


def extract(signal: np.ndarray, bit_count: int, q_step: float, *, variant: str,
            wavelet: str = WAVELET) -> tuple[np.ndarray, int]:
    normalized, _, _ = normalize_signal(signal)
    started = time.perf_counter_ns()
    c_a, _ = _temporal_dwt(normalized, wavelet)
    try:
        _, mapping = VARIANTS[variant]
    except KeyError as exc:
        raise ValueError(f"unknown variant: {variant}") from exc
    locations = _embedding_locations(signal, c_a.shape[1], mapping)
    if bit_count > len(locations):
        raise CapacityError(f"payload={bit_count} bits exceeds mapped capacity={len(locations)} bits")
    result = np.empty(bit_count, dtype=np.int8)
    for index, (channel, start) in enumerate(locations[:bit_count]):
        result[index] = qim_extract(float(c_a[channel, start]), q_step)
    return result, int(time.perf_counter_ns() - started)


def deterministic_seed(trial_id: str, stress: str) -> int:
    digest = hashlib.sha256(f"{trial_id}|{stress}".encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "little", signed=False)


def apply_stress(watermarked: np.ndarray, original: np.ndarray, fs_hz: float,
                 stress: str, trial_id: str) -> np.ndarray:
    wm = np.asarray(watermarked, dtype=np.float64)
    original = np.asarray(original, dtype=np.float64)
    if stress == "clean":
        return wm.copy()
    if stress == "float32_roundtrip":
        return wm.astype(np.float32).astype(np.float64)
    if stress == "quantize16":
        lo, hi = float(np.min(original)), float(np.max(original))
        step = (hi - lo) / 65535.0
        return np.clip(np.rint((wm - lo) / step), 0, 65535) * step + lo
    if stress == "awgn40":
        rng = np.random.default_rng(deterministic_seed(trial_id, stress))
        rms = float(np.sqrt(np.mean(wm ** 2)))
        sigma = rms / (10.0 ** (40.0 / 20.0))
        return wm + rng.normal(0.0, sigma, size=wm.shape)
    if stress == "bandpass_0p5_45":
        nyquist = float(fs_hz) / 2.0
        high = min(45.0, 0.95 * nyquist)
        if high <= 0.5:
            raise ValueError(f"sampling rate {fs_hz} is too low for requested bandpass")
        sos = butter(4, [0.5 / nyquist, high / nyquist], btype="bandpass", output="sos")
        return sosfiltfilt(sos, wm, axis=-1)
    raise ValueError(f"unknown stress: {stress}")


def evaluate_recovery(bits: np.ndarray, received: np.ndarray, q_step: float, *, variant: str) -> dict:
    extracted, extract_ns = extract(received, len(bits), q_step, variant=variant)
    ber = bit_error_rate(bits, extracted)
    return {"ber": ber, "exact_recovery": bool(ber == 0.0), "extract_time_ns": extract_ns,
            "extracted_bits": extracted}
