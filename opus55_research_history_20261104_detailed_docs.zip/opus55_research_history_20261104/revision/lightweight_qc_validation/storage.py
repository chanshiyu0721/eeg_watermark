"""Versioned integer storage interface for the frozen EEG watermark method.

The authenticated embedding scale is deliberately separate from this storage
range: quantization must cover the *watermarked* samples, not the input extrema.
"""
from __future__ import annotations

import struct

import numpy as np

_HEADER = struct.Struct("<4sBff")
_MAGIC = b"EQS1"
SUPPORTED_BITS = (16, 24)


def storage_bounds(signal: np.ndarray) -> tuple[float, float]:
    values = np.asarray(signal, dtype=np.float64)
    if values.ndim != 2 or not values.size or not np.isfinite(values).all():
        raise ValueError("storage requires a nonempty finite channel-by-sample array")
    minimum, maximum = float(np.min(values)), float(np.max(values))
    if minimum >= maximum:
        raise ValueError("storage requires a nonconstant signal")
    lo, hi = np.float32(minimum), np.float32(maximum)
    if not np.isfinite(lo) or not np.isfinite(hi):
        raise ValueError("storage bounds are not finite in float32")
    if float(lo) > minimum:
        lo = np.nextafter(lo, np.float32(-np.inf), dtype=np.float32)
    if float(hi) < maximum:
        hi = np.nextafter(hi, np.float32(np.inf), dtype=np.float32)
    if not np.isfinite(lo) or not np.isfinite(hi) or lo >= hi:
        raise ValueError("outward float32 storage bounds are not representable")
    return float(lo), float(hi)


def encode_integer_storage(signal: np.ndarray, bits: int) -> tuple[np.ndarray, bytes]:
    """Return unsigned integer codes and a 13-byte range/version header.

    Bounds are rounded outward in float32. Any clipping is an error, never a
    silent success; decoder uses exactly the recorded bounds.
    """
    if bits not in SUPPORTED_BITS:
        raise ValueError(f"supported integer depths are {SUPPORTED_BITS}")
    values = np.asarray(signal, dtype=np.float64)
    lo, hi = storage_bounds(values)
    levels = (1 << bits) - 1
    scaled = (values - lo) * (levels / (hi - lo))
    if np.any(scaled < -1e-7) or np.any(scaled > levels + 1e-7):
        raise ValueError("outward storage range failed to cover samples")
    codes = np.rint(np.clip(scaled, 0, levels)).astype(np.uint16 if bits == 16 else np.uint32)
    return codes, _HEADER.pack(_MAGIC, bits, lo, hi)


def decode_integer_storage(codes: np.ndarray, header: bytes) -> np.ndarray:
    if len(header) != _HEADER.size:
        raise ValueError("invalid storage header length")
    magic, bits, lo, hi = _HEADER.unpack(header)
    if magic != _MAGIC or bits not in SUPPORTED_BITS or not np.isfinite((lo, hi)).all() or lo >= hi:
        raise ValueError("invalid storage header")
    array = np.asarray(codes)
    expected = np.dtype(np.uint16 if bits == 16 else np.uint32)
    if array.ndim != 2 or array.dtype != expected or not array.size:
        raise ValueError("storage codes have invalid shape or dtype")
    levels = (1 << bits) - 1
    if np.any(array > levels):
        raise ValueError("storage code exceeds bit depth")
    return lo + array.astype(np.float64) * ((hi - lo) / levels)


def pack_codes(codes: np.ndarray, bits: int) -> bytes:
    """Serialize logical codes as exactly 2 or 3 little-endian bytes/sample."""
    if bits not in SUPPORTED_BITS:
        raise ValueError(f"supported integer depths are {SUPPORTED_BITS}")
    array = np.asarray(codes)
    expected = np.dtype(np.uint16 if bits == 16 else np.uint32)
    if array.ndim != 2 or array.dtype != expected or np.any(array > (1 << bits) - 1):
        raise ValueError("invalid codes for packed storage")
    if bits == 16:
        return array.astype("<u2", copy=False).tobytes()
    return np.ascontiguousarray(array.astype("<u4", copy=False)).view(np.uint8).reshape(-1, 4)[:, :3].tobytes()


def unpack_codes(data: bytes, shape: tuple[int, int], bits: int) -> np.ndarray:
    if bits not in SUPPORTED_BITS or len(shape) != 2 or min(shape) <= 0:
        raise ValueError("invalid storage dimensions or bit depth")
    count = shape[0] * shape[1]
    if len(data) != count * (bits // 8):
        raise ValueError("packed storage byte length mismatch")
    if bits == 16:
        return np.frombuffer(data, dtype="<u2").astype(np.uint16).reshape(shape).copy()
    unpacked = np.zeros((count, 4), dtype=np.uint8)
    unpacked[:, :3] = np.frombuffer(data, dtype=np.uint8).reshape(-1, 3)
    return unpacked.reshape(-1).view("<u4").reshape(shape).copy()
