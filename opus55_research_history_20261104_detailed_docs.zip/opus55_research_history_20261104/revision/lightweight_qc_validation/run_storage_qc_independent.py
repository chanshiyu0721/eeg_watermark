"""One-pass, resumable execution of the frozen storage/QC independent protocol."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import time
from pathlib import Path

import mne
import numpy as np
import pandas as pd

from revision.rerun_v2 import DEFAULT_TIMESTAMP, TEST_KEY
from revision.lightweight_qc_validation import methods, qc, storage
from revision.lightweight_qc_validation.download_external_datasets import BASE, checksum
from revision.lightweight_qc_validation.run_external_confirmation import eeg_picks
from revision.lightweight_qc_validation.run_expanded_recovery import append_rows, read_completed

HERE = Path(__file__).resolve().parent
OUT = HERE / "storage_qc_independent"
KEYS = ["trial_id", "dataset", "source_file", "trial_index", "channels", "samples", "fs_hz",
        "input_pass", "input_reason", "max_rms_ratio", "min_ac_rms_fraction", "output_pass",
        "output_reason", "global_prd_pct", "max_channel_prd_pct", "accepted", "embed_ns",
        "clean_exact", "clean_auth", "float32_exact", "float32_auth", "q24_exact",
        "q24_auth", "q16_exact", "q16_auth", "q24_header_bytes", "q16_header_bytes",
        "q24_clipped", "q16_clipped"]


def evaluate(signal: np.ndarray, identity: str, dataset: str, source: str,
             start: int, fs: float) -> dict:
    x = np.asarray(signal, dtype=np.float64)
    row = dict.fromkeys(KEYS, "")
    row.update(trial_id=identity, dataset=dataset, source_file=source, trial_index=start,
               channels=x.shape[0], samples=x.shape[1], fs_hz=fs, accepted=0)
    input_result = qc.input_qc(x)
    row.update(input_pass=int(input_result["pass"]), input_reason=input_result["reason"],
               max_rms_ratio=input_result["max_rms_ratio"],
               min_ac_rms_fraction=input_result["min_ac_rms_fraction"])
    if not input_result["pass"]:
        return row
    metadata = methods.encode_energy_mapping_metadata(x)
    payload = methods.build_metadata_authenticated_payload(
        x, metadata=metadata, device_id="SAW-V2-BENCHMARK", timestamp=DEFAULT_TIMESTAMP,
        trial_id=identity, secret_key=TEST_KEY)
    started = time.perf_counter_ns()
    marked, _ = methods.embed_with_scale_metadata(
        x, payload, 0.5, metadata, carrier="block_dc", mapping="authenticated_energy_top_half")
    row["embed_ns"] = time.perf_counter_ns() - started
    output_result = qc.output_qc(x, marked)
    row.update(output_pass=int(output_result["pass"]), output_reason=output_result["reason"],
               global_prd_pct=output_result["global_prd_pct"],
               max_channel_prd_pct=output_result["max_channel_prd_pct"])
    if not output_result["pass"]:
        return row
    row["accepted"] = 1
    for name, received in (("clean", marked),
                           ("float32", marked.astype(np.float32).astype(np.float64))):
        extracted, _ = methods.extract_with_scale_metadata(
            received, payload.size, 0.5, metadata, carrier="block_dc",
            mapping="authenticated_energy_top_half")
        row[f"{name}_exact"] = int(np.array_equal(payload, extracted))
        row[f"{name}_auth"] = int(methods.verify_metadata_authenticated_payload(
            extracted, metadata=metadata, secret_key=TEST_KEY))
    for bits in (24, 16):
        codes, header = storage.encode_integer_storage(marked, bits)
        lo, hi = storage.storage_bounds(marked)
        row[f"q{bits}_clipped"] = int(np.count_nonzero((marked < lo) | (marked > hi)))
        packed = storage.pack_codes(codes, bits)
        restored_codes = storage.unpack_codes(packed, marked.shape, bits)
        received = storage.decode_integer_storage(restored_codes, header)
        extracted, _ = methods.extract_with_scale_metadata(
            received, payload.size, 0.5, metadata, carrier="block_dc",
            mapping="authenticated_energy_top_half")
        row[f"q{bits}_exact"] = int(np.array_equal(payload, extracted))
        row[f"q{bits}_auth"] = int(methods.verify_metadata_authenticated_payload(
            extracted, metadata=metadata, secret_key=TEST_KEY))
        row[f"q{bits}_header_bytes"] = len(header)
    return row


def file_list(datasets: tuple[str, ...]) -> list[tuple[str, str, str, float]]:
    manifest = json.loads((OUT / "planned_manifest.json").read_text(encoding="utf-8"))
    result = []
    for source_name, dataset, seconds in (("sleep-edfx", "SleepEDF-21-40", 30.0),
                                          ("chbmit", "CHBMIT-chb02", 4.0)):
        if source_name not in datasets:
            continue
        for file in manifest["datasets"][source_name]["files"]:
            relative = file["path"]
            target = BASE / source_name / relative
            if checksum(target) != file["sha256"]:
                raise RuntimeError(f"source checksum mismatch: {target}")
            result.append((dataset, f"{source_name}/{relative}", str(target), seconds))
    return result


def summarize() -> None:
    frame = pd.read_csv(OUT / "per_trial.csv")
    errors_path = OUT / "errors.csv"
    errors = pd.read_csv(errors_path) if errors_path.exists() else pd.DataFrame(columns=["dataset"])
    rows = []
    for dataset, group in frame.groupby("dataset"):
        accepted = group[group["accepted"].eq(1)]
        row = {"dataset": dataset, "windows_processed": len(group),
               "errors": int(errors["dataset"].eq(dataset).sum()),
               "accepted": len(accepted), "rejected": int(group["accepted"].eq(0).sum()),
               "acceptance_rate": len(accepted) / (len(group) + int(errors["dataset"].eq(dataset).sum())),
               "input_rejected": int(group["input_pass"].eq(0).sum()),
               "output_rejected": int((group["input_pass"].eq(1) & group["output_pass"].eq(0)).sum()),
               "max_global_prd_pct": float(group["global_prd_pct"].max()),
               "max_channel_prd_pct": float(group["max_channel_prd_pct"].max())}
        for condition in ("clean", "float32", "q24", "q16"):
            row[f"{condition}_exact_count"] = int(accepted[f"{condition}_exact"].sum())
            row[f"{condition}_auth_count"] = int(accepted[f"{condition}_auth"].sum())
            row[f"{condition}_exact_rate"] = float(accepted[f"{condition}_exact"].mean()) if len(accepted) else np.nan
        for bits in (24, 16):
            row[f"q{bits}_clipped_samples"] = int(accepted[f"q{bits}_clipped"].sum())
        rows.append(row)
    pd.DataFrame(rows).to_csv(OUT / "summary.csv", index=False, encoding="utf-8-sig")
    frame.groupby(["dataset", "input_reason", "output_reason"], dropna=False).size().rename(
        "windows").reset_index().to_csv(OUT / "rejection_reasons.csv", index=False, encoding="utf-8-sig")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--stop-after", type=int)
    parser.add_argument("--datasets", nargs="+", choices=["sleep-edfx", "chbmit"],
                        default=["sleep-edfx", "chbmit"])
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    audit_path = OUT / "run_code_sha256.json"
    if not audit_path.exists():
        audited = ["STORAGE_QC_INDEPENDENT_PROTOCOL.md", "methods.py", "qc.py", "storage.py",
                   "run_storage_qc_independent.py"]
        audit_path.write_text(json.dumps({name: hashlib.sha256((HERE / name).read_bytes()).hexdigest()
                                          for name in audited}, indent=2), encoding="utf-8")
    files = file_list(tuple(args.datasets))
    result_path, error_path = OUT / "per_trial.csv", OUT / "errors.csv"
    completed = read_completed(result_path) | read_completed(error_path)
    buffer, processed = [], 0
    for dataset, source, absolute, seconds in files:
        raw = mne.io.read_raw_edf(absolute, preload=False, verbose="ERROR")
        try:
            picks = eeg_picks(raw)
            width = int(round(seconds * float(raw.info["sfreq"])))
            for start in range(0, raw.n_times - width + 1, width):
                identity = f"{dataset}/{source}/{start:012d}"
                if identity in completed:
                    continue
                try:
                    signal = raw.get_data(picks=picks, start=start, stop=start + width)
                    buffer.append(evaluate(signal, identity, dataset, source, start,
                                           float(raw.info["sfreq"])))
                except Exception as exc:
                    with error_path.open("a", newline="", encoding="utf-8") as handle:
                        writer = csv.DictWriter(handle, fieldnames=["trial_id", "dataset", "source_file",
                                                                   "trial_index", "error_type", "message"])
                        if handle.tell() == 0:
                            writer.writeheader()
                        writer.writerow({"trial_id": identity, "dataset": dataset,
                                         "source_file": source, "trial_index": start,
                                         "error_type": type(exc).__name__, "message": str(exc)})
                processed += 1
                if len(buffer) >= 100:
                    append_rows(result_path, buffer); buffer.clear()
                if processed % 1000 == 0:
                    print(f"new windows={processed} dataset={dataset}", flush=True)
                if args.stop_after and processed >= args.stop_after:
                    break
            print(f"source complete: {source}", flush=True)
        finally:
            raw.close()
        if args.stop_after and processed >= args.stop_after:
            break
    append_rows(result_path, buffer)
    if result_path.exists():
        summarize()
    print(f"run complete: new windows={processed}", flush=True)


if __name__ == "__main__":
    main()
