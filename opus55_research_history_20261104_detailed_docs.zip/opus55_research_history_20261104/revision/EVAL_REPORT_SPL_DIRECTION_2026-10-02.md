# 独立评估报告：以 IEEE SPL 为目标的方向判断

评估日期：2026-10-02
评估对象：`revision/DEEPSEEK_HARNESS_HANDOFF_SPL_DIRECTION_2026-10-02.md` 所列方法与证据
评估身份：独立、严格的论文评估者（只读复查，未修改任何项目代码或数据，未新增实验结论）
评估环境：本地文件可读；网络可读（IEEE SPS 官方页、Crossref、eScholarship 全文 PDF、作者 GitHub）；OpenAlex/Semantic Scholar 被限流

---

## 0. 结论（≤300 字）

**按现有方法直接投稿 SPL，不建议，风险高于收益。** 主要拒稿风险是"已确立算法与理论的直接组合 + 缺少真正可比基线"：四系数单位投影是 STDM/块投影 QIM 的特例（该投影向量的设计本身在 2006 年已有专文），解析 PRD 是正交小波域的 Parseval 恒等式，"任务/诊断保持"已被 RPW-EEG（CogSci 2025，公开代码，任务范式准确率 88.5%）与 DS-FTAN（Electronics 2026，"仅 0.42% 下游准确率下降"）两次先占；SPL 官方明文把这类稿列为"立即拒稿候选"。且证据显示四系数投影相对 2017 DWT-SVD 核心适配**无质量优势**（0.0550% vs 0.0585%），"轻量"仅给出整链时延而未与无嵌入基线对比，多数消融结论为"数据依赖"或"无差异"。

**但不宜放弃，应重构。** 唯一经检索未发现先例的点是：**整数（16/24-bit）存储量化后水印提取裕量的可分析设计**。建议把贡献从"轻量可分析水印"改为"任务频带与存储位深联合约束下的投影/步长设计"，只保留一条可检验主张，重做真正没看过的确认集。否则应退出 SPL，转投生物医学信号/医疗信息类期刊作应用论文。

---

## 1. 我实际核验了什么（可复查路径）

### 1.1 已证实（我读了实现并逐项对上文档）

| 文档说法 | 核验结果 | 证据位置 |
|---|---|---|
| 正式方法为四系数单位投影 `[0.5,0.5,0.5,0.5]`、最近码点 QIM、Q=0.5 | **一致**。全部正式运行脚本均传 `carrier='block_dc'`，映射为 `authenticated_energy_top_half` | `revision/lightweight_qc_validation/methods.py:229-233`；`revision/post_20260926/utility_common.py:26`、`run_p3_certificate.py:48` |
| 投影 = 四系数块 DC | **一致**。`unit=full(4,0.5)`（L2 范数 1），`old=block·unit=S/2`，`embedded=block+(new-old)*unit`。导出为 `S'=2·QIM(S/2)`，即"对四系数和做步长 Q 的奇偶 QIM" | `methods.py:229-233`；我独立复算确认与"对 S/2 用步长 Q/2"等价 |
| 一级 Haar periodization、互不重叠四系数块 | **一致**。`starts=range(0,(len//4)*4,4)`，每块 4 个连续 cA | `methods.py:155` |
| 208-bit 载荷 = HMAC + 尺度元数据 + 通道索引 | **一致**。26 字节 = 18 字节正文（含版本 2）+ 8 字节截断 HMAC；tag 定义域含 `metadata`（=8B scale + `ET1` + 通道列表） | `methods.py:109-131`；26 字节与实测一致（`p3_resource_v1/RESULTS.md`） |
| 选道 = 原信号能量排序高能量半数，索引为认证侧信息 | **一致**。`selected_count=max(required, min(C,max(2,ceil(C/2))))`，`np.linalg.norm` 排序，索引写入 ET1 并参与 HMAC | `methods.py:70-106` |
| 整数存储上下界向外扩展、裁剪报错 | **一致**。float32 `nextafter` 外扩；`scaled` 越界即 `ValueError` | `storage.py:17-51` |
| 逐窗 PRD 与全局 PRD 双 1% 阈值 | **一致**。`MAX_CHANNEL_PRD_PCT = MAX_GLOBAL_PRD_PCT = 1.0` | `qc.py:8-9, 31-46` |

### 1.2 数值证据核验（我读了证据 CSV 并重算）

- `p3_certificate_v1/A01T_per_trial.csv` 共 1,024 行，与"128 窗 × 4 个 Q × 2 位深"一致。
- **证书倍率精确成立**：`bit_shift_upper = sqrt(2)*1000*h/D`。我用 `D = sqrt(2)*1000*h/bit_shift_upper` 反解，128 窗反解值与 `storage_step/(2^16-1)` 的比值中位数为 **65534.997**，即 D 恰为存储跨度，倍率无自由参数，文档未失真。
- 证书通过/失败分界可复现：Q=0.5、0.125 在两位深下 128/128 全通过；Q=0.03125、0.015625 在 16-bit 下 0/128，而 24-bit 下 128/128。与 `RESULTS.md` 表格一致。
- 实测最坏投影偏移为解析倍率的 **0.585 倍**（16/24-bit 均同），说明该倍率不紧但未失效。
- 独立复算的三条基础数学（用自带 numpy 从零实现 Haar，未使用项目环境）：
  - 单位样本脉冲的 cA 仅 `0.7071` 在 index 0，确认 `cA[2i]=(x2i+x2i+1)/sqrt(2)`；
  - 单块扰动 `dcA=[0.5,0.5,0.5,0.5]` 对应时域 8 点权重 `[1.3536,0.3536×7]`，即**每样本权重 `1/(2*sqrt(2))`**，与协议一致；
  - 系数域能量 1.0 = 时域误差范数平方 0.9999999999999996，Parseval 恒等式确认；
  - QIM 往返在 Q=0.5 与 Q=0.03125 下 40,000/40,000 位正确，`max|delta|=Q/2` 确认。
- 频谱数字有出处：block_dc 的 gamma P95 = 0.3688 dB vs single 载体 2.2866 dB（`carrier_diagnostic/RESULTS.md:5-6`），新试验确认 0.2804 dB（`blockdc_confirmation/RESULTS.md:16`）。**已证实**。

### 1.3 推断（我未重跑，源自记录值 + 我的推导）

- **存储量化在正式配置下对绝对信号幅度微不足道。** 由 CSV 反解的每段嵌入跨度 D 中位 6.99e-5、存储步长 h 中位 1.07e-9，因此**每样本最坏存储误差 h/2 ≈ 5.3e-10（原生单位）**，而实测投影偏移 0.0126（归一化）= 全长 1.26e-5。两级都比真实 EEG 噪声底（µV 量级）小 3–4 个数量级。
- **因此"16/24-bit 存储"不是一个有威胁的信道。** 该"可分析"结论的真实内容是**否定性**的：在 Q=0.5 下存储位深不构成约束。这本身是有价值的信息，但它不能充当方法创新。

### 1.4 我未能核验的（明确标注，不臆造）

- 我没有项目运行环境（`pywt` 未装），**未**重跑嵌入/提取、未重算存储误差范数；1.3 的结论来自记录值与算术推导。
- 我只核对了 `p3_certificate_v1` 的 A01T 逐窗 CSV 与若干 `RESULTS.md`，**未**逐行核对 `bci_mi_session`、`rsvp_natural_v1`、`eegnet_session_v1`、`p4_*` 的逐窗产物。
- 2015 Pham 原文与 2017 Pham 摘要为闭源；我依赖元数据/标题级证据，未读正文。
- DS-FTAN（Electronics 2026）与 2020 Electronics Letters 等仅得摘要/题录，正文 403。

---

## 2. 对现有证据的严格评估（含与文档的**分歧**）

### 2.1 文档质量：明显高于常态，主要偏差方向是自我不利

备忘录主动写出了对己不利的事实（能力不足、证书保守、L4 无优势、S21–S30 已被看过、无独立外部确认、不能称盲提取）。**这是本次评估最大的正面信号**：它说明作者不会用错误结论填充论文。

### 2.2 一处必须修正的技术表述（**建议**，非"已证明的推导错误"）

`P3_CERTIFICATE_PROTOCOL_2026-10-01.md` 第 8 条写"存储误差造成的投影偏移不大于 `sqrt(2)*1000*h/D`"。按记录值，**这个常数不是任何逐样本最坏上界**：

- 单个存储误差对投影的权重是 `1/(2*sqrt(2))`；208 个投影共 416 个 cA 系数，coherent 最坏累积上界约为 `(h/2)·(416/2)·(1/(2*sqrt(2))) = 18.4h`，是现用常数 `sqrt(2)*h ≈ 1.414h` 的**约 13 倍**；
- 实测值恰为 `0.585 × sqrt(2)*1000h/D`，说明它的实际含义是"典型最坏"而非"上界"。它是**口径正确的统计裕量**，不是推导出来的充分条件。

**必须三选一**：(a) 把该量重新命名为经验裕量并给出校准方法与覆盖概率；(b) 换成可证的最坏上界（会变得极松，可能失去区分力，见 1.3）；(c) 重推为"存储误差随样本近似独立均匀"下的失败概率界。**在完成之前，论文不得出现"sufficient condition / certified"字样**，否则这是审稿人最容易一击致命的地方（SPL 明文要求 "figures, tables and other reported results accurately reflect the experimental work"）。

### 2.3 已确认的"无优势"与"数据依赖"

- 对 2017 DWT-SVD 核心适配：同一 864/3000 窗、同 208-bit、同 q16、同 QC 下，正式 top4 最大 global/channel PRD = 0.0550/0.0885（BCI）、0.0807/0.2782（RSVP）；2017-core delta=0.5 = 0.0585/0.0873、0.0844/0.8701。**质量基本等同。已证实。**
- 通道选道：BCI 上 all4 的 max-channel PRD 优于 top4（0.03302 vs 0.03825），RSVP 上反之（0.06485 vs 0.03626）。**数据依赖，已证实。**
- 同位点 L1/2/4/8：四组**全部** 0 类别翻转、BA 完全相同（BCI 0.697917、RSVP 0.780696）。这既说明投影长度不敏感，也说明**该子集没有分辨力**——不能作为"L4 是设计折中"的正向证据。**已证实。**
- 解析预筛：Q=0.5 下 40/40 窗两路都执行 IDWT，配对时延跨零。**没有常态加速，已证实。**

### 2.4 为什么"轻量"目前立不住

`p3_resource_v1` 给出 BCI 22×750 整链中位 1.501 ms、RSVP 64×250 2.966 ms，并诚实注明"不能引用为纯嵌入时延"。但**缺少与"不做水印"基线的对比**，也缺少目标设备（可穿戴/嵌入式采集前端）的功耗与内存数据。没有这些，`resource-constrained` 只是一个形容词，不构成问题陈述。审稿人第一个问题会是"EEG 归档的瓶颈是带宽与存储，不是 CPU；你的 1.5 ms 便宜在哪儿？"。

### 2.5 来自外部先例的硬约束（决定性）

已核验的一手来源（详见第 6 节）：

1. **"任务/诊断保持"已被先占两次。**
   - RPW-EEG（CogSci 47(0), 2025，作者代码公开，我读的是官方 eScholarship PDF 全文）：端到端编码器-解码器 + 噪声层 + "plug-and-play fine-tuning module that restores these features"，攻击下水印提取 >61%，任务范式分类准确率 88.5%。
   - DS-FTAN（Electronics 15(13):2864, 2026，DOI 10.3390/electronics15132864，摘要级）："preserves diagnostic integrity, causing merely a 0.42% accuracy drop in downstream EEGNet intention recognition"。
   → 本条不能作为创新点，只能作为**与深度学习路线对照的、可解释的轻量替代**。
2. **"DWT + EEG 水印"已饱和**：Pham/Tran/Ma ICONIP 2015（DWT-SVD，DOI 10.1007/978-3-319-26561-2_9）；同组 2017 ICONIP 专文即"水印对 EEG 应用系统性能的影响"（DOI 10.1007/978-3-319-70136-3_70）——**标题就已覆盖"任务影响"这一贡献**；另有 PSO-DWT-SVD（2022）、Firefly-DWT-SVD（2022）。
3. **"PRD 作为 EEG 质量指标"不是新的**：Efe, PeerJ CS 11:e2900, 2025（DOI 10.7717/peerj-cs.2900）在 Graz A/DEAP/Bonn 上以 PRD 为主指标之一。
4. **QIM + 解析失真保证是成熟理论**：Chen & Wornell 2001（DOI 10.1109/18.923725，标题本身即 "provably good"）；Altun & Sharma 集合论 QIM（ICASSP 2006, DOI 10.1109/icassp.2006.1660321）与半脆弱篡改检测 TIFS 2006（DOI 10.1109/tifs.2006.885018）；MD-QIM 格基最小失真数据隐藏（IEEE Comm. Lett. 25(9), 2021, DOI 10.1109/lcomm.2021.3089542，**明确以医疗/生理信号最小失真为动机并报告 PRD**）。
5. **投影向量本身已有专文**："扩展变换抖动调制水印算法中投影向量的研究"，《中国图象图形学报》2006 年第 12 期（[CNKI 题录](https://wap.cnki.net/touch/web/Journal/Article/ZGTB200612009.html)、[SciEngine DOI 10.11834/jig.2006012314](https://www.sciengine.com/IAG/doi/10.11834/jig.2006012314)）。我**只读到题录，未读正文**（正文页无可抽取文本）。这足以证明"STDM 投影向量选择"是 2006 年就存在的研究题目——"我们选 `[0.5,0.5,0.5,0.5]`"不能称为创新。
6. **SPL 官方规则（原文，我读了官方页正文）**：
   - "Must not exceed four pages of technical information including title; names of authors and their complete contact information; abstract; text; all images, figures and tables, appendices and proofs… A fifth page is available for references only." 且 "no exceptions per the EIC"，不能付超页费。
   - 立即拒稿事由："A paper is a candidate for an Immediate Rejection if it is of limited novelty, e.g. a straightforward combination of theories and algorithms that are well established and are repeated on a known scenario. Experimental contributions will be rejected without review if there is insufficient experimental data."
   - 还有一条对当前写法直接不利："Do not give theoretical derivations or algorithm descriptions that are easily found in the literature; merely cite the reference."——**把 Haar 正交性、Parseval、QIM 裕量当正文推导会被视为缺点。**
   - 来源：[Information for Authors-SPL](https://signalprocessingsociety.org/publications-resources/ieee-signal-processing-letters/information-authors-spl)、[About SP Letters](https://signalprocessingsociety.org/index.php/publications-resources/ieee-signal-processing-letters/about-sp-letters)。
7. **未发现先例的负结果（本次检索范围内）**："对整数/定点存储量化后水印恢复的界"在 Crossref 未见对应文献；"EEG 上使用 QIM"亦未见。**这是负结果，不是不存在性证明**（IEEE Xplore 全文检索被 403/418 拦截）。

---

## 3. 回答五个问题

### 问题 1：哪一项最容易被先例击穿？哪一项仍可能成为有价值贡献？

**最易被击穿（按危险程度排序）：**

| 候选"创新" | 判定 | 依据 |
|---|---|---|
| "首次在 EEG 上用 DWT/HMAC/QIM" | **已证实被击穿** | DWT-EEG 2015 起多篇；QIM 2001 起成熟 |
| "四系数单位投影" | **已证实被击穿（作为创新）** | STDM 投影向量研究 2006；Altun & Sharma 明言可用于线性变换域 |
| "任务/诊断保持" | **已证实被击穿** | RPW-EEG 2025（含代码）、DS-FTAN 2026 |
| "解析计算 PRD，重构前判定" | **已证实被击穿** | 正交变换 Parseval 恒等式；且 SPL 明文要求不要重推文献中已有的推导 |
| "零可训练参数 / 轻量" | **推断**被击穿 | 无同预算基线；相对 2017-core 无质量优势；无设备功耗 |
| "存储后提取裕量的解析证书" | **建议**：仍有价值，但**当前形式不成立** | 未发现先例；但见 2.2，常数是经验裕量而非可证上界；且正式配置下约束不紧（1.3） |

**仍可能成为贡献的（按我判断的可发表性排序）：**

1. **（建议，最有希望）把"投影方向 + 步长 + 块长"作为一个受约束设计问题。** 约束 = 任务频带扰动上限、输出 QC 上限、整数存储位深下的提取裕量、208-bit 容量。当前实现只是该问题的**一个任意可行点**（均匀投影、Q=0.5、L=4），而 2006 年 STDM 投影向量工作与 MD-QIM 提供了工具却没解决"存储位深约束 + 任务频带约束"这个组合。这是一个**能被一条定理和一张表讲完**的贡献，适合 SPL 的四页。
2. **（建议，次选）存储接口本身作为对象。** EDF+/BDF+ 的 16/24-bit 定点表示是临床归档的现实环节，而现有 EEG 水印文献（Pham 2015、Efe 2025、RPW-EEG）都未把定点量化纳入提取保证。把"水印必须在目标存储格式的量化格点上仍然可提取"写成设计约束是**真问题**，不是数学练习。但必须承认：在 Q=0.5 下该约束自动满足（1.3），所以它只有在**降低 Q / 提高鲁棒性 / 降低位深**时才有内容。
3. **（已证实可行但不新）诚实的效用与失败边界报告**（40 dB AWGN 与 0.5-45 Hz 滤波下恢复率 0%，40 dB 下 BER 约 0.5）。这是好科学，但 SPL 不接受"只有阴性边界的应用报告"，应把它作为结构性组成而非主张。

### 问题 2：A/B/C/D 四路线评价与排序

| 路线 | 新颖性 | 可实现性 | 验证成本 | SPL 风险 | 判断 |
|---|---|---|---|---|---|
| **A** 保留四系数，补真实 SOTA 与外部数据，主张"资源受限 + 可分析接口" | **低**（推断：文档自身已承认四项模块优势均不成立） | 高 | 中（SOTA 需重实现，RPW-EEG 官方仓库当前不可运行） | **极高**：SPL 立即拒稿条款几乎逐字命中 | **不应作为主路线** |
| **B** 保留 208-bit 与四系数容量，研究"任务频带 + 高频代价 + q16 裕量"共同约束的新投影/写入策略 | **中**：方向对，但"STDM 投影向量优化"是 2006 年旧题，仅"任务频带 + 存储位深"组合可能新 | 高（闭式小特征问题，零参数） | 低-中（可用现有证据链，只需新确认集） | 中 | **推荐（即 D 的具体化）** |
| **C** 改八系数或自适应块长 | **低**（推断）：L8 在同位点下任务指标与 L4 完全相同（0 翻转、同 BA），频带优势真实但容量减半（BCI 1023→506 bit，RSVP 992→480 bit），RSVP 概率尾部 L8 反而更差（0.00784 > 0.00727） | 中（容量不足需重定义选道规则） | 中-高（方法变更须全部重做 + 新确认） | 高：换来的是"更差容量 + 无任务增益" | **不推荐作为主方法**；L 应作为 B 里的自由变量而非新版本 |
| **D**（我的建议）**把投影方向/步长/块长当作受约束设计变量，主张"在给定任务频带扰动预算与目标整数存储位深下，使嵌入可检出的同时最小化任务频带扰动"** | **中高**（未见同一问题的先例；工具是旧的，问题组合是新的） | 高（解析可解 + 零参数，符合"资源受限"叙事） | 中（需一次真正未见数据的确认 + 一个诚实基线） | **中低**（现有选项中最低） | **推荐** |

**排序：D > B > C > A。** D 与 B 实质是同一条线的"问题陈述版"与"参数搜索版"；区别在于 D 承认 QIM/STDM 是既有工具，只在**约束组合**上主张新意——这正是 SPL 要求"state what is distinctive and new relative to these previously published works"时最稳的姿势。

### 问题 3：我最推荐的单句可检验主张

> **单句主张（建议）**：在一级 Haar 近似频带内以固定 QIM 步长嵌入 208 bit 时，把每 4 个近似系数上的单位投影向量从均匀 `[0.5,0.5,0.5,0.5]` 改为由"任务频带扰动最小化 + 目标整数存储位深下的提取裕量可证"共同确定的向量，可在**位载荷、输出 QC（1% 逐通道 PRD）、侧信息字节数、可训练参数（0）与存储格式全部不变**的条件下，把 8-30 Hz 带内扰动降低一个量级，同时保持 16/24-bit 存储后的精确提取。

**相对最近先例的新点**：不是 QIM，不是 STDM，不是投影向量优化本身（2006 已有），也不是任务保持（2025/2026 已有）；新点是**"目标整数存储位深的提取裕量"作为投影方向的显式约束，与任务频带约束联立**——经检索未见先例，且它是 EEG 归档（EDF+/BDF+）的真实工程环节。

**必要的数学命题（必须证明，不能只是数值验证）**：
1. 对固定载荷、固定步长与固定块位置，扰动的时间-频率能量是投影向量 `u`（`||u||=1`）的二次型 `u^T A_b u`（`A_b` 为该块 4 个 Haar 基的带限 Gram 矩阵，可按 250 Hz 解析写出）；
2. 在 `u^T A_b u <= beta`（任务频带预算）与输出 PRD 上限下，最优 `u` 是某个小矩阵的最小特征向量，可闭式求解；
3. 存储量化引起的投影偏移存在一个**可证**上界（不是 2.2 的经验倍率），且该上界随 `u` 的时间支撑权重与 `h` 变化；
4. 联立 2、3 给出可行域非空的充要条件，并给出"给定存储位深下允许的最小 Q"。

**至少一个可能推翻它的反例（必须主动寻找）**：
- 若命题 3 的可证上界（而非经验倍率）代入后可行域**为空**，则整条路线崩溃——这正是 2.2 必须先解决的原因；
- 若最优 `u` 把扰动推向极低频（基线漂移/慢漂移），则它会通过 PRD 与 8-30 Hz 指标，却改变 ERP 的慢成分与 delta 带，属于"指标作弊"。必须预设 delta 带与基线漂移的独立限值，并检查 `p4_matched_task` 中概率尾部是否变大（现有 RSVP L8 尾部变差即是预警）。

**最少需要的两组实验**：
1. **未见确认组合（1 组即可但必须真未见）**：在方法、`u`、Q、位深、QC 全部冻结并**写入哈希**后，只运行一次。数据不能再用 BCI 2a 的 E 会话、RSVP S21-S30，也不能再用 A01-A03 / S1-S3。建议取完全未参与的记录（例如 PhysioNet 或其他公开队列中此前未触及的受试者），同时冻结任务解码器与打分代码。
2. **同预算基线组（1 组，但必须同预算）**：同一批窗口、同 208-bit、同侧信息、同 QC、同存储、同任务模型下比较：(i) 均匀投影 L4（现方法）、(ii) 新 `u`、(iii) 无嵌入基线（新增，用于把"轻量"量化）、(iv) 2017 DWT-SVD 核心适配（已可运行）。RPW-EEG 官方仓库当前不可端到端运行，若修补，必须标为"基于作者代码的重实现"，并在其原生 30-bit 条件下比较，不得混入 208-bit 主表。

### 问题 4：最小但可信的 SPL 比较表

**共同口径（必须写明）**：同一批窗口；同一 208-bit 载荷语义；嵌入失真以"输出 QC 逐通道 PRD 上限"匹配（不是让对手用更差质量取胜）；同一 16/24-bit 存储与同一提取器输入；同一冻结任务模型与同一测试试次；`n` = 受试者数（不是窗口数），窗口级重复须用受试者聚类。

| 方法 | 类型 | 载荷 | 侧信息/参数 | 逐通道 PRD（中位/最大 %） | q16 精确提取 | 任务 delta BA（百分点） | 嵌入时延 |
|---|---|---|---|---|---|---|---|
| 无嵌入基线 | - | 0 | 0 / 0 | 0 | - | 0（定义） | 测量（新增，必须有） |
| 本方法（均匀 u, L4, Q=0.5） | 零参数 QIM | 208 bit | 24-45 B / 0 | 0.038/0.089（BCI）、0.036/0.278（RSVP，已核实） | 100% | 0.000（BCI）/−0.019（RSVP） | 1.501/2.966 ms |
| 本方法 + 约束最优 u（待做） | 零参数 QIM | 208 bit | 同上 / 0 | 必须同预算 | 必须 100% | 必须 <= 基线差 | 必须报告 |
| 2017 DWT-SVD 核心适配（已可运行） | 变换域+SVD | 208 bit | 8 B / 0 | 0.0585/0.0873（BCI）、0.0844/0.8701（RSVP，已核实） | 100% | 未测（须补） | 须同机配对 |
| RPW-EEG（作者论文数值） | 深度学习 | 30 bit | 网络权重 | 作者未报告 PRD | 攻击下 61%（作者数值） | 88.5% 范式准确率（作者数值） | 须计入训练成本 |
| Efe 2025（SWT+SVD+tent map） | 隐写 | 未对齐 | 未对齐 | 报 PRD，数值须读原文 | BER 约 0 | 未报告 | - |

**对无法复现者的诚实报告方式（建议直接写进论文的 Limitations 或脚注）**：
- 明确三分："作者原始实现（可运行）"、"基于作者代码的重实现（列逐项差异）"、"依论文公式的核心适配（列省略项，如 Arnold/PSO）"。**绝不可**把第三类放进"与 EEG SOTA 比较"栏。
- 引用作者论文数值时必须写"as reported in [x]"，并注明容量/位深/质量口径不同，**不做 BER/PRD/速度 的直接排名**。
- 若某方法的侧信息字节数不同（如 8 B vs 24-45 B），必须单列说明其是否认证、是否可复用于重排，不能只比 PRD。
- 对 RPW-EEG 目前只有 30-bit、PRD 18.67% 的修补微实验，应清楚写"在 1% QC 预算内无可比工作点"，并把它放在 Discussion 而非主表。

### 问题 5：红/黄/绿投稿门槛

**绿色（可投 SPL，需全部满足）**
1. 一条可检验、且**逐字经得起**"相对最近先例新在何处"的方法主张（问题 3 的形式）。
2. 该主张有**可证**（非经验倍率）的数学命题，且推导不超过半页——SPL 明文不欢迎重推文献已有推导。
3. 一次真正的**未见数据**确认：新受试者/新记录、方法哈希冻结在前、只运行一次。
4. 同预算基线（至少 2017-core + 无嵌入基线）与资源计量（同机配对，最好含目标设备功耗）。
5. 全部阴性边界如实报告（无滤波/AWGN 鲁棒性、非盲、S21-S30 已被看过等）。

**黄色（可投，但降级或改刊）**
- 只满足 1、3、4 而数学命题只是经验校准 → 投 **IEEE TBME / Biomedical Signal Processing and Control / Journal of Neural Engineering / Computers in Biology and Medicine** 作应用论文，其中"临床归档格式下的可复验水印接口 + 大规模任务效用"是完整贡献。
- 主张落在"EEG 归档水印系统工程"而非算法创新 → 投生物医学信息类期刊，SPL 的"成熟算法组合"条款不适用。

**红色（应放弃 SPL，或至少暂缓）**
- 主张仍是"轻量 + 可分析 + 任务保持"的三点组合说明；或
- 仍无未见数据确认；或
- 证书仍以 `sqrt(2)*1000*h/D` 作为"充分条件"出现在论文中；或
- 仍以"zero-parameter / lightweight"为主卖点而无同预算基线和设备资源数据。

**明确何时放弃 SPL**：完成问题 3 的第 3 条数学命题后，若**可行域为空**或**最优 u 无法在保持 1% QC 的同时给出可测的带内改善**，说明"存储约束 + 任务频带约束"这一组合没有内容，此时 D 路线不成立，应退到黄色路线改刊；若同时外部先例（如 2026 年出现"存储感知 EEG 水印"）落地，则退出该题目。**我不估算任何录用概率**——现有信息不支持这种估算。

---

## 4. 与 Codex 备忘录的分歧（诚实标注）

我**不默认接受** `P4_METHOD_DIRECTION_DECISION_2026-10-01.md` 的"建议选 A"。分歧点：

1. 备忘录说 A 的"优点是既有正式链与 72,245 窗存储审计可保留"。但既有链的**唯一独占优势已被自己证伪**（2.3），保留它换来的是"SPL 立即拒稿条款"的直接命中风险。保留资产的价值不等于投稿可行性。
2. 备忘录把 B 的缺点归为"L8 容量收缩"和"频段优势来自已见开发集"。我认为 B/D 的真正障碍不是容量，而是**先例**：STDM 投影向量优化是 2006 年旧题。若不做"存储位深约束"这一层，B 很容易被审稿人一句"这是 spread-transform dither modulation 的已知自由度"打回。
3. 备忘录与 `SPL_NOVELTY_GATE` 都正确指出证书不足以构成创新，但**未发现该常数本身不是可证上界**（2.2）。这是本次评估最实质的技术发现，应优先修复。

---

## 5. 建议的下一步（按优先级）

1. **修证书（1-2 周）**：判定 `sqrt(2)*1000*h/D` 的性质，改成经验裕量（含覆盖概率与校准）或重推可证界；同步核对 `P3_CERTIFICATE_PROTOCOL_2026-10-01.md` 第 8 条的措辞。产出：一页推导 + 复算脚本 + 全量 CSV 重跑对照。
2. **做可行性判定（2-4 周）**：按问题 3 的命题 1-4 写出闭式解，在**只用既有开发数据**的前提下画可行域图，回答"是否存在比均匀投影更好的可行 u"。若为空，立即执行黄色路线。
3. **锁定未见确认集（并行）**：确定外部记录/受试者，写哈希与排除规则，冻结任务模型与打分代码。**在第 1、2 项完成前不打开标签。**
4. **补无嵌入基线与同机配对资源计量**：这是把"轻量"从形容词变成数据的唯一途径。

---

## 6. 我实际读取的来源清单

### 6.1 本地文件（已读）

- 交接文档：`revision/DEEPSEEK_HARNESS_HANDOFF_SPL_DIRECTION_2026-10-02.md`
- 实现：`revision/lightweight_qc_validation/methods.py`、`qc.py`、`storage.py`
- 方法与结果：`lightweight_qc_validation/FINAL_METHOD_DECISION.md`、`RESULTS.md`、`STATUS.md`、`carrier_diagnostic/RESULTS.md`、`blockdc_confirmation/RESULTS.md`、`wavelet_diagnostic/RESULTS.md`
- 协议与决策：`post_20260926/P3_CERTIFICATE_PROTOCOL_2026-10-01.md`、`P4_CHANNEL_PROJECTION_PROTOCOL_2026-10-01.md`、`P4_METHOD_DIRECTION_DECISION_2026-10-01.md`、`SPL_NOVELTY_GATE_2026-10-01.md`、`P2_PHAM_2017_CORE_AUDIT_2026-10-01.md`、`P2_RPW_SOURCE_AUDIT.md`
- 结果报告：`post_20260926/P1_COMBINED_RESULTS_2026-09-26.md`、`bci_mi_session/RESULTS.md`、`rsvp_natural_v1/RESULTS.md`、`p3_certificate_v1/RESULTS.md` 与 `analysis.json`、`p3_certificate_v1/A01T_per_trial.csv`、`p3_resource_v1/RESULTS.md`、`p4_prescreen_v2/RESULTS.md`、`p4_channel_projection_v1/RESULTS.md`、`p4_matched_task_v1/RESULTS.md`、`p2_pham2017_dev_v1/RESULTS.md`
- 脚本：`post_20260926/run_p3_certificate.py`
- 旧稿：`papers/egg_watermark.pdf`（仅提取首页文本以确认题目与路线）

### 6.2 外部一手来源

- SPL 官方：[Information for Authors-SPL](https://signalprocessingsociety.org/publications-resources/ieee-signal-processing-letters/information-authors-spl)、[About SP Letters](https://signalprocessingsociety.org/index.php/publications-resources/ieee-signal-processing-letters/about-sp-letters)（页数限制与立即拒稿条款原文）
- Chen & Wornell 2001：DOI [10.1109/18.923725](https://doi.org/10.1109/18.923725)
- Altun & Sharma 集合论 QIM：DOI [10.1109/icassp.2006.1660321](https://doi.org/10.1109/icassp.2006.1660321)；半脆弱 TIFS 2006：DOI [10.1109/tifs.2006.885018](https://doi.org/10.1109/tifs.2006.885018)
- MD-QIM 2021（医疗信号最小失真动机）：DOI [10.1109/lcomm.2021.3089542](https://doi.org/10.1109/lcomm.2021.3089542)
- STDM 投影向量（题录级）：[CNKI](https://wap.cnki.net/touch/web/Journal/Article/ZGTB200612009.html)、[SciEngine](https://www.sciengine.com/IAG/doi/10.11834/jig.2006012314)
- Pham/Tran/Ma ICONIP 2015 DWT-SVD EEG：DOI [10.1007/978-3-319-26561-2_9](https://doi.org/10.1007/978-3-319-26561-2_9)
- Pham/Tran/Ma ICONIP 2017 水印对 EEG 应用性能影响：DOI [10.1007/978-3-319-70136-3_70](https://doi.org/10.1007/978-3-319-70136-3_70)（闭源，仅题录）
- Gupta et al. 2022 PSO-DWT-SVD EEG：DOI [10.1007/978-981-19-2445-3_48](https://doi.org/10.1007/978-981-19-2445-3_48)
- RPW-EEG（CogSci 2025，全文 PDF 已读）：[eScholarship](https://escholarship.org/uc/item/96h9c291)、作者代码 [github.com/qintianyang/RPW-EEG](https://github.com/qintianyang/RPW-EEG)
- DS-FTAN（Electronics 2026，摘要级）：DOI [10.3390/electronics15132864](https://doi.org/10.3390/electronics15132864)
- Efe 2025（PeerJ CS，摘要级，PRD 用于 EEG）：DOI [10.7717/peerj-cs.2900](https://doi.org/10.7717/peerj-cs.2900)
- EEG 模型水印（旁支，用于判断领域活跃度）：arXiv [2502.05931](https://export.arxiv.org/abs/2502.05931)、代码 [Prog-Jacob/watermarking-eeg-models](https://github.com/Prog-Jacob/watermarking-eeg-models)

### 6.3 访问失败/受限

- IEEE Xplore 全文检索（HTTP 418/403）、mdpi.com（403）、Springer 落地页（IdP 重定向）、IET/Wiley（403）、OpenAlex API（当日额度耗尽）、Semantic Scholar API（429）。因此第 2.5 节第 7 条的负结果**不是不存在性证明**。

---

## 7. 声明

本报告为审查与建议，未修改任何项目文件、未重跑任何实验、未产生新的实验结论。第 1.3 与 2.2 的算术结论基于记录值与公开推导，核验路径与未核验范围已在第 1.2、1.4 节写明。