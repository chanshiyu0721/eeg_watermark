"""Strict metrics for the v2 rerun: no silent fallbacks or fabricated values."""
from __future__ import annotations

import numpy as np
from scipy.signal import welch
from skimage.metrics import structural_similarity


def _paired(original: np.ndarray, watermarked: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    a = np.asarray(original, dtype=np.float64)
    b = np.asarray(watermarked, dtype=np.float64)
    if a.shape != b.shape or a.ndim != 2:
        raise ValueError(f"metric inputs must be equal 2-D shapes, got {a.shape} and {b.shape}")
    if not np.all(np.isfinite(a)) or not np.all(np.isfinite(b)):
        raise ValueError("metric inputs contain NaN or infinity")
    return a, b


def fidelity_metrics(original: np.ndarray, watermarked: np.ndarray) -> dict[str, float]:
    a, b = _paired(original, watermarked)
    error = a - b
    mse = float(np.mean(error ** 2))
    rmse = float(np.sqrt(mse))
    data_range = float(np.max(a) - np.min(a))
    rms = float(np.sqrt(np.mean(a ** 2)))
    noise_power = mse
    signal_power = float(np.mean(a ** 2))
    psnr = float("inf") if mse == 0 else float(10 * np.log10(data_range ** 2 / mse))
    snr = float("inf") if noise_power == 0 else float(10 * np.log10(signal_power / noise_power))
    nrmse_range = rmse / data_range if data_range else float("nan")
    prd = 100 * rmse / rms if rms else float("nan")
    max_error = float(np.max(np.abs(error)))
    correlation = float(np.corrcoef(a.reshape(-1), b.reshape(-1))[0, 1])
    min_dim = min(a.shape)
    win_size = min(7, min_dim if min_dim % 2 else min_dim - 1)
    if win_size < 3:
        raise ValueError(f"SSIM requires a spatial dimension of at least 3, got {a.shape}")
    ssim = float(structural_similarity(a, b, data_range=max(data_range, np.finfo(float).eps), win_size=win_size))
    return {
        "psnr_db": psnr,
        "ssim": ssim,
        "prd_pct": prd,
        "snr_db": snr,
        "rmse": rmse,
        "nrmse_range": nrmse_range,
        "max_abs_error": max_error,
        "correlation": correlation,
    }


def welch_bandpower_change(
    original: np.ndarray,
    watermarked: np.ndarray,
    *,
    fs: float,
    bands: dict[str, tuple[float, float]] | None = None,
) -> dict[str, float]:
    a, b = _paired(original, watermarked)
    if bands is None:
        bands = {
            "delta": (0.5, 4.0),
            "theta": (4.0, 8.0),
            "alpha": (8.0, 13.0),
            "beta": (13.0, 30.0),
            "low_gamma": (30.0, 45.0),
        }
    nperseg = min(a.shape[-1], max(32, int(round(fs * 2))))
    freqs, p_a = welch(a, fs=fs, axis=-1, nperseg=nperseg)
    _, p_b = welch(b, fs=fs, axis=-1, nperseg=nperseg)
    result: dict[str, float] = {}
    for name, (low, high) in bands.items():
        mask = (freqs >= low) & (freqs < high)
        if not np.any(mask):
            result[f"bandpower_{name}_change_pct"] = float("nan")
            continue
        base = np.trapezoid(p_a[:, mask], freqs[mask], axis=-1)
        marked = np.trapezoid(p_b[:, mask], freqs[mask], axis=-1)
        valid = np.abs(base) > np.finfo(float).eps
        if not np.any(valid):
            result[f"bandpower_{name}_change_pct"] = float("nan")
            continue
        changes = 100.0 * (marked[valid] - base[valid]) / base[valid]
        result[f"bandpower_{name}_change_pct"] = float(np.median(changes))
    return result


def summarize(values: list[float] | np.ndarray, *, threshold: float | None = None, below_is_failure: bool = True) -> dict[str, float | int]:
    arr = np.asarray(values, dtype=np.float64)
    finite = arr[np.isfinite(arr)]
    if finite.size == 0:
        return {"n": int(arr.size), "n_finite": 0}
    result: dict[str, float | int] = {
        "n": int(arr.size),
        "n_finite": int(finite.size),
        "mean": float(np.mean(finite)),
        "std": float(np.std(finite, ddof=1)) if finite.size > 1 else 0.0,
        "min": float(np.min(finite)),
        "p05": float(np.quantile(finite, 0.05)),
        "p25": float(np.quantile(finite, 0.25)),
        "median": float(np.quantile(finite, 0.50)),
        "p75": float(np.quantile(finite, 0.75)),
        "p95": float(np.quantile(finite, 0.95)),
        "max": float(np.max(finite)),
    }
    if threshold is not None:
        failed = finite < threshold if below_is_failure else finite > threshold
        result["failure_count"] = int(np.sum(failed))
        result["failure_rate"] = float(np.mean(failed))
    return result
