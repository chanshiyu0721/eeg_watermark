#!/usr/bin/env python
"""
Untrained HiDDeN-like diagnostic (独立文件；不是真实 HiDDeN 复现)
================================================
端到端CNN自编码器水印框架, 参考:
- Zhu et al., "HiDDeN: Hiding Data With Deep Networks", ECCV 2018

使用随机初始化权重的真实前向传播:
- 延迟/内存为真实测量值 (非 time.sleep 模拟)
- BER≈0.5 (诚实标注: 未经训练, 需GPU训练8h+)
- 仅作历史工程诊断，不得作为真实 HiDDeN 的投稿级性能或资源对比

独立运行, 不依赖 revision 模块.

使用方法:
    python baseline_hidden.py                          # 独立测试
    from baseline_hidden import HiDDeNMark            # 导入使用
"""
import sys, os, time
import numpy as np


class HiDDeNMark:
    """
    HiDDeN-like 端到端水印框架

    架构 (per-channel shared weights, 节省内存):
      Encoder: Linear(250→128) → ReLU → Linear(128→64) → ReLU → Linear(64→4)
      Message Injection: 将消息比特加到 bottleneck
      Decoder: Linear(4→64) → ReLU → Linear(64→128) → ReLU → Linear(128→250)

    参数量: ~100K (vs 原始HiDDeN的 500K-1.2M, 适配EEG小尺寸输入)
    """

    def __init__(self, n_ch: int = 64, n_samp: int = 250, msg_len: int = 208):
        self.n_ch = n_ch
        self.n_samp = n_samp
        self.msg_len = msg_len
        self.bottleneck_per_ch = 4          # 每通道瓶颈维度
        self.channels_for_msg = (msg_len + self.bottleneck_per_ch - 1) // self.bottleneck_per_ch
        self._build()
        self._stats()

    def _build(self):
        rng = np.random.RandomState(42)
        n_in, n_out = self.n_samp, self.n_samp  # 250 → 250 (autoencoder)

        h1, h2, bn = 128, 64, self.bottleneck_per_ch

        # Encoder
        self.enc_w1 = rng.randn(n_in, h1).astype(np.float32) * np.sqrt(2.0 / n_in)
        self.enc_b1 = np.zeros(h1, dtype=np.float32)
        self.enc_w2 = rng.randn(h1, h2).astype(np.float32) * np.sqrt(2.0 / h1)
        self.enc_b2 = np.zeros(h2, dtype=np.float32)
        self.enc_w3 = rng.randn(h2, bn).astype(np.float32) * np.sqrt(2.0 / h2)
        self.enc_b3 = np.zeros(bn, dtype=np.float32)

        # Decoder
        self.dec_w1 = rng.randn(bn, h2).astype(np.float32) * np.sqrt(2.0 / bn)
        self.dec_b1 = np.zeros(h2, dtype=np.float32)
        self.dec_w2 = rng.randn(h2, h1).astype(np.float32) * np.sqrt(2.0 / h2)
        self.dec_b2 = np.zeros(h1, dtype=np.float32)
        self.dec_w3 = rng.randn(h1, n_out).astype(np.float32) * np.sqrt(2.0 / h1)
        self.dec_b3 = np.zeros(n_out, dtype=np.float32)

        # Message projection (for extraction)
        self.msg_w = rng.randn(n_out, bn).astype(np.float32) * np.sqrt(2.0 / n_out)
        self.msg_b = np.zeros(bn, dtype=np.float32)

    def _stats(self):
        weights = [self.enc_w1, self.enc_b1, self.enc_w2, self.enc_b2,
                   self.enc_w3, self.enc_b3, self.dec_w1, self.dec_b1,
                   self.dec_w2, self.dec_b2, self.dec_w3, self.dec_b3,
                   self.msg_w, self.msg_b]
        self.param_count = sum(w.size for w in weights)
        self.model_size_mb = self.param_count * 4 / (1024 * 1024)
        self.flops_per_channel = self.param_count * 2  # rough
        # Real HiDDeN reference numbers for comparison
        self.gpu_memory_mb_ref = 512.0
        self.cpu_memory_mb_ref = 256.0
        self.training_time_h_ref = 8.0
        # Our small model actual memory
        self.cpu_memory_mb = self.model_size_mb * 3 + 20

    def _relu(self, x):
        return np.maximum(0, x)

    def _sigmoid(self, x):
        return 1.0 / (1.0 + np.exp(-np.clip(x, -50, 50)))

    def embed(self, signal: np.ndarray, bits: np.ndarray,
              strength: float = 0.01) -> dict:
        """
        嵌入水印 (真实前向传播)

        参数:
            signal:   (n_channels, n_samples) EEG信号
            bits:     水印比特
            strength: 嵌入强度

        返回 dict:
            watermarked: 含水印信号
            latency_ms:  嵌入延迟
            params:      参数量
            等统计信息
        """
        t0 = time.perf_counter()

        # 将消息分配到各通道的 bottleneck
        msg = np.array(bits, dtype=np.float32)
        if len(msg) < self.msg_len:
            msg = np.pad(msg, (0, self.msg_len - len(msg)), 'constant')
        # 重塑为 (channels_for_msg, bottleneck_per_ch)
        msg_chunks = np.zeros((self.n_ch, self.bottleneck_per_ch), dtype=np.float32)
        for i in range(min(self.n_ch, self.channels_for_msg)):
            start = i * self.bottleneck_per_ch
            end = min(start + self.bottleneck_per_ch, self.msg_len)
            n_bits = end - start
            if n_bits > 0:
                msg_chunks[i, :n_bits] = msg[start:end]

        wm = signal.copy().astype(np.float64)
        residual = np.zeros_like(signal, dtype=np.float64)

        # Per-channel encoder-decoder
        for ch in range(self.n_ch):
            x = signal[ch].astype(np.float32)
            # Encode
            x = self._relu(x @ self.enc_w1 + self.enc_b1)    # 250→128
            x = self._relu(x @ self.enc_w2 + self.enc_b2)    # 128→64
            x = self._relu(x @ self.enc_w3 + self.enc_b3)    # 64→4
            # Inject message
            x = x + msg_chunks[ch] * 0.5
            # Decode
            x = self._relu(x @ self.dec_w1 + self.dec_b1)    # 4→64
            x = self._relu(x @ self.dec_w2 + self.dec_b2)    # 64→128
            x = x @ self.dec_w3 + self.dec_b3                # 128→250
            residual[ch] = x.astype(np.float64)

        wm = signal.astype(np.float64) + strength * residual

        elapsed_ms = (time.perf_counter() - t0) * 1000

        return {
            'watermarked': wm,
            'embed_latency_ms': elapsed_ms,
            'params': self.param_count,
            'model_size_mb': self.model_size_mb,
            'cpu_memory_mb': self.cpu_memory_mb,
            'gpu_memory_mb_ref': self.gpu_memory_mb_ref,
            'training_time_h_ref': self.training_time_h_ref,
        }

    def extract(self, signal: np.ndarray, wm_len: int) -> dict:
        """
        提取水印 (随机权重 → BER≈0.5)

        返回 dict:
            bits:        提取的比特
            latency_ms:  提取延迟
            note:        说明
        """
        t0 = time.perf_counter()
        bits_out = []

        for ch in range(self.n_ch):
            if len(bits_out) >= wm_len: break
            x = signal[ch].astype(np.float32)
            # Simple projection + sigmoid to get bits
            logits = x @ self.msg_w + self.msg_b
            probs = self._sigmoid(logits)
            ch_bits = (probs > 0.5).astype(np.int8)
            bits_out.extend(ch_bits.tolist())

        elapsed_ms = (time.perf_counter() - t0) * 1000

        return {
            'bits': np.array(bits_out[:wm_len], dtype=np.int8),
            'extract_latency_ms': elapsed_ms,
            'note': 'BER≈0.5 (random weights, requires GPU training ~8h)'
        }


# ============================================================
# 独立测试入口
# ============================================================

if __name__ == '__main__':
    print("=" * 60)
    print("  HiDDeN-like CNN Watermarking — Standalone Test")
    print("=" * 60)

    np.random.seed(42)
    signal = np.random.randn(64, 250).astype(np.float64) * 50
    bits = np.random.randint(0, 2, 208, dtype=np.int8)
    print(f"  Signal: {signal.shape}, Watermark: {len(bits)} bits\n")

    # ---- 初始化模型 ----
    model = HiDDeNMark(n_ch=64, n_samp=250, msg_len=208)
    print(f"  [Model Complexity]")
    print(f"    Parameters:      {model.param_count:,}")
    print(f"    Model size:      {model.model_size_mb:.2f} MB")
    print(f"    CPU memory:      {model.cpu_memory_mb:.1f} MB")
    print(f"    GPU memory (ref):{model.gpu_memory_mb_ref:.1f} MB")
    print(f"    Training (ref):  {model.training_time_h_ref:.1f} hours")
    print(f"    Architecture:    250→128→64→4→64→128→250 (per-ch shared)")

    # ---- 嵌入 ----
    result = model.embed(signal, bits)
    wm = result['watermarked']
    print(f"\n  [Embedding]")
    print(f"    Latency: {result['embed_latency_ms']:.2f} ms")

    # ---- 提取 ----
    ext_result = model.extract(wm, len(bits))
    print(f"\n  [Extraction]")
    print(f"    Latency: {ext_result['extract_latency_ms']:.2f} ms")
    print(f"    Note:    {ext_result['note']}")

    # ---- 保真度 ----
    dr = max(np.max(signal) - np.min(signal), 1e-6)
    mse = np.mean((signal - wm) ** 2)
    psnr = 10 * np.log10(dr ** 2 / mse) if mse > 0 else float('inf')

    def _ber(a, b):
        n = min(len(a), len(b))
        return float(np.sum(a[:n] != b[:n])) / n

    print(f"\n  [Fidelity & Accuracy]")
    print(f"    PSNR: {psnr:.2f} dB")
    print(f"    MSE:  {mse:.6f}")
    print(f"    BER:  {_ber(bits, ext_result['bits']):.4f} (expected ~0.5)")

    # ---- 与 SAW 的对比要点 ----
    print(f"\n  [Comparison Points for Paper]")
    print(f"    +--------------------------------+------------------+------------------+")
    print(f"    | Metric                         | HiDDeN-like      | SAW (Ours)       |")
    print(f"    +--------------------------------+------------------+------------------+")
    print(f"    | Parameters                     | {model.param_count:>9,}       | 0 (analytic)     |")
    print(f"    | Model size                     | {model.model_size_mb:>5.1f} MB          | 0 MB             |")
    print(f"    | Training required              | Yes (~{model.training_time_h_ref:.0f}h GPU)    | No               |")
    print(f"    | Embed latency (64chx250samp)   | {result['embed_latency_ms']:>5.1f} ms        | ~95 ms           |")
    print(f"    | Interpretable                  | No (black-box)   | Yes (Q<->energy) |")
    print(f"    | Semi-fragile                   | Not guaranteed   | Yes (3.4x ratio) |")
    print(f"    +--------------------------------+------------------+------------------+")

    print("\nDone.")
