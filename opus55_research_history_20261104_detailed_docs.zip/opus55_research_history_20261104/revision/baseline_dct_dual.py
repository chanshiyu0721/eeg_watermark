#!/usr/bin/env python
"""
DCT-Dual Watermarking Baseline (独立文件)
=========================================
双域DCT盲水印: 中频鲁棒水印 + 高频脆弱水印
不依赖 revision 模块, 独立运行

参考文献:
- Cox et al., "Secure Spread Spectrum Watermarking for Multimedia", IEEE TIP, 1997
- Singh et al., "DCT based blind dual watermarking", Telecommunication Systems, 2019

使用方法:
    python baseline_dct_dual.py                          # 独立测试
    from baseline_dct_dual import dct_dual_embed, dct_dual_extract  # 导入使用
"""
import sys, os, time
import numpy as np
from scipy.fft import dct, idct


# ============================================================
# QIM 辅助函数 (自包含, 不依赖 saw_core)
# ============================================================

def _qim_embed(value: float, bit: int, step: float) -> float:
    """QIM嵌入: 将浮点值量化到对应的比特区间中心"""
    q = np.floor(value / step)
    if int(q) % 2 == bit:
        return q * step + step / 2.0
    return (q + 1) * step + step / 2.0 if bit == 1 else (q - 1) * step + step / 2.0


def _qim_extract(value: float, step: float) -> int:
    """QIM提取: 判断值所在的量化区间"""
    return int(round(value / step)) % 2


# ============================================================
# 核心算法
# ============================================================

def _normalize(signal: np.ndarray):
    """归一化到 [0, 1]"""
    mn = signal.min()
    mx = signal.max()
    rng = mx - mn
    if rng < 1e-12:
        return signal.copy(), mn, 1.0
    return (signal - mn) / rng, mn, rng


def _denormalize(norm_signal: np.ndarray, mn: float, rng: float):
    """逆归一化"""
    return norm_signal * rng + mn


def dct_dual_embed(signal: np.ndarray, bits: np.ndarray,
                   Q_robust: float = None, Q_fragile: float = None) -> np.ndarray:
    """
    DCT双域水印嵌入 (自适应Q版)

    策略:
    - 先归一化信号到 [0,1]
    - 中频DCT系数 (indices 5~50): 嵌入鲁棒水印
    - 高频DCT系数 (indices 60~160): 嵌入脆弱水印
    - Q值自适应: Q_robust = k * std(DCT_mid), Q_fragile = Q_robust / 50

    参数:
        signal:     (n_channels, n_samples) EEG信号
        bits:       水印比特数组
        Q_robust:   鲁棒层QIM步长 (None=自适应)
        Q_fragile:  脆弱层QIM步长 (None=自适应)

    返回:
        watermarked_signal: 嵌入水印后的信号
    """
    # 归一化
    norm_sig, sig_min, sig_rng = _normalize(signal)
    wm = norm_sig.copy()
    n_ch, n_samp = wm.shape

    # DCT频段定义
    mid_start, mid_end = 5, 50
    high_start, high_end = 60, min(160, n_samp)

    # 自适应Q: 基于中频DCT系数标准差, 低因子保证保真度
    if Q_robust is None:
        ch0_dct = dct(wm[0], type=2, norm='ortho')
        mid_std = np.std(np.abs(ch0_dct[mid_start:mid_end]))
        Q_robust = max(mid_std * 0.1, 1e-8)  # 0.1x 因子平衡保真度和鲁棒性
    if Q_fragile is None:
        Q_fragile = max(Q_robust / 50.0, 1e-12)

    half_bits = len(bits) // 2
    robust_bits = bits[:half_bits]
    fragile_bits = bits[half_bits:2 * half_bits]
    rb_per_ch = max(1, len(robust_bits) // n_ch)
    fb_per_ch = max(1, len(fragile_bits) // n_ch)

    for ch in range(n_ch):
        dct_coeffs = dct(wm[ch], type=2, norm='ortho')

        # 鲁棒层: 中频 QIM
        for i in range(min(rb_per_ch, mid_end - mid_start)):
            bit_idx = ch * rb_per_ch + i
            if bit_idx >= len(robust_bits): break
            pos = mid_start + i
            dct_coeffs[pos] = _qim_embed(dct_coeffs[pos], int(robust_bits[bit_idx]), Q_robust)

        # 脆弱层: 高频 QIM (更小步长 -> 对篡改更敏感)
        for i in range(min(fb_per_ch, high_end - high_start)):
            bit_idx = ch * fb_per_ch + i
            if bit_idx >= len(fragile_bits): break
            pos = high_start + i
            dct_coeffs[pos] = _qim_embed(dct_coeffs[pos], int(fragile_bits[bit_idx]), Q_fragile)

        wm[ch] = idct(dct_coeffs, type=2, norm='ortho')

    # 逆归一化
    return _denormalize(wm, sig_min, sig_rng)


def dct_dual_extract(signal: np.ndarray, wm_len: int,
                     Q_robust: float = None, Q_fragile: float = None) -> np.ndarray:
    """
    DCT双域水印盲提取 (含归一化)

    参数:
        signal:     含水印信号
        wm_len:     水印比特长度
        Q_robust:   鲁棒层QIM步长 (None=自适应)
        Q_fragile:  脆弱层QIM步长 (None=自适应)

    返回:
        extracted_bits: 提取的水印比特
    """
    # 归一化
    mn = signal.min()
    mx = signal.max()
    rng = mx - mn
    if rng < 1e-12:
        rng = 1.0
    norm_sig = (signal - mn) / rng

    n_ch, n_samp = norm_sig.shape
    mid_start, mid_end = 5, 50
    high_start, high_end = 60, min(160, n_samp)

    # 自适应Q (与嵌入逻辑一致)
    if Q_robust is None:
        ch0_dct = dct(norm_sig[0], type=2, norm='ortho')
        mid_std = np.std(np.abs(ch0_dct[mid_start:mid_end]))
        Q_robust = max(mid_std * 0.1, 1e-8)
    if Q_fragile is None:
        Q_fragile = max(Q_robust / 50.0, 1e-12)

    half_bits = wm_len // 2
    rb_per_ch = max(1, half_bits // n_ch)
    fb_per_ch = max(1, (wm_len - half_bits) // n_ch)

    robust_bits, fragile_bits = [], []

    for ch in range(n_ch):
        dct_coeffs = dct(norm_sig[ch], type=2, norm='ortho')
        for i in range(min(rb_per_ch, mid_end - mid_start)):
            if len(robust_bits) >= half_bits: break
            robust_bits.append(_qim_extract(dct_coeffs[mid_start + i], Q_robust))
        for i in range(min(fb_per_ch, high_end - high_start)):
            if len(fragile_bits) >= half_bits: break
            fragile_bits.append(_qim_extract(dct_coeffs[high_start + i], Q_fragile))

    result = np.concatenate([
        np.array(robust_bits[:half_bits], dtype=np.int8),
        np.array(fragile_bits[:half_bits], dtype=np.int8)
    ])
    if len(result) < wm_len:
        result = np.pad(result, (0, wm_len - len(result)), 'constant')
    return result[:wm_len]


# ============================================================
# 攻击测试辅助
# ============================================================

def compute_ber(original: np.ndarray, extracted: np.ndarray) -> float:
    """计算比特错误率"""
    n = min(len(original), len(extracted))
    return float(np.sum(original[:n] != extracted[:n])) / n


# ============================================================
# 独立测试入口
# ============================================================

if __name__ == '__main__':
    print("=" * 60)
    print("  DCT-Dual Watermarking — Standalone Test")
    print("=" * 60)

    # 模拟EEG数据 (64ch × 250samp)
    np.random.seed(42)
    signal = np.random.randn(64, 250).astype(np.float64) * 50
    bits = np.random.randint(0, 2, 208, dtype=np.int8)
    print(f"  Signal: {signal.shape}, Watermark: {len(bits)} bits\n")

    # ---- 嵌入 ----
    t0 = time.perf_counter()
    wm = dct_dual_embed(signal, bits)
    embed_ms = (time.perf_counter() - t0) * 1000

    # ---- 提取 ----
    t0 = time.perf_counter()
    ext = dct_dual_extract(wm, len(bits))
    extract_ms = (time.perf_counter() - t0) * 1000

    # ---- 指标 ----
    dr = max(np.max(signal) - np.min(signal), 1e-6)
    mse = np.mean((signal - wm) ** 2)
    psnr = 10 * np.log10(dr ** 2 / mse) if mse > 0 else float('inf')
    ber = compute_ber(bits, ext)

    print(f"  [Fidelity]")
    print(f"    PSNR: {psnr:.2f} dB")
    print(f"    MSE:  {mse:.6f}")
    print(f"  [Extraction]")
    print(f"    BER:  {ber:.4f}")
    print(f"  [Efficiency]")
    print(f"    Embed:   {embed_ms:.2f} ms")
    print(f"    Extract: {extract_ms:.2f} ms")
    print(f"    Total:   {embed_ms + extract_ms:.2f} ms")
    print(f"  [Design]")
    print(f"    Blind:   Yes")
    print(f"    Dual:    Robust (mid-freq Q=0.5) + Fragile (high-freq Q=0.05)")
    print(f"    Requires Training: No")

    # ---- 鲁棒性测试 ----
    print(f"\n  [Robustness Quick Test]")
    from scipy.signal import butter, filtfilt, iirnotch

    fs = 250.0
    # Lowpass
    b, a = butter(4, 45 / (fs / 2), 'low')
    wm_lp = np.array([filtfilt(b, a, wm[ch]) for ch in range(wm.shape[0])])
    ber_lp = compute_ber(bits, dct_dual_extract(wm_lp, len(bits)))
    print(f"    LowPass 45Hz  → BER={ber_lp:.4f}")

    # Notch
    b, a = iirnotch(50, 30, fs)
    wm_notch = np.array([filtfilt(b, a, wm[ch]) for ch in range(wm.shape[0])])
    ber_notch = compute_ber(bits, dct_dual_extract(wm_notch, len(bits)))
    print(f"    Notch 50Hz    → BER={ber_notch:.4f}")

    # Gaussian noise
    wm_noisy = wm + np.random.normal(0, 0.05 * np.std(wm), wm.shape)
    ber_noise = compute_ber(bits, dct_dual_extract(wm_noisy, len(bits)))
    print(f"    Gaussian 0.05 → BER={ber_noise:.4f}")

    # Segment replace (forgery)
    wm_forgery = wm.copy()
    seg_len = int(0.30 * wm.shape[1])
    wm_forgery[:, :seg_len] = np.random.randn(wm.shape[0], seg_len) * 50
    ber_forgery = compute_ber(bits, dct_dual_extract(wm_forgery, len(bits)))
    print(f"    SegReplace 30%→ BER={ber_forgery:.4f}")

    semi_ratio = ber_forgery / max(ber_lp, 0.001)
    print(f"\n  Semi-fragile ratio: {semi_ratio:.1f}x (Forgery/Noise)")
    print(f"  {'PASS' if semi_ratio > 1.5 else 'FAIL'}: Semi-fragile boundary detected")
    print("\nDone.")
