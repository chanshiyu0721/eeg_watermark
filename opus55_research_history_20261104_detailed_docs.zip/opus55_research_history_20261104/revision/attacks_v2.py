"""Deterministic and explicitly named attacks for the v2 rerun."""
from __future__ import annotations

from fractions import Fraction
import numpy as np
from scipy import signal as scipy_signal


def lowpass(sig: np.ndarray, *, cutoff: float, fs: float, order: int = 4) -> np.ndarray:
    sos = scipy_signal.butter(order, cutoff, btype="lowpass", fs=fs, output="sos")
    return scipy_signal.sosfiltfilt(sos, sig, axis=-1)


def notch(sig: np.ndarray, *, frequency: float, fs: float, quality: float = 30.0) -> np.ndarray:
    b, a = scipy_signal.iirnotch(frequency, quality, fs)
    return scipy_signal.filtfilt(b, a, sig, axis=-1)


def contiguous_crop(sig: np.ndarray, *, ratio: float, rng: np.random.Generator) -> np.ndarray:
    result = np.asarray(sig).copy()
    length = max(1, int(round(result.shape[-1] * ratio)))
    start = int(rng.integers(0, result.shape[-1] - length + 1))
    result[..., start:start + length] = 0.0
    return result


def random_sample_loss(sig: np.ndarray, *, ratio: float, rng: np.random.Generator) -> np.ndarray:
    result = np.asarray(sig).copy()
    mask = rng.random(result.shape) < ratio
    result[mask] = 0.0
    return result


def burst_packet_loss(sig: np.ndarray, *, ratio: float, rng: np.random.Generator, bursts: int = 3) -> np.ndarray:
    result = np.asarray(sig).copy()
    total = max(1, int(round(result.shape[-1] * ratio)))
    burst = max(1, total // bursts)
    for _ in range(bursts):
        start = int(rng.integers(0, max(1, result.shape[-1] - burst + 1)))
        result[..., start:start + burst] = 0.0
    return result


def channel_dropout(sig: np.ndarray, *, ratio: float, rng: np.random.Generator) -> np.ndarray:
    result = np.asarray(sig).copy()
    count = max(1, int(round(result.shape[0] * ratio)))
    channels = rng.choice(result.shape[0], size=min(count, result.shape[0]), replace=False)
    result[channels, :] = 0.0
    return result


def resample_roundtrip(sig: np.ndarray, *, ratio: float) -> np.ndarray:
    factor = Fraction(1.0 + ratio).limit_denominator(1000)
    changed = scipy_signal.resample_poly(sig, factor.numerator, factor.denominator, axis=-1)
    restored = scipy_signal.resample_poly(changed, factor.denominator, factor.numerator, axis=-1)
    if restored.shape[-1] < sig.shape[-1]:
        restored = np.pad(restored, ((0, 0), (0, sig.shape[-1] - restored.shape[-1])))
    return restored[..., : sig.shape[-1]]


def gaussian_noise(sig: np.ndarray, *, sigma: float, rng: np.random.Generator) -> np.ndarray:
    scale = float(np.std(sig)) or 1.0
    return np.asarray(sig) + rng.normal(0.0, sigma * scale, size=np.asarray(sig).shape)


def segment_replace(sig: np.ndarray, replacement: np.ndarray, *, ratio: float, rng: np.random.Generator) -> np.ndarray:
    result = np.asarray(sig).copy()
    other = np.asarray(replacement)
    if result.shape != other.shape:
        raise ValueError(f"replacement shape {other.shape} differs from signal {result.shape}")
    length = max(1, int(round(result.shape[-1] * ratio)))
    start = int(rng.integers(0, result.shape[-1] - length + 1))
    result[..., start:start + length] = other[..., start:start + length]
    return result


def make_attack_suite(fs: float, *, seed: int, replacement: np.ndarray | None = None) -> dict[str, callable]:
    rng = np.random.default_rng(seed)
    suite = {
        "lowpass_45hz": lambda x: lowpass(x, cutoff=min(45.0, 0.45 * fs), fs=fs),
        "notch_50hz": lambda x: notch(x, frequency=min(50.0, 0.4 * fs), fs=fs),
        "contiguous_crop_10pct": lambda x: contiguous_crop(x, ratio=0.10, rng=rng),
        "random_sample_loss_10pct": lambda x: random_sample_loss(x, ratio=0.10, rng=rng),
        "burst_packet_loss_10pct": lambda x: burst_packet_loss(x, ratio=0.10, rng=rng),
        "channel_dropout_10pct": lambda x: channel_dropout(x, ratio=0.10, rng=rng),
        "resample_plus_5pct": lambda x: resample_roundtrip(x, ratio=0.05),
        "gaussian_sigma_0p05": lambda x: gaussian_noise(x, sigma=0.05, rng=rng),
    }
    if replacement is not None:
        suite["cross_trial_replace_30pct"] = lambda x: segment_replace(x, replacement, ratio=0.30, rng=rng)
    return suite

