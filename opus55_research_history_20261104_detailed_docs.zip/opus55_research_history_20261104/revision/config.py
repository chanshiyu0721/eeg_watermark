"""
Revision 项目配置
所有可调参数集中管理
"""
import os

# === 路径配置 ===
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TEST_DIR = os.path.join(BASE_DIR, 'test')
DATA_DIR = os.path.join(BASE_DIR, 'data')
OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'output')
REAL_EEG_PKL = os.path.join(TEST_DIR, 'filtered_eeg_dataset.pkl')
FINAL_PERF_CSV = os.path.join(TEST_DIR, 'Final_Performance_Table.csv')
BCI_UTILITY_CSV = os.path.join(TEST_DIR, 'BCI_Utility_Report.csv')

# === SAW 核心算法参数 (与07_optimization_fix.py一致) ===
WAVELET = 'haar'
SCALING_FACTOR = 1000.0
BLOCK_SIZE = 2
HASH_LEN = 8
ENCRYPTION_KEY = 0.75
MU = 3.99
INIT_Q = 1.0
Q_GROWTH = 1.5
MAX_Q = 5000.0
MAX_CAL_ITER = 50

# === 基线方法参数 ===
SPREAD_LSB_ALPHA = 0.05      # Spread-LSB 嵌入强度
RPW_EEG_Q = 20.0             # RPW-EEG 固定量化步长

# === 攻击参数 ===
DEFAULT_FS = 250.0            # 默认采样率
LOWPASS_CUTOFF_45 = 45.0
LOWPASS_CUTOFF_60 = 60.0
NOTCH_FREQ_50 = 50.0
NOTCH_FREQ_60 = 60.0
CROP_RATIOS = [0.05, 0.10, 0.15]
RESAMPLE_RATIOS = [-0.05, 0.05]
FORGERY_RATIOS = [0.2, 0.3, 0.4, 0.5]

# === 可解释性 ===
EEG_BANDS = {
    'delta': (0.5, 4.0),
    'theta': (4.0, 8.0),
    'alpha': (8.0, 13.0),
    'beta': (13.0, 30.0),
    'low_gamma': (30.0, 50.0),
}

# === 验证阈值 ===
THRESHOLDS = {
    'psnr_min': 35.0,
    'ssim_min': 0.98,
    'prd_max': 10.0,
    'ber_clean_max': 0.0,
    'ber_noise_max': 0.10,
    'ber_crop_max': 0.15,
    'forgery_noise_ratio': 2.0,   # forgery BER > ratio * noise BER
    'latency_max_ms': 200.0,
    'psd_change_max_pct': 10.0,
}

os.makedirs(OUTPUT_DIR, exist_ok=True)
