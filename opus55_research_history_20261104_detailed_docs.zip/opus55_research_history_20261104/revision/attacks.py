"""
综合攻击模拟模块
================
三类攻击 (对应Paper_Revision_Plan.md Section 5):
  1. 常规信号处理 (鲁棒性证明):
     - 低通滤波 (45Hz / 60Hz, 4阶Butterworth)
     - 50Hz / 60Hz 陷波 (工频干扰去除)
  2. 同步攻击:
     - 随机裁剪/丢包 (5%, 10%, 15%)
     - 重采样 (±5% 采样率微调)
  3. 恶意伪造攻击 (脆弱性证明):
     - 片段替换 (20%-50%)
     - 高斯噪声
"""
import numpy as np
from scipy import signal as scipy_signal
from scipy.interpolate import interp1d
from . import config


# ====================================================================
# Category 1: 信号处理攻击 - Signal Processing Attacks
# ====================================================================

def attack_lowpass(sig: np.ndarray, cutoff: float = None, fs: float = None,
                   order: int = 4) -> np.ndarray:
    """
    低通滤波攻击
    模拟临床常见的抗混叠滤波或带宽限制
    """
    if cutoff is None: cutoff = config.LOWPASS_CUTOFF_45
    if fs is None: fs = config.DEFAULT_FS
    nyq = fs / 2.0
    b, a = scipy_signal.butter(order, cutoff / nyq, btype='low')
    return scipy_signal.filtfilt(b, a, sig, axis=-1)


def attack_notch(sig: np.ndarray, freq: float = None, fs: float = None,
                 Q: float = 30.0) -> np.ndarray:
    """
    陷波滤波攻击
    模拟临床工频干扰去除 (50Hz或60Hz)
    """
    if freq is None: freq = config.NOTCH_FREQ_50
    if fs is None: fs = config.DEFAULT_FS
    b, a = scipy_signal.iirnotch(freq, Q, fs)
    return scipy_signal.filtfilt(b, a, sig, axis=-1)


def attack_highpass(sig: np.ndarray, cutoff: float = 0.5, fs: float = None,
                    order: int = 4) -> np.ndarray:
    """
    高通滤波攻击
    模拟DC偏移去除
    """
    if fs is None: fs = config.DEFAULT_FS
    nyq = fs / 2.0
    b, a = scipy_signal.butter(order, cutoff / nyq, btype='high')
    return scipy_signal.filtfilt(b, a, sig, axis=-1)


def attack_bandpass(sig: np.ndarray, low: float = 0.5, high: float = 100.0,
                    fs: float = None, order: int = 4) -> np.ndarray:
    """带通滤波攻击 (模拟完整预处理管线)"""
    if fs is None: fs = config.DEFAULT_FS
    nyq = fs / 2.0
    b, a = scipy_signal.butter(order, [low / nyq, high / nyq], btype='band')
    return scipy_signal.filtfilt(b, a, sig, axis=-1)


# ====================================================================
# Category 2: 同步攻击 - Synchronization Attacks
# ====================================================================

def attack_cropping(sig: np.ndarray, loss_ratio: float = 0.10) -> np.ndarray:
    """
    随机裁剪/丢包攻击
    模拟无线传输中的数据包丢失
    """
    result = sig.copy()
    mask = np.random.random(result.shape) > loss_ratio
    result[~mask] = 0.0
    return result


def attack_resample(sig: np.ndarray, ratio: float = 0.05,
                    fs: float = None) -> np.ndarray:
    """
    重采样攻击
    模拟ADC时钟漂移导致的采样率偏差
    """
    if fs is None: fs = config.DEFAULT_FS
    result = np.zeros_like(sig)
    for ch in range(sig.shape[0]):
        n = len(sig[ch])
        x_orig = np.arange(n)
        new_fs = fs * (1.0 + ratio)
        new_n = int(n * fs / new_fs)
        f_down = interp1d(x_orig, sig[ch], kind='linear',
                          bounds_error=False, fill_value=0.0)
        downsampled = f_down(np.linspace(0, n - 1, new_n))
        f_up = interp1d(np.linspace(0, n - 1, new_n), downsampled,
                        kind='linear', bounds_error=False, fill_value=0.0)
        result[ch] = f_up(x_orig)
    return result


def attack_time_shift(sig: np.ndarray, shift_samples: int = 10) -> np.ndarray:
    """
    时间偏移攻击
    模拟采集设备间的同步误差
    """
    result = np.zeros_like(sig)
    if shift_samples > 0:
        result[:, shift_samples:] = sig[:, :-shift_samples]
    elif shift_samples < 0:
        result[:, :shift_samples] = sig[:, -shift_samples:]
    else:
        result = sig.copy()
    return result


# ====================================================================
# Category 3: 恶意伪造攻击 - Forgery Attacks
# ====================================================================

def attack_segment_replace(sig: np.ndarray, replacement: np.ndarray,
                           ratio: float = 0.2) -> np.ndarray:
    """
    片段替换攻击
    用其他试次的数据替换信号的一段，模拟恶意数据伪造
    """
    result = sig.copy()
    n_samples = sig.shape[-1]
    seg_len = int(n_samples * ratio)
    if seg_len < 1: seg_len = 1
    start = np.random.randint(0, n_samples - seg_len)

    if sig.ndim == 2:
        result[:, start:start + seg_len] = replacement[:, start:start + seg_len]
    else:
        result[..., start:start + seg_len] = replacement[..., start:start + seg_len]
    return result


def attack_gaussian_noise(sig: np.ndarray, sigma: float = 0.05) -> np.ndarray:
    """
    高斯噪声攻击
    模拟环境噪声叠加
    """
    noise = np.random.normal(0, sigma, sig.shape)
    signal_std = np.std(sig)
    if signal_std == 0: signal_std = 1.0
    return sig + noise * signal_std


def attack_amplitude_scale(sig: np.ndarray, factor: float = 1.2) -> np.ndarray:
    """
    幅度缩放攻击
    模拟增益漂移
    """
    return sig * factor


def attack_dc_offset(sig: np.ndarray, offset: float = None) -> np.ndarray:
    """DC偏移攻击"""
    if offset is None: offset = 0.1 * np.std(sig)
    return sig + offset


def attack_quantization(sig: np.ndarray, bits: int = 12) -> np.ndarray:
    """
    量化攻击
    模拟ADC分辨率降低
    """
    min_v, max_v = np.min(sig), np.max(sig)
    levels = 2 ** bits - 1
    quantized = np.round((sig - min_v) / (max_v - min_v) * levels) / levels
    return quantized * (max_v - min_v) + min_v


# ====================================================================
# 综合攻击套件
# ====================================================================

ALL_ATTACKS = {
    # === 信号处理 (鲁棒性) ===
    'LowPass 45Hz': lambda s: attack_lowpass(s, cutoff=45.0),
    'LowPass 60Hz': lambda s: attack_lowpass(s, cutoff=60.0),
    'HighPass 0.5Hz': lambda s: attack_highpass(s, cutoff=0.5),
    'BandPass 0.5-100Hz': lambda s: attack_bandpass(s),
    'Notch 50Hz': lambda s: attack_notch(s, freq=50.0),
    'Notch 60Hz': lambda s: attack_notch(s, freq=60.0),

    # === 同步攻击 ===
    'Cropping 5%': lambda s: attack_cropping(s, loss_ratio=0.05),
    'Cropping 10%': lambda s: attack_cropping(s, loss_ratio=0.10),
    'Cropping 15%': lambda s: attack_cropping(s, loss_ratio=0.15),
    'Resample +5%': lambda s: attack_resample(s, ratio=0.05),
    'Resample -5%': lambda s: attack_resample(s, ratio=-0.05),

    # === 噪声/失真 ===
    'Gaussian sigma=0.01': lambda s: attack_gaussian_noise(s, sigma=0.01),
    'Gaussian sigma=0.05': lambda s: attack_gaussian_noise(s, sigma=0.05),
    'Gaussian sigma=0.10': lambda s: attack_gaussian_noise(s, sigma=0.10),
    'Amplitude Scale 1.1': lambda s: attack_amplitude_scale(s, factor=1.1),
    'Amplitude Scale 1.2': lambda s: attack_amplitude_scale(s, factor=1.2),
    'DC Offset': lambda s: attack_dc_offset(s),
    'Quantization 12bit': lambda s: attack_quantization(s, bits=12),
    'Quantization 16bit': lambda s: attack_quantization(s, bits=16),
}


def run_attack_suite(signal: np.ndarray, watermarked: np.ndarray,
                     bits: np.ndarray, q_step: float,
                     attacks: dict = None,
                     replacement_signal: np.ndarray = None) -> dict:
    """
    运行完整攻击套件，返回每种攻击的BER

    Args:
        signal: 原始信号
        watermarked: 含水印信号
        bits: 原始水印比特
        q_step: 使用的量化步长
        attacks: 要测试的攻击字典，默认使用ALL_ATTACKS
        replacement_signal: 用于片段替换攻击的替代信号

    Returns:
        dict: {attack_name: BER}
    """
    from .saw_core import extract_full, normalize_signal
    from .metrics import compute_ber

    if attacks is None:
        attacks = ALL_ATTACKS

    results = {}
    for name, attack_fn in attacks.items():
        try:
            attacked = attack_fn(watermarked)
            extracted = extract_full(attacked, len(bits), q_step)
            ber = compute_ber(bits, extracted)
            results[name] = ber
        except Exception as e:
            results[name] = 1.0  # fail = BER=1
    return results


def run_forgery_suite(signals: list, bits: np.ndarray,
                      ratios: list = None) -> dict:
    """
    运行伪造攻击套件 (片段替换，不同比例)

    Args:
        signals: 信号列表 (至少需要2个)
        bits: 水印比特
        ratios: 替换比例列表

    Returns:
        dict: {ratio_label: avg_BER}
    """
    from .saw_core import calibrate, extract_full
    from .metrics import compute_ber

    if ratios is None:
        ratios = config.FORGERY_RATIOS

    results = {}
    for ratio in ratios:
        bers = []
        for i in range(len(signals) - 1):
            wm, q, _, _ = calibrate(signals[i], bits)
            forged = attack_segment_replace(wm, signals[i + 1], ratio)
            ext = extract_full(forged, len(bits), q)
            bers.append(compute_ber(bits, ext))
        results[f'SegmentReplace_{int(ratio*100)}%'] = float(np.mean(bers))
    return results
