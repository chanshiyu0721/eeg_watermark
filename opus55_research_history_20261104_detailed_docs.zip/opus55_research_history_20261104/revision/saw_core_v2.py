"""Corrected SAW v2 core used by the reproducible rerun.

The legacy ``saw_core.py`` is intentionally preserved for auditability.  V2 uses
a one-dimensional temporal DWT and forms each 2x2 SVD block from four adjacent
approximation coefficients within one channel.  It therefore never treats EEG
channel order as a spatial image axis.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import hmac
import struct
from typing import Any

import numpy as np
import pywt


PAYLOAD_BYTES = 26
PAYLOAD_BITS = PAYLOAD_BYTES * 8
PAYLOAD_VERSION = 2


class CapacityError(ValueError):
    """Raised when a trial cannot hold the complete payload."""


@dataclass(frozen=True)
class CalibrationResult:
    watermarked: np.ndarray
    q_step: float
    ber: float
    psnr_db: float
    iterations: int
    capacity_bits: int
    success: bool
    failure_reason: str | None = None


def bytes_to_bits(payload: bytes) -> np.ndarray:
    return np.unpackbits(np.frombuffer(payload, dtype=np.uint8)).astype(np.int8)


def bits_to_bytes(bits: np.ndarray) -> bytes:
    bits = np.asarray(bits, dtype=np.uint8).reshape(-1)
    if bits.size % 8:
        raise ValueError("bit length must be divisible by eight")
    return np.packbits(bits).tobytes()


def canonical_signal_bytes(signal: np.ndarray) -> bytes:
    """Canonical little-endian float32 representation used for benchmark IDs."""
    arr = np.asarray(signal, dtype="<f4", order="C")
    return struct.pack("<II", arr.shape[0], arr.shape[1]) + arr.tobytes(order="C")


def build_authenticated_payload(
    signal: np.ndarray,
    *,
    device_id: str,
    timestamp: int,
    trial_id: str,
    secret_key: bytes,
) -> np.ndarray:
    """Build a deterministic, trial-unique 208-bit authenticated test payload.

    Layout: version(1), device hash(3), timestamp(4), signal digest(6),
    trial nonce(4), HMAC-SHA256 tag(8).  The 64-bit tag is suitable for the
    benchmark payload budget but is not presented as a general PKI solution.
    """
    if not secret_key:
        raise ValueError("secret_key must be supplied explicitly")
    if not (0 <= int(timestamp) <= 0xFFFFFFFF):
        raise ValueError("timestamp must fit in uint32")
    device_hash = hashlib.sha256(device_id.encode("utf-8")).digest()[:3]
    signal_digest = hashlib.sha256(canonical_signal_bytes(signal)).digest()[:6]
    trial_nonce = hashlib.sha256(trial_id.encode("utf-8")).digest()[:4]
    body = struct.pack("<B", PAYLOAD_VERSION) + device_hash
    body += struct.pack("<I", int(timestamp)) + signal_digest + trial_nonce
    tag = hmac.new(secret_key, body, hashlib.sha256).digest()[:8]
    payload = body + tag
    if len(payload) != PAYLOAD_BYTES:
        raise AssertionError("unexpected payload length")
    return bytes_to_bits(payload)


def verify_authenticated_payload(bits: np.ndarray, *, secret_key: bytes) -> dict[str, Any]:
    """Parse and authenticate an extracted payload.

    This verifies payload authenticity only.  The embedded pre-watermark signal
    digest requires a trusted reference record (or a future robust/reversible
    hashing design) to verify the signal content itself.
    """
    raw = bits_to_bytes(bits)
    if len(raw) != PAYLOAD_BYTES:
        return {"authenticated": False, "reason": "wrong_length"}
    body, supplied_tag = raw[:-8], raw[-8:]
    expected_tag = hmac.new(secret_key, body, hashlib.sha256).digest()[:8]
    version = body[0]
    return {
        "authenticated": bool(version == PAYLOAD_VERSION and hmac.compare_digest(supplied_tag, expected_tag)),
        "version": int(version),
        "device_hash": body[1:4].hex(),
        "timestamp": int(struct.unpack("<I", body[4:8])[0]),
        "signal_digest": body[8:14].hex(),
        "trial_nonce": body[14:18].hex(),
        "reason": None if version == PAYLOAD_VERSION else "wrong_version",
    }


def normalize_signal(signal: np.ndarray, scaling_factor: float = 1000.0) -> tuple[np.ndarray, float, float]:
    signal = np.asarray(signal, dtype=np.float64)
    if signal.ndim != 2:
        raise ValueError(f"expected channels x samples, got shape {signal.shape}")
    if not np.all(np.isfinite(signal)):
        raise ValueError("signal contains NaN or infinity")
    min_v, max_v = float(np.min(signal)), float(np.max(signal))
    if max_v <= min_v:
        raise ValueError("constant signal is not embeddable")
    normalized = (signal - min_v) / (max_v - min_v) * scaling_factor
    return normalized, min_v, max_v


def denormalize_signal(signal: np.ndarray, min_v: float, max_v: float, scaling_factor: float = 1000.0) -> np.ndarray:
    return signal / scaling_factor * (max_v - min_v) + min_v


def qim_embed(value: float, bit: int, step: float) -> float:
    """Embed one bit at the centre of an even/odd quantization bin."""
    if not np.isfinite(step) or step <= 0:
        raise ValueError("step must be positive and finite")
    if bit not in (0, 1):
        raise ValueError("bit must be 0 or 1")
    index = int(np.floor(value / step))
    if index % 2 != bit:
        index += 1
    return (index + 0.5) * step


def qim_extract(value: float, step: float) -> int:
    """Extract using the same half-open bins used by :func:`qim_embed`."""
    if not np.isfinite(step) or step <= 0:
        raise ValueError("step must be positive and finite")
    index = int(np.floor(value / step + 1e-10))
    return index & 1


def _temporal_dwt(signal: np.ndarray, wavelet: str) -> tuple[np.ndarray, np.ndarray]:
    c_a, c_d = pywt.dwt(signal, wavelet, mode="periodization", axis=-1)
    return np.asarray(c_a), np.asarray(c_d)


def max_capacity(shape: tuple[int, int], wavelet: str = "haar") -> int:
    if len(shape) != 2:
        return 0
    channels, samples = int(shape[0]), int(shape[1])
    if channels <= 0 or samples <= 0:
        return 0
    coeff_len = pywt.dwt_coeff_len(samples, pywt.Wavelet(wavelet).dec_len, mode="periodization")
    return channels * (coeff_len // 4)


def _block_location(index: int, blocks_per_channel: int) -> tuple[int, int]:
    channel = index // blocks_per_channel
    start = (index % blocks_per_channel) * 4
    return channel, start


def embed_core(normalized: np.ndarray, bits: np.ndarray, q_step: float, wavelet: str = "haar") -> np.ndarray:
    bits = np.asarray(bits, dtype=np.int8).reshape(-1)
    capacity = max_capacity(normalized.shape, wavelet)
    if bits.size > capacity:
        raise CapacityError(f"payload={bits.size} bits exceeds capacity={capacity} bits")
    c_a, c_d = _temporal_dwt(normalized, wavelet)
    blocks_per_channel = c_a.shape[1] // 4
    embedded = c_a.copy()
    for index, bit in enumerate(bits):
        channel, start = _block_location(index, blocks_per_channel)
        block = embedded[channel, start:start + 4].reshape(2, 2)
        u, singular, vt = np.linalg.svd(block, full_matrices=False)
        singular[0] = qim_embed(float(singular[0]), int(bit), q_step)
        embedded[channel, start:start + 4] = (u @ np.diag(singular) @ vt).reshape(-1)
    reconstructed = pywt.idwt(embedded, c_d, wavelet, mode="periodization", axis=-1)
    return reconstructed[:, : normalized.shape[1]]


def extract_core(normalized: np.ndarray, bit_count: int, q_step: float, wavelet: str = "haar") -> np.ndarray:
    capacity = max_capacity(normalized.shape, wavelet)
    if bit_count > capacity:
        raise CapacityError(f"payload={bit_count} bits exceeds capacity={capacity} bits")
    c_a, _ = _temporal_dwt(normalized, wavelet)
    blocks_per_channel = c_a.shape[1] // 4
    result = np.empty(bit_count, dtype=np.int8)
    for index in range(bit_count):
        channel, start = _block_location(index, blocks_per_channel)
        block = c_a[channel, start:start + 4].reshape(2, 2)
        singular = np.linalg.svd(block, compute_uv=False)
        result[index] = qim_extract(float(singular[0]), q_step)
    return result


def bit_error_rate(reference: np.ndarray, extracted: np.ndarray) -> float:
    reference = np.asarray(reference).reshape(-1)
    extracted = np.asarray(extracted).reshape(-1)
    if reference.size != extracted.size or reference.size == 0:
        return 1.0
    return float(np.mean(reference != extracted))


def extract_full(signal: np.ndarray, bit_count: int, q_step: float, *, wavelet: str = "haar") -> np.ndarray:
    normalized, _, _ = normalize_signal(signal)
    return extract_core(normalized, bit_count, q_step, wavelet)


def _psnr(original: np.ndarray, watermarked: np.ndarray) -> float:
    mse = float(np.mean((original - watermarked) ** 2))
    if mse == 0:
        return float("inf")
    data_range = float(np.max(original) - np.min(original))
    return float(10.0 * np.log10((data_range * data_range) / mse))


def calibrate(
    signal: np.ndarray,
    bits: np.ndarray,
    *,
    initial_q: float = 1.0,
    growth: float = 1.5,
    max_q: float = 5000.0,
    max_iterations: int = 50,
    wavelet: str = "haar",
) -> CalibrationResult:
    """Increase Q until exact blind extraction succeeds or a bound is reached."""
    if initial_q <= 0 or growth <= 1 or max_q < initial_q or max_iterations < 1:
        raise ValueError("invalid calibration parameters")
    bits = np.asarray(bits, dtype=np.int8).reshape(-1)
    capacity = max_capacity(np.asarray(signal).shape, wavelet)
    if bits.size > capacity:
        raise CapacityError(f"payload={bits.size} bits exceeds capacity={capacity} bits")
    normalized, min_v, max_v = normalize_signal(signal)
    last: tuple[np.ndarray, float, float, int] | None = None
    q_step = float(initial_q)
    for iteration in range(1, max_iterations + 1):
        if q_step > max_q:
            break
        wm_normalized = embed_core(normalized, bits, q_step, wavelet)
        watermarked = denormalize_signal(wm_normalized, min_v, max_v)
        extracted = extract_full(watermarked, bits.size, q_step, wavelet=wavelet)
        ber = bit_error_rate(bits, extracted)
        last = (watermarked, q_step, ber, iteration)
        if ber == 0.0:
            return CalibrationResult(
                watermarked=watermarked,
                q_step=q_step,
                ber=ber,
                psnr_db=_psnr(np.asarray(signal, dtype=np.float64), watermarked),
                iterations=iteration,
                capacity_bits=capacity,
                success=True,
            )
        q_step *= growth
    if last is None:
        raise RuntimeError("calibration made no attempt")
    watermarked, used_q, ber, iteration = last
    return CalibrationResult(
        watermarked=watermarked,
        q_step=used_q,
        ber=ber,
        psnr_db=_psnr(np.asarray(signal, dtype=np.float64), watermarked),
        iterations=iteration,
        capacity_bits=capacity,
        success=False,
        failure_reason="max_q_or_iterations_reached",
    )

