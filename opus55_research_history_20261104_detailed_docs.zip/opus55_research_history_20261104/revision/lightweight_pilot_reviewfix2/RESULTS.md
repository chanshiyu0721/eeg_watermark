# Lightweight pilot — second review-fix results

This round corrects extraction timing, odd-length boundary reasoning, clipping
reasoning, and the distinction between an oracle union and a deployable sequential
fixed-grid selector. The frozen 220-trial sample, payloads and subject split are
unchanged. Trial IDs, split labels, input SHA-256 and payload SHA-256 are identical
to `revision/lightweight_pilot/manifests/sample_manifest.csv`.

## Verification

- Unit/regression tests: **39/39 pass**.
- Experiment: 220 trials; validation 110, test 110; no attacks.
- Historical result directories and manuscript files were not modified.

## Corrected timing

Extraction is now timed on a precomputed watermarked signal. The timed region
contains receiver normalization and extraction only; it contains no embedding.
Pooled medians over 27 repeated measurements are:

| Operation | SVD | Direct DWT | Ratio |
|---|---:|---:|---:|
| Embed | 2.646 ms | 0.357 ms | **7.41x** |
| Extract | 1.178 ms | 0.253 ms | **4.66x** |
| Geometric search | 14.167 ms | 0.594 ms | **23.84x** |

The previous 7.2x extraction claim is withdrawn because its timed region included
embedding. These are desktop CPython timings, not edge-device benchmarks; memory
was not measured.

## Deployable fixed-grid search

The fixed grid `{0.5,1,2,4,8,16,32,64}` is scanned in ascending order. The embedder
knows the payload and stops at the first candidate whose clean round-trip BER is
zero. This is a concrete sequential algorithm, unlike the oracle union/best-Q
ceiling.

| Method (test) | Recovery | Recovery and PRD <= 1% | Worst PRD | Median PRD |
|---|---:|---:|---:|---:|
| SVD fixed-grid first-success | 110/110 | 107/110 | 5.863% | 0.0514% |
| Direct-DWT fixed-grid first-success | **110/110** | **109/110** | **1.674%** | **0.0480%** |
| Direct-DWT fixed-grid, 1% gate | 109/110 | 109/110 | **0.429%** | 0.0477% |
| Direct-DWT fixed-grid, 0.5% gate | 109/110 | 109/110 | **0.429%** | 0.0477% |
| Direct-DWT fixed-grid, 0.1% gate | 100/110 | 100/110 | **0.092%** | 0.0462% |

Against geometric direct-DWT self-calibration, fixed-grid direct DWT recovers the
same 110/110 test trials and has no greater PRD on 104/110 paired trials. Against
geometric SVD method A, fixed-grid SVD recovers 110/110 versus 109/110, but its
ungated distortion tail remains poor. The evidence therefore supports a small
fixed grid as the next search domain, especially with direct DWT and a quality gate.

The oracle tables remain in `oracle_q_ceiling.csv` and are labelled ceilings; they
are not used as delivered-method results.

## Corrected analyzability statements

- Even length, orthonormal Haar and no clipping: coefficient-domain and
  signal-domain Frobenius perturbation norms are equal.
- With odd length, periodization followed by truncation is contractive. The final
  approximation coefficient has signal norm `1/sqrt(2)` for a unit perturbation.
  Thus the coefficient-domain norm remains an upper bound, but equality is not
  general.
- Direct DWT modifies the first coefficient of each complete four-coefficient
  block. All such actually used positions retained equality for every tested length.
- SVD can modify a block containing the periodized boundary. Its signal error can
  be strictly below the block Frobenius error; the upper bound still holds.
- For a valid normalized reference in `[0,1000]`, clipping is a non-expansive
  projection. The boundary case reduces error from 500.0 to 15.873. Clipping can
  break equality downward, not invalidate the upper bound.

## Scientific decision

1. **Drop SVD: supported.** Direct DWT has equal payload capacity, lower computation,
   equal or better recovery, and a better distortion tail.
2. **Replace the 1.5x ladder: supported for the next design.** The deployable
   eight-point direct-DWT selector reaches 110/110 clean recovery without the
   catastrophic geometric-SVD failure.
3. **Quality gating is necessary but not sufficient novelty.** It turns 110/110
   recovery with one 1.674% outlier into 109/110 accepted with worst PRD 0.429%.
   In this form it remains a rejection rule; the contribution should predict or
   control distortion before reconstruction rather than merely filter afterward.
4. **Normalization remains the largest mechanism risk.** Forty of 220 low-Q SVD
   trials fail blind min/max decoding and all recover with original extrema. Side
   information is diagnostic, not yet a deployable solution.

Overall decision: **continue, with a focused pivot** to direct DWT-QIM, a small
fixed candidate grid, and an analytically derived pre-embedding distortion
criterion. Attack robustness, independent held-out confirmation, and deployable
normalization treatment remain required before publication claims.
