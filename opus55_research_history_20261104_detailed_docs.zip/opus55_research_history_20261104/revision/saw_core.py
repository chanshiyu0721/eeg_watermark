"""
SAW 核心算法模块 (基于07_optimization_fix.py确认可运行版本)
=============================================================
单级DWT + SVD-QIM + Logistic混沌加密 + 自适应校准
"""
import numpy as np
import pywt
from scipy.linalg import svd, diagsvd
from . import config

# ============================================================
# 水印编解码
# ============================================================

def text_to_bits(text: str) -> np.ndarray:
    """文本 -> 比特数组"""
    bits = bin(int.from_bytes(text.encode('utf-8'), 'big'))[2:]
    return np.array([int(b) for b in bits.zfill(8 * ((len(bits) + 7) // 8))], dtype=np.int8)


def bits_to_text(bits: np.ndarray) -> str:
    """比特数组 -> 文本"""
    chars = []
    for i in range(0, len(bits), 8):
        byte = bits[i:i + 8]
        if len(byte) < 8: break
        try:
            chars.append(chr(int("".join(map(str, byte)), 2)))
        except: pass
    return "".join(chars)


def generate_logistic_sequence(length: int, x0: float = None, mu: float = None) -> np.ndarray:
    """Logistic混沌序列生成 (用于加密)"""
    if x0 is None: x0 = config.ENCRYPTION_KEY
    if mu is None: mu = config.MU
    seq, x = [], x0
    for _ in range(length):
        x = mu * x * (1 - x)
        seq.append(1 if x > 0.5 else 0)
    return np.array(seq, dtype=np.int8)


def generate_watermark(device_id: str = "DEV-01", timestamp: str = "0000000000",
                       signal_hash: str = None) -> np.ndarray:
    """生成完整的加密水印 payload"""
    if signal_hash is None:
        import hashlib, time
        signal_hash = hashlib.sha256(str(time.time()).encode()).hexdigest()[:config.HASH_LEN]
    payload_text = f"{device_id}|{timestamp}|{signal_hash}"
    raw_bits = text_to_bits(payload_text)
    chaos = generate_logistic_sequence(len(raw_bits))
    return np.bitwise_xor(raw_bits, chaos)

# ============================================================
# 信号归一化
# ============================================================

def normalize_signal(signal: np.ndarray) -> tuple:
    """Min-max归一化到[0, SCALING_FACTOR]"""
    min_v, max_v = np.min(signal), np.max(signal)
    if max_v - min_v == 0:
        return signal.copy(), 0.0, 1.0
    return (signal - min_v) / (max_v - min_v) * config.SCALING_FACTOR, min_v, max_v


def denormalize_signal(norm_signal: np.ndarray, min_v: float, max_v: float) -> np.ndarray:
    """反归一化"""
    return (norm_signal / config.SCALING_FACTOR) * (max_v - min_v) + min_v

# ============================================================
# QIM 量化 (嵌入/提取)
# ============================================================

def qim_embed(val: float, bit: int, step: float) -> float:
    """QIM嵌入：将值推向目标bit对应的区间中心 (使用floor)"""
    quotient = np.floor(val / step)
    if bit == 1:
        if quotient % 2 == 0: quotient += 1
    else:
        if quotient % 2 == 1: quotient += 1
    return quotient * step + (step / 2)


def qim_extract(val: float, step: float) -> int:
    """QIM提取：使用round (与07一致)"""
    q = int(round(val / step))
    return 1 if q % 2 != 0 else 0

# ============================================================
# DWT-SVD 嵌入/提取 (核心)
# ============================================================

def embed_core(norm_signal: np.ndarray, bits: np.ndarray, q_step: float) -> np.ndarray:
    """
    核心嵌入：单级Haar DWT + 2x2块SVD-QIM
    Input: 归一化后的信号 (服从[0, SCALING_FACTOR])
    """
    LL, details = pywt.dwt2(norm_signal, config.WAVELET)
    rows, cols = LL.shape
    idx = 0
    emb_LL = LL.copy()

    for r in range(0, rows - config.BLOCK_SIZE + 1, config.BLOCK_SIZE):
        for c in range(0, cols - config.BLOCK_SIZE + 1, config.BLOCK_SIZE):
            if idx >= len(bits): break
            block = emb_LL[r:r + config.BLOCK_SIZE, c:c + config.BLOCK_SIZE]
            try:
                U, s, Vt = svd(block)
                s[0] = qim_embed(s[0], int(bits[idx]), q_step)
                emb_LL[r:r + config.BLOCK_SIZE, c:c + config.BLOCK_SIZE] = \
                    U @ diagsvd(s, config.BLOCK_SIZE, config.BLOCK_SIZE) @ Vt
                idx += 1
            except np.linalg.LinAlgError:
                continue

    wm_norm = pywt.idwt2((emb_LL, details), config.WAVELET)
    return wm_norm[:norm_signal.shape[0], :norm_signal.shape[1]]


def extract_core(norm_signal: np.ndarray, wm_len: int, q_step: float) -> np.ndarray:
    """
    核心提取：从归一化信号中提取水印比特
    """
    LL, _ = pywt.dwt2(norm_signal, config.WAVELET)
    rows, cols = LL.shape
    bits = []

    for r in range(0, rows - config.BLOCK_SIZE + 1, config.BLOCK_SIZE):
        for c in range(0, cols - config.BLOCK_SIZE + 1, config.BLOCK_SIZE):
            if len(bits) >= wm_len: break
            block = LL[r:r + config.BLOCK_SIZE, c:c + config.BLOCK_SIZE]
            try:
                _, s, _ = svd(block)
                bits.append(qim_extract(s[0], q_step))
            except np.linalg.LinAlgError:
                bits.append(0)

    return np.array(bits, dtype=np.int8)

# ============================================================
# 完整嵌入/提取流水线
# ============================================================

def embed_full(signal: np.ndarray, bits: np.ndarray, q_step: float) -> np.ndarray:
    """完整嵌入流水线：归一化 -> DWT-SVD-QIM -> 反归一化"""
    norm_sig, min_v, max_v = normalize_signal(signal)
    wm_norm = embed_core(norm_sig, bits, q_step)
    return denormalize_signal(wm_norm, min_v, max_v)


def extract_full(signal: np.ndarray, wm_len: int, q_step: float) -> np.ndarray:
    """完整提取流水线：归一化 -> 提取"""
    norm_sig, _, _ = normalize_signal(signal)
    return extract_core(norm_sig, wm_len, q_step)

# ============================================================
# 自适应校准循环 (Algorithm 1)
# ============================================================

def calibrate(signal: np.ndarray, bits: np.ndarray) -> tuple:
    """
    自适应校准：迭代增长Q直到BER=0 (乘法增长策略)
    返回: (含水印信号, 最终Q值, BER, PSNR)

    这是论文的核心创新：Self-Calibrating Adaptive Q-loop
    """
    from skimage.metrics import peak_signal_noise_ratio
    norm_sig, min_v, max_v = normalize_signal(signal)
    current_step = config.INIT_Q
    dr = max(np.max(signal) - np.min(signal), 1e-6)

    for _ in range(config.MAX_CAL_ITER):
        if current_step > config.MAX_Q: break

        wm_norm = embed_core(norm_sig, bits, current_step)
        final_candidate = denormalize_signal(wm_norm, min_v, max_v)
        test_norm, _, _ = normalize_signal(final_candidate)
        extracted = extract_core(test_norm, len(bits), current_step)

        if len(extracted) >= len(bits) and np.sum(bits != extracted[:len(bits)]) == 0:
            psnr_v = peak_signal_noise_ratio(signal, final_candidate, data_range=dr)
            return final_candidate, current_step, 0.0, psnr_v

        current_step *= config.Q_GROWTH

    # fallback: 返回最后一次尝试
    from skimage.metrics import peak_signal_noise_ratio
    psnr_v = peak_signal_noise_ratio(signal, final_candidate, data_range=dr)
    ext_final = extract_core(normalize_signal(final_candidate)[0], len(bits), current_step)
    ber = float(np.mean(bits != ext_final[:len(bits)])) if len(ext_final) >= len(bits) else 1.0
    return final_candidate, current_step, ber, psnr_v


def get_max_capacity(signal_shape: tuple) -> int:
    """计算给定信号形状下可嵌入的最大比特数"""
    ll_rows = signal_shape[0] // 2
    ll_cols = signal_shape[1] // 2
    return (ll_rows // config.BLOCK_SIZE) * (ll_cols // config.BLOCK_SIZE)
