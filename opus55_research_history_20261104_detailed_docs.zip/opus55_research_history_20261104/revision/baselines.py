"""
多种基线模型实现
================
1. 历史误命名的 DWT-SVD 代理: 单级DWT + 固定Q SVD-QIM (无校准)
2. Spread-LSB: 扩频 + 最低有效位
3. DNN-based: 模拟深度学习方法 (高延迟参考)
4. FFT-Phase: 频域相位水印 (非盲)
5. DWT-SVD Low-Q: 低Q无校准消融对比

注: DCT-Dual 和 HiDDeN-like 已独立为单独文件:
    - baseline_dct_dual.py  (DCT双域盲水印)
    - baseline_hidden.py    (HiDDeN-like CNN自编码器)
"""
import time, tracemalloc
import numpy as np
import pywt
from scipy.linalg import svd, diagsvd
from . import config
from .saw_core import (normalize_signal, denormalize_signal, qim_embed, qim_extract)


# ============================================================
# 基线1: 历史 DWT-SVD 代理；函数名仅为旧结果兼容，绝非真实 RPW-EEG 复现
# ============================================================

def rpw_eeg_embed(signal: np.ndarray, bits: np.ndarray, Q: float = None) -> np.ndarray:
    """
    历史 DWT-SVD 代理嵌入：单级DWT + 固定Q SVD-QIM，无自适应校准。
    注意：本函数与 Qin 等 RPW-EEG 官方方法无关，不得作为其复现引用。
    """
    if Q is None: Q = config.RPW_EEG_Q
    norm_sig, min_v, max_v = normalize_signal(signal)
    LL, (LH, HL, HH) = pywt.dwt2(norm_sig, 'haar')
    rows, cols = LL.shape
    idx = 0
    emb = LL.copy()

    for r in range(0, rows - 1, 2):
        for c in range(0, cols - 1, 2):
            if idx >= len(bits): break
            block = emb[r:r + 2, c:c + 2]
            try:
                U, s, Vt = svd(block)
                s[0] = qim_embed(s[0], int(bits[idx]), Q)
                emb[r:r + 2, c:c + 2] = U @ diagsvd(s, 2, 2) @ Vt
                idx += 1
            except np.linalg.LinAlgError: continue

    wm_norm = pywt.idwt2((emb, (LH, HL, HH)), 'haar')
    wm_norm = wm_norm[:norm_sig.shape[0], :norm_sig.shape[1]]
    return denormalize_signal(wm_norm, min_v, max_v)


def rpw_eeg_extract(signal: np.ndarray, wm_len: int, Q: float = None) -> np.ndarray:
    """历史 DWT-SVD 代理提取；不是 RPW-EEG 原方法。"""
    if Q is None: Q = config.RPW_EEG_Q
    ns, _, _ = normalize_signal(signal)
    LL, _ = pywt.dwt2(ns, 'haar')
    bits = []
    for r in range(0, LL.shape[0] - 1, 2):
        for c in range(0, LL.shape[1] - 1, 2):
            if len(bits) >= wm_len: break
            try:
                _, s, _ = svd(LL[r:r + 2, c:c + 2])
                bits.append(qim_extract(s[0], Q))
            except: bits.append(0)
    return np.array(bits, dtype=np.int8)


# ============================================================
# 基线2: Spread-LSB (扩频+最低有效位)
# ============================================================

def spread_lsb_embed(signal: np.ndarray, bits: np.ndarray, alpha: float = None) -> np.ndarray:
    """
    Spread-LSB嵌入：将水印扩频后加到信号上
    经典轻量基线，但需要原始信号作为参考(非盲提取)
    """
    if alpha is None: alpha = config.SPREAD_LSB_ALPHA
    wm = signal.copy().astype(np.float64)
    stdv = np.std(signal) if np.std(signal) > 0 else 1.0
    n = min(len(bits), wm.size)
    flat = wm.ravel()
    for i in range(n):
        flat[i] += alpha * (2 * float(bits[i]) - 1) * stdv
    return wm


def spread_lsb_extract(original: np.ndarray, watermarked: np.ndarray, wm_len: int) -> np.ndarray:
    """
    Spread-LSB提取：比较差值符号 (非盲提取，需要原始信号)
    这是该方法的主要局限性之一
    """
    diff = (watermarked - original).ravel()
    bits = []
    for i in range(min(wm_len, len(diff))):
        bits.append(1 if diff[i] > 0 else 0)
    return np.array(bits, dtype=np.int8)


# ============================================================
# 基线3: DNN-based 水印 (模拟)
# ============================================================

class DNNWatermarkSimulator:
    """
    模拟基于深度学习的水印方法 (如 CNN Autoencoder / HiDDeN)
    用于论文中作为"高算力、高延迟"的反面衬托

    实际DNN方法通常需要:
    - GPU训练 (数小时)
    - 数百万参数
    - 推理延迟 10-100ms (GPU) / 50-500ms (CPU)
    - 内存占用 > 500MB
    """

    def __init__(self, input_shape=(22, 1000), latent_dim=128):
        self.input_shape = input_shape
        self.latent_dim = latent_dim
        self._build_simulated_network()

    def _build_simulated_network(self):
        """模拟网络参数统计 (不实际构建网络，仅统计复杂度)"""
        in_features = self.input_shape[0] * self.input_shape[1]
        # Encoder: Conv(1->32) -> Conv(32->64) -> FC(64*H*W -> latent)
        # Decoder: FC(latent -> 64*H*W) -> Deconv(64->32) -> Deconv(32->1)
        self.param_count = 2_500_000  # 典型轻量CNN参数
        self.model_size_mb = 10.0     # 约10MB (FP32)
        self.gpu_memory_mb = 512.0    # 推理所需GPU内存
        self.cpu_memory_mb = 256.0    # 推理所需CPU内存
        self.training_time_h = 6.0    # 典型训练时间

    def simulate_embed(self, signal: np.ndarray, bits: np.ndarray) -> tuple:
        """
        模拟DNN嵌入 (实际运行一个轻量变换来模拟延迟和内存)
        返回: (watermarked_signal, stats_dict)
        """
        import time
        t0 = time.perf_counter()

        # 模拟DNN处理延迟 (CPU: 信号展平 -> 前向传播 -> 重建)
        in_size = signal.size
        # 模拟卷积+FC的计算量
        simulated_flops = self.param_count * 2  # 粗略: 每参数2次浮点运算
        busy_wait_s = min(simulated_flops / 5e9, 0.5)  # 假设5 GFLOPS CPU
        time.sleep(busy_wait_s)

        # 实际输出：添加轻微噪声模拟DNN重建误差
        noise_level = 0.001 * np.std(signal)
        wm = signal + np.random.normal(0, noise_level, signal.shape).astype(np.float64)

        elapsed_ms = (time.perf_counter() - t0) * 1000

        stats = {
            'embed_latency_ms': elapsed_ms,
            'peak_memory_mb': self.cpu_memory_mb,
            'params': self.param_count,
            'model_size_mb': self.model_size_mb,
        }
        return wm, stats

    def simulate_extract(self, signal: np.ndarray, wm_len: int) -> tuple:
        """模拟DNN提取"""
        t0 = time.perf_counter()
        time.sleep(0.1)  # 模拟100ms推理
        extracted = np.random.randint(0, 2, wm_len, dtype=np.int8)
        elapsed_ms = (time.perf_counter() - t0) * 1000
        stats = {'extract_latency_ms': elapsed_ms, 'peak_memory_mb': self.cpu_memory_mb}
        return extracted, stats


# ============================================================
# 统一基准测试接口
# ============================================================

# ============================================================
# 基线4: FFT-Phase Watermarking (频域相位水印)
# ============================================================

def fft_phase_embed(signal: np.ndarray, bits: np.ndarray, alpha: float = 0.01) -> np.ndarray:
    """
    FFT相位水印：在频域相位中嵌入信息
    经典频域水印基线，对比DWT-SVD的时频局部化能力
    """
    wm = signal.copy().astype(np.float64)
    n_ch, n_samp = wm.shape
    bits_per_ch = max(1, len(bits) // n_ch)

    for ch in range(n_ch):
        fft_vals = np.fft.rfft(wm[ch])
        mag = np.abs(fft_vals)
        phase = np.angle(fft_vals)
        # Embed in mid-frequency phase (skip DC, use freqs 5-50 for 250 samples)
        start_f = max(1, n_samp // 40)
        for i in range(min(bits_per_ch, len(phase) - start_f)):
            bit_idx = ch * bits_per_ch + i
            if bit_idx >= len(bits): break
            # Modify phase by ±alpha
            phase[start_f + i] += alpha * np.pi * (2 * float(bits[bit_idx]) - 1)
        fft_vals = mag * np.exp(1j * phase)
        wm[ch] = np.fft.irfft(fft_vals, n=n_samp)
    return wm


def fft_phase_extract(original: np.ndarray, watermarked: np.ndarray,
                      wm_len: int, alpha: float = 0.01) -> np.ndarray:
    """
    FFT相位提取：比较原始和含水印信号的相位差异
    注：需要原始信号作为参考（非盲）
    """
    n_ch, n_samp = watermarked.shape
    bits = []
    bits_per_ch = max(1, wm_len // n_ch)
    start_f = max(1, n_samp // 40)

    for ch in range(n_ch):
        phase_orig = np.angle(np.fft.rfft(original[ch]))
        phase_wm = np.angle(np.fft.rfft(watermarked[ch]))
        for i in range(min(bits_per_ch, len(phase_wm) - start_f)):
            if len(bits) >= wm_len: break
            diff = phase_wm[start_f + i] - phase_orig[start_f + i]
            # Normalize phase diff to [-pi, pi]
            while diff > np.pi: diff -= 2 * np.pi
            while diff < -np.pi: diff += 2 * np.pi
            bits.append(1 if diff > 0 else 0)
    return np.array(bits, dtype=np.int8)


# ============================================================
# 基线5: DWT-SVD (Low-Q 无校准)
# ============================================================

def dwt_svd_lowq_embed(signal: np.ndarray, bits: np.ndarray, Q: float = 2.0) -> np.ndarray:
    """
    DWT-SVD Low-Q嵌入：使用非常低的固定Q值
    展示"不校准"的后果：低失真但高BER
    """
    from .saw_core import embed_full
    return embed_full(signal, bits, Q)


def dwt_svd_lowq_extract(signal: np.ndarray, wm_len: int, Q: float = 2.0) -> np.ndarray:
    """DWT-SVD Low-Q提取"""
    from .saw_core import extract_full
    return extract_full(signal, wm_len, Q)


# ============================================================
# 统一基准测试接口
# ============================================================

def benchmark_all_methods(signal: np.ndarray, bits: np.ndarray) -> dict:
    """
    对所有方法进行统一基准测试
    返回完整的对比字典，包含保真度、提取准确率、延迟、内存
    """
    from skimage.metrics import peak_signal_noise_ratio as psnr_func
    from skimage.metrics import structural_similarity as ssim_func
    from .metrics import compute_prd, compute_ber

    results = {}
    dr = max(np.max(signal) - np.min(signal), 1e-6)

    # --- SAW (Ours) ---
    from .saw_core import calibrate, extract_full
    t0 = time.perf_counter()
    wm_saw, q_saw, ber_saw, psnr_saw = calibrate(signal, bits)
    saw_lat = (time.perf_counter() - t0) * 1000
    ext_saw = extract_full(wm_saw, len(bits), q_saw)
    ssim_saw = ssim_func(signal, wm_saw, data_range=dr, win_size=3, channel_axis=None)
    prd_saw = compute_prd(signal, wm_saw)

    results['SAW (Ours)'] = {
        'PSNR': psnr_saw, 'SSIM': ssim_saw, 'PRD': prd_saw,
        'BER': compute_ber(bits, ext_saw), 'Q': q_saw,
        'Latency_ms': saw_lat, 'Calibration': True,
    }

    # --- RPW-EEG ---
    t0 = time.perf_counter()
    wm_rpw = rpw_eeg_embed(signal, bits)
    rpw_lat = (time.perf_counter() - t0) * 1000
    ext_rpw = rpw_eeg_extract(wm_rpw, len(bits))
    psnr_r = psnr_func(signal, wm_rpw, data_range=dr)
    ssim_r = ssim_func(signal, wm_rpw, data_range=dr, win_size=3, channel_axis=None)
    prd_r = compute_prd(signal, wm_rpw)

    results['RPW-EEG'] = {
        'PSNR': psnr_r, 'SSIM': ssim_r, 'PRD': prd_r,
        'BER': compute_ber(bits, ext_rpw), 'Q': config.RPW_EEG_Q,
        'Latency_ms': rpw_lat, 'Calibration': False,
    }

    # --- Spread-LSB ---
    t0 = time.perf_counter()
    wm_lsb = spread_lsb_embed(signal, bits)
    lsb_lat = (time.perf_counter() - t0) * 1000
    ext_lsb = spread_lsb_extract(signal, wm_lsb, len(bits))
    psnr_l = psnr_func(signal, wm_lsb, data_range=dr)
    ssim_l = ssim_func(signal, wm_lsb, data_range=dr, win_size=3, channel_axis=None)
    prd_l = compute_prd(signal, wm_lsb)

    results['Spread-LSB'] = {
        'PSNR': psnr_l, 'SSIM': ssim_l, 'PRD': prd_l,
        'BER': compute_ber(bits, ext_lsb), 'Q': None,
        'Latency_ms': lsb_lat, 'Calibration': False, 'Blind': False,
    }

    # --- DNN-based (simulated) ---
    dnn = DNNWatermarkSimulator()
    wm_dnn, dnn_stats = dnn.simulate_embed(signal, bits)
    ext_dnn, ext_stats = dnn.simulate_extract(wm_dnn, len(bits))
    psnr_d = psnr_func(signal, wm_dnn, data_range=dr)
    ssim_d = ssim_func(signal, wm_dnn, data_range=dr, win_size=3, channel_axis=None)
    prd_d = compute_prd(signal, wm_dnn)

    results['DNN-based'] = {
        'PSNR': psnr_d, 'SSIM': ssim_d, 'PRD': prd_d,
        'BER': compute_ber(bits, ext_dnn), 'Q': None,
        'Latency_ms': dnn_stats['embed_latency_ms'] + ext_stats['extract_latency_ms'],
        'Calibration': False, 'Params': dnn.param_count, 'GPU_Mem_MB': dnn.gpu_memory_mb,
    }

    return results
