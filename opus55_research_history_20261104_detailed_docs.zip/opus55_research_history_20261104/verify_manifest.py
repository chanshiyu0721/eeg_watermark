"""Check the review-package file manifest without modifying files; stdlib only."""
import hashlib
import json
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent
manifest = json.loads((root / 'MANIFEST.json').read_text(encoding='utf-8'))
failures = []
for item in manifest['files']:
    target = (root / item['path']).resolve()
    try:
        target.relative_to(root)
    except ValueError:
        failures.append('path outside package: ' + item['path'])
        continue
    if not target.is_file():
        failures.append('missing: ' + item['path'])
        continue
    data = target.read_bytes()
    if len(data) != item['bytes'] or hashlib.sha256(data).hexdigest() != item['sha256']:
        failures.append('bytes/hash mismatch: ' + item['path'])
if failures:
    print('\n'.join(failures))
    raise SystemExit(1)
print('PASS: ' + str(len(manifest['files'])) + ' listed files match their recorded bytes and SHA-256.')
print('Scope: package integrity only; no claim about historical timestamps or scientific validity.')
