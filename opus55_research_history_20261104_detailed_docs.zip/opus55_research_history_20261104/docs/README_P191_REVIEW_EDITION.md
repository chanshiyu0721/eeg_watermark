# EEG 接收方指纹论文：Opus 5.5 独立审查交接包

这是一次**现有论文、开发证据及正在执行的确认方案**的交接。请先独立读稿，再参考既有评审，输出有证据的修改和研究建议。本包没有执行投稿，也没有替作者决定发表去向。

**主审对象是 P191 开发稿；P190 是已完成冻结确认的历史基线。** 两者不能混用结果。项目仍有其他会话执行实验，本包是固定版本的审查快照，不是实时镜像。

## 1. 最快开始

1. 先读本 README 的第 2–7 节，确认版本、实验对象和证据状态。
2. 读 [P191 正文](../output/paper/eeg_submission_p191_dev_v1/main.pdf) / [可检索正文](../output/paper/eeg_submission_p191_dev_v1/manuscript.md)，以及 [补充材料](../output/paper/eeg_submission_p191_dev_v1/supplement.pdf) / [可检索补充](../output/paper/eeg_submission_p191_dev_v1/technical_appendix.md)。
3. 查 [交接时状态](../docs/STATUS_AT_HANDOFF.md)，必要时对照 [逐文件状态和修订核对](../docs/HANDOFF_STATUS_SNAPSHOT.json)。**稿件里的 prospective 设计早于外部确认冻结，不能单凭稿件判断最新执行状态。**
4. 如可运行 Python，在解压后的包根目录执行 `python verify_evidence.py`。该命令只核对保存证据，不启动 EEG 处理、训练或网络请求。
5. 形成第一轮独立判断后，再读第 10 节的既有 Codex 审查，说明哪些批评仍适用、哪些已由 P191 解决、哪些需要纠正。
6. 请按 [REVIEW_REQUEST.md](../REVIEW_REQUEST.md) 的交付格式给出中文建议。

如果阅读时间有限：优先看 P191 正文、状态交接、`READOUT_MECHANISM.md`、`FACTORIAL_DEV_COMPARISON.json` 和最终确认冻结；不要先被旧评审的结论锚定。

## 2. 版本与证据层级

| 材料 | 定位 | 能回答什么 |
|---|---|---|
| `output/paper/eeg_submission_p191_dev_v1/` | 本次主审的新开发稿，正文和附录主要更新于北京时间 2026-11-04 19:58 | 新读数公式、机制诊断、DEV 消融；不是完整新人员确认论文 |
| `output/paper/eeg_submission_p190_overview_v2/` | 原 P190 的路线图整理版，沿用原实验 | 已完成的共享规则人员迁移、选择器增量负结果、历史任务证据 |
| `revision/post_20260926/p191_confirmation_v1/` | 后续正式确认协议、原冻结和 FIX01 修订 | 实际冻结版本、研究约束、实现修复时序；不能仅看旧设计草案 |
| `docs/STATUS_AT_HANDOFF.md` | 交接时的有限只读状态 | 正在执行的归属、任务和边界实验进度，以及旧状态文件的滞后 |
| `output/reviews/idea_review_20261104_p190/` | 较早对 P190 的审查 | 作为二轮对照；不是对后来 P191 新稿与新冻结的完整审查 |

证据按以下顺序解释：

- **已执行的保存结果**支持相应人员、载体、处理条件和版本下的观测。
- **DEV 结果**支持机制开发和方案选择；即使分数很好，也不能改称未触碰确认。
- **冻结协议**说明预定运行和判定方法，不等同于已经完成或通过确认。
- **部分执行检查点**说明执行进度；缺少全人员结果时，不据其计算或宣称正式成功。
- **理论推导**按其固定模板、伪逆和条件响应等假设解释；不自动推出总体误接收保证。
- **既有模型评审**只是可核查意见，不能按提及次数或厂商品牌决定正误。

## 3. 研究对象：接收者身份与 EEG 人员是两条轴

系统试图识别“哪位接收者获得的发行副本产生了查询记录”。这里的 recipient identity 是嵌入码身份，**不是 EEG 受试者的生物身份识别**。

所有者知道候选干净 EEG 源，保留八份真实发行副本及登记表。接收端看到经处理的短查询，估计共同延迟、未知响应，再返回登记接收者或拒绝。实际场景是 reference-assisted、known-source、有限注册表归因。

统一物理与访问条件：

| 项目 | 约定 |
|---|---|
| 原始参考 / 实际发行参考 | 112 s，8 通道，160 Hz |
| 查询评分 | 五个 8 s 窗，共 40 s |
| 查询可见范围 | 含每窗两侧 128 样本上下文，共 48 s |
| 跨窗拟合 | 其余四窗选择延迟/响应，预测第五窗；轮换五折 |
| 存储链路 | 实际 16-bit EDF 写入和读回 |
| PRD 上限 | 全局 0.25%；最大通道 0.5%；8–30 Hz 1% |
| 注册载体实际全局 PRD 匹配 | 每源/身份相对 spread 不超过 0.001 |
| `level 1` | 各源可行扰动强度的完整比例，不是 1% 全局 PRD |
| 主载体与对照 | smooth；direct、spatial、hybrid、身份适配 QIM，以及适用的现代学习载体 |

未知处理主要是共享时间响应。固定滤波网格、八身份、已知源及参考访问应与跨设备、任意预处理、大注册表等更广主张分开。

身份政策保留三类对象：

1. 合法登记接收者；
2. 独立生成、必须拒绝的未登记码；
3. 从某个实际发行副本出发、允许保留父身份的受损副本。

`.025` 和 `.0125` 是单位码空间邻域角度，并非所有 EEG 频点的实际相位幅度。QIM 的合法 Walsh 未知码与 1/2-chip 修改也不是同一种几何。身份语义和码距见 [IDENTITY_POLICY_AND_IDENTIFIABILITY.md](../revision/post_20260926/p191_identity_v1/IDENTITY_POLICY_AND_IDENTIFIABILITY.md)。原 P190 压力标签和计数保留原义。

## 4. P190 的已完成结论

P190 主要固定点为 smooth / candidate-conditioned FIR / level 1。八名新目标为 OpenBMI005–012，四名错源为 OpenBMI013–016。

| 主要观测 | 计数 |
|---|---:|
| 注册正确归属 | 192/192 |
| `.025` 独立近码接受 | 0/384 |
| `.0125` 压力接受，三处理总计 | 30/192 |
| 其中 elliptic 压力接受 | 30/64（46.875%） |
| 另外两个处理各自压力接受 | 0/64 |
| clean / wrong-source 接受 | 0/24；0/96 |

五种重新校准程序在确认前已经选择同一配置、阈值和 gate，因此主要差异结构性为零。它不是“八人样本太少导致不显著”；增加相同规则下的确认人数也不能证明选择器增量。原成功判定失败保留。

八名目标、四名错源是独立人员层次；身份、窗口和处理是重复观测。13,320 个物理查询或 270 个程序汇总不是同等数量的独立验证人员。

完整保存结果和开发选择已压缩为：

- [P190 确认结果 gzip](../evidence_archives/p190_CONFIRMATION_RESULTS.json.gz)
- [P190 开发选择 gzip](../evidence_archives/p190_DEVELOPMENT_SELECTION.json.gz)
- [原主要表数据](../revision/post_20260926/p190_manuscript_v1/PRIMARY_TABLE_DATA.json)
- [原确认冻结](../revision/post_20260926/p190_experiment_v1/CONFIRMATION_FREEZE.json)
- [确认前规则等价记录](../revision/post_20260926/p190_experiment_v1/DEV_PRIMARY_RULE_EQUIVALENCE.json)

gzip 文件解压后保留原 JSON 字节；来源和解压后 SHA-256 见 `docs/SOURCE_PROVENANCE.json`。无需人工阅读数千万字节 JSON，可以先运行只读检查器，再按具体路径查询对象。

## 5. P191 的新技术候选与已有结果

### 5.1 为什么改读数

背景响应误差可能同时主导注册约束残差与无约束身份残差，使历史 compatibility 比值趋近 1，从而遮蔽真实存在的近码差别。仅增加响应容量或重新定阈值未必解决整个问题。

对同一个候选条件响应，定义：

```text
G_i = T_i^T T_i
b_i = T_i^T v_i
d_i = v_i^T v_i
R_i = d_i + [G_i]_{ii} - 2[b_i]_i
U_i = d_i - b_i^T G_i^† b_i
q_i = max(0, R_i - U_i) / max([G_i]_{ii}, numerical_floor)
score_i = -q_i
```

共同项 `d_i` 在固定条件模板下相减抵消；接收器仍有查询依赖响应估计、最优身份选择、五折池化、资格判据和阈值。稿件没有把这条代数式当作无条件低风险保证。

请重点判断：这与经典残差检验、匹配子空间检测、GLRT 或变量投影的关系是什么？技术价值应落在哪个可验证能力或机制上？不能因存在经典组件就直接否定整个贡献，也不能把代数相减本身包装成全新理论。

### 5.2 同预算 DEV 消融

四个 fit 人和四个 select 人均已在过去研究中观察过，每个面板 96 次登记机会。以下是选定规则的计数，所报未登记与控制接受均为零：

| 接收方案 | D_fit 登记正确 | D_select 登记正确 |
|---|---:|---:|
| 129 taps / pressure-aware compatibility | 95/96 | 94/96 |
| 257 taps / pressure-aware compatibility | 86/96 | 89/96 |
| 129 taps / exact conditional readout | 88/96 | 96/96 |
| 257 taps / exact conditional readout | 96/96 | 96/96 |

源文件：

- [READOUT_MECHANISM.md](../revision/post_20260926/p191_fir_capacity_v1/READOUT_MECHANISM.md)
- [完整 2×2 DEV 比较](../revision/post_20260926/p191_fir_capacity_v1/runs/dev257/FACTORIAL_DEV_COMPARISON.json)
- [当时的 DEV 规则提案](../revision/post_20260926/p191_fir_capacity_v1/runs/dev257/FACTORIAL_DEV_RULE_PROPOSAL.json)
- [保存充分统计量](../output/paper/eeg_submission_p191_dev_v1/evidence/scores/)，16 个 `.json.gz`
- [代数核对](../revision/post_20260926/p191_fir_capacity_v1/runs/dev257/EXACT_SCALAR_ALGEBRA_CHECK.json)

早期提案按 select 同分优先低阶推荐过 129/exact；新稿及后续确认设计采用 257/exact。应按文件时间和最终冻结解释这一演变，不把旧提案直接当最终冻结方案。

现有消融区分了 FIR 容量和整套读数，但 exact 同时改变“同响应配对”和“身份能量归一分母”。若主张某个单一因素贡献全部收益，还需最小因素对照。压力感知的简单阈值是强基线，必须保留。

## 6. 交接时的确认、修订与任务状态

完整观察记录见 [STATUS_AT_HANDOFF.md](../docs/STATUS_AT_HANDOFF.md)。该记录截止北京时间 **2026-11-04 21:28:54**；实际打包文件另有逐文件时间和哈希。

### 6.1 确认冻结与 FIX01

- [原确认冻结](../revision/post_20260926/p191_confirmation_v1/CONFIRMATION_FREEZE.json) 于约 20:32 北京时间生成。
- [FIX01](../revision/post_20260926/p191_confirmation_v1/CONFIRMATION_FREEZE_FIX01.json) 于约 20:47 形成，原冻结保留。
- 修订顶层沿用原冻结时间；应查看 `implementation_amendment.created_utc`，不能据顶层时间把修订说成原始时间生成。
- 记录声明：17/18 已发行并进行首查询拟合，因 ridge 键为 float/string 不一致而在首个决策保存前抛出 KeyError；没有确认决策被保存或查看。
- 静态核对发现两处只增加 ridge 键规范化；端点、成功标准、统计、身份政策和任务约束相等，修订记录还载有 DEV 决策等价检查。
- **修订发生于新信号访问之后。** 这些材料支持“表示层修复”的解释，但不能仅凭哈希独立证明全部历史访问，也不能仅因出现修订就认定违规。请据代码差异、访问范围、时间顺序及科学字段是否变化审查。

相关文件：`amend_score_key_fix.py`、`implementation_before_fix01/`、两份冻结及各自 `.sha256`、`CONTRACT.json`。它们均在 `revision/post_20260926/p191_confirmation_v1/`。

`PARTIAL_PRIMARY_DESCRIPTIVE.json` 是较早的空状态文件：manifest 全 missing、descriptive 为空、没有正式推断。后续 raw 检查点已有部分人员完成，但截至上述观察时未见完整八人最终确认汇总。**空旧状态不代表没有开始；部分检查点也不代表完整确认成功。** 本包不复制持续写入的新确认 raw 检查点。

### 6.2 任务验证已继续推进

新任务流程有旧人群训练、模型选择、个体校准和 test-phase 评价等不同阶段。旧 pooled 模型未达门槛的失败保留；后续固定工作点达到所设 DEV 门槛。校准、模型和任务评价有各自冻结记录。

新人 train phase 按固定程序用于个体校准，test phase 另行评价。这比稿件中的早期概述更具体；应说明 task pipeline 的访问条件，而非把它误写成纯旧人模型直接零样本测试。

本包提供训练协议、模型选择和冻结摘要及代码，不提供模型权重或原始波形。任务部分在交接观察时仍只有部分 test-block 执行状态，没有完整效用汇总。冻结时 `new_test_predictions=0` 是该时刻的声明，不代表后续从未开始测试。

### 6.3 更近角度与现代载体

- 更近角度扫描是旧 DEV 两人的诊断：`.003125` 和 `.00625` 仍观察到接受。不能宣称任意接近身份都可拒绝。
- 现代载体已有真实训练和有限码本 owner-adapted 证据，及共同接收接口 DEV 记录；它们不是原生 RPW-EEG 全协议、全数据和所有预算下的统一复现。
- 现代水印载体训练与下游 EEG 分类模型训练分别评价。请查实际协议、适配、消息分布和接收信息，不沿用旧报告“还没有新训练”的过时概括。

## 7. 请 Opus 重点回答的问题

请按问题重要性组织证据，不要求每项都增加实验。

1. **贡献定位。** 新读数与经典统计的实质关系是什么？除代数表达外，未知响应背景、近身份及实际 EDF 中是否形成足够清楚的新能力/机制？如果需要补最近工作，给原始论文和具体方法对照。
2. **机制可识别性。** 容量、响应配对、残差相减、归一分母、阈值政策分别解释多少收益？现有 2×2 支持哪些结论，最小还缺哪个因素对照？
3. **强基线与公平性。** 新读数是否仅优于未用压力校准的旧阈值？与压力感知简单规则相比，应如何同时衡量覆盖、误归属、两种近码接受、计算成本和观察预算？
4. **身份与威胁模型。** 合法码最小间距、严格独立近码、受损副本三类定义是否一致？QIM chip、相位角和现代原生消息家族应怎样分表，哪些不能直接横比？
5. **确认与修订。** 对原冻结、FIX01、旧设计稿及模型/任务冻结逐项核对。指出已证实的变化、仅由运行记录支持的历史声明、真正可能改变科学结论的事项；不要预设有或没有违规。
6. **任务效用。** 当前任务训练和个体校准访问是否说清？同一波形/网格/人员上的联合归属与任务端点是否足以支撑目标主张？概率稳定性、分类性能与临床意义分别解释。
7. **统计与外推。** 以人员为单位，正确处理共享错源、处理和身份重复。有限零接受、经验最大阈值、代数抵消与总体风险保证有什么区别？只针对实际声称的范围要求证据。
8. **写作与投稿竞争力。** 哪条贡献应进入标题、摘要和主图？哪些旧批评已经不适用于 P191？如果要增强面向 CCF-B 的竞争力，最多列三项真正改变判断的工作，不给虚构录用概率。

## 8. 建议的输出格式与工作方式

输出中文，建议依次给出：

1. 一段对当前贡献和证据状态的判断。
2. “主张—证据—状态”表，区分已支持、部分支持、尚待验证。
3. 最重要的 5–8 个问题，每项附文件路径、PDF 页码或代码位置、影响和最小处理方式。
4. 最近工作的重合/差异表。确称“已做过”的判断必须有原始全文依据；只看笔记或摘要就明确说明。
5. 最小下一轮工作流：先做什么、验证什么、何时停止这轮检查、什么结果会改变方向。
6. 给导师的 3–5 个方向问题。

工作原则：已通过且没有相关变更的核对直接继承；把新增检查对应到具体未解决问题。允许提出有风险但可检验的新技术假设，用小实验区分。局部负结果按其条件解释，不自动否定整条路线。冻结确认的部分成绩不用于当前版本事后选阈值或换主方案。

本轮请求是审查和建议；默认不改论文、不运行训练、不重新处理 EEG、不发布仓库或代为投稿。

## 9. 保存证据的轻量核对

在包根目录使用 Python 3.9+：

```bash
python verify_manifest.py
python verify_evidence.py
```

两者仅使用标准库。`verify_manifest.py` 检查本包清单中的字节；`verify_evidence.py` 从保存充分统计量重算 DEV 的四格计数、相关代数和 P190 汇总一致性。运行输出范例保存于 `verification/`。

这属于 saved-evidence 核对，不是原始 EEG → EDF → 拟合 → 分数的独立复现。包内原研究脚本保留了部分 E 盘绝对路径、历史依赖和未随包复制的资产。**不要把原 `freeze_science.py`、`run_experiment.py`、训练或收集脚本当作可直接运行的入口。** 它们提供实现审查上下文。

原 `reproduce_development.py` 会写回 `DEVELOPMENT_REPRODUCED.json`；审查时优先使用根目录的只读检查器。完整实验复现需要原始数据、运行环境、模型和完整依赖，超出本次交接包范围。

`MANIFEST.json`、`docs/SOURCE_PROVENANCE.json` 和 ZIP 外部 `.sha256` 用于记录版本与完整性；它们不等同于可信第三方时间戳，也不自行证明某项结果事前未被查看。

## 10. 既有审查及文献入口

二轮参考目录：[旧 P190 审查](../output/reviews/idea_review_20261104_p190/)。优先看 `manuscript_findings.json`、`calibration_comparison.json` 和 `10_chair.json`。

这些评审来自 Codex 同厂商独立会话，未完成异厂商审查。旧报告中的 P191 状态观察早于本次交接，当前状态以第 6 节及 `docs/STATUS_AT_HANDOFF.md` 为准。

旧 P190 的“关键 G/b/d 等定义不完整”“实际 δ 未展示”等意见应按版本核对：P191 已给新读数的 G/b/d 公式，且研究中心已有变化，不能把每条旧意见原样复制为新稿缺陷。

原始文献入口、阅读范围和未完成全文核对的项目见 [REFERENCE_LINKS.md](../docs/REFERENCE_LINKS.md)。文献笔记不等于 Opus 自己读过全文。本包不重新分发外部论文 PDF，保留书目、原始链接和带页码笔记。

## 11. 文件布局与刻意未包含的材料

```text
README.md                         本交接说明
REVIEW_REQUEST.md                 可直接交给 Opus 的审查请求
MANIFEST.json                     本包文件、大小、SHA-256
verify_manifest.py                包完整性检查
verify_evidence.py                只读保存证据核对
docs/                             状态快照、来源、复现范围、文献入口
output/paper/...p191_dev_v1/       当前开发稿、源文件、图、16份评分文件
output/paper/...p190_overview_v2/  已完成基线稿件及源文件
output/reviews/...p190/            旧模型审查，仅二轮参考
revision/post_20260926/...         选定协议、冻结、结果摘要及代码上下文
evidence_archives/                P190完整保存JSON的无损gzip
verification/                     本次便携检查的输出
```

完整列表和大小见 [FILE_INDEX.md](../FILE_INDEX.md)。原项目相对路径尽量保留，便于交叉引用。部分原收据仍含历史机器路径，它们是来源记录，不是包内运行路径。

没有包含：原始 EEG/EDF/MAT、持续写入的确认 raw、模型权重和 joblib、环境目录、浏览器缓存、密钥文件、整个第三方仓库、外部论文 PDF。这是审查与保存证据包，不是训练数据集或完整实验环境。

## 12. 上传 GitHub / 交给 Opus

当前没有指定目标仓库，也未发现项目根的 GitHub remote，因此本次交付为本地上传包，没有自动公开发布。

GitHub 使用方式：

1. 新建用于审查的仓库，按你的需要选择可见性；未公开稿件可先用私有仓库。
2. 解压 ZIP，将**解压目录内的文件和子目录**放到仓库根目录，让 README 自动显示。只上传 ZIP 时，部分审查工具无法直接浏览内部 Markdown 和代码。
3. 若使用 Git，先进入解压目录，再按下例替换仓库地址执行：

```bash
git init
git add .
git commit -m "Add EEG paper review handoff snapshot"
git branch -M main
git remote add origin https://github.com/YOUR_ACCOUNT/YOUR_REVIEW_REPO.git
git push -u origin main
```

4. 将仓库地址与 `REVIEW_REQUEST.md` 交给你使用的 Opus 5.5 工具，并确认该工具可以访问该仓库。
5. 如果直接在聊天中传文件，可上传本 ZIP，并让它先读取本 README、P191 `manuscript.md` 和 `technical_appendix.md`；PDF 用于核查图表与实际页码。

后续实验完成后，应另建新的交接快照，明确新增结果和版本差异。保留本包，便于判断审查建议依据的是哪一版材料。
