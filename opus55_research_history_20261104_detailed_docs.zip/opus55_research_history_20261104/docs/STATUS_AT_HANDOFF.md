# P191状态事实（有限只读核查）

观察窗口：2026-11-04T13:28:52.814219+00:00 至 2026-11-04T13:28:54.762719+00:00。时间均为UTC；北京时间加8小时。源目录仍可能更新。

- 正文与技术附录于2026-11-04 11:58:02 UTC更新，明确是P191开发稿；96/96等是已观察人群的DEV证据，不是OpenBMI017–024的新确认结果。

- CLAIM_EVIDENCE_MAP与CONFIRMATION_DESIGN_DRAFT于12:05:58 UTC更新，仍将新确认与任务效用列为未来；其时间早于12:32确认冻结及后续实现修订，不能用旧设计稿代表外部最新状态。

- 原CONFIRMATION_FREEZE创建于12:32:05 UTC；FIX01修订创建于12:47:03 UTC，原文件保留。FIX01顶层status及created_utc沿用原冻结值，应查看implementation_amendment.created_utc辨认修订时点。

- FIX01声明17/18已进行发行与首查询拟合，首个决策保存前因ridge键float/string不一致抛出KeyError；记录称无确认决策被保存或查看。它发生于信号访问后，不能写成完全未接触新信号的首次冻结。

- 静态核对显示两处修订各只增加3行ridge键转字符串；原/修订冻结的端点、成功标准、统计、身份政策和任务约束相等，contract/modern除文件哈希外的字段相等。修订记录载DEV源OpenBMI001的972项决策等价比较。该检查支持表示层修复的解释，不足以独立证明所有历史访问；不据此自动认定违规。

- PARTIAL_PRIMARY_DESCRIPTIVE于12:43:54 UTC生成，48项manifest全部missing，descriptive及逐人向量为空，formal_inference_performed=false；它是无可用结果的旧部分状态文件，不是新确认性能证据。

- 观察时已存在OpenBMI017/018的五经典臂及现代臂complete原始结果检查点，另有019/020的smooth running检查点；这仍是未完成8人全臂确认，未见最终确认汇总。

- 任务研发保留多次旧人群失败：pooled CSP/EEGNet BA .575/.5825均未达.60；RMS仅CSP达门槛；后续旧DEV固定全局工作点为CSP4 BA .63及warmstart EEGNet25 BA .60。这些是模型能力开发证据。

- 任务流程于12:39校准冻结、12:42全8人模型冻结、12:53评估冻结；新人的train phase用于按固定80/20程序个体校准，test phase另评估。因此任务方案已从稿件概述的纯旧人训练推进为冻结的个体校准方案；尚不能宣称新任务效用已最终确认。

- 任务联合评估已有017的部分test-phase block检查点；冻结文件中new_test_predictions=0是冻结当时的声明，不能据其否认后续测试已经开始。

- 角度边界pilot于12:44:08 UTC完成，只有旧DEV OpenBMI005/012两人；.003125与.00625均观察到257 exact接受，.0125及更大扫描角全拒绝。它支持有限网格边界诊断，不支持任意接近身份都拒绝或新确认泛化。

逐文件原路径、更新时间、SHA-256、结果检查点及建议打包清单见 `handoff_status.json` 和 `handoff_status_file_list.json`。本次只记录状态，没有运行训练、推断或最终性能分析。
