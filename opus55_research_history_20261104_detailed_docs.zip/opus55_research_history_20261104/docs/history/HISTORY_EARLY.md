# 早期研究历史：SAW → 轻量 Haar/QIM → 必要性审查

整理日期：2026-11-04。源根目录：`E:/python/数字水印/`。本文覆盖旧 SAW、2026-09 的 V2 与轻量化，以及 2026-09-26 至 2026-10-03 的 p2–p5；仅在结尾引用 10-04 决策说明分支交接。本次只读既有资料，未运行实验、训练、下载或重算性能；只在本交接目录写入报告与结构化索引。以下路径均相对项目根目录。

## 1. 对新负责人最有用的历史结论

这段历史形成了三次实质转向。第一，旧 SAW 的“零误码、自校准、半脆弱来源验证”经实现和统计审计，收敛为有明确失败分母的 DWT–SVD/QIM 变体。第二，小规模机制实验支持去掉 SVD；极值与排名漂移又促使接收合同改为认证尺度和认证通道索引，最终形成固定 `Q=0.5` 的 Haar 四系数 block-DC QIM。第三，整数存储、局部 QC 和任务链已经能稳定工作，但同预算对照、跨采样率确认及强无水印对照揭示：工程可行性尚未转化为独占方法优势或嵌入必要性。这个缺口推动后续研究转向差异副本的接收方归因。

旧 README 的 Main 208,493 trial、BER≈0 以及“半脆弱 3.0×”是旧实现的历史运行记录。它们的算法、载荷、统计处理和基线身份均不同于后来的正式接口，适合作为审计起点，不能作为当前冻结版本的 SOTA 证据。更大的试次数也不能替代受试者/完整记录层面的独立性。

## 2. 时间与命名的核定范围

| 时段 / 日期 | 可核定里程碑 | 主要证据 |
|---|---|---|
| 早期稿，具体日期未定位 | CogSci 匿名旧稿已使用 SAW、Haar/SVD 和 Zero-BER 校准叙事 | `papers/egg_watermark.pdf`；已有逐页文本 `tmp/heer_source_lookup_20261027/000_egg_watermark.txt` |
| 2026-06-04 | 旧 SAW 完整实验文档及 README 更新标记 | `README.md`；`revision/EXPERIMENT_DOCUMENTATION.md` |
| 2026-09-15 | 升级计划、V2 重跑和审计；同时保留失败候选 | `revision/PAPER_UPGRADE_AND_RERUN_PLAN.md`；`revision/rerun_v2/audit/RERUN_REPORT.md` |
| 2026-09-16 前后 | 220 trial 轻量 pilot 的二次复核；固定 Q、认证尺度、block-DC 等小规模机制研究 | `revision/lightweight_pilot_reviewfix2/RESULTS.md`；`revision/lightweight_qc_validation/FINAL_METHOD_DECISION.md` |
| 2026-09-17 | 214,779 trial 扩大验证，发现局部尾部与整数裁剪反例 | `revision/lightweight_qc_validation/EXPANDED_RESULTS_2026-09-17.md` |
| 2026-09-18 | 外部 146,096 有效窗确认，定位存储范围和通道异常问题 | `revision/lightweight_qc_validation/EXTERNAL_CONFIRMATION_RESULTS_2026-09-18.md` |
| 2026-09-24 | 范围保护/局部 QC 进入正式接口，86,589 窗独立工程确认 | `revision/lightweight_qc_validation/STORAGE_QC_INDEPENDENT_RESULTS_2026-09-24.md` |
| 2026-09-26 | 新题目、正式接口与回顾性强任务协议冻结 | `revision/NEW_TITLE_EXPERIMENT_DESIGN_2026-09-26.md`；`revision/post_20260926/P0_PROTOCOL_FREEZE.md` |
| 2026-09-27～10-01 | p2 身份/核心适配审计，p3 存储/证书/资源，p4 选道/投影/预筛消融 | 下文分支记录 |
| 2026-10-02 | 外部 SPL 评估及技术复核；方向和 Q 联动研究 | `revision/EVAL_REPORT_SPL_DIRECTION_2026-10-02.md`；对应 `revision/EVAL_REPORT_SPL_DIRECTION_TECHNICAL_AUDIT_2026-10-02.md`；`revision/post_20260926/P4_JOINT_EXPANSION_DECISION_2026-10-02.md` |
| 2026-10-03 | 160 Hz 新受试者确认、三法第二队列、p5 必要性审查 | `revision/post_20260926/P4_EEGMMIDB_UNSEEN_DECISION_2026-10-03.md`；`revision/post_20260926/p2_eegmmidb_second_external_v1/RESULTS.md`；`revision/post_20260926/P5_NECESSITY_DECISION_2026-10-03.md` |
| 2026-10-04，交接边界 | 接收方指纹分支明确保留旧方法为独立历史分支 | `revision/post_20260926/P6_DECISION_2026-10-04.md` |

用户所指“5 月起点”在本次优先资料中没有定位到明确日期的原始研究记录。本文保留早期稿机制，以 6 月 4 日为最早可直接核定的文档日期，不按文件修改时间补造 5 月进程，也不补造 P0–P191 连续编号时间线。

**SAW 有两种英文展开。** 旧 PDF 正文为 **Signal-Aware Adaptive Watermarking**，准确题名为 *Self-Calibrating Cognitive Data Provenance: A Quality-Adaptive, Tamper-Evident Framework for Trusted BCI Clinical Workflows*；README 写 **Self-Calibrating Adaptive Watermarking**。两者共同指向本项目早期 SVD/自校准路线，但命名分歧应保留。**HEER 尚未定位到原文、展开或方法定义**。既有定位记录 `tmp/heer_source_lookup_20261027/SEARCH_FINDINGS.md` 与 `tmp/heer_source_lookup_20261027/HAAR_ROUTE_TRACE.md` 支持“找到 Haar/QIM 路线”，不支持把 HEER 自动等同 SAW 或正式 Haar 方法。

## 3. 旧 SAW：大规模结果先出现，合同与实现随后被审计

### 目标与实际方法

旧稿试图给 EEG 附加“数字护照”，以逐 trial 自校准达到 clean 零误码，并通过良性处理与片段替换的 BER 差异主张半脆弱完整性告警。旧文档实现为通道×时间二维单层 Haar `dwt2`、LL 子带 2×2 块 SVD、最大奇异值 QIM；`Q` 从 1 开始按 1.5 倍增长，上限 5000、最多 50 轮。载荷约 208 bit，包含 device/source ID、时间、截断哈希及 Logistic 序列处理。

旧 PDF 还声称 LL3/0–4 Hz、闭式 SVD、O(1)、83 被试、96.49 dB PSNR 和“Verify or Reject”。9 月升级计划逐项指出这些表述与现有单层实现、算法成本、认证对象及实验口径不一致，因此这些旧稿句子应作为待撤回/核验的历史主张保存。

### 历史结果与分母

`revision/EXPERIMENT_DOCUMENTATION.md` 报告 Main 30 人、208,493 trial：PSNR 65.68 dB、PRD 7.58%、平均 BER 约 0.000005；BCI 7,128 trial、BER 0.000155；ERP CORE 1 人 400 trial；PhysioNet 一处列 900 trial，README 又列 2,700 trial，存在分母不一致。Consumer 14 通道失败/容量解释也需回看真实 loader 与块计数，旧文档自己的“218 块足够/不足 208 bit”叙述不自洽。旧攻击把 BER 阈值和恶意/良性 BER 比作为分类依据，不能据该比值建立正式检测 ROC 或通用半脆弱性。

旧表的 RPW-EEG 实为本地 DWT–SVD 固定 Q 代理，HiDDeN-like 为随机权重诊断，Spread-LSB/FFT-Phase 使用原信号参考。文档末的 2026-09-26 身份警示已明确旧表不进入新 SOTA 主比较。原论文与 6 月文档中的数据队列、单位及结果还不相同；它们应分版本保存。

**可复用资产：** 原始数据/loader、旧 SAW 代码和检查点、攻击实现及审计反例。用途是复现错误与解释研究起点，不能直接继承其优越性结论。

## 4. 9 月 V2：建立事实表与失败分母

### 改了什么

2026-09-15 升级将二维 DWT 改为逐通道时间 DWT，统一 floor 判决，修复 MAX_Q 后“旧候选+新 Q”的返回错配，显式记录失败/容量，生成逐 trial 认证载荷，并把异常、BER=1、SSIM 错误、受试者级统计、真实 PSD/计时纳入审计。V2 同时改变了变换轴和载荷，是新算法变体；旧/新均值差不具有单一 bug 的因果解释。

### 已运行结果

| 数据 | clean trial | 嵌入/校准失败 | 平均 BER | 作用域 |
|---|---:|---:|---:|---|
| Main | 208,493 | 137 | 0.00030277 | 该 V2 全量事实表 |
| BCI | 2,592 | 1 | 0.00019290 | 9 个 T 训练文件，四类 cue |
| Consumer | 2,884 | 0 | 0 | 文件身份可核，人员对应未独立核实 |
| PhysioNet | 450 | 0 | 0 | 10 人的已缓存数据 |

405 个来源 trial 产生 26,730 条攻击记录；确定性滤波重复、pilot 重叠和 Consumer 人员分组使其保持探索性。结果不支持通用半脆弱检测。ERP 无可用数据；真实 RPW/WPT-SVD/训练神经基线未完成。

旧下游分析排除了 12 个失败样本，inclusive 审计保留了 16,012 个平衡抽样 trial 和失败候选。受试者分组、时间统计特征+逻辑回归下，BA 均值从 0.854835 到 0.854684，差 −0.000151，受试者 bootstrap 95% CI [−0.000486, 0.000222]；AUC 差 −0.000574。该抽样阳性约 50%，不是自然 RSVP 约 5% 的 PR-AUC。载荷 HMAC 尚未绑定 Q/归一化元数据，也没有接收端重算整段 EEG 的内容认证闭环。

120 个相同真实 trial 的匹配消融区分了实现因素：1D_floor 和 2D_floor 均零失败、平均 PSNR 79.6840/79.5162 dB；2D_round 64.4263 dB；固定 Q=1 的 1D 有 22/120 提取失败。主要保真改善来自判决修复，1D/2D 在这批数据上的均值差较小。此固定 Q 尚未经过验证集调优。

**源：** `revision/rerun_v2/audit/RERUN_REPORT.md`、`revision/rerun_v2/RUN_STATUS.md`、`revision/PAPER_UPGRADE_AND_RERUN_PLAN.md`、`revision/matched_ablation_v2.py`。逐 trial CSV、inclusive 折外预测和 subject bootstrap 是后续核对入口。

## 5. 轻量化：先删复杂度，再修接收合同

### 220 trial pilot 的决策依据

`revision/LIGHTWEIGHT_PILOT_CLAUDE_TASK.md` 是任务协议，实际二次复核结果在 `revision/lightweight_pilot_reviewfix2/RESULTS.md`。原约定 `revision/lightweight_pilot/` 当前未找到，引用 manifest 时应以保留下来的 reviewfix2 目录核对。

固定 220 trial、validation/test 各 110；八点 Q 网格 `{0.5,1,2,4,8,16,32,64}` 的可部署 first-success selector 在 test 上，SVD 和 direct DWT 都恢复 110/110，但恢复且 PRD≤1% 分别 107/110、109/110，最坏 PRD 5.863%/1.674%。direct 加 1% 门控接受 109/110，接受部分最坏 0.429%。这说明去 SVD 和受控拒发有价值；拒发的 1 个样本保留在覆盖率分母。

纠正后的桌面计时：嵌入 SVD/direct 为 2.646/0.357 ms，独立提取 1.178/0.253 ms；先前提取“7.2×”因为计入嵌入而撤回。40/220 的低 Q SVD 候选在独立 min/max 解码失败，却全部在原尺度解码恢复，将归一化漂移确定为优先机制风险。偶数、正交 Haar、无裁剪下能量恒等；奇数截断为收缩界，不能直接复用等式。

### 动态映射失败 → 认证尺度

第一轮固定测试 110 trial：独立 min/max 的 nearest 只有 90% clean 精确恢复。极值/排名保护 k=1 达 99.1%；看过该失败后追加 k=16 达 100%，因此属于探索修正。独立 170 trial 的 k16 确认仍失败 1 条（PhysioNet 39/40，总体 169/170），映射保持也仅 99.4%，暂停第二阶段。

随后将已见 220+170 合成 390 个机制开发 trial，以两个 float32 原始 min/max 共 8 B 认证侧信息解决接收端尺度；另 140 个零 trial-ID 重叠确认 clean/float32/q16 全通过，最大 PRD 0.0621%。尺度加入现有 64-bit HMAC 认证，载荷仍 208 bit。这个接收合同保留原样本免参考、增加显式旁信息，应按 semi-blind 描述。

### 单系数 → 四系数 block-DC

正式载体由四个连续 cA 系数 `a` 和单位向量 `u=[.5,.5,.5,.5]` 构成；投影 `p=uᵀa` 最近同位 QIM 后回写 `a′=a+(p′−p)u`。合法中心是 `{(2k+b+0.5)Q}`；同位中心间距 `2Q`，最大嵌入位移可达 Q，提取判决半步为 Q/2。正式 Q=.5，不再使用 SVD 或逐 trial Q 迭代。

另 140 个新 trial ID 的 block-DC 确认 clean/float32/q16 全通过、最大 PRD 0.0552%；gamma 跨 trial P95 0.2804 dB。相较开发单系数的 2.2866 dB，block-DC 开发为 0.3688 dB。早期解析门控 1,120 个 trial-Q 决策中接受800/拒绝320，和后验门控一致，少做 320 次 IDWT；这是包含高 Q 拒绝候选的门控试验。

**源：** `revision/lightweight_qc_validation/RESULTS.md`、`revision/lightweight_qc_validation/confirmation/RESULTS.md`、`revision/lightweight_qc_validation/scale_development/RESULTS.md`、`revision/lightweight_qc_validation/scale_confirmation/RESULTS.md`、`revision/lightweight_qc_validation/blockdc_confirmation/RESULTS.md`、`revision/lightweight_qc_validation/phase2_qc/RESULTS.md`、`revision/lightweight_qc_validation/FINAL_METHOD_DECISION.md`；实际 `revision/lightweight_qc_validation/methods.py` 可核量化、尺度与映射定义。

## 6. 扩大规模：存储范围和局部 QC 成为正式研究对象

9 月 17 日，Main 208,493、BCI 2,592、Consumer 2,884、PhysioNet 810，共 214,779 trial 的 clean/float32 全恢复。q16/q24 各有同一 BCI trial 失败；它的 572 个水印后样本越过原始认证量程，仅饱和就可复制相同 8/208 错位，水印后范围可恢复。q12 4,978/214,779 失败。global PRD 全低于1%，却有 Main/Consumer 最坏单通道 4.650%/5.492%，Main gamma P95 0.552 dB。这些反例推动按通道分配和局部 QC，而不是继续扩大原版本。

9 月 18 日，EEGMAT 4,338、LTRSVP 10,601、SleepEDF20 55,334、CHBMIT3 75,823，共 146,096 **有效窗**，另有 1 个输入 QC 拒绝。clean/float32 全恢复；原始量程 q16/q24 各 242 个失败，均落在裁剪窗，向外保护水印后范围后这 242/242 均恢复。q12 合并恢复90.9306%，并有3,224个未裁剪失败，不能用范围保护解决。global PRD 最大0.19044%，局部 PRD>1%却有366窗，显示 global 门槛掩盖异常通道。

9 月 24 日将规则和队列冻结：输入 RMS 失衡比≤100、最小通道 AC RMS/中位 AC RMS≥.01；输出 global/max-channel PRD 各≤1%，原信号范数作分母。选择原始能量高的半数通道，容量不足时增加，通道索引认证后传给接收端，避免接收时重排序。`revision/lightweight_qc_validation/storage.py` 以水印后极值的 float32 向外舍入界保存 q16/q24，13 B 是存储版本/位深/范围头，与认证的原始尺度/选道元数据分开。

新的 Sleep-EDF 第21–40个 PSG 20文件54,850窗、CHB-MIT chb02 36文件31,739窗，共56个官方哈希核验文件、86,589窗。near-flatline 拒1；86,588接受窗 clean/float32/q16/q24 精确208位恢复和载荷认证均86,588/86,588，零裁剪/处理错误。这个队列支持冻结接口的工程可靠性；9月18队列已经用于制定异常规则，保留为开发资料。两者不可相加为同一独立确认。

## 7. 9/26 后：强任务、p2 真实对照与 p3 成本账本

### 任务链补强

9/26 正式工作题目改为《面向资源受限 EEG 数据处理的轻量 可分析水印方法》；“可分析”落在误差、门控和存储成本。P0 将既有 Main S1–S30、BCI A01–A09、PhysioNet S1–S18 标成已见。BCI E 是新会话同受试者，不能称新独立人群。

`revision/post_20260926/P1_COMBINED_RESULTS_2026-09-26.md`：CSP+LDA 与 EEGNet 分别测试同一2,592个 BCI E trial；RSVP 从原始70,000剔除347个行为反应错误目标后，69,653有效trial，目标2,824（4.0544%）。全部通过正式QC和存储恢复。受试者等权 BA 原始→q16：CSP .637731→.637731（翻1/2592），EEGNet .552083→.551698（翻1），RSVP .835623→.835433（翻5/69653，4对→错、1错→对）。这是回顾性固定解码器敏感性证据；弱个体模型、概率尾部和数据已见状态一并保留。

### p2：审计身份比凑 SOTA 行数更关键

1. `revision/post_20260926/P2_RPW_SOURCE_AUDIT.md` 核对作者固定提交 `a029a5c...` 及全文：缺 metrics、卷积通道/输入shape不符、Trainer配置和训练目标不一致，且原生30bit、论文两阶段任务微调尚无可执行闭环。修补微试验仅8个A01T片段、150步，训练位准确率96.25%，PRD18.67%，没有1%预算内可比点。此项当时不能进入SOTA主表。
2. `revision/post_20260926/P2_PHAM_2017_CORE_AUDIT_2026-10-01.md` 对应 **2017 AJIS** *Ownership Protection of Outsourced Biomedical Time Series Data Based on Optimal Watermarking Scheme in Data Mining*，区别于2015 ICONIP DWT-SVD和2017 ICONIP任务影响论文。二级Haar/SVD/dither-QIM的公式经量纲和相位解释修复；省略Arnold/PSO，固定Δ=.5，适配208bit和8B共享尺度。这是受限文献核心适配。
3. 开发3,864窗中正式法与核心Δ=.5均恢复/认证；BCI最坏通道PRD .0885%/.0873%，RSVP .2782%/.8701%。正式法局部优势依数据而异，不能单看极值宣称总体支配。回顾性任务在共同QC集合比较；RSVP核心有26/3000拒绝，但这些窗仍精确提取，恢复分母和QC分母必须分开。
4. 三法跨数据集表及新12人S031–S042第二批：正式、标量、核心均540/540通过clean/q16/q24和QC；受试者中位的8–30Hz PRD为 .053475/.068216/.025503%，max-channel为 .060013/.060653/.098001%。8名原始BA≥.55者中核心概率P95较正式低8/8，正式较标量低7/8。正式/核心/标量形成频带、局部质量、成本权衡。
5. S031同20窗×每臂6次配对：embed正式/标量/核心 .2077/.1169/.3704ms；q16全链 .4468/.2660/.6703ms。结论针对本机这三个实现；早先相对历史逐块SVD的21–40倍不适用于该核心适配。

主要源：`revision/post_20260926/p2_pham2017_dev_v1/RESULTS.md`、`revision/post_20260926/p2_pham2017_task_v1/RESULTS.md`、`revision/post_20260926/p2_cross_dataset_comparison_v1/RESULTS.md`、`revision/post_20260926/p2_eegmmidb_second_external_v1/RESULTS.md`、`revision/post_20260926/p2_second_external_resource_v1/RESULTS.md`、`revision/post_20260926/P2_EEG_BASELINE_FEASIBILITY_UPDATE_2026-10-03.md`。

### p3：解析关系、整数证书与资源各有明确对象

- 72,245个不同任务窗（BCI2592+RSVP69653；两个BCI解码器不重复计窗）验证嵌入解析PRD，最大残差5.402e−15/1.590e−14个百分点。它是嵌入误差恒等式；后续量化总误差单列。
- q16总PRD最坏BCI .04902799%、RSVP .08616824%；72,245接受窗各存储条件均恢复/认证，平方误差分解无超容差残差。量化增量与嵌入PRD有交叉项，不能直接相加。
- 256个已用开发窗×4个Q×2位深=2,048条件记录。Q=.5两位深均256/256证书及恢复通过；Q=.03125/q16证书0/256而实际254/256完整恢复；Q=.015625/q16完整恢复0/256、q24为256/256。证书是保守充分条件。
- 逐bit存储扰动界是 `sqrt(2)*1000*h/D < Q/2`，适用于偶数长度、一级Haar、独立四系数块、无裁剪及无后处理的理想实数运算。10/2独立评估曾误把所有载体累积到同一bit，提出“13倍低估”；技术复核给出每bit仅8个样本的证明并用对抗测试核查，撤销这项反驳。浮点实现仍需舍入裕量，数值核查不等于形式化证明。
- 整接口计时BCI1.501ms、RSVP2.966ms，包含四种存储恢复、QC、载荷/HMAC；纯embed分阶段为.2541/.4680ms。RSS是含解释器/loader的进程值，Main峰值受MAT加载影响；全部属于桌面软件指标。字节账本中208bit已经在样本内，不能再加26B；q16/q24为替代格式。

源：`revision/post_20260926/p3_analytic_v1/RESULTS.md`、`revision/post_20260926/p3_storage_v1/RESULTS.md`、`revision/post_20260926/p3_certificate_v1/RESULTS.md`、`revision/post_20260926/p3_resource_v1/RESULTS.md`、`revision/post_20260926/p3_stage_timing_v1/RESULTS.md`、`revision/post_20260926/P2_BYTE_LEDGER_2026-10-03.md`、`revision/EVAL_REPORT_SPL_DIRECTION_TECHNICAL_AUDIT_2026-10-02.md`。

## 8. p4：模块优势逐步被限定，候选收益未跨采样率复制

**选道依赖数据。** 开发BCI864/RSVP3000窗：top-energy半通道max-channel PRD中位.03825%/.03626%；全通道为.03302%/.06485%。两队列方向相反。各长度连续布局不同，随后同208起点控制的L1/2/4/8试验才分离投影形状；L8的13–30Hz误差逐窗低于L4，但正式容量约减半（BCI1023→506bit，RSVP992→480bit）。小任务子集四组均零类别翻转，只能判读概率敏感性和容量折中。

**预筛能少做拒绝候选的IDWT，正常Q=.5无常态加速。** `revision/post_20260926/p4_prescreen_v2/RESULTS.md` 的40个正常窗两路均重建40次，配对耗时跨零；高Q=32/128的80条件窗全拒，预筛跳过79次IDWT，其中1个global预筛通过后被局部QC拒绝。预筛未默认接入正式链。

**固定Q的多频带约束触发停止。** 4维Haar单块、250Hz、8192点离散Gram的65个起点，没有找到在其他频带不增时将8–30Hz降低≥1%的非平凡方向；只是该离散单块问题的数值证据。只压8–30Hz的beta-only在开发窗把该频段PRD降至约.12倍，却将30–45/45–90Hz抬至2.3/4倍。

**Q与方向联动找到质量点，但大部分收益来自减Q。** 预定Q=.0625候选与同Q均匀、正式Q=.5，在19名已见受试者12,592窗全部QC/q16/208位/HMAC/证书通过。新方向对同Q均匀8–30Hz PRD比约.124（BCI）/.118（RSVP），高频代价约2.35/4.1倍；同Q均匀相对正式本身已将各带降到约.125。候选概率变化P95在19/19人低于同Q均匀，绝对变化小、类别分数缺乏分辨力。q16后0.5h额外噪声正式200/200、同Q185/200、候选191/200；1h时正式200/200而两小Q组0/200。零噪声都成功。候选的质量与裕量形成真实权衡，正式方法保留。

**160Hz独立确认否定稳定任务优势。** S019–S030下载前冻结方向/Q，12人×45事件=540窗，三臂信号/QC/q16/q24均成功。相同Q下候选8–30Hz比从250Hz约.12退到.759，30–45Hz代价约4.975倍；每人run4+8训练30窗、run12测试15窗，共180任务事件，三臂0翻转。在6名原始BA≥.55者，候选概率P95仅2/6低于同Q，受试者中位比1.074。于是停止把该方向升级为正式方法。任务脚本v1在训练前因MNE CSP不接受verbose退出，v2只删除该参数，数据/模型/评价不变；失败痕迹保留。

独立SPL评估对原创性和真实基线缺口的总体批评仍有效；它的证书反驳、QIM最大位移和Pham文献归属已经技术复核修正。评估中“最小特征向量即可解决联合问题”“降一个量级”等是建议/假设，不能转写为已完成结果。

源：`revision/post_20260926/p4_channel_projection_v1/RESULTS.md`、`revision/post_20260926/p4_matched_anchor_v1/RESULTS.md`、`revision/post_20260926/p4_matched_task_v1/RESULTS.md`、`revision/post_20260926/P4_METHOD_DIRECTION_DECISION_2026-10-01.md`、`revision/post_20260926/p4_spectral_projection_v1/RESULTS.md`、`revision/post_20260926/P4_JOINT_MECHANISM_DECISION_2026-10-02.md`、`revision/post_20260926/P4_JOINT_EXPANSION_DECISION_2026-10-02.md`、`revision/post_20260926/p4_joint_resource_v1/RESULTS.md`、`revision/post_20260926/p4_joint_perturbation_v1/RESULTS.md`、`revision/post_20260926/P4_EEGMMIDB_UNSEEN_DECISION_2026-10-03.md`。

## 9. p5：水印必要性与完整性合同成为转向原因

10/3以已见S031–S042每人5窗共60窗，先冻结15条件机制协议，再明确标记事后强对照：外置HMAC绑定最终q16回读的全部信号及shape/通道序/采样率/ID；可信内容登记表作来源查找；原q16刻度规范化让float32/q24转存重建原整数码后认证。

正常q16、改名、无损NPZ：水印、外置HMAC和登记均各60/60。直接float64 HMAC在数值转存失效，但更强的原刻度HMAC与登记在float32/q24也60/60，消除了当时水印对弱对照的表观优势。只丢外置来源而保留45B水印侧信息是条件不对称；全可选信息丢失时现水印也无法执行，可信登记对未变信号仍可查找。

结构反例更关键：未选通道反号、或选定Haar载体样本对等量加减，都能水印载荷认证60/60；后者重新q16后max-channel PRD .05638–.09056%，60/60仍过参考QC。外置内容HMAC和原刻度HMAC均拒绝。外部ID/采样率改动也不影响当前水印载荷认证。原因是HMAC绑定载荷/尺度/映射，验证器没有重算整个接收EEG的内容摘要；载体投影存在不读取的方向。QC与载荷认证联合，仍不等于完整EEG未改动。

因此当时结论为：正常归档/受控转存尚未证明必须嵌入；当前四系数方法的工作性仍成立，必要性与完整性主张收缩。45B提取元数据与原刻度方案保守39B也没有旁信息天然优势。原刻度方案自身的亚半格容忍、新颖性、登记库规模成本仍待研究。`revision/post_20260926/P6_DECISION_2026-10-04.md` 随后把旧方法保留独立分支，将新需求定义为授权接收方差异副本泄露归因；这是应用合同和载体问题的重建，不能把后续共同相位路线描述成原Haar公式逐步微调。

源：`revision/post_20260926/P5_NECESSITY_PROTOCOL_2026-10-03.md`、`revision/post_20260926/P5_GRID_CANONICAL_FOLLOWUP_PROTOCOL_2026-10-03.md`、`revision/post_20260926/p5_necessity_v1/RESULTS.md`、`revision/post_20260926/P5_NECESSITY_DECISION_2026-10-03.md`、`revision/post_20260926/run_p5_necessity.py`、`revision/post_20260926/run_p5_grid_canonical.py`（均位于`revision/post_20260926/`）。

## 10. 可复用资产与仍需核验

| 资产 | 复用方式 | 复用前核验 |
|---|---|---|
| `revision/saw_core.py`、`revision/saw_core_v2.py`、`rerun_v2/` | 历史失败/修复对照、事实表设计 | 原实现与版本/载荷绑定，旧基线改名 |
| `revision/lightweight_pilot_reviewfix2/` | 去SVD、Q网格、计时污染和归一化漂移反例 | 220清单与原pilot引用能否完全追回 |
| `revision/lightweight_qc_validation/{methods.py,qc.py,storage.py}` | 冻结Haar历史基线、元数据/HMAC和存储接口 | 历史PRD为原信号范数；不得混入后来AC分母预算 |
| 9/18与9/24外部清单及逐窗事实 | 区分开发异常与独立工程确认、范围保护回归样本 | 官方哈希、拒绝、有效分母和使用历史 |
| `revision/post_20260926/utility_common.py` 与P1模型/逐窗概率 | 固定任务评价及失败分母范式 | 已见组状态；CSP/EEGNet身份和模型哈希 |
| `revision/post_20260926/p3_certificate_v1/`及`revision/post_20260926/test_p3_certificate_adversarial.py` | 理想存储界、保守性、机器舍入研究 | 每bit支撑、适用域、真实容器范围与浮点裕量 |
| p2核心/标量三法及字节账本 | 内部经典对照和资源账本 | 核心适配身份；原生/适配合同；同轮计时 |
| p4同位点/频带矩阵/跨采样率/微扰负结果 | 新优化目标的反例和停止条件 | 数值单块结论不能升级普适定理 |
| p5强HMAC/登记/原刻度对照 | 新选题必要性基线与认证对象审查 | 容忍与攻击定义、在线登记成本和新颖性另查 |

待核验优先项：①5月原始时间锚点与HEER原文；②旧稿83被试/96.49dB与6月Main口径的来源差异；③旧PhysioNet900/2700和Consumer容量解释；④pilot原目录缺失、manifest和归档关系；⑤候选Q/投影版本是否真正绑定到互操作认证接口（p4当时尚未完成）；⑥接收元数据中的shape、采样率、ID/新鲜度及存储头如何绑定；⑦真正作者法/原生协议与当前预算下的完整公平复现；⑧硬件能耗/算法独占内存；⑨所有确认队列的已见状态。后续新选题应继承这些审计资产，重新定义其独立测试。

## 11. 能支撑新选题的三个遗留科学问题（以下均为推断）

1. **推断：把“可接受变换”与“必须拒绝的变化”统一为可执行认证等价类。** p5显示整数刻度规范化可以吸收受控精度转存，Haar载荷却允许投影零空间改动。问题是：在给定存储/采样/滤波合同下，如何定义既保留来源又绑定全部可观测内容的认证对象？可证伪终点是强无水印规范化认证在同信息/成本条件下是否已满足全部需求；若满足，嵌入的必要性被否定。
2. **推断：跨采样率、容量与整数裕量约束下的多频带扰动设计，能否存在超越简单减Q的收益？** p4在250Hz的方向效果到160Hz衰减，且同Q抬高非目标带。新问题应直接用连续物理频带、时域任务ROI、载荷容量、局部失真和实际存储裕量约束设计；以同Q均匀、标量、核心适配和减Q为强对照。若收益完全由Q缩小解释或转移到其他任务频段，则停止该机制。
3. **推断：在未来任务模型未知时，什么可测结构保持足以预测多任务效用，而又允许可归因的差异副本？** 早期global PRD、频谱摘要和零类别翻转均掩盖局部/概率变化；p5又说明认证投影的不可见方向很大。可把局部物理预算、时空统计保持与接收方可分性联立，比较模型未知方法和模型已知避让的差距；以多个强任务模型、事件/受试者层统计和同预算接收方读出为证伪条件。这里是对后续指纹方向的研究动机，不是该路线已经解决问题的结论。

与本文配套的 `history_early.json` 保存结构化里程碑和最多20个建议随交接包携带的原始小文件；完整逐窗大表与原始数据按路径保留，不复制进本段最小清单。
