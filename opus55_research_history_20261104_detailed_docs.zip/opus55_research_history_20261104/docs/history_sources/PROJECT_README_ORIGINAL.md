# 面向资源受限 EEG 数据处理的轻量 可分析水印方法

> 当前研究题目与投稿级实验工作流见 [2026-09-26 实验设计](revision/NEW_TITLE_EXPERIMENT_DESIGN_2026-09-26.md)。以下 SAW 目录说明和旧结果为历史项目记录，不代表当前冻结的 Haar block-DC/QIM 方法或真实 SOTA 复现。

> EEG 自校准水印 (Self-Calibrating Adaptive Watermarking)
> 最后更新：2026-06-04

## 目录结构

```
.
├── revision/                         # ★ 核心工作目录
│   ├── saw_core.py                   #   SAW 核心算法
│   ├── baselines.py                  #   5种基线模型
│   ├── baseline_dct_dual.py         #   DCT双域盲水印
│   ├── baseline_hidden.py           #   HiDDeN-like CNN
│   ├── attacks.py                    #   6种攻击实现
│   ├── metrics.py                    #   评估指标
│   ├── config.py                     #   参数配置
│   ├── dataset_loaders.py           #   多数据集加载器
│   ├── EXPERIMENT_DOCUMENTATION.md  #   ★ 完整实验文档
│   ├── PPT_Briefing_Doc.md          #   PPT制作说明
│   ├── output_full_all/             #   主数据集全量验证结果
│   ├── output_full_new_baselines/   #   DCT-Dual/HiDDeN全量结果
│   ├── output_multi_dataset/        #   跨数据集SAW结果
│   ├── output_cross_sota/           #   跨数据集SOTA+攻击对比
│   ├── output_full/                 #   200试次采样验证结果
│   └── output/                      #   合成数据快速验证
│
├── test/                             # 测试与核心数据
│   ├── 07_optimization_fix.py       #   核心技术确认版本
│   └── filtered_eeg_dataset.pkl    #   主数据集 (13GB)
│
├── datasets/                         # 外部数据集
│   ├── BCICIV_2a_gdf/               #   BCI Competition IV 2a
│   └── raw_eeg_data/                #   原始EEG数据 (.mat)
│
├── reference_docs/                   # 参考文档
│   ├── Paper_Revision_Plan.md       #   论文修改计划
│   └── ...                          #   数据集说明书等
│
├── papers/                           # 论文PDF
│   └── egg_watermark.pdf
│
├── data/                             # 行为学实验数据
├── EEG_data&Matlab_Script&ML_result/ # 原始EEG和ML结果
└── archive/                          # 历史文件 (18GB)
    ├── historical_scripts/
    ├── old_results/
    └── old_embeddings/
```

## 快速开始

```python
from revision.saw_core import generate_watermark, calibrate, extract_full
from revision.metrics import compute_psnr, compute_ssim, compute_prd, compute_ber

# 嵌入
payload = generate_watermark()
wm, q, ber, psnr = calibrate(eeg_signal, payload)

# 提取
extracted = extract_full(wm, len(payload), q)
```

## 关键结果

| 数据集 | 试次 | SAW_BER | 半脆弱边界 |
|--------|------|---------|-----------|
| Main | 208,493 | 0.0000 | 3.0x |
| BCI IV 2a | 7,128 | 0.0002 | 1.0x* |
| ERP CORE | 400 | 0.0000 | 2.9x |
| PhysioNet MI | 2,700 | 0.0000 | 1.9x |

> 详细结果见 [EXPERIMENT_DOCUMENTATION.md](revision/EXPERIMENT_DOCUMENTATION.md)
