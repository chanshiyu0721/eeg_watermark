# 原始文献与阅读范围

本包提供来源链接、书目及旧精读笔记，不重新分发外部论文PDF。审查者应自行区分“本次读了原文”“只读了笔记”和“仅有书目/摘要”。以下不是穷尽的 SOTA 清单；`references.bib` 含其他相关工作。

| 工作 | 原始入口 | 本包已有阅读记录 |
|---|---|---|
| Tong et al., Neyman–Pearson classification algorithms and NP receiver operating characteristics, 2018 | https://pmc.ncbi.nlm.nih.gov/articles/PMC5804623/ | `output/reviews/idea_review_20261104_p190/notes/L03.json`；包含独立校准条件与读取范围，未逐行核对额外补充证明 |
| Angelopoulos et al., Learn then Test, 2025 正式发表 | https://doi.org/10.1214/24-AOAS1998 ； https://arxiv.org/abs/2110.01052 | `notes/L04.json`；包中旧笔记依据已保存的全文版本，页码对应该PDF而非保证与出版排版相同 |
| Gulrajani and Lopez-Paz, In Search of Lost Domain Generalization | https://openreview.net/forum?id=lQdXeXDoWtI | `notes/L05.json`；选择程序与公平搜索预算；长文阅读范围在笔记中 |
| Sonoda et al., Blind detection of watermarks embedded by periodical phase shifts, 2004 | https://www.jstage.jst.go.jp/article/ast/25/1/25_1_103/_article/-char/en | `notes/P11.json`；共同相位和邻帧相位差的经典先例 |
| Efe, Network aware blind EEG data hiding using quantization index modulation, 2026 | https://link.springer.com/article/10.1007/s44354-026-00054-x | `notes/P10.json`；完整盲DCT–RS–QIM/ECC/CRC协议，区别项目QIM-ID适配 |
| Zhang et al., Robust EEG Watermark via Dual-Stream Frequency–Time Attention Network Against Signal Processing Attacks, 2026 | https://www.mdpi.com/2079-9292/15/13/2864 | `notes/P12.json`；原生32bit与任务实验，原文主张和边界均按笔记核实；不代表项目已完成原生复现 |
| Qin et al., RPW-EEG, 2025 | https://escholarship.org/uc/item/96h9c291 ； https://github.com/qintianyang/RPW-EEG | P190审查本轮下载返回403，未标成当轮全文精读；P191有另次原始论文与作者源码记录，请看下述矩阵并区分证据时点 |
| Golub and Pereyra, separable nonlinear least squares / variable projection | https://doi.org/10.1137/0710036 | 现稿已有引用；本包旧独立审查未提供该论文完整精读笔记，新的数学重合判断应另核原文 |
| Scharf and Friedlander, Matched Subspace Detectors | https://doi.org/10.1109/78.301849 | 现稿已有引用；新读数与经典检测几何的关系是Opus需核实的问题 |

P191原始来源、作者源码收据、现代载体适配差异见：

- [PRIMARY_SOURCES.json](../revision/post_20260926/p191_identity_v1/PRIMARY_SOURCES.json)
- [SOTA_PRIMARY_SOURCE_MATRIX.md](../revision/post_20260926/p191_identity_v1/SOTA_PRIMARY_SOURCE_MATRIX.md)
- 主稿 [references.bib](../output/paper/eeg_submission_p191_dev_v1/references.bib)

旧笔记默认目录前缀为 `output/reviews/idea_review_20261104_p190/`。其中论文编号是旧检索编号，不是新颖性排名。旧模型对外部论文的质量档位也应由新审查者按原文重新判断，不当作领域共识。
