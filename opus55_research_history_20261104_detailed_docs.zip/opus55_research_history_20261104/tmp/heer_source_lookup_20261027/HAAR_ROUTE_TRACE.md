# 早期 Haar + QIM + 质量门控路线定位

依据旧会话给出的“EEG完整性→Haar+QIM+质量门控→多接收方指纹→共同相位”回溯，已定位到明确的项目内方法：**Proposed Haar block-DC QIM**。原文件仍未出现HEER的明确拼写或英文展开，因此本记录确认路线和机制，不替HEER补造正式名称。

## 方法、版本与实际文件

最直接的方法定义为 `E:\python\数字水印\revision\lightweight_qc_validation\FINAL_METHOD_DECISION.md`；实现为同目录 `methods.py`、`qc.py`、`storage.py`。`papers/revised/LIGHTWEIGHT_QC_MANUSCRIPT.md`的证据版本为2026-09-16，`revision/post_20260926/P0_PROTOCOL_FREEZE.md`在2026-09-26将正式链条冻结。P0已包含认证的能量前半通道索引，较最初仅8字节尺度的版本更完整。

机制如下：

1. 每通道一级正交Haar时间DWT，periodization边界。
2. 四个互不重叠的近似系数组成 `a`，取单位DC方向 `u=[.5,.5,.5,.5]`，载体 `p=uᵀa`。
3. 对位 `b`，最近合法QIM码点为集合 `{(2k+b+.5)Q}` 中距 `p` 最近的中心；回写 `a′=a+(p′−p)u`。正式 `Q=.5`，在共享尺度映射到0–1000的空间中定义，载荷208bit。
4. 收端重算投影，以 `floor(p/Q+1e−10) mod2` 提位。它不需要原EEG样本，但需要共享尺度、Q、位置/通道映射等信息。
5. 尺度是两个little-endian float32的原min/max，共8字节；P0正式能量选道版本还携带ET1标记、通道数与索引。HMAC覆盖载荷正文和全部元数据，防止收端从已改变的极值/排名重新推测映射。
6. 设物理尺度 `s=(max−min)/1000`，各单位投影量化位移为 `δ_i`。理想正交、偶数长度、无重叠块条件下，误差范数为 `s sqrt(Σδ_i²)`，从而可在IDWT前拒绝超预算候选；接受后只重构一次。P3另给整数存储后误差上界及QIM提取充分条件。

实际函数入口包括 `methods.py:33 qim_embed_nearest`、`:70 encode_energy_mapping_metadata`、`:304 screen_and_embed_with_scale_metadata`。该实现不再使用SVD或逐试次Q迭代搜索。

历史QC与当前物理预算应分别识别。`qc.py`的输入门控检查有限/非常量、通道RMS失衡和近flatline；输出门控为global和max-channel PRD各≤1%，分母为**原信号范数**。`methods.py:353`解析预测也用原信号范数。它不是当前P181/P184逐通道去均值AC分母下的0.25%/0.5%/8–30Hz 1%合同。Q=.5也不是固定的物理PRD。HMAC保护的是载荷/元数据契约，不自动等于任意处理后整段EEG内容的完整性证明。

## 经典构件与项目新增层

| 层级 | 原文件支持的定位 |
|---|---|
| Haar/DWT、QIM、HMAC、正交能量守恒 | 经典构件；项目定稿明确不主张首次使用 |
| 4系数单位DC投影和最近码点回写 | 替换旧SVD/单系数路径的具体轻量载体设计，具有容量—频谱扰动折中；没有全局最优或独占优势证明 |
| 认证原尺度/选道映射 | 解决项目中接收端min/max漂移和动态排序漂移的协议设计；增加显式旁信息，属于semi-blind |
| IDWT前解析门控及整数存储证书 | 将已知正交/QIM误差关系落到具体EEG接口、拒发和存储可靠性；有可靠性与工程价值，单独不是新QIM理论 |
| EEG任务、局部通道、频带与资源链 | 项目系统性实证层，实际有效范围为归档/轻格式处理；原定稿保留噪声/后滤波失败 |

这一区别已经由原项目作过审查。`FINAL_METHOD_DECISION.md:38–46`把贡献集中在block投影、认证尺度和解析QC的组合；`SPL_NOVELTY_GATE_2026-10-01.md:11–16`列出Chen–Wornell 2001 QIM及Altun–Sharma 2006约束QIM先例，明确“给现有QIM与Haar接口推导证书”不足以单独构成SPL方法创新。`P4_METHOD_DIRECTION_DECISION_2026-10-01.md`继续将正式方法保留为固定设计折中，并要求真实同预算基线和新数据。

## 与当前路线的关系

这不是把同一Haar公式一直改到P180。`P6_DECISION_2026-10-04.md:3`明确**保留旧方法为独立历史分支**，新分支改为多接收方差异副本归因。P6先比较普通扩频、协方差零空间与模型已知避让。

`P7_STAGE_PROTOCOL_2026-10-06.md:9`再定义共同相位：实Fourier成对cos/sin系数按同一正交2×2旋转作用，`Y=X+(ZR−Z)Bᵀ`，理想算术保持空间Gram。`P7D_ORTHO_PHASE_PROTOCOL_2026-10-06.md`添加频谱加权正交接收方码。这与用户回溯中的“频域共同相位+接收方编码”一致，和Haar/QIM质控载荷方法是不同载体/接收合同。

较早的 `P27_LITERATURE_CONTRACT_AND_NOVELTY_AUDIT_2026-10-07.md`及 `P33_METHOD_NECESSITY_AND_REPARAMETERIZATION_AUDIT_2026-10-07.md`也已明确：通用接收方指纹/正交码和共同相位保持协方差有先例，不能仅凭Gram恒等式或更换表述构成新算法。

## 能否作为SOTA对照

**早期Haar block-DC QIM可以作为冻结的内部历史/机制对照；原资料没有把它确立为公认外部SOTA。** `BASELINE_IDENTITY_AUDIT.md:10`将其列为“Proposed Haar block-DC QIM，作为被比较方法”。若纳入当前比较，需另立适配版本，匹配应用载荷、40秒读出、接收端侧信息、EDF和实际AC/频带预算，并保持旧版本/负结果；不能直接搬用旧208bit/1% QC数字。

更早已存在的外部方法审查记录为：

- `BASELINE_IDENTITY_AUDIT.md`，2026-09-26：旧标RPW的实际为自写DWT-SVD代理；HiDDeN-like为未训练诊断；均无外部SOTA主表资格。
- `P2_RPW_SOURCE_AUDIT.md`，2026-09-26起：作者论文和固定提交的形状/训练/目标审计；后补微实现不等于完整原法复现。
- `P2_PHAM_2017_CORE_AUDIT_2026-10-01.md`：公开2017 DWT-SVD全文核心适配，有明确公式解释、无Arnold/PSO，不能冒称2015方法或完整SOTA。
- `EXTERNAL_BASELINE_COMPARABILITY_AUDIT_2026-10-07.md`及P27：按盲提取/留原参考、载荷、接收方、任务与部署对象区分方法，不直接复用论文数字排名。

本次只核对定义与已有审查，不逐P重统计或重训。全部新摘录保存在E盘，本次源文件哈希见 `haar_route_receipt.json`。
