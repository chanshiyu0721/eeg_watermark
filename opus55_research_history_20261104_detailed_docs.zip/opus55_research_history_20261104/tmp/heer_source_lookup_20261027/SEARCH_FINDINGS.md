# HEER 本地原文定位记录

状态：**尚未确认 HEER 原始文件、展开或方法定义。** 查询范围为 E:\python\数字水印；本轮只读资料，没有运行原方法代码、重新训练或修改实验。

检索覆盖：

- 文件名检索覆盖项目根目录及各子目录，排除依赖、缓存和原始数据内容；补查了课程报告、近似缩写和其他Word格式文件名。
- 已提取64个PDF/DOCX文件（57 PDF、7 DOCX，含渲染/协作副本），保留逐页/逐XML部件文本和原文件SHA256。
- 728个小文本文件覆盖现有Markdown、TXT、HTML、XML、配置、项目协作及隐藏目录；另覆盖唯一的main.tex。检索范围内未发现.ipynb或.bib原文。
- 搜索HEER、H-E-E-R、HREE、HEAR、HERR、HEIR、HIER、HEEW等近似名，另以NFKC转换数学字母并消除LaTeX字体包装/空白分隔后重查。“不出众”“不投稿”也已检索。
- 方法原文的PDF/DOCX归一化匹配为零；小文本仅命中2026-10-27新写的两份“HEER出处待核”说明，未发现更早的方法定义。
- 少文本PDF是既有实验图表，没有定位到需OCR的独立EEG方法稿。未扫描巨型EEG/结果JSON、依赖或大型数据压缩包内容。

## 已核定的近似项目线索

`papers/egg_watermark.pdf`的准确题名为 **Self-Calibrating Cognitive Data Provenance: A Quality-Adaptive, Tamper-Evident Framework for Trusted BCI Clinical Workflows**，首页标记Anonymous CogSci Submission，方法明确称 **Signal-Aware Adaptive Watermarking (SAW)**。其正文描述Haar分解、2×2块的SVD/最大奇异值量化、逐试次Zero-BER校准，以及带SourceID、timestamp和截断hash的载荷；Q和timestamp放在公开header。该文件没有HEER或上述近似方法名。

根目录README把SAW列作历史项目，并明确区分当前冻结的Haar block-DC/QIM工作流和真实SOTA复现。`papers/revised/SAW_V2_REVISED_MANUSCRIPT.md`继续以SAW V2定义单层时域DWT-SVD-QIM和208位载荷，声明RPW-EEG等外部方法尚未在该稿中复现。这支持将SAW视为本项目已有历史方法候选，不能将其直接认作用户所说HEER，也不能据旧稿中的跨协议表格赋予强外部SOTA基线地位。

根目录还存在隐藏的162字节Word占用文件 `~$W_Course_Report.docx`。它不是报告正文，正文未在本次文件名清单中检出。Word占用文件可能替换原文件名开头，不能仅凭此推出完整正文文件名；它只提供“课程报告曾与本目录关联”的线索。既有2026-10-03清理日志也记录保留该锁文件。

## 当前可作出的判断

HEER的定义、与当前方法关系以及能否作为强基线，仍需对应原文才能核定。本次检索没有把SAW、旧QIM或当前相位载体替代为HEER。进一步定位最有用的信息是正文文件名、目录或题名中的一段，而不是扩大EEG数据扫描。

覆盖与哈希见 `manifest.json`、`extra_manifest.json`、`small_text_search.json`、`normalized_document_matches.json` 和 `search_receipt.json`。所有提取产物均在本E盘临时目录。
