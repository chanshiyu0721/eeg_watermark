"""Reproduce Table 1 from saved sufficient statistics; standard library only.

Usage: python reproduce_development.py [package_directory]
No EEG, EDF generation, response refit, network or training is needed.
"""
from pathlib import Path
import gzip,json,math,sys

HERE=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent
SOURCES=dict(fit=('OpenBMI001','OpenBMI002','A02T','A03E'),
             select=('OpenBMI003','OpenBMI004','A05E','A07E'))
CONFIGS=((129,'compatibility',1e-6),(257,'compatibility',1e-4),
         (129,'exact',1e-4),(257,'exact',1e-4))
EXPECTED=((95,94),(86,89),(88,96),(96,96))

def family(row):
    if row['kind']=='enrolled':return 'registered'
    if row['kind']=='clean':return 'clean'
    if row['kind']=='wrong_source':return 'wrong'
    return 'pressure0125' if row['pressure'] else 'near025'

def load(taps,source):
    path=HERE/'evidence'/'scores'/f'taps{taps}'/f'{source}_taps{taps}.json.gz'
    result=json.loads(gzip.decompress(path.read_bytes()))
    assert result['status']=='complete' and result['source']==source
    return result['rows']

def score(row,head,ridge):
    value=row['receiver']['methods']['candidate_FIR_GLRT']['by_ridge'][str(ridge)]
    eligible=value['eligible'] and value['support']>=1 and value['presence']>=.25
    if head=='exact':
        q=max(0.,value['top_held_RSS']-value['conditional_unrestricted_RSS'])/max(value['winning_template_energy'],1e-30)
        s=-q
    else:s=value['compatibility']
    return float(s),bool(eligible),int(value['top'])

def main():
    output=[]
    for (taps,head,ridge),expected in zip(CONFIGS,EXPECTED):
        rows={role:[r for p in names for r in load(taps,p)] for role,names in SOURCES.items()}
        negative=[score(r,head,ridge)[0] for r in rows['fit']
                  if family(r)!='registered' and score(r,head,ridge)[1]]
        threshold=math.nextafter(max(negative),math.inf) if negative else 0.
        record=dict(taps=taps,head=head,ridge=ridge,threshold=threshold,panels={},people={})
        for role,data in rows.items():
            panel={name:dict(n=0,accepted=0,correct=0) for name in ('registered','near025','pressure0125','clean','wrong')}
            for row in data:
                s,eligible,top=score(row,head,ridge);accepted=eligible and s>=threshold;f=family(row)
                panel[f]['n']+=1;panel[f]['accepted']+=int(accepted)
                good=accepted and f=='registered' and top==row['identity']
                panel[f]['correct']+=int(good)
                person=record['people'].setdefault(row['source'],dict(role=role,registered_correct=0,negative_accepted=0))
                person['registered_correct']+=int(good)
                person['negative_accepted']+=int(accepted and f!='registered')
            record['panels'][role]=panel
        counts=tuple(record['panels'][role]['registered']['correct'] for role in ('fit','select'))
        assert counts==expected,(taps,head,counts,expected)
        assert all(v['accepted']==0 for p in record['panels'].values() for k,v in p.items() if k!='registered')
        output.append(record)
        print(f'{taps}/{head}: fit {counts[0]}/96; select {counts[1]}/96; all unknown/control accepts 0')
    path=HERE/'DEVELOPMENT_REPRODUCED.json'
    path.write_text(json.dumps(dict(status='saved_score_reproduction_passed',table1=output),indent=2),encoding='utf-8')
    print(path)

if __name__=='__main__':main()
