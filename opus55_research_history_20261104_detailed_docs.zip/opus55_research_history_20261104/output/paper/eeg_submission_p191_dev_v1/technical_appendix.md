## S1. Status and Evidence Roles

This supplement accompanies the P191 development manuscript. P190 remains the immutable earlier confirmation. All P190 people already observed are development or diagnostic records for a new method. OpenBMI017-024 and 025-028 are the new target and wrong-source roster [@lee2019openbmi]; the present results precede its frozen evaluation.

**Table S1.** Evidence roles and independent units.

|Evidence|People / role|Purpose|
|---|---|---|
|P190 fit|OpenBMI001/002, A02T/A03E|Fit scores and thresholds|
|P190 select|OpenBMI003/004, A05E/A07E|Select fixed fit rules|
|Observed former confirmation|OpenBMI005-012|P191 mechanism development|
|New confirmation|OpenBMI017-024|Frozen attribution and task evaluation|
|New wrong sources|OpenBMI025-028|Frozen negative controls|
|Task train / validation|Earlier people, disjoint from new confirmation|Fit task models before test predictions|

Canonical participant identity is the statistical unit. Multiple identity codes, query windows and processing conditions are repeated measurements. Wrong-source summaries retain the negative participant and crossed target-source identifiers.

## S2. Identity Geometry

The phase registry contains eight orthonormal unit codes, with minimum angle pi/2 and minimum chord distance sqrt(2). Near codes use a unit tangent orthogonal to the parent; the chord lengths for .025 and .0125 are .024999348963419578 and .012499918619950612. The continuous encoder's independently issuable set has minimum spacing zero, despite the finite registry's larger spacing.

QIM-ID uses balanced Walsh rows 1-31 of length 32, each repeated 20 times, for 640 chips. Registered rows are 1-8 and native unknown rows are 9-16. Distinct legal words differ in 320 chips. One/two-chip replacements lie outside that legal codebook and within a parent's correction neighborhood. P190 retains its original strict pressure table; damaged-copy attribution is an additional interpretation with its own table.

Let Z(u) be the allowed processed observations of issued identity u, and A(r)=Z(r) plus a declared error ball. If an independent unknown observation lies in A(r), the same observed signal carries opposite desired labels under the two histories. A deterministic receiver cannot satisfy both. Disjoint bounded-error observation sets with minimum spacing above twice the error radius give unique nearest-set identity. These geometric statements specify the evaluation semantics and do not imply a finite-sample false-acceptance bound.

## S3. Storage and Processing

All reported development comparisons reconstruct the original EDF queries with exact sample-byte hashes. Re-export is identity before EDF writing. Elliptic is a fifth-order causal bandpass with 1.3 dB ripple, 50 dB stop attenuation and 1.7-32.5 Hz passband; Bessel is sixth order, 3-33 Hz with phase normalization. Both causal filters are followed by common-average referencing across channels. The receiver's vector also applies its original temporal-centering convention. Temporal demeaning and across-channel CAR are distinct operations.

The common observation contract is 8 channels at 160 Hz, 112 s owner references, five held-out 8 s windows and 48 s visible received contexts. The 257-tap receiver extends the usable owner-reference support, while retaining each original received query. Actual PRD caps are .25% global, .5% maximum channel and 1% 8-30 Hz. Registered carrier global PRD is matched within relative spread .001 after actual write/read.

Across all eight observed former confirmation targets, 792/792 reconstructed queries reproduce the original EDF bytes. No .0125 or .025 unknown-parent pair has identical scored samples. The median elliptic .0125 difference is .903075 query LSB RMS, with .471318 of samples changed; the median .025 RMS is 1.29103 LSB. Code angle, EDF signal angle and conditional receiver distance have separate meanings.

## S4. Conditional Sufficient Statistics

For each candidate-conditioned response, the implementation pools G, b and d from held-out predictions. The least-squares coefficient uses the same stored matrix with numerical rank tolerance 1e-7. Conditional unrestricted RSS is max(0,d-b^T beta). The registered RSS uses the winning candidate selected by the original prediction procedure. The new score is minus max(0,R-U_same)/max(G_ii,1e-30).

The global unrestricted minimum in the historical compatibility score may come from a different conditional response. Replacing it by the same winner's U is part of the method, rather than a cosmetic score rescaling. Fold-level statistics, pooled matrices and the exact normalized defect are saved so that readout decisions can be reproduced without fitting another FIR.

An additive residual orthogonal to the fixed template span changes only d, and cancels algebraically from R-U. Error projected into the span changes b and can affect the score. Query-selected responses, alignment, numerical conditioning, presence and support remain empirical components of the complete receiver.

## S5. Calibration and Development Choices

Compatibility uses the original twelve configurations: ridge 1e-4/1e-6, compatibility/relative-gap/clean-relative-presence and support one/three. The exact score has one formula and the four ridge/support combinations. Presence remains .25. For every configuration, the fit threshold is nextafter(maximum eligible negative score,+infinity), now including .0125 negatives. The select ordering first minimizes false acceptance, then maximizes registered correct decisions and then uses the fixed menu index.

The initial low-order proposal looked only at select equivalence. The full 2 x 2 evidence shows 129 exact at 88/96 fit and 96/96 select, while 257 exact has 96/96 in both. The final preconfirmation eligibility requires at least .95 coverage in both roles and .90 for each target, with zero observed .025/.0125/clean/wrong acceptance. This makes 257 exact the current candidate. The earlier proposal and its lock remain in the archive; no new-person score entered this choice.

**Table S2.** Original 257-tap receiver controls, each with the same twelve configurations and pressure-aware fitting. Correct counts have denominator 96 per role; all listed negative acceptances are zero.

|Receiver|Fit correct|Select correct|
|---|---:|---:|
|Ordinary FIR|0|0|
|Identity-projected FIR|88|88|
|Candidate-conditioned FIR compatibility|86|89|
|Candidate-conditioned FIR exact score|96|96|

**Table S3.** Inherited 129-tap controls. The exact-score row required newly collected sufficient statistics; original compatibility observations are inherited.

|Receiver|Fit correct|Select correct|
|---|---:|---:|
|Ordinary FIR|0|0|
|Identity-projected FIR|58|75|
|Candidate-conditioned FIR compatibility|95|94|
|Candidate-conditioned FIR exact score|88|96|

Each source supplies 81 actual DEV queries: 24 registered, 24 .025, 24 .0125, 3 clean and 6 wrong-source observations over three conditions. Eight sources supply 648 queries for each new response-capacity collection. Candidate-conditioned FIR fits eight responses in each of five folds, 40 fits per ridge per query. Ordinary and projected each use five. The three-method 257 collection records 460.07 s, median extraction .4297 s and 95th percentile 1.1857 s. The new scalar readout adds zero response fits.

## S6. Mechanism and Retained Failures

The full eight-person diagnostic uses the original threshold only descriptively for its diagnostic branches. Registered attribution remains64/64 across blind, clean-lag, frozen-clean-response, combined and known-operator branches. Pressure acceptance is30/64 for all four estimated-response branches and0/64 for the known operator. Primary near acceptance is0/128 and clean/wrong acceptance0/40 in all branches. Unknown processing information is withheld from deployment receivers. The original005/012 pilot is retained and the other six records are added without repeating it.

In the paired capacity pilot, 129/257/513 taps retain 16/16 registered and 0/32 .025 acceptance at ridge 1e-6 and the historical threshold. Pressure acceptance changes 7/16 to 0/16 to 0/16. At source005, registered RSS drops 160.8-fold from129 to257, while mean pressure identity residual changes only about .6%. This isolates a response-error floor; the complete DEV factorial demonstrates that capacity alone is insufficient across domains.

The failed gain-normalized proxy uses -(R_top-U_global)/(R0-R_top). Its fit/select panels both have full registered coverage and no accepted near identities, but its observed former-confirmation panel accepts 47/192 pressure and 1/384 .025 identities. The beta-distance control also transfers imperfectly. These results are retained alongside the exact template-energy explanation check.

## S7. Learned Carrier Training

The RPW-based owner adaptation trains an encoder and reference-conditioned decoder with a real-EDF-compatible differentiable quantizer [@qin2025rpw]. Processing includes true channel CAR; temporal demeaning is an explicit decoder feature. Stage A uses eight fixed 30-bit messages. At update400, eight held-out carrier windows and eight identities yield 64 messages per condition, 1920 bits, and exact recovery after EDF under identity and causal elliptic. The stageA model is frozen for common-interface evaluation.

StageB changes training to random 30-bit messages and ends at update800. Across the full run, training records 6400 window exposures and 497.4 s on CPU with two threads. Random-message DEV accuracy is 1228/1920 and 1211/1920 bits, with zero exact messages. A predeclared decoder-only batch-normalization diagnostic uses training random messages without optimizer updates and preserves all trainable parameters and encoder buffers. Accuracy becomes1253/1920 and1222/1920, still zero exact messages. This single check does not explain the main extension failure.

The known-response finite-message development test, common unknown-response attribution and native random-payload recovery have separate result labels. Training an EEG task classifier cannot replace training this watermark carrier. The new task-model experiment uses a distinct dataset split and frozen models.

## S8. Confirmation and Reproduction

New raw files are prefetched as opaque bytes before scoring, with source URL, exact roster and SHA-256 receipts. Final freezing precedes signal analysis and predictions on the new confirmation roster. The frozen record must contain code, method menus and per-carrier thresholds, identity labels and unknown families, physical gates, people, processing, endpoints, success criteria and statistics. The final procedure is never replaced by a post-confirmation diagnostic rule.

The primary reporting unit is one participant averaged equally across that participant's identities and declared conditions. Registered recovery, .025/.0125 acceptance and controls have separate denominators. Paired intervals and individual participant rows accompany aggregate results. The previous P190 confirmation retains its original selector-failure conclusion.

Minimal saved-score reproduction loads the collected sufficient-statistic files, applies the locked threshold/support/presence rule, and emits per-person counts without EDF regeneration or response fitting. The report package maps each table and figure to its authoritative result file. Task evidence states its training/validation/test people, labels, clean validation capability and frozen preprocessing separately.
