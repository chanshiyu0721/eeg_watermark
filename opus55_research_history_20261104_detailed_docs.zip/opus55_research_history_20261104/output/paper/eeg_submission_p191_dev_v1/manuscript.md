---
title: "Separating Identity Mismatch from Unknown-Response Error in EEG Recipient Fingerprinting"
bibliography: references.bib
lang: en
---

## Abstract

Reference-assisted recipient fingerprinting identifies which issued EEG copy produced a processed recording. Close independent identities expose a failure of residual-ratio evidence: background error in an unknown filter can make an incorrect identity appear compatible. We derive a conditional identity defect whose background residual energy cancels, and normalize it by the actual processed fingerprint-template energy. The receiver preserves common-delay estimation, candidate-conditioned response fitting and five-window cross-fitting. In a development study of eight previously observed people across OpenBMI and BCI data, we compare response capacity and evidence readout using identical actual 16-bit EDF queries, a 40 s scoring interval and matched issuance budgets. Pressure-aware 129-tap compatibility correctly attributes 95/96 fit and 94/96 select queries with zero close-identity acceptance; increasing capacity to 257 taps alone lowers these counts to 86/96 and 89/96. The conditional energy readout with 257 taps achieves 96/96 in both panels, while rejecting all .025 and .0125 independent identities and clean/wrong-source controls. Controlled known-response experiments and an unsuccessful null-gain normalization explain why model capacity and the evidence scale must be treated separately. The manuscript records this development evidence and a prospective, person-separated confirmation protocol.

**Index terms:** EEG, recipient fingerprinting, open-set attribution, unknown response, conditional identity evidence.

## 1. Introduction

EEG recipient fingerprinting links a redistributed recording to an authorized recipient after external distribution labels disappear. The owner retains the clean source, issued recipient copies and the registry. A receiver must correctly identify processed issued copies and reject independent unregistered fingerprints, including identities very close to a registered code. This task combines signal preservation with recipient specificity under unknown preprocessing. Figure 1 connects the issuance path, reference-assisted receiver and the evidence needed to evaluate both properties.

![Overall method and evidence route](figures/P191_overall_route_en.pdf)

**Figure 1.** Overall route. Actual EDF issuance is followed by unknown processing, common-delay and response estimation, conditional identity evidence and a development-frozen recipient-or-rejection decision. Dashed arrows supply owner-held references and frozen rules. Offline identity definition, mechanism diagnostics and development precede a separate new-person confirmation. Task models have their own training and evaluation roles. The lower rows describe the study design; the development results in this manuscript precede its new-person confirmation.

The P190 baseline establishes the relevant starting point. A frozen smooth-carrier rule recovered all 192 registered observations and rejected all 384 .025 independent neighbors on eight new target people, while accepting 30/64 tighter .0125 neighbors under causal elliptic processing. The five tested calibration procedures had already selected the same primary decision function before confirmation. Their primary selector increment was therefore zero. The present study uses those observed records for mechanism development and retains their original outcomes.

We investigate why elliptic processing can preserve recipient recovery while weakening close-identity rejection. A compatibility ratio divides an unrestricted identity-fit residual by a registered-identity residual. Shared background response error can dominate both quantities and drive the ratio toward one. The relevant question is how much error is specifically attributable to identity mismatch, relative to the energy of the actual identity template.

Our study develops three connected contributions. First, it separates registered identity, independent unregistered code and damaged issued copy, preserving the strict historical near-code tests. Second, it derives and implements a readout that subtracts residuals under the same conditional response and normalizes by template energy. Third, it evaluates response capacity and readout as separate factors under actual storage, reference and observation constraints. A pressure-aware simple threshold is a mandatory comparator. New-person confirmation and task preservation are the next evidence stages in the same frozen evaluation design.

## 2. Related Work

Phase watermarking has established audio precedents for shared-channel phase structure and differential readout [@bender1996hiding; @sonoda2004periodical; @takahashi2005multiple]. QIM supplies distortion-controlled embedding [@chen2001qim], and recent EEG data hiding combines transform coding and robust payload recovery [@efe2026network]. Learning-based EEG watermarking studies robust message decoding and task behavior [@qin2025rpw; @zhang2026dsftan]. Those payload objectives motivate strong carrier controls; our verification object is a registered recipient under declared clean-source and archived-copy access.

Variable projection, matched-subspace detection and attack-parameter estimation provide established nuisance-estimation tools [@golub1973separable; @scharf1994matched; @moulin2002desynchronization]. The present readout uses conditional residual geometry to distinguish identity mismatch from background response error. Its algebra is evaluated within the actual query-selected, cross-fitted system. Person-separated development and frozen testing address the distinction between choosing a threshold and demonstrating its transfer [@tong2018np; @gulrajani2021domainbed].

## 3. Identity and Physical Contract

An identity denotes a recipient mark, rather than the physiological identity of the EEG participant. Eight registered phase codes are orthonormal unit vectors. Independent near codes are generated by $u_\theta=\cos(\theta)u_r+\sin(\theta)v$, with unit $v$ orthogonal to $u_r$. The .025 and .0125 offsets retain their original code-angle meaning. An independently generated near code remains an unknown even when its signal is close to an issued parent. A damaged-copy experiment instead starts with the issued parent and keeps its attribution label. These generation histories have distinct evaluation tables.

The verifier receives 112 s of eight-channel references at 160 Hz. A query exposes five 8 s scoring windows and 128 contextual samples on each side: 40 s scored and 48 s visible in total. The real 16-bit EDF write/read is part of issuance and received-query construction. PRD caps are .25% global, .5% maximum channel and 1% in 8-30 Hz. Actual registered global PRD is matched across carriers within relative spread .001. Level 1 denotes the full feasible source-relative strength, rather than a 1% global disturbance.

The main carrier is smooth cross-window differential phase, with direct phase, spatial, smooth-spatial hybrid and identity-adapted QIM controls. QIM uses a finite Walsh codebook; its chip modifications are reported separately from phase angles. The supplement records code geometry, the damaged-copy interpretation and the observed distances after EDF serialization.

## 4. Conditional Identity Evidence

### 4.1. Cross-fitted response estimation

Each held-out scoring window uses the other four windows to select a common delay and estimate an unknown residual FIR response. Candidate-conditioned fitting accounts for the interaction between the clean source and each issued residual. Ordinary and identity-projected FIR remain receiver controls. We test 129 and 257 taps without extending received-query context; the longer FIR uses more of the already available owner reference.

For a candidate response fit $i$, concatenate the held-out identity templates into $T_i$ and the received-minus-predicted-clean vector into $v_i$. Pool the five held-out folds as

$$
G_i=T_i^\top T_i,\qquad b_i=T_i^\top v_i,\qquad d_i=v_i^\top v_i.
\tag{1}
$$

The fixed registered-identity residual and its unrestricted identity fit under this same response are

$$
R_i=d_i+[G_i]_{ii}-2[b_i]_i,\qquad U_i=d_i-b_i^\top G_i^\dagger b_i.
\tag{2}
$$

### 4.2. Background cancellation and normalization

Subtracting (2) cancels the common residual-energy term:

$$
D_i=R_i-U_i=[G_i]_{ii}-2[b_i]_i+b_i^\top G_i^\dagger b_i.
\tag{3}
$$

For nonsingular $G_i$, $D_i=(e_i-\widehat\beta_i)^\top G_i(e_i-\widehat\beta_i)$, where $\widehat\beta_i=G_i^{-1}b_i$. We use dimensionless mismatch

$$
q_i=\frac{\max(0,D_i)}{\max([G_i]_{ii},10^{-30})},\qquad s_i=-q_i.
\tag{4}
$$

An additive response-error component orthogonal to the template dictionary changes neither $G_i$ nor $b_i$. It increases the common background in $R_i$ and $U_i$ while preserving (3). In contrast, $U_i/R_i=1-D_i/R_i$ approaches one as background error grows. The historical compatibility head uses $\min_jU_j/R_i$; its unrestricted minimum may come from another candidate's response. Equation (3) deliberately uses the winning candidate's own $U_i$.

The implementation retains the original winner $i=\arg\min_jR_j$, common alignment, window support, presence and eligibility. It changes the final evidence readout. Projected response error can still change $b_i$, so the complete system is assessed empirically. The same saved sufficient statistics also support the original compatibility head; the new scalar requires no additional response fits.

### 4.3. Development and strong controls

Fit targets are OpenBMI001/002 and A02T/A03E; select targets are OpenBMI003/004 and A05E/A07E. Their wrong-source people remain disjoint between roles. Each role contains 96 registered, 96 .025, 96 .0125, 12 clean and 24 wrong-source observations over re-export, causal elliptic and causal Bessel processing. Previously observed P190 confirmation people are diagnostic development records in this study.

For each configuration, the threshold is the next representable score above the maximum eligible fit-negative score, including .0125 identities. Compatibility controls receive the inherited twelve ridge/head/support configurations. The new single-formula score uses two ridge values and one/three-window support, four configurations, with presence .25. Select data choose among fixed fit thresholds; unused configuration budget is reported. The final preconfirmation choice considers fit and select coverage together. The earlier select-only low-order proposal is preserved in the experiment history.

## 5. Development Evidence

### 5.1. Mechanism isolation

Controlled diagnostics cover all eight observed elliptic records. Every reconstructed query matches its original actual EDF byte hash, and the blind scores reproduce exactly. The original receiver accepts 30/64 pressure identities while recovering 64/64 registered copies. Replacing only alignment with paired-clean estimates, freezing response to the ordinary paired-clean fit, or combining both changes leaves pressure acceptance at 30/64. The true processing operator gives 0/64 pressure acceptance and 64/64 registered recovery. True operator information appears only in this diagnostic branch. These complete-person results extend the initial high/low-acceptance pair without replacing it.

Increasing FIR support from 129 to 257 taps lowers mean registered held-out RSS on source005 from .129910675 to .000807806, a 160.8-fold reduction. The pressure fixed-minus-unrestricted residual remains approximately .000399325 versus .000401587. Under the old descriptive threshold, 257 taps rejects all 16 pressure queries across the two sources; 513 taps adds no correct decisions. This paired result motivates a capacity-by-readout experiment across the complete development panel.

### 5.2. Capacity and readout are separate factors

**Table 1.** Development outcomes for candidate-conditioned FIR. Thresholds include pressure negatives. C denotes registered correct out of 96 per role. Each listed procedure accepts 0/96 .0125, 0/96 .025, 0/12 clean and 0/24 wrong-source observations in each role. The 129-tap exact row and its threshold are calibrated separately.

|Response/readout|Fit C|Select C|
|---|---:|---:|
|129 / pressure-aware compatibility|95|94|
|257 / pressure-aware compatibility|86|89|
|129 / conditional template-energy score|88|96|
|257 / conditional template-energy score|96|96|

Longer FIR support alone reduces coverage in the multi-domain panel. The conditional template-energy score restores both development roles with 257 taps. A 129-tap variant matches select coverage while retaining eight fit failures; it remains an important low-cost ablation. The 257-tap score uses ridge $10^{-4}$, one-window support, presence .25 and fit threshold $-5.941561436978785\times10^{-5}$. These are development decisions to be fixed before new-person decoding.

An earlier score divided the identity defect by optimized clean-null improvement. It achieved full fit/select coverage but accepted 47/192 pressure and 1/384 .025 identities on the observed P190 transfer panel. Replacing that proxy with actual template energy and using the winner's conditional residual addresses the tested explanation. The failed proxy remains part of the results.

### 5.3. Modern learned carrier

An owner-assisted adaptation of the RPW-EEG architecture undergoes actual joint encoder/decoder training. At 400 updates, a fixed eight-message carrier decodes all 1920 bits and all 64 messages in each of identity and causal elliptic processing on eight development windows after real EDF serialization. Maximum measured global/channel/band PRD is .234154%/.450321%/.491624%. This experiment establishes finite-registry carrier learning under the physical caps.

Expansion to random 30-bit messages at 800 updates gives 63.96% and 63.07% bit accuracy, with zero exact messages in both conditions. One training-only decoder batch-normalization diagnostic changes these to 65.26% and 63.65%, still with zero exact messages. The finite-code carrier proceeds to the common unknown-response interface; native random-payload recovery retains its failed outcome. Modern watermark-carrier training and downstream EEG task-model training have distinct roles.

The first common-interface experiment uses OpenBMI001 for fit and003 for select, keeping 112 s references, 40 s scoring and unknown response estimation. The frozen stageA carrier matches each smooth registered EDF's actual global PRD within .001 relative spread. Across three conditions, 257-tap candidate compatibility recovers 24/24 registered queries in each role with 0/48 native Hamming1/2 unknown acceptance; 129-tap controls recover20/24 and23/24 and accept1/48 select unknowns. These native unknowns have larger actual residual angles than the phase pressure family, so each retains its own identity geometry. The full-person learned-carrier development panel is collected separately before confirmation.

## 6. Independent Confirmation and Task Protocol

The new confirmation roster comprises OpenBMI017-024 targets and 025-028 wrong-source people. Raw files are acquired without receiver or task predictions before freezing. The freeze binds identity policies, all methods and per-carrier development rules, code hashes, subjects, processing, endpoints and statistics. Smooth is primary; direct, spatial, hybrid and applicable QIM/learned carriers use the same reference, received duration and actual storage budgets.

The principal outcomes are registered correct attribution and .0125 independent-identity acceptance, with .025, clean/wrong acceptance and each processing condition as constraints. Equal-weight participant summaries and paired participant differences are the statistical units. Windows, recipients and transformations remain within-person observations. Prespecified intervals and paired contrasts describe both coverage and specificity; an empirical zero count is reported with its finite-person scope.

Task validation trains CSP/LDA and a modern EEG model on earlier OpenBMI people, uses disjoint earlier people for validation, and predicts the new target people after freezing. Clean-model task capability is established before comparing carriers. Accuracy, prediction flips and probability change are reported separately under the same fixed model and preprocessing. The historic encoding-grid reversal remains an independent result; any new grid intervention must hold disturbance allocation fixed or separately identify its changes.

## 7. Discussion

The current evidence supports a specific mechanism: response-model background can mask close-identity mismatch in ratio evidence. Conditional subtraction removes its unstructured energy, while template energy supplies a relevant scale. The complete development comparison shows why additional response capacity and an appropriate readout must be tested separately. Pressure-aware compatibility already provides a strong simple baseline, so the new-person study measures the added benefit of the full procedure against that control.

The setting is known-source, reference-assisted attribution with a finite enrolled registry. For continuous independently issuable codes, arbitrarily close identities can overlap an allowed damaged-copy observation set; bounded-error attribution therefore needs a declared identity spacing and processing scope. Actual EDF distances establish that the tested .0125 examples are physically distinct. Independent confirmation will determine transfer of the chosen rule, and joint task evaluation will determine whether the retained low-disturbance carrier preserves useful EEG behavior.

## Acknowledgment of AI Assistance

OpenAI Codex assisted with implementations, analysis, drafting and programmatic figures. Reported numerical observations derive from executed, saved experiments.
