---
title: "Calibration Transfer in EEG Recipient Attribution: A Source-Disjoint Study"
bibliography: references.bib
lang: en
---

## Abstract

Reference-assisted EEG recipient attribution must distinguish an issued copy from nearby unregistered fingerprints after preprocessing. Registered recovery alone can conceal different recipient specificity. We evaluate five calibration procedures with the same development people and configuration menu, including pooled maximum coverage, fixed weak ridge and person-separated threshold perturbation. All rules are frozen before decoding eight new target participants and four independent wrong-source participants. Real 16-bit EDF serialization, measured matched disturbance and a fixed 40 s scoring contract govern 13,320 confirmation queries across five carriers, three strengths and three processing conditions. Before confirmation, all five recalibrated procedures select the identical primary smooth-carrier decision rule. This shared rule correctly attributes 192/192 registered queries, rejects all 384 primary near identities and accepts 30/192 tighter pressure identities, all under causal elliptic processing. Its two primary baseline contrasts are structurally zero, and the prespecified selector-improvement criterion fails. Matched receiver and carrier results expose coverage-specificity trade-offs, while retained task experiments show encoding-grid-dependent output stability. The study establishes source-disjoint transfer of a calibrated attribution system and separates that capability from the benefit of additional selection machinery.

**Index terms:** EEG, recipient attribution, differential phase, calibration transfer, nuisance estimation.

## 1. Introduction

EEG recipient attribution links a processed recording to an issued copy after distribution metadata disappear. In the reference-assisted setting, the owner retains the clean candidate source and eight archived recipient copies, and observes short contexts of the suspect recording. Attribution combines registered recovery with rejection of nearby unregistered fingerprints, clean recordings and unrelated sources under a small actual storage distortion. Physiological watermarking has established robust payload recovery and task-related evaluation [@pham2017effects; @qin2025rpw; @zhang2026dsftan]. Recipient attribution makes the specificity of recovered evidence a central outcome. Figure 1 connects the signal path, owner-held reference inputs and the evaluation design.

![Overall EEG recipient-attribution research route](figures/P190_overview_en.pdf)

**Figure 1.** Overall route of EEG recipient attribution and its evidence design. Solid arrows show pipeline flow; dashed arrows supply owner-held clean and actual issued references. Response compensation and candidate-conditioned evidence feed a development-frozen identity-or-rejection decision. The lower row locates person-separated calibration, matched carrier comparisons and historical task utility. Phase neighborhoods use unit-code angles; QIM retains its native unknown family. The eight-new-target/four-wrong-source cohort tests attribution; the task models and grid interventions retain their historical cohorts. Waveforms are schematic.

Registered recovery alone can conceal different recipient specificity. In the historical smooth-carrier experiment, two configurations correctly attributed all 72 held registered queries while accepting 16 versus zero of 72 primary near identities at level 1. The weak-ridge alternative changed pressure acceptance in opposite directions: 59/72 to zero on BCI and 5/128 to 12/128 on the retained OpenBMI bridge. These observations motivate a direct test of configuration selection and threshold transfer with people separated between development and confirmation.

We evaluate person-separated calibration for a fixed recipient receiver. Thresholds are fitted on one group of people; deleting each fit person measures its influence on the negative-score threshold. Disjoint people then select a configuration through a fixed source-by-processing specificity ordering. Pooled and split maximum-coverage selectors and fixed weak-ridge policies receive the same data and configuration menu. The complete procedures are frozen before one confirmation on eight new OpenBMI target participants and four separate wrong-source participants [@lee2019openbmi].

Development establishes primary decision equivalence before new-person decoding: all five recalibrated procedures select configuration 6, weak-ridge compatibility with one-window support, threshold 0.9957274054693162 and presence gate .25. Their subsequent primary decisions are therefore identical. The new-person experiment measures transfer of this common rule and the broader controlled panel while retaining the original success criteria for the tested selector. The study contributes a source-disjoint calibration evaluation, matched receiver and carrier comparisons, and an explicit separation of shared-system performance from additional selection machinery.

## 2. Related Work

**Watermarking and attribution.** Phase-based data hiding has audio precedents in differential and shared-channel constructions [@bender1996hiding; @sonoda2004periodical; @takahashi2005multiple]. QIM provides distortion-controlled embedding [@chen2001qim], including recent blind EEG data hiding [@efe2026network]. EEG payload methods also evaluate processing robustness and downstream behavior [@qin2025rpw; @zhang2026dsftan]. Our verification object is the recipient of a recovered recording under declared clean-source and enrollment access. Phase-neighborhood offsets and legal QIM identities retain their distinct code geometries.

**Estimation and calibration.** Variable projection, matched-subspace detection and watermark detection under unknown attack parameters supply established nuisance-estimation tools [@golub1973separable; @scharf1994matched; @moulin2002desynchronization]. Neyman–Pearson classification and Learn then Test develop risk-calibration principles [@tong2018np; @angelopoulos2025ltt]; EEG seizure-alarm calibration already uses the latter [@segal2023eegltt]. Worst-group objectives and explicit model-selection rules are established in group DRO and DomainBed [@sagawa2020groupdro; @gulrajani2021domainbed]. We evaluate their practical concerns in recipient attribution through canonical-person threshold deletions, disjoint configuration selection and frozen new-person testing. The threshold perturbation measures empirical influence within saved evidence.

## 3. Method

### 3.1. Observation and response–identity coupling

The verifier returns an enrolled recipient or rejection using 112 s of eight-channel clean and enrollment references at 160 Hz. Each query exposes five 8 s scoring windows, with 128 contextual samples per side: 40 s scored and 48 s visible. In each fold, the other four windows determine a common delay and fit a 129-tap residual FIR; the held-out window supplies prediction error. Processing labels and true filter coefficients are unavailable to the receiver.

Let $v$ be the normalized query residual, $A$ the clean-reference convolution matrix, $T=[t_1,\ldots,t_8]$ the actual enrollment residuals and $D_i$ the convolution matrix of $t_i$. The response–identity model is

$$
v=Ah+T\beta+D(\beta)h+\epsilon,\qquad D(\beta)=\sum_i\beta_iD_i.
\tag{1}
$$

Ordinary FIR fits the response directly; identity-projected FIR removes the additive enrollment span during fitting. Candidate-conditioned FIR retains the interaction in (1) by fitting each issued candidate separately:

$$
\widehat h_i=\arg\min_h\|(v-t_i)-(A+D_i)h\|_2^2+\lambda\|h\|_2^2.
\tag{2}
$$

Its held-out prediction is $t_i+(A+D_i)\widehat h_i$. All receivers share references, alignment, filter order and the same absolute penalty at a common $\rho$: $\lambda=\rho\operatorname{tr}(A^\top A)/129$. Candidate conditioning requires eight fits per fold instead of one.

The twelve-configuration menu combines $\rho\in\{10^{-4},10^{-6}\}$, compatibility/relative-gap/clean-relative-presence heads and one or three agreeing windows. Every configuration requires presence $\ge.25$. A query returns the winning registered identity when its eligibility, support and frozen score threshold are met. The supplement specifies the residual-ratio scores and numerical conventions.

### 3.2. Physical comparisons

Smooth differential phase applies common channel phase rotations in four-second blocks and tapers the residual with a Tukey window of parameter .125. Direct phase, spatial rotation, a 95%/5% smooth–spatial hybrid and identity-only QIM provide controls. Issuance includes a real 16-bit EDF write/read, with global/channel/8–30 Hz PRD caps of .25%/.5%/1%. Registered carriers match each source–identity's realized global PRD with relative spread at most .001. Levels .5/.75/1 scale the feasible source-relative strength.

### 3.3. Person-separated calibration

Fit and select each contain four target and two wrong-source people, disjoint at the canonical-person level; all sessions and derived copies retain their person's role. Provenance checks cover both target-source and negative-source fields. All five recalibrated procedures share the same development people, receiver scores, configuration menu, eligibility rules and processing grid.

For configuration $k$, the split threshold $t_k$ is the next representable value above the largest eligible nonpressure fit-negative score, or zero if none exists. Acceptance is inclusive. Deleting every row naming each of the six fit people in either provenance role gives $t_k^{(-p)}$ and $\delta_k=\max_p(t_k-t_k^{(-p)})$. Issued/query EDF bytes, quantization ranges and receiver scores remain fixed during deletion.

Selection requires a complete registered, primary-unknown and clean/wrong panel, mean registered correct coverage $\ge.95$, minimum-source coverage $\ge.90$ and zero clean/wrong acceptance. Admissible configurations are assessed at $t_k-\delta_k$, $t_k$ and $t_k+\delta_k$. The fixed ordering prioritizes lower-threshold worst-source-by-processing primary acceptance, followed by mean acceptance, upper-threshold coverage and decision stability. Split thresholds carry directly from fit. Supplementary Figure S1 details the fit/select/freeze sequence; the supplement also specifies exact ordering, fallback and leave-one-select-target stability.

### 3.4. Comparisons and operating points

**Pooled-original** fits pooled development thresholds and maximizes registered coverage with earliest-index ties. **Fixed-weak-pooled** fixes configuration 6 with a pooled threshold. **Split-maxcoverage** retains fit-only thresholds and selects by select coverage; **fixed-weak-split** fixes configuration 6 with its fit threshold. **Source-stable** uses the perturbation ordering. Historical rules retain their original, smaller development set.

The prespecified primary point is smooth/candidate-conditioned FIR/level 1. Separately, each procedure chooses its lowest development-eligible level from {.5,.75,1}, requiring the coverage criteria above and zero primary/control acceptance. No eligible level remains an explicit outcome. The .0125 phase and QIM-chip pressure families enter no threshold fitting, selection, deletion population or selection diagnostic.

## 4. Evaluation Design

Confirmation uses OpenBMI005–012 as targets and OpenBMI013–016 as wrong-source people [@lee2019openbmi]. Their finite roster is fixed before acquisition. The pre-decoding freeze binds code, policies, development evidence, acquisition, metadata and statistical rules. One uniform round evaluates five carriers and three strengths under re-export, causal elliptic and causal Bessel processing. Phase queries contain eight registered identities, sixteen .025 neighbors in two fixed directions and eight .0125 pressure identities. QIM retains its native legal-unknown and chip-pressure definitions. Failed issuance remains visible.

Each target supplies one paired coverage and primary-acceptance value, equally averaging recipients, directions where applicable, and processing conditions. Thus primary contrasts have eight person units. Their uncertainty is conditional on the fixed identities, processing grid and shared wrong-source/range fixture: query EDF ranges use transformed clean and allocated wrong-source signals. Wrong-source results retain four negative-person units and the crossed target-by-negative cells.

Primary inference compares source-stable against pooled-original and fixed-weak-pooled. Each comparison combines one-sided paired-$t$ coverage noninferiority, margin $-.05$, and primary-acceptance superiority versus zero. The intersection-union $p$ is the larger component; Holm adjustment controls both baseline contrasts at family $\alpha=.05$. Both must pass. Paired 95% intervals and all 256 person-level sign flips accompany the primary analysis. Complete success also requires development feasibility/stability, mean coverage $\ge.95$, observed coverage loss $\le.02$, primary-acceptance reduction $\ge.05$ and the prespecified source/processing/control gates listed in the supplement.

Common-level confirmation is primary; development-selected points and the complete receiver/carrier grid describe transfer. Reused CSP/LDA and EEGNet evidence [@ang2012fbcsp; @lawhern2018eegnet] retains the distinct 45-event joint, 270-event original-grid and +1 s encoder-origin scopes. The shifted grid reverses the smooth/direct ordering for both models, tying utility interpretation to the tested encoder/task geometry.

## 5. Results

### 5.1. Primary confirmation and rule equivalence

All 120 confirmation source/strength/carrier groups completed, with 13,320 evaluated observations and no infeasible issuance. All 270 receiver-group-policy summaries have zero registered misattributions and zero clean/wrong-source acceptance. Repeated identities and transforms remain within the eight target-person units.

The primary shared rule attains 192/192 correct attribution, zero registered rejection and 0/384 primary near acceptance (Table 1). Every target contributes 24/24 correct and 0/48 primary acceptance. Coverage and primary-acceptance differences against both principal baselines are exactly zero for every person, with collapsed paired intervals [0,0]. Both Holm-adjusted intersection-union p values are 1. The five-point reduction and two-strictly-improved-person gates fail, while the coverage, control and development gates pass. The full prespecified selector-improvement criterion therefore fails.

The primary equality has a direct development explanation. Pooled maximum coverage correctly attributes 191/192 development copies at index 0 and 192/192 at index 6. The old coverage tie is absent in this expanded panel, and the simple pooled objective already selects the shared weak-ridge rule. Historical and new development differ in data and calibration; their comparison describes the complete procedures.

**Table 1.** Primary smooth/candidate-FIR/level-1 confirmation. C/R/M denote registered correct/rejected/misattributed counts, out of 192. Unknown and control columns show accepted/evaluated. The five recalibrated rows share the same decision function; the historical rule uses its original development set.

|Calibration|C/R/M|.025 unknown|.0125 pressure|Clean|Wrong source|
|---|---:|---:|---:|---:|---:|
|Pooled original|192/0/0|0/384|30/192|0/24|0/96|
|Fixed weak, pooled|192/0/0|0/384|30/192|0/24|0/96|
|Split max coverage|192/0/0|0/384|30/192|0/24|0/96|
|Fixed weak, split|192/0/0|0/384|30/192|0/24|0/96|
|Source stable|192/0/0|0/384|30/192|0/24|0/96|
|Historical freeze|192/0/0|0/384|41/192|0/24|0/96|

![Frozen candidate-receiver transfer grid](figures/P190_absolute_grid.pdf)

**Figure 2.** Source-stable candidate-receiver confirmation across all five carriers, strengths and processing conditions. Values are rounded source-equal percentages over eight target people. Stars identify a development-infeasible rule's fixed fallback. Gold outlines identify confirmation coverage below 95% or accepted clean/wrong controls. Phase primary unknowns have code angle .025; QIM uses legal native unknowns. Pressure outcomes appear in the complete supplementary tables.

### 5.2. Processing and receiver trade-offs

The shared primary rule correctly attributes 64/64 registered queries and rejects all 128 primary unknowns in each condition. All 30 pressure acceptances occur under elliptic processing (30/64); re-export and Bessel each accept 0/64. Historical pressure acceptance is 41/192, comprising 27 elliptic and 14 Bessel queries. Its lower total after recalibration accompanies an elliptic increase from 27 to 30, exposing a processing-specific trade-off.

Receiver compensation remains consequential under the shared observation and development budgets. At common level 0.5, the frozen source-stable ordinary/projected/candidate procedures correctly attribute 27/140/187 of 192 smooth copies; primary acceptance is 26/0/0 and pressure acceptance 20/25/24. The ordinary and projected procedures use their declared fallback when development feasibility fails. At level 1, projected/candidate coverage is 171/192 versus 192/192, with pressure acceptance 17/192 versus 30/192. These are complete calibrated-procedure comparisons: candidate fitting increases observed coverage, with strength-dependent rejection trade-offs.

### 5.3. Carrier and operating-point transfer

Figure 2 reports every candidate-receiver strength/processing cell under source-stable, including development-infeasible fallback points. At common level 1, smooth and direct both achieve 192/192 registration and 0/384 primary acceptance, while accepting 30/192 and 25/192 pressure identities. Hybrid and spatial retain different coverage and pressure outcomes. QIM-ID gives 192/192 registration and 0/192 legal-unknown acceptance at every strength, while accepting all 384 chip-forgery pressure queries; its legal and chip neighborhoods retain their native geometry.

**Table 2.** Candidate-FIR operating points chosen on development before confirmation, shown here for source-stable. G is mean measured registered global PRD in percent. Registered correct/primary accepted/pressure accepted use denominators 192/384/192 for phase carriers and 192/192/384 for QIM-ID. Levels and native unknown families differ across rows.

|Carrier|DEV level|G (%)|Correct|Primary accepted|Pressure accepted|
|---|---:|---:|---:|---:|---:|
|Smooth|0.5|0.06131|187|0|24|
|Direct|1|0.12244|192|0|25|
|Hybrid|0.75|0.09204|192|0|29|
|Spatial|1|0.12244|185|0|21|
|QIM-ID|0.5|0.06134|192|0|384|

The development-selected points give a different comparison (Table 2). Smooth selects level 0.5 and registers 187/192 with zero primary acceptance; direct selects level 1 and hybrid selects 0.75, both registering 192/192. The common-strength comparison and these different-strength policies answer separate questions. Added selection machinery also has adverse secondary slices: at smooth level 0.75, source-stable gives 190/192 correct and 32/192 pressure acceptance, versus 192/192 and 26/192 for pooled-original and fixed-weak-pooled. At spatial level 0.5, source-stable raises primary acceptance from 18/384 to 23/384 while raising coverage from 188/192 to 190/192. These slices retain the failed primary conclusion.



### 5.4. Historical task context

The retained 45-event Bessel joint point gives smooth/direct probability MAE of $(6.667,7.322)\times10^{-5}$ for CSP/LDA and $(1.346,1.519)\times10^{-4}$ for EEGNet. Their participant difference intervals include zero, and all carriers/strengths retain zero prediction flips in that panel. The overlapping 270-event original-grid analysis favors smooth, but a fixed +1 s encoder-origin intervention reverses the mean ordering for both models, with all nine participants favoring direct. That intervention changes block transformation and physical rematching together. These task results concern the historical waveforms and models; the new cohort confirms attribution calibration. Full counts and the bounded learned-carrier adaptation are in the supplement.

## 6. Discussion and Conclusion

The independent cohort supports transfer of the shared smooth/candidate-FIR rule at the primary .025 neighborhood, with full observed registered coverage and zero clean/wrong acceptance. Tighter identities remain difficult under elliptic preprocessing. Equal reference access, actual matched EDF disturbance and the complete carrier/receiver grid locate this capability within a finite-registry, known-source setting.

The proposed selector adds no primary decision benefit over the matched simple baselines. That conclusion follows from exact preconfirmation rule equality and is confirmed by the frozen outcomes. More elaborate selection is unnecessary at this primary point; secondary carrier and strength slices expose additional trade-offs. The resulting evidence supports source-disjoint evaluation of the full calibrated system, with task utility tied to the tested encoding geometry.

## Acknowledgment of AI Assistance

OpenAI Codex assisted with drafting, analysis scripts and programmatic figures. Numerical findings derive from executed archived experiments and saved-output reproduction.
