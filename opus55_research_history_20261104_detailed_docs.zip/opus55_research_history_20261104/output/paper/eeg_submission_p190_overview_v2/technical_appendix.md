# Supplementary Material

This supplement specifies the frozen P190 calibration and independent-person design, the completed development and confirmation results, and the historical measurements retained from P189. Historical BCI2a/OpenBMI panels and task analyses keep their original people, waveforms and denominators. The new confirmation uses the separate cohort specified below.

## S1. Cohorts, provenance and freeze

Canonical people define the fit, select and confirmation roles. Every session, T/E alias, recipient copy and processed derivative retains its person's role. Provenance checks apply to both the target-source field and the negative-source field of a wrong-source query.

**Table S1.** Fixed people by experimental role. OpenBMI identifiers denote session-1 motor-imagery participants; AxxT/E identifiers retain their historical BCI2a recording names.

| Role | Target people | Wrong-source people |
|---|---|---|
| Fit | OpenBMI001, OpenBMI002, A02T, A03E | A01T, A04E |
| Select | OpenBMI003, OpenBMI004, A05E, A07E | A06E, A08E |
| Confirmation | OpenBMI005-012 | OpenBMI013-016 |

The OpenBMI adapter reads the session-1 train phase [@lee2019openbmi]. It selects FC3, FC4, C3, C4, Cz, CP3, CP4 and Pz, resamples the selected eight-channel phase from 1000 to 160 Hz with the inherited 4/25 polyphase operation (Kaiser parameter 5, line padding), then takes the metadata-fixed 112 s block beginning two seconds before the first cue. Decoding returns voltage-valued $8\times17920$ references. The BCI references reuse their archived EDF bytes and physical grids. Four-class BCI task models are evaluated only on the historical BCI task cohort.

The twelve new OpenBMI raw files and their metadata were acquired under the finite roster before new-signal decoding. The confirmation freeze binds code, source/acquisition and metadata receipts, development scores, policies, statistical rules and historical inputs. The recorded freeze is `CONFIRMATION_FREEZE.json`, SHA-256 `e71ecf6ad433fdeec75837f8055cdb3c41eeb71b7ec1156f8b31dad101f44c9c`, written on 2026-10-30 before confirmation decoding. All recalibrated configurations, thresholds and operating points were fixed at that boundary.

One uniform confirmation round applies the frozen rules. An interrupted computation resumes identical missing groups and retains completed checkpoints and failure receipts. The roster, primary system, sample size, threshold, ridge, carrier and endpoint remain fixed throughout confirmation.

## S2. Receiver and physical-query conventions

### S2.1. Observation and cross-prediction

The verifier knows the candidate clean source and retains eight actual serialized issued copies. Clean and enrollment access is 112 s. A query exposes five 8 s scoring windows beginning at 8, 24, 40, 56 and 72 s, with 128 visible contextual samples per side at 160 Hz. These disjoint contexts give 40 s scored and 48 s observed. Query processing uses these visible contexts.

Each held-out-window fold chooses the coarse response on the other four windows and uses their lower-median lag for common alignment. Preliminary normalized cross-correlation searches lags from -128 to +128 samples. The inherited coarse bank contains channel centering alone; fourth-order 2-35 Hz Butterworth forward-backward filtering; fourth-order 2-35 Hz elliptic forward-backward or causal filtering with 1 dB ripple and 40 dB stopband; and causal 129-tap 2-35 Hz FIR filtering. Each coarse candidate is followed by channel centering. A fourth-order 8-30 Hz forward-backward Butterworth analysis filter operates within each visible aligned context, and only its central scored window is read.

The three P190 received conditions are re-export, causal fifth-order elliptic 1.7-32.5 Hz (1.3 dB ripple, 50 dB stopband) and causal sixth-order phase-normalized Bessel 3-33 Hz. The true received filter parameters and condition labels are unavailable to extraction. Historical eight-condition receiver panels and four-condition task panels retain their separate condition lists.

### S2.2. Response fitting and score heads

For a coarse-compensated query, let $v$ be its normalized residual from the clean reference, $A$ the 129-column clean convolution design, $T=[t_1,\ldots,t_8]$ the actual enrollment residuals and $D_i$ the convolution design of $t_i$. Channelwise temporal centering and clean-reference RMS normalization are common to every branch. At ridge factor $\rho$, the absolute penalty is

$$
\lambda=\rho\operatorname{tr}(A^\top A)/129,\qquad \rho\in\{10^{-4},10^{-6}\}.
$$

The candidate-conditioned fit on the four fitting windows is

$$
\widehat h_i=\arg\min_h\|(v-t_i)-(A+D_i)h\|_2^2+\lambda\|h\|_2^2.
$$

Its held-out residual prediction is $t_{i,w}+(A_w+D_{i,w})\widehat h_i$. Thus response fitting retains the convolution between the issued fingerprint and temporal response. The ordinary branch fits $v$ to $A$; the projected branch fits $P_T^\perp v$ to $P_T^\perp A$, where $P_T^\perp=I-TT^\dagger$. Both use the same absolute penalty at a common $\rho$. Variable elimination and matched-subspace geometry provide the classical foundations [@golub1973separable; @scharf1994matched]. Candidate fitting uses eight response fits per fold; ordinary and projected fitting use one.

Summing held-out errors over five folds gives fixed-candidate residuals $R_i$. Let $R_{(1)}$ and $R_{(2)}$ be the two smallest residuals. The clean-reference null $R_0$ is fitted to the same suspect query on the other four windows. The unrestricted identity residual $R_U$ uses the same fitted response; the candidate branch takes the minimum over its eight conditional unrestricted fits. The heads are

$$
S_C=R_U/R_{(1)},\qquad S_G=1-R_{(1)}/R_{(2)},\qquad S_P=1-R_{(1)}/R_0.
$$

Heads are clipped to $[0,1]$. The fixed base eligibility requires positive top gain and a nonnegative median fold peak. Support is the number of five per-window winners agreeing with the pooled winner, with options one or three. Every recalibrated procedure retains $S_P\ge0.25$. Configuration order is $10^{-4}$ then $10^{-6}$, compatibility/gap/presence within each ridge, and support one then three within each head. The resulting twelve configurations give index 6 as weak ridge, compatibility and support one. The final decision accepts the pooled winner when all eligibility conditions hold and the chosen score is at least its threshold.

For numerical residual calculations, fixed-identity RSS is $\max(0,d+G_{ii}-2b_i)$; the unrestricted coefficient uses `lstsq(G,b,rcond=1e-7)` and residual $\max(0,d-b^\top\widehat\beta)$. The floor is $64\epsilon_{\rm machine}\max(\sum d,\sum\operatorname{tr}G,10^{-30})$, pooled across the relevant shared or eight conditional triples. Compatibility is one when $R_{(1)}$ is at most the floor; gap and presence use the corresponding floored denominators. Stable global sorting and per-window first minima resolve candidate ties. The projected nuisance pseudoinverse tolerance is $10^{-9}$. These inherited numerical conventions and source files are hash-bound by the freeze.

### S2.3. Serialization and physical matching

All physical budgets are checked after a real 16-bit EDF round-trip. For issued error $e=Y-X$, temporal channel centering $\mathcal A$ and fixed 8-30 Hz analysis filter $F$, the requirements in percent are

$$
100\|e\|_F/\|\mathcal AX\|_F\le0.25,\qquad
100\max_c\|e_c\|_2/\|\mathcal AX_c\|_2\le0.5,\qquad
100\|Fe\|_F/\|FX\|_F\le1.
$$

Registered carriers match the realized global distortion for each source and recipient with relative spread at most 0.001. QIM-ID supplies actual EDF anchors; levels 0.5, 0.75 and 1 retain the frozen issuance and physical-matching rule. Other active constraints can place realized global PRD below its cap. Unknown copies retain their parent's declared anchor.

The EDF digital range is $[-32768,32767]$. Gain is $(p_{\max}-p_{\min})/65535$, and digital conversion uses tie-to-even rounding. Query ranges are common to each target and processing condition, computed from transformed clean plus every wrong-source signal allocated to that role. The range margin is the larger of $5\,\mu\mathrm V$ and 5% of peak-to-peak amplitude. It is fixed before marked-query serialization and carries no recipient-specific scale. Pre-serialization clipping fails issuance; read-back checks the expected LSB and at most 0.50001 LSB rounding error. Failure remains distinct from a receiver rejection.

## S3. Carriers, unknown families and planned counts

The phase carrier applies a common eight-coordinate rotation across channels in four-second blocks. For frequency group $g(f)$ in the eight groups spanning 8-30 Hz,

$$
X'_{c,b}(f)=X_{c,b}(f)\exp\{\mathrm i(-1)^b\alpha u_{r,g(f)}\}.
$$

Direct phase inverse-transforms this signal. Smooth phase multiplies only the resulting residual by a Tukey taper of parameter 0.125 before adding it to the clean source. Spatial coding uses a skew-symmetric channel rotation; hybrid coding allocates nominal component energy 95% to smooth and 5% to spatial before actual distortion matching. Phase modulation and differential phase coding have established audio precedents [@bender1996hiding; @sonoda2004periodical; @takahashi2005multiple].

The QIM-ID control retains the inherited DCT/lattice primitives, dither, permutation and public identity-independent source/frame scales [@chen2001qim; @efe2026network]. Fourteen 8 s frames carry 640-chip words formed by twenty repetitions of an order-32 Walsh row. Rows 1-8 are registered; rows 9-16 are legal unregistered identities. The words have pairwise Hamming distance 320. Sixteen one/two-chip modifications form an out-of-encoder pressure family. The earlier native 45-byte payload decoder is historical context; the current fifth arm is identity-only QIM.

Primary unknowns use unit recipient-code neighbors $u(\theta)=\cos(\theta)u_r+\sin(\theta)v$, where $v$ is a unit tangent orthogonal to $u_r$. The values 0.025 and 0.0125 parameterize this code-neighborhood angle; actual EEG phase rotation depends on the issued strength $\alpha$ and frequency-group coordinates. Spatial and hybrid use the same recipient-code family with their own carrier transforms and actual stored-distortion matching. Development uses one fixed tangent direction at 0.025; confirmation retains two fixed original directions, for sixteen primary unknown identities. Eight direction-0 offset-0.0125 identities form the tighter pressure family. The registered codebooks, tangents and generation seeds are retained in the frozen source/asset manifest. Legal QIM unknowns keep their native code geometry, separate from these unit-code angles. The 0.0125 and QIM-chip families are excluded from threshold fitting, configuration selection, deletion populations and all selection diagnostics; their frozen outcomes are reported separately.

**Table S2.** Planned query counts per target, carrier and strength. The last column includes three processing conditions. Primary denotes phase-0.025 or legal QIM identities.

| Role and carrier | Registered | Primary | Pressure | Clean | Wrong-source | Queries per target/level |
|---|---:|---:|---:|---:|---:|---:|
| DEV non-QIM carrier | 8 | 8 | 8 | 1 | 2 | 81 |
| DEV QIM-ID | 8 | 8 | 16 | 1 | 2 | 105 |
| Confirmation non-QIM carrier | 8 | 16 | 8 | 1 | 4 | 111 |
| Confirmation QIM-ID | 8 | 8 | 16 | 1 | 4 | 111 |

Four non-QIM carriers, three levels and eight development targets contribute 7,776 observations; QIM-ID adds 2,520, totaling 10,296. The fixed confirmation panel plans 13,320 observations across eight targets, five carriers, three levels and three conditions. Counts remain separated by carrier, family and role. Registered coverage uses planned opportunities; unknown/control acceptance reports evaluated denominators with every infeasible planned item identified. Complete registered, primary and control evaluation is required for nominal admissibility and full confirmation. A pressure-only issuance failure is recorded as failure, with no successful-rejection credit.

## S4. Calibration and selection rules

### S4.1. Threshold and fixed-evidence person deletion

For configuration $k$, the split threshold is the next representable float above the maximum eligible nonpressure negative score on fit people, or zero if there is no eligible negative. Since acceptance is inclusive, this immediate successor lies above every eligible fit-negative score. Eligibility includes the fixed presence criterion.

Each canonical fit person is omitted once. Deletion removes every saved row naming that person in either target-source or negative-source provenance, including crossed wrong-source queries and all session aliases. Four target plus two wrong-source people yield six deletions. Let $t_k^{(-p)}$ be the threshold from the remaining rows. Then

$$
\delta_k=\max_p\{t_k-t_k^{(-p)}\}.
$$

This calculation uses fixed serialized issued/query EDF bytes and fixed receiver scores; quantization ranges are retained unchanged. Delta therefore measures person-attributed threshold influence in saved evidence. Each audit entry retains the omitted canonical key, remaining eligible-negative count, recomputed threshold and threshold decrease.

### S4.2. Feasibility, ordering and fallback

Select people are disjoint from fit people in both provenance roles. A configuration is nominally admissible only with a complete registered/primary/control panel, source-equal mean correct registered coverage at least 0.95, minimum-source coverage at least 0.90 and zero clean/wrong acceptance at $t_k$. Every declared source-by-processing cell must contain evaluated primary evidence.

For an admissible configuration, evaluate $t_k-\delta_k$, $t_k$ and $t_k+\delta_k$ without clipping. Selection uses the following lexicographic order:

1. Minimize the largest source-by-processing primary acceptance at the lower threshold.
2. Minimize source-equal mean primary acceptance at the lower threshold.
3. Maximize minimum-source registered coverage at the upper threshold.
4. Minimize source-equal decision changes between the lower and upper thresholds.
5. Maximize nominal source-equal registered coverage.
6. Choose the earliest configuration index.

For step 4, each select person's change fraction counts different returned decisions over evaluated registered plus nonpressure primary queries, then averages equally across people. Clean/wrong controls enter nominal feasibility and control summaries, while the change objective uses registered and primary queries. Fit-only thresholds are retained after selecting the configuration.

If no configuration is admissible, the control-first fallback minimizes, in order, nominal control-acceptance count, the positive deficit from 0.95 mean coverage, the positive deficit from 0.90 minimum-source coverage, then the six-element objective above. The development-target flag remains false. This fallback fixes a reportable rule without satisfying the declared development objective.

Leave-one-select-target stability retains all fit scores, thresholds and deltas, removes one of the four select targets and its derived rows, and repeats selection. An infeasible deletion counts as a nonmatch. The stability gate requires at least three of four admissible deletion choices to match the full-select index.

### S4.3. Comparators and operating levels

**Table S3.** Calibration comparisons. The five recalibrated procedures share the same eight DEV targets, four wrong-source people, twelve-configuration menu, receiver evidence, processing grid, eligibility logic and family weights. Historical rules retain their original different DEV set.

| Procedure | Threshold evidence | Configuration rule |
|---|---|---|
| Pooled-original | Fit and select negatives pooled | Maximum pooled correct registered count, then earliest index |
| Fixed-weak-pooled | Fit and select negatives pooled | Fixed index 6 |
| Split-maxcoverage | Fit negatives only | Maximum select correct registered count, then earliest index |
| Fixed-weak-split | Fit negatives only | Fixed index 6 |
| Source-stable | Fit negatives only | Nominal feasibility and perturbation ordering |
| Historical freeze | Original frozen historical DEV | Original configuration, threshold and presence rule |

The primary common point is smooth carrier, candidate-conditioned FIR, level 1. Pooled-original and fixed-weak-pooled are the two primary baseline contrasts; the split procedures separate threshold fitting from the configuration objective. A development-only operating analysis selects the lowest level in {0.5, 0.75, 1} with complete nominal select evidence, mean registered coverage at least 0.95, minimum-source coverage at least 0.90, zero primary acceptance and zero clean/wrong acceptance. A procedure with no eligible level retains that outcome. Historical operating choices retain their original freeze.

![Person-separated calibration and confirmation](figures/P190_workflow.pdf)

**Figure S1.** Threshold fitting, six canonical-person deletions, disjoint configuration selection and one frozen confirmation. Deletion measures influence in fixed saved evidence. Five recalibrated procedures share development inputs and the configuration menu; the historical frozen rule is separate. Pressure families enter reporting only.

## S5. Development result fixed before confirmation

Development completed all 120 source/level/carrier groups and 10,296 planned observations, with no infeasible observation. At the primary smooth/candidate/level-1 point, all five recalibrated rules selected exactly the same configuration and numerical threshold: index 6, $\rho=10^{-6}$, compatibility, support one, threshold 0.9957274054693162 and presence gate 0.25. Source-stable was nominally feasible and matched its full-select index in all four select-person deletions.

These identical decision functions return the same decision on any common future query evidence. Accordingly, the planned positive primary improvement over pooled-original and fixed-weak-pooled is unattainable at this common point. This preconfirmation result separates the shared multisource calibration outcome from an independent benefit of the added selector. The original primary point and independent cohort remain fixed; confirmation measures transfer of the shared rule, the historical comparison and the prespecified receiver/carrier/strength/processing panel.

The exact evidence is `DEV_PRIMARY_RULE_EQUIVALENCE.json`, linked to `DEVELOPMENT_SELECTION.json` SHA-256 `5c90641847af85f627a5e7df97e348b12ade098d4662cc620ff511404f17a614`. The completed DEV collection receipt has SHA-256 `7ff72a83c1c19728c72e24b667b3ddf2be6e6903c314f8d65ee6c0396e46986b`.

Pooled development coverage at the primary point is 191/192 for index 0 (threshold 0.9983738237739442) and 192/192 for index 6 (threshold 0.9957274054693162). The simple maximum-coverage objective therefore resolves the old configuration tie in the expanded development panel.

## S6. Complete confirmation criteria and inference

### S6.1. Person endpoints and conditional scope

Each of the eight confirmation targets supplies one coverage and one primary-acceptance value per procedure. Coverage averages equally over eight registered identities and three processing conditions. Phase primary acceptance averages equally over two 0.025 directions, eight parents and three conditions. Comparisons use the resulting eight paired target values. Processing-specific results accompany these averages.

The target contrasts and uncertainty are conditional on the fixed shared wrong-source/range fixture, identities and processing grid. Each target's query EDF range is computed from its transformed clean plus the same four allocated wrong-source people, and calibration procedures share those actual bytes. The fixed sequential cohort supplies eight target units; person-level t inference requires independent participant effects and the paired-difference distributional approximation. Wrong-source variation is described by four negative people, with all target-by-negative-source-by-condition cells retained. The 32 target/negative pairs retain four negative people as their control units.

For a proposed rule and baseline $b$, define $d_{C,i}=C_{{\rm prop},i}-C_{b,i}$ and $d_{A,i}=A_{{\rm prop},i}-A_{b,i}$. Coverage retention and lower acceptance are distinct targets. Each baseline contrast tests one-sided coverage noninferiority at margin -0.05 and one-sided acceptance superiority against zero:

$$
H_{0,C}:\mathbb E[d_C]\le-0.05,\qquad
H_{0,A}:\mathbb E[d_A]\ge0.
$$

The paired t statistics use eight people and seven degrees of freedom. The intersection-union contrast p value is $\max(p_C,p_A)$. Holm adjustment applies to the two contrast p values against pooled-original and fixed-weak-pooled at family alpha 0.05. Both adjusted contrasts must reject for full inferential confirmation. Reported paired 95% intervals are $\overline d\pm t_{0.975,7}s_d/\sqrt8$.

### S6.2. Full success gate

Complete prespecified success requires the inferential criterion and every empirical/development condition below. Empirical gate comparisons use the frozen numerical tolerance $10^{-12}$ where specified by the implementation.

**Table S4.** Joint success requirements. Each outcome condition must hold against both primary baselines.

| Component | Requirement |
|---|---|
| Completeness | Complete proposed and baseline registered, primary and clean/wrong panels |
| Absolute coverage | Proposed source-equal mean correct coverage at least 0.95 |
| Observed coverage loss | Mean proposed-minus-baseline coverage at least -0.02 |
| Coverage interval | Paired 95% interval lower bound at least -0.05 |
| Practical specificity | Mean primary acceptance reduction at least 0.05 |
| Person directions | At least 6/8 nonworse primary acceptance and at least 2/8 strictly better |
| Worst person and spread | Worst-target primary acceptance and across-target sample SD do not increase |
| Attribution and controls | Registered misattribution, clean acceptance and wrong-source acceptance do not increase |
| Causal processing | Source-mean primary acceptance within elliptic and within Bessel does not increase |
| Development | Source-stable nominal feasibility and at least 3/4 select-person stability |
| Inference | Both baseline intersection-union contrasts pass Holm at family alpha 0.05 |

Strict person improvement uses $d_A<-10^{-12}$; nonworse uses $d_A\le10^{-12}$. Complete missing endpoints receive no imputation. They remain failed or undefined outcomes under the frozen accounting and cannot be replaced with another person. The practical five-percentage-point reduction remains separate from the superiority null of zero.

### S6.3. Degenerate differences and sensitivity

Zero sample variance produces a collapsed empirical interval at the observed constant difference. For a nonzero shift from the specified null, the one-sided t p value uses its limiting direction; when every difference equals the null, p=1. All empirical values and the degenerate flag remain in the record. Such intervals describe observed paired differences and their model convention.

All $2^8=256$ sign assignments provide the prespecified sensitivity analysis. Differences are centered at the endpoint's null (-0.05 for coverage noninferiority, zero for acceptance), and every sign-flipped mean is retained. Tail calculations use tolerance $10^{-12}$. The interpretation assumes independent person differences symmetric about the specified null. The paired t/IUT/Holm analysis remains primary. Descriptive difference plots, shape checks and outlier summaries retain their reporting role without changing the primary test.

Neyman-Pearson classification and Learn then Test provide existing statistical risk-control principles [@tong2018np; @angelopoulos2025ltt], including an EEG seizure-prediction application [@segal2023eegltt]. P190 evaluates an empirical threshold-influence procedure under the stated finite-cohort contract. Its measured acceptance rates retain that contract; the threshold deletion is an influence diagnostic.

## S7. Frozen independent-person confirmation

All 120 new confirmation groups and 13,320 observations completed with no infeasible item. At the primary point, all five recalibrated rules give 192/192 correct, 0/384 primary acceptance and 30/192 pressure acceptance. The latter are all elliptic observations (30/64); re-export and Bessel each have zero pressure acceptance. Historical pressure counts are 27 elliptic and 14 Bessel.

The full prespecified confirmation criterion fails. Against each principal baseline, coverage and primary-acceptance differences are zero for all eight people, with empirical paired intervals [0,0]. Both IUT and Holm-adjusted p values are 1. The required five-point reduction and two strictly improved people fail against both baselines. Other empirical/development gates pass. Primary sign-flip sensitivity is also p=1. This is exact decision equivalence, independent of statistical power.

This section presents only the once-frozen new-person confirmation. Eight target people and four shared wrong-source people retain their declared statistical roles. The machine-readable result includes every policy, stratum and planned/evaluated/infeasible denominator.

### Primary result by target person

**Table S5.** Smooth/candidate-conditioned FIR/level 1 under source-stable. All five recalibrated procedures have the identical primary rule. Primary near identities have code angle .025; pressure identities have angle .0125.

|Target|Correct / planned|Rejected|Misattributed|.025 accepted / evaluated|.0125 accepted / evaluated|Clean / evaluated|Wrong / evaluated|
|---|---:|---:|---:|---:|---:|---:|---:|
|OpenBMI005|24/24|0|0|0/48|7/24|0/3|0/12|
|OpenBMI006|24/24|0|0|0/48|4/24|0/3|0/12|
|OpenBMI007|24/24|0|0|0/48|5/24|0/3|0/12|
|OpenBMI008|24/24|0|0|0/48|3/24|0/3|0/12|
|OpenBMI009|24/24|0|0|0/48|6/24|0/3|0/12|
|OpenBMI010|24/24|0|0|0/48|3/24|0/3|0/12|
|OpenBMI011|24/24|0|0|0/48|2/24|0/3|0/12|
|OpenBMI012|24/24|0|0|0/48|0/24|0/3|0/12|

### Primary result by processing condition

**Table S6.** Registered correct, primary acceptance and pressure acceptance for the primary system. Each cell gives correct/primary/pressure counts. Their evaluated denominators are 64/128/64 per condition when the panel is complete. The historical rule retains its original development set.

|Condition|Pooled|Weak pooled|Split max|Weak split|Stable|Historical|
|---|---:|---:|---:|---:|---:|---:|
|reexport|64/0/0|64/0/0|64/0/0|64/0/0|64/0/0|64/0/0|
|elliptic new causal|64/0/30|64/0/30|64/0/30|64/0/30|64/0/30|64/0/27|
|bessel shifted causal|64/0/0|64/0/0|64/0/0|64/0/0|64/0/0|64/0/14|

### Complete common-level receiver and carrier grid

Tables S7-S15 retain all three receiver branches, three strengths, five carriers and six frozen policies. Each cell is registered correct / primary unknown accepted / pressure unknown accepted. In a complete panel, phase-carrier denominators are 192/384/192 and QIM-ID denominators are 192/192/384. QIM legal unknowns and chip forgeries retain native geometry. An asterisk flags any infeasible observation; these are reported below and never credited as rejection.

**Table S7.** ordinary FIR, level 0.5.

|Carrier|Pooled|Weak pooled|Split max|Weak split|Stable|Historical|
|---|---:|---:|---:|---:|---:|---:|
|Smooth|8/15/8|11/1/1|27/26/20|11/1/1|27/26/20|89/138/85|
|Direct|0/0/0|14/0/1|36/34/29|14/0/1|36/34/29|105/176/100|
|Hybrid|8/15/8|14/1/3|22/20/13|14/1/3|22/20/13|34/29/22|
|Spatial|131/17/34|131/17/34|138/19/36|138/19/36|138/19/36|167/92/104|
|QIM-ID|192/0/384|192/0/384|192/0/384|192/0/384|192/0/384|192/0/384|

**Table S8.** ordinary FIR, level 0.75.

|Carrier|Pooled|Weak pooled|Split max|Weak split|Stable|Historical|
|---|---:|---:|---:|---:|---:|---:|
|Smooth|9/9/7|29/0/7|35/46/30|29/0/7|35/46/30|80/99/69|
|Direct|7/5/4|21/0/3|50/68/42|21/0/3|50/68/42|112/152/99|
|Hybrid|8/8/6|21/1/6|23/32/17|21/1/6|23/32/17|23/32/18|
|Spatial|115/7/23|115/7/23|104/0/7|115/7/23|104/0/7|176/78/85|
|QIM-ID|192/0/384|192/0/384|192/0/384|192/0/384|192/0/384|192/0/384|

**Table S9.** ordinary FIR, level 1.

|Carrier|Pooled|Weak pooled|Split max|Weak split|Stable|Historical|
|---|---:|---:|---:|---:|---:|---:|
|Smooth|8/6/4|36/2/12|39/50/29|36/2/12|39/50/29|16/29/16|
|Direct|4/1/3|37/0/8|60/80/46|37/0/8|60/80/46|24/32/16|
|Hybrid|5/5/4|24/2/9|21/35/16|24/2/9|21/35/16|17/34/16|
|Spatial|108/3/21|108/3/21|108/3/21|108/3/21|108/3/21|184/165/135|
|QIM-ID|192/0/384|192/0/384|192/0/384|192/0/384|192/0/384|192/0/384|

**Table S10.** projected FIR, level 0.5.

|Carrier|Pooled|Weak pooled|Split max|Weak split|Stable|Historical|
|---|---:|---:|---:|---:|---:|---:|
|Smooth|140/0/25|140/0/25|140/0/25|140/0/25|140/0/25|136/0/17|
|Direct|138/0/22|127/0/14|138/0/22|127/0/14|138/0/22|145/0/25|
|Hybrid|141/0/32|135/0/25|141/0/32|135/0/25|141/0/32|141/0/32|
|Spatial|182/16/35|182/16/35|182/16/35|182/16/35|182/16/35|181/103/108|
|QIM-ID|192/0/384|192/0/384|192/0/384|192/0/384|192/0/384|192/0/384|

**Table S11.** projected FIR, level 0.75.

|Carrier|Pooled|Weak pooled|Split max|Weak split|Stable|Historical|
|---|---:|---:|---:|---:|---:|---:|
|Smooth|170/0/24|158/0/27|170/0/24|158/0/27|170/0/24|174/0/39|
|Direct|165/0/21|156/0/19|165/0/21|156/0/19|165/0/21|175/0/42|
|Hybrid|168/0/30|161/0/34|168/0/30|161/0/34|168/0/30|173/0/41|
|Spatial|170/4/25|170/4/25|170/4/25|170/4/25|170/4/25|192/156/131|
|QIM-ID|192/0/384|192/0/384|192/0/384|192/0/384|192/0/384|192/0/384|

**Table S12.** projected FIR, level 1.

|Carrier|Pooled|Weak pooled|Split max|Weak split|Stable|Historical|
|---|---:|---:|---:|---:|---:|---:|
|Smooth|171/0/17|168/0/32|171/0/17|168/0/32|171/0/17|175/0/40|
|Direct|167/0/20|167/0/20|167/0/20|167/0/20|167/0/20|176/0/46|
|Hybrid|171/0/18|166/0/37|171/0/18|166/0/37|171/0/18|176/1/54|
|Spatial|171/0/20|171/0/20|171/0/20|171/0/20|171/0/20|192/176/140|
|QIM-ID|192/0/384|192/0/384|192/0/384|192/0/384|192/0/384|192/0/384|

**Table S13.** candidate FIR GLRT, level 0.5.

|Carrier|Pooled|Weak pooled|Split max|Weak split|Stable|Historical|
|---|---:|---:|---:|---:|---:|---:|
|Smooth|187/0/24|187/0/24|187/0/24|187/0/24|187/0/24|188/0/30|
|Direct|185/0/15|185/0/15|185/0/15|185/0/15|185/0/15|188/0/27|
|Hybrid|183/0/20|183/0/20|183/0/20|183/0/20|183/0/20|190/0/30|
|Spatial|188/18/36|188/18/36|190/23/47|190/23/47|190/23/47|182/106/109|
|QIM-ID|192/0/384|192/0/384|192/0/384|192/0/384|192/0/384|192/0/384|

**Table S14.** candidate FIR GLRT, level 0.75.

|Carrier|Pooled|Weak pooled|Split max|Weak split|Stable|Historical|
|---|---:|---:|---:|---:|---:|---:|
|Smooth|192/0/26|192/0/26|190/0/32|192/0/26|190/0/32|192/0/28|
|Direct|192/0/22|192/0/22|192/0/22|192/0/22|192/0/22|190/0/48|
|Hybrid|192/0/29|192/0/29|192/0/29|192/0/29|192/0/29|189/0/49|
|Spatial|184/4/25|184/4/25|184/4/25|184/4/25|184/4/25|192/157/132|
|QIM-ID|192/0/384|192/0/384|192/0/384|192/0/384|192/0/384|192/0/384|

**Table S15.** candidate FIR GLRT, level 1.

|Carrier|Pooled|Weak pooled|Split max|Weak split|Stable|Historical|
|---|---:|---:|---:|---:|---:|---:|
|Smooth|192/0/30|192/0/30|192/0/30|192/0/30|192/0/30|192/0/41|
|Direct|192/0/25|192/0/25|192/0/25|192/0/25|192/0/25|192/0/46|
|Hybrid|191/0/20|192/0/35|191/0/20|192/0/35|192/0/35|192/0/60|
|Spatial|185/0/21|185/0/21|185/0/21|185/0/21|185/0/21|192/177/141|
|QIM-ID|192/0/384|192/0/384|192/0/384|192/0/384|192/0/384|192/0/384|

### Controls and failed-observation accounting

The clean/wrong-source denominators are 24/96 for each carrier-strength-receiver-policy summary in the complete panel. The 96 wrong-source cells reuse four people. They are descriptive checks rather than 96 independent negative people.

Nonzero control outcomes: zero across all 270 frozen group-policy summaries.

Infeasible observations: zero across all 270 frozen group-policy summaries.

Registered misattributions: zero across all 270 frozen group-policy summaries.

### Shared wrong-source people at the primary point

**Table S16.** Source-stable wrong-source checks. Each target-by-negative entry aggregates its three conditions. Rows are target people, while the four negative columns identify the four distinct negative people.

|Target|OpenBMI013|OpenBMI014|OpenBMI015|OpenBMI016|
|---|---:|---:|---:|---:|
|OpenBMI005|0/3|0/3|0/3|0/3|
|OpenBMI006|0/3|0/3|0/3|0/3|
|OpenBMI007|0/3|0/3|0/3|0/3|
|OpenBMI008|0/3|0/3|0/3|0/3|
|OpenBMI009|0/3|0/3|0/3|0/3|
|OpenBMI010|0/3|0/3|0/3|0/3|
|OpenBMI011|0/3|0/3|0/3|0/3|
|OpenBMI012|0/3|0/3|0/3|0/3|

### Measured issuance distortion

**Table S17.** Registered actual-EDF PRD in percent over eight target people and eight recipient identities per row. Matching spread is the maximum source-identity relative spread over all five carriers at that strength. These physical summaries read issuance receipts and perform no new serialization.

|Carrier|Level|Mean global PRD (%)|Global range (%)|Max channel PRD (%)|Max band PRD (%)|Max relative spread|
|---|---:|---:|---:|---:|---:|---:|
|Smooth|0.5|0.06131|0.03253-0.10249|0.13685|0.40528|0.0008280|
|Direct|0.5|0.06131|0.03252-0.10249|0.13411|0.40440|0.0008280|
|Hybrid|0.5|0.06131|0.03254-0.10246|0.13420|0.39585|0.0008280|
|Spatial|0.5|0.06131|0.03253-0.10246|0.18882|0.17241|0.0008280|
|QIM-ID|0.5|0.06134|0.03254-0.10253|0.14469|0.41521|0.0008280|
|Smooth|0.75|0.09204|0.04853-0.15304|0.20554|0.61229|0.0007411|
|Direct|0.75|0.09203|0.04853-0.15305|0.20044|0.61228|0.0007411|
|Hybrid|0.75|0.09204|0.04853-0.15304|0.20291|0.59703|0.0007411|
|Spatial|0.75|0.09204|0.04851-0.15304|0.28106|0.26033|0.0007411|
|QIM-ID|0.75|0.09207|0.04855-0.15312|0.21495|0.62877|0.0007411|
|Smooth|1|0.12244|0.06479-0.20451|0.27419|0.80935|0.0006395|
|Direct|1|0.12244|0.06479-0.20447|0.26783|0.80931|0.0006395|
|Hybrid|1|0.12244|0.06479-0.20451|0.26794|0.78922|0.0006395|
|Spatial|1|0.12244|0.06479-0.20449|0.37758|0.34285|0.0006395|
|QIM-ID|1|0.12248|0.06482-0.20456|0.28939|0.83055|0.0006395|

![Candidate policy transfer differences](figures/P190_transfer.pdf)

**Figure S2.** Source-stable minus pooled-original primary-acceptance difference in percentage points, for every candidate-receiver carrier/strength/processing cell. Gold outlines identify coverage below .95 or positive clean/wrong outcomes. The spatial/level-0.5/elliptic difference is +3.90625 points; all other cells are zero. Phase and legal-QIM primary geometries remain distinct.

## S8. Retained historical receiver, carrier and calibration evidence

### S8.1. Receiver and carrier context

The historical nine-participant BCI2a causal-Bessel comparison used a common level-0.5 smooth point with approximately 0.0999% actual global PRD. Every method had the same clean/enrollment access and twelve-configuration development budget. All registered errors below were rejections, with zero misattributions; each method rejected all nine clean and nine fixed wrong-source fixtures.

**Table S18.** Historical P189 receiver results at its common low point. Each identity-family denominator is 72; these are nine BCI participants, separate from the new OpenBMI cohort.

| Receiver | Correct registered | Primary 0.025 accepted | Pressure 0.0125 accepted |
|---|---:|---:|---:|
| Ordinary FIR | 36 | 36 | 36 |
| Projected FIR | 60 | 6 | 42 |
| Candidate FIR | 72 | 0 | 0 |

At this historical low point, candidate smooth, direct and hybrid each accepted zero of 72 in both phase-unknown strata. Spatial accepted 7/72 primary and 67/72 pressure queries. QIM-ID correctly registered 72/72, rejected all 72 legal Walsh unknowns and accepted all 144 chip modifications. The phase, legal-QIM and chip families retain these different code geometries. Measured historical warm-query times on sixteen fixed calls with one numerical thread were approximately 75.25/75.02/222.23 ms for ordinary/projected/candidate fitting; the workload and implementation define that comparison.

Historical serialization diagnostics found no exact collision among 192 issued or 1,536 processed unknown/parent pairs. Smooth direction-0 primary and pressure differences had median 0.342/0.243 LSB RMS and changed 11.69%/5.89% of samples. Distinct EDF samples coexist with receiver- and calibration-dependent acceptance.

### S8.2. The retained pressure counterexample

Retrospective replay in P189 identified configurations tied under the old maximum-coverage objective. The original earliest-index policies remained primary throughout that release.

**Table S19.** Historical candidate-FIR tie replay. Each triple is correct registered/primary accepted/pressure accepted. The bridge uses the two retained OpenBMI sources and denominator 128 per outcome; the BCI level-1 panel uses denominator 72.

| Historical panel | DEV coverage at both configurations | Frozen index 0 | Tied index 6 |
|---|---|---|---|
| OpenBMI bridge | 64/64 | 128/0/5 | 128/0/12 |
| BCI smooth level 1 | 24/24 | 72/16/59 | 72/0/0 |

Thus the weak-ridge alternative lowered BCI primary and pressure acceptance while raising retained-OpenBMI pressure acceptance from 5/128 to 12/128. These historical outcomes motivate prespecified calibration and remain separate from its new-person evaluation. The P190 primary rule equality in S5 is a new development fact, not a selection of the favorable historical BCI replay.

### S8.3. Bounded learned-carrier adaptation and DC control

The historical public-structure RPW adaptation retained native thirty-bit, eight-second messages [@qin2025rpw]. Its substantive follow-up completed 3,600 training steps, 28,800 window exposures and 600 discriminator steps, with an additional zero-temporal-mean residual constraint. The two declared checkpoints at 2,400/3,600 steps recovered 1,431/2,880 and 1,437/2,880 development bits, with zero of 96 exact messages at each checkpoint; development selected step 3,600. This failed the declared usable-payload gate of 95% bit and 50% exact-message recovery. Maximum actual global/channel/band PRDs at the selected checkpoint were 0.239813%/0.477156%/0.533159%. The bounded development adaptation remains outside the successful matched-carrier ranking.

A paired 300-step, training-only control removed the additional zero-DC projection while retaining BCE loss, blend factor one and training-only batch-normalization calibration. At initialization, the projection removed 86.48% of native message-dependent variation. Both the zero-DC and DC-allowed runs recovered 174/240 bits, zero of eight exact messages and two distinct hard output codes. The DC-allowed maximum global/channel/band PRDs were 0.234210%/0.387068%/0.221438%, and the declared substantive-improvement trigger was false. This control measures the extra constraint over the stated short training horizon. Native RPW convergence and native DS-FTAN performance remain outside this measured comparison [@qin2025rpw; @zhang2026dsftan].

## S9. Retained historical task-output evidence

Historical task evidence uses the same nine BCI2a participants across the 45-event joint point, overlapping 270-event original-grid cohort and fixed +1 s encoder-origin intervention. Qualified CSP/LDA and EEGNet models remain frozen: training uses T runs 0-4 (240 trials), and selection uses run 5 (48 trials) [@ang2012fbcsp; @lawhern2018eegnet]. CSP/LDA chooses from broadband CSP4, four-band FBCSP2/FBCSP4 and RMS-normalized FBCSP2, with bands 8-12/12-18/18-24/24-30 Hz, Ledoit-Wolf covariance, training-only feature scaling and automatic-shrinkage LDA. EEGNet uses one trajectory per participant (seed 18504), selects among epochs 100/200/300 by DEV BA, cross-entropy and earlier epoch, and retains training-only normalization/batch-normalization recalculation. Every participant predicts all four classes and exceeds 25% DEV BA; cohort DEV means are 63.426%/60.648% for CSP/EEGNet. Model states are frozen before E evaluation.

Probability MAE compares marked predictions with identically processed clean predictions, averaging repeated identities, events and conditions within participant. The nine participant means are the inferential units. Historical paired-t intervals and exhaustive 512-sign-flip tests describe fixed-pipeline exploratory comparisons.

**Table S20.** Historical task-output measurements. MAE is multiplied by $10^4$; flips and BA changes are smooth/direct. BA changes are in percentage points.

| Scope | Model | Smooth MAE | Direct MAE | Flips | BA change |
|---|---|---:|---:|---|---|
| 45-event Bessel | CSP/LDA | 0.666688 | 0.732216 | 0/0 | 0/0 |
| 45-event Bessel | EEGNet | 1.346168 | 1.519430 | 0/0 | 0/0 |
| 270-event original grid | CSP/LDA | 1.617876 | 1.829708 | 0/0 | 0/0 |
| 270-event original grid | EEGNet | 2.204584 | 2.404203 | 4/5 | 0/-0.01085069 |
| 270-event grid +1 s | CSP/LDA | 1.505902 | 1.446113 | 0/0 | 0/0 |
| 270-event grid +1 s | EEGNet | 2.065974 | 1.982126 | 6/5 | -0.02325149/-0.01085069 |

The 45-event point has 360 repeated predictions per carrier/model. Both smooth/direct participant intervals include zero, with exact p=.0703125/.21484375 for CSP/EEGNet. Clean and marked BA is 47.222222%/38.888889%. The 270-event cohort uses four processing conditions and 8,640 repeated predictions per carrier/model. Its original-grid ordering favors smooth, with exact p=.0078125/.00390625; clean BA is 52.703373%/44.288746%. The overlapping event sets and separately matched physical issuance policies retain their own denominators and waveform definitions.

The fixed +1 s intervention changes nominal join crossings from 216/270 to zero and reverses the mean ordering for both models: all nine participants favor direct, with exact p=.00390625 for each model. A fixed-clean-lag counterfactual preserves all nine negative direct-minus-smooth differences, with means $-5.99814\times10^{-6}$ and $-8.38479\times10^{-6}$. Four one-sample query-lag changes therefore do not explain the reversal. The intervention jointly changes block transformation and rematched issuance strength, identifying encoder/task-geometry sensitivity. Counterfactual EEGNet class vectors are absent, so its BA change is unavailable. Shifted-grid attribution was not evaluated. These historical outcomes provide task context independently of the new OpenBMI attribution confirmation.

## S10. Saved-evidence reproduction and reporting interfaces

Signal collection publishes one atomic complete checkpoint for each role/target/level/carrier. Each checkpoint contains all three receiver branches and twelve configurations, source and issuance lineage, actual EDF digests, and planned/evaluated/failed denominators. Completed checkpoints are immutable. Separate source and issuance receipts retain actual serialized reference/copy hashes. The confirmation analysis applies frozen policies to those saved scores and performs no fitting.

`prepare_reporting.py` consumes complete `CONFIRMATION_RESULTS.json` and `DEVELOPMENT_SELECTION.json`. It writes `FROZEN_RESULTS_FOR_MANUSCRIPT.md`, `PRIMARY_TABLE_DATA.json`, and the transfer/person plots from the same frozen summaries. The primary table contains five recalibrated procedures plus historical freeze. Figures and tables retain evaluated unknown denominators, planned registered opportunities and explicit failure counts.

`reproduce_saved.py` reads the completed frozen DEV and confirmation scores, recomputes the pre-existing policies, select-person deletions and confirmation summaries, and compares them with immutable records. It writes a separate reproduction receipt. This scope recomputes score-level decisions and statistics; signal-level reproduction additionally requires the public raw recordings, frozen transforms/assets, acquisition receipts and numerical dependencies listed in the release. No new configuration, model, offset or operating point is introduced by either reporting or saved-score reproduction.

The source ledger below identifies the exact scientific material retained in this supplement. File paths are relative to `revision/post_20260926`.

**Table S21.** Source ledger for P190 protocol material and retained historical measurements.

| Material | Exact source |
|---|---|
| People, query counts, selection and full success | `p190_experiment_v1/PROTOCOL_BEFORE_DEVELOPMENT.md` |
| Conditional fixture and fixed-evidence deletion | `p190_experiment_v1/INTERPRETATION_BEFORE_CONFIRMATION.md` |
| Freeze chronology and completed DEV scope | `p190_experiment_v1/STATE_AFTER_FREEZE_20261030.md` |
| Canonical deletion, rank, fallback, decision-change calculation | `p190_calibration_v1/design.md` and `calibration_api.py` |
| Main-rule equality | `p190_experiment_v1/DEV_PRIMARY_RULE_EQUIVALENCE.json` and `DEVELOPMENT_SELECTION.json` |
| OpenBMI adapter and collection | `p190_experiment_v1/adapter.py` and `run_experiment.py` |
| Paired t, IUT, Holm and sign-flip conventions | `p190_experiment_v1/statistics_api.py` and `analysis.py` |
| Reporting and reproduction interfaces | `p190_experiment_v1/prepare_reporting.py`, `reproduce_saved.py` and `README_REPRODUCE.md` |
| Historical observation, fitting and QIM conventions | `p189_submission_manuscript_v1/technical_appendix.md`, S1-S2, S6 and S12.3-S12.4; `manuscript.md`, 3.1-3.5 |
| Historical receiver/carrier counts and costs | P189 `manuscript.md`, 5.1-5.3; P189 SI S4.3, S5.2 and S8 |
| Historical bridge pressure counterexample | P189 SI S12.1, Table S2 |
| Bounded learned-carrier failure and paired DC control | P189 SI H5 and H10.1 |
| Historical task scopes, reversal and accounting | P189 `manuscript.md`, 5.4; P189 SI S7.1-S7.3 and S13, Table S4 |

Completed saved-score reproduction matches all 45 receiver/carrier/strength groups, every pre-existing DEV policy and select-person deletion, all frozen confirmation summaries and the complete primary inference/gate decision. The matching receipt is `REPRODUCTION_CHECK_1793357543999699300.json`. It writes no new rule and decodes no raw EEG. The review archive preserves source paths and freeze hashes; the validated command runs in the original workspace and requires its public-data files/metadata.
