"""Read-only recount of saved decisions in the fixed six-person history snapshot."""
from collections import defaultdict
import gzip
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent
def load(path):
    return json.loads((ROOT / path).read_text(encoding='utf-8'))
def sha(data):
    return hashlib.sha256(data).hexdigest()
def check(value, message):
    if not value:
        raise ValueError(message)

snapshot = load('docs/history/P191_PARTIAL_SNAPSHOT.json')
index = load('docs/HISTORY_SCORE_SNAPSHOT_INDEX.json')
freeze = ROOT / snapshot['confirmation_freeze']['path']
freeze_sha = sha(freeze.read_bytes())
check(freeze_sha == snapshot['confirmation_freeze']['sha256'], 'freeze differs from snapshot')
check(len(index) == snapshot['n_complete_target_people'], 'source count')
fields = ('n','accepted','correct','misattributed','issuance_infeasible')
aggregate = {}
for record in index:
    data = (ROOT / record['package_path']).read_bytes()
    check(sha(data) == record['sha256'], 'saved-score bytes differ: '+record['source'])
    raw = json.loads(gzip.decompress(data))
    person = record['source']
    check(raw['status']=='complete' and raw['source']==person and raw['arm']=='smooth', 'score role')
    check(raw['confirmation_freeze_sha256']==freeze_sha, 'score freeze')
    check(len(raw['rows'])==raw['expected_n']==111, 'complete denominator')
    for method, expected in snapshot['per_person'][person].items():
        counts = {}
        for row in raw['rows']:
            family = ('registered' if row['kind']=='enrolled' else
                      'clean' if row['kind']=='clean' else
                      'wrong_source' if row['kind']=='wrong_source' else
                      'pressure0125' if row['pressure'] else 'phase025')
            key = row['condition']+'/'+family
            count = counts.setdefault(key, dict.fromkeys(fields,0))
            decision = row['decisions'][method]
            accepted = decision >= 0
            correct = accepted and family=='registered' and decision==row['identity']
            misattributed = accepted and family=='registered' and decision!=row['identity']
            count['n']+=1
            count['accepted']+=int(accepted)
            count['correct']+=int(correct)
            count['misattributed']+=int(misattributed)
            count['issuance_infeasible']+=int(not row['issuance_feasible'])
        check(counts==expected, 'person snapshot counts differ: '+person+'/'+method)
        total = aggregate.setdefault(method,{})
        for key, count in counts.items():
            bucket = total.setdefault(key,dict.fromkeys(fields,0))
            for field in fields:
                bucket[field]+=count[field]
check(aggregate==snapshot['aggregate_saved_counts'], 'aggregate saved counts differ')
report=[]
for method, values in aggregate.items():
    report.append({'method':method,
        'registered_correct':sum(v['correct'] for k,v in values.items() if k.endswith('/registered')),
        'registered_n':sum(v['n'] for k,v in values.items() if k.endswith('/registered')),
        'pressure_accepted':sum(v['accepted'] for k,v in values.items() if k.endswith('/pressure0125')),
        'pressure_n':sum(v['n'] for k,v in values.items() if k.endswith('/pressure0125')),
        'elliptic_pressure':values['elliptic_new_causal/pressure0125']})
print(json.dumps({'status':'saved_partial_snapshot_recount_passed',
    'observed_local':snapshot['observed_local'],'people':len(index),'complete_saved_rows':666,
    'results':report,'full_cohort_complete':False,'formal_inference_performed':False,
    'scope':'Tally supplied saved integer decisions only; no score computation, calibration, EEG processing or new inference.',
    'writes':False},ensure_ascii=False,indent=2))
