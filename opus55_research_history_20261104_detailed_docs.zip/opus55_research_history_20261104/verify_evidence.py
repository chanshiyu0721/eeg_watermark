"""Read-only saved-evidence review checks; Python 3.9+, standard library only.

Run: python verify_evidence.py [package-root]
Inputs use project-relative paths retained inside the review package. This does
not import research code, decode EEG, fit responses, train models, or write files.
Its checks concern arithmetic and consistency of supplied saved evidence.
"""
from pathlib import Path
import gzip
import hashlib
import json
import math
import sys

ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent
P191 = Path("output/paper/eeg_submission_p191_dev_v1")
CAP = Path("revision/post_20260926/p191_fir_capacity_v1")
P190 = Path("revision/post_20260926/p190_experiment_v1")
PAPER190 = Path("revision/post_20260926/p190_manuscript_v1")
ROLES = {"fit": ("OpenBMI001", "OpenBMI002", "A02T", "A03E"),
         "select": ("OpenBMI003", "OpenBMI004", "A05E", "A07E")}
FAMILIES = ("registered", "pressure0125", "near025", "clean", "wrong")
CONFIGS = ((129, "compatibility", 1e-6), (257, "compatibility", 1e-4),
           (129, "exact", 1e-4), (257, "exact", 1e-4))


def check(test, message):
    if not test:
        raise ValueError(message)


def raw(relative):
    path = ROOT / relative
    if path.is_file():
        data = path.read_bytes()
        return gzip.decompress(data) if str(path).endswith(".gz") else data
    # The large P190 summary may be losslessly gzip-packed in the review copy.
    packed = path.with_name(path.name + ".gz")
    if packed.is_file():
        return gzip.decompress(packed.read_bytes())
    aliases = {
        P190 / "CONFIRMATION_RESULTS.json": Path("evidence_archives/p190_CONFIRMATION_RESULTS.json.gz"),
        P190 / "DEVELOPMENT_SELECTION.json": Path("evidence_archives/p190_DEVELOPMENT_SELECTION.json.gz"),
    }
    if relative in aliases and (ROOT / aliases[relative]).is_file():
        return gzip.decompress((ROOT / aliases[relative]).read_bytes())
    raise FileNotFoundError(path)


def load(relative):
    return json.loads(raw(relative))


def close(actual, expected, label, rel=1e-10, absolute=1e-12):
    check(math.isfinite(actual) and math.isfinite(expected)
          and math.isclose(actual, expected, rel_tol=rel, abs_tol=absolute),
          label + ": " + repr((actual, expected)))


def family(row):
    if row["kind"] == "enrolled":
        return "registered"
    if row["kind"] == "clean":
        return "clean"
    if row["kind"] == "wrong_source":
        return "wrong"
    return "pressure0125" if row["pressure"] else "near025"


def values(row, head, ridge, support=1):
    a = row["receiver"]["methods"]["candidate_FIR_GLRT"]["by_ridge"][str(ridge)]
    eligible = bool(a["eligible"] and a["support"] >= support and a["presence"] >= .25)
    score = (-max(0., a["top_held_RSS"] - a["conditional_unrestricted_RSS"])
             / max(a["winning_template_energy"], 1e-30)) if head == "exact" else a[head]
    return score, eligible, a["top"]


def panel(rows, head, ridge, threshold, support=1):
    result = {f: {"n": 0, "accepted": 0, "correct": 0} for f in FAMILIES}
    for row in rows:
        score, eligible, top = values(row, head, ridge, support)
        accepted = eligible and score >= threshold
        item = result[family(row)]
        item["n"] += 1
        item["accepted"] += int(accepted)
        item["correct"] += int(accepted and family(row) == "registered" and top == row["identity"])
    return result


def compare_panel(actual, expected, label):
    for f in FAMILIES:
        for key in ("n", "accepted", "correct"):
            if key in expected[f]:
                check(actual[f][key] == expected[f][key], label + "/" + f + "/" + key)


def verify_p191():
    evidence = {}
    cell_hashes = {}
    algebra_n = 0
    largest_cancel_error = 0.
    for taps in (129, 257):
        evidence[taps] = {role: [] for role in ROLES}
        for role, people in ROLES.items():
            for person in people:
                relative = P191 / "evidence/scores" / ("taps" + str(taps)) / (person + "_taps" + str(taps) + ".json.gz")
                obj = load(relative)
                check(obj["status"] == "complete" and obj["source"] == person and obj["taps"] == taps,
                      "P191 checkpoint identity/status")
                rows = obj["rows"]
                check(len(rows) == obj["expected_n"] == 81, "P191 planned row count")
                seen = set()
                for row in rows:
                    key = (person, row["condition"], row["query_index"])
                    check(key not in seen, "P191 duplicate query cell")
                    seen.add(key)
                    check(row["source"] == person and row["cohort"] == role, "P191 row role")
                    if taps == 129:
                        cell_hashes[key] = row["query_raw_sha256"]
                    else:
                        check(cell_hashes[key] == row["query_raw_sha256"], "P191 paired saved query hash")
                    for method in row["receiver"]["methods"].values():
                        for a in method["by_ridge"].values():
                            top = a["top"]
                            G, b, d, beta = (a["pooled_winning_G"], a["pooled_winning_b"],
                                             a["pooled_winning_d"], a["beta"])
                            energy = G[top][top]
                            bbeta = sum(x*y for x, y in zip(b, beta))
                            fixed = max(0., d + energy - 2*b[top])
                            conditional = max(0., d - bbeta)
                            q = max(0., fixed - conditional) / max(energy, 1e-30)
                            q_algebra = max(0., energy - 2*b[top] + bbeta) / max(energy, 1e-30)
                            close(energy, a["winning_template_energy"], "P191 template energy")
                            close(fixed, a["top_held_RSS"], "P191 fixed residual", absolute=1e-8)
                            close(conditional, a["conditional_unrestricted_RSS"], "P191 conditional residual", absolute=1e-8)
                            close(q, a["exact_normalized_identity_defect"], "P191 normalized defect", absolute=1e-7)
                            close(q, q_algebra, "P191 common-energy cancellation", absolute=1e-7)
                            largest_cancel_error = max(largest_cancel_error, abs(q - q_algebra))
                            algebra_n += 1
                evidence[taps][role].extend(rows)

    saved = load(P191 / "DEVELOPMENT_REPRODUCED.json")
    factorial = load(CAP / "runs/dev257/FACTORIAL_DEV_COMPARISON.json")
    table = []
    for (taps, head, ridge), expected in zip(CONFIGS, saved["table1"]):
        rows = evidence[taps]
        negative = [values(r, head, ridge)[0] for r in rows["fit"]
                    if family(r) != "registered" and values(r, head, ridge)[1]]
        threshold = math.nextafter(max(negative), math.inf) if negative else 0.
        close(threshold, expected["threshold"], "P191 saved threshold", rel=0., absolute=0.)
        panels = {role: panel(data, head, ridge, threshold) for role, data in rows.items()}
        for role in ROLES:
            compare_panel(panels[role], expected["panels"][role], "P191 reproduced table")
            compare_panel(panels[role], factorial["panels"][str(taps) + "/" + head][role]["total"],
                          "P191 factorial summary")
        for person, expected_person in expected["people"].items():
            role = expected_person["role"]
            p = panel([r for r in rows[role] if r["source"] == person], head, ridge, threshold)
            check(p["registered"]["correct"] == expected_person["registered_correct"], "P191 person correct count")
            check(sum(p[f]["accepted"] for f in FAMILIES if f != "registered")
                  == expected_person["negative_accepted"], "P191 person negative count")
        table.append({"taps": taps, "readout": head, "fit_correct": panels["fit"]["registered"]["correct"],
                      "select_correct": panels["select"]["registered"]["correct"], "threshold": threshold})
    check(len(saved["table1"]) == 4, "P191 reported table length")
    return {"score_files": 16, "rows": sum(len(rr) for groups in evidence.values() for rr in groups.values()),
            "paired_query_hash_cells": len(cell_hashes), "scalar_algebra_checks": algebra_n,
            "max_absolute_cancellation_difference": largest_cancel_error, "table1": table,
            "limit": "Saved sufficient-statistic arithmetic; no raw-data or response-estimation rerun."}


def totals(summary, predicate):
    return {k: sum(r[k] or 0 for r in summary["strata"] if predicate(r))
            for k in ("planned_n", "evaluated_n", "infeasible_n", "accepted", "correct", "misattributed")}


def verify_p190():
    result_bytes = raw(P190 / "CONFIRMATION_RESULTS.json")
    results = json.loads(result_bytes)
    saved = load(PAPER190 / "PRIMARY_TABLE_DATA.json")
    check(results["status"] == "once_frozen_confirmation_analyzed_without_refitting", "P190 status")
    check(results["confirmation_used_for_fit_or_selection"] is False, "P190 no-refitting flag")
    check(hashlib.sha256(result_bytes).hexdigest() == saved["source_results_sha256"], "P190 reported-table input hash")
    development_bytes = raw(P190 / "DEVELOPMENT_SELECTION.json")
    development = json.loads(development_bytes)
    check(hashlib.sha256(development_bytes).hexdigest() == results["development_sha256"], "P190 development lineage hash")
    check(development["status"] == "development_completed_before_confirmation", "P190 development status")
    primary = results["groups"]["level100/smooth/candidate_FIR_GLRT"]
    actual_rows = []
    for row in saved["rows"]:
        s = primary[row["policy"]]
        actual_rows.append({"policy": row["policy"],
            "registered": totals(s, lambda r: r["kind"] == "enrolled"),
            "registered_rejected": sum(r["rejected"] for r in s["strata"] if r["kind"] == "enrolled"),
            "near025": totals(s, lambda r: r["angle"] == .025),
            "pressure0125": totals(s, lambda r: r["pressure"]),
            "clean": totals(s, lambda r: r["kind"] == "clean"),
            "wrong": totals(s, lambda r: r["kind"] == "wrong_source")})
    check(actual_rows == saved["rows"], "P190 primary table differs from supplied summary strata")
    checked = 0
    for name, group in results["groups"].items():
        for policy, summary in group.items():
            for s in summary["strata"]:
                check(s["planned_n"] == s["evaluated_n"] + s["infeasible_n"], "P190 planned denominator")
                check(s["accepted"] + s["rejected"] == s["evaluated_n"], "P190 evaluated denominator")
                if s["kind"] == "enrolled":
                    check(s["correct"] + s["misattributed"] == s["accepted"], "P190 attribution denominator")
                checked += 1
    optional = []
    dev_summary_path = PAPER190 / "DEV_MULTIARM_SUMMARY.json"
    if (ROOT / dev_summary_path).is_file():
        dev_summary = load(dev_summary_path)
        check(dev_summary["source_sha256"] == hashlib.sha256(development_bytes).hexdigest(), "P190 DEV summary lineage")
        identical = 0
        for group in development["groups"].values():
            signatures = {(p["selected"]["index"], p["selected"]["threshold"], p["selected"].get("presence_gate", .25))
                          for p in group["policies"].values()}
            identical += int(len(signatures) == 1)
        check(identical == dev_summary["all_five_identical_groups"], "P190 DEV identical-rule count")
        check(sum(g["policies"]["source_stable"]["primary_development_target_met"]
                  for g in development["groups"].values()) == dev_summary["source_stable_feasible_groups"],
              "P190 DEV feasible-group count")
        optional.append("DEV_MULTIARM_SUMMARY: source hash, identical-rule and feasible-group counts")
    grid_path = PAPER190 / "ABSOLUTE_GRID_DATA.json"
    if (ROOT / grid_path).is_file():
        grid = load(grid_path)
        check(grid["results_sha256"] == hashlib.sha256(result_bytes).hexdigest(), "P190 grid lineage")
        for cell in grid["cells"]:
            metric = results["groups"][cell["group"]]["source_stable"]["processing"][cell["condition"]]
            check(cell["complete"] == metric["complete_selection_panel"], "P190 grid completeness")
            if cell["complete"]:
                close(cell["coverage"], metric["source_mean_coverage"], "P190 grid coverage")
                close(cell["primary_acceptance"], metric["source_mean_primary_acceptance"], "P190 grid acceptance")
            check(cell["control_accepted"] == metric["control_accepted"], "P190 grid controls")
            check(cell["development_infeasible"] == (not development["groups"][cell["group"]]["policies"]["source_stable"]["primary_development_target_met"]),
                  "P190 grid DEV fallback flag")
        optional.append("ABSOLUTE_GRID_DATA: source hash and " + str(len(grid["cells"])) + " cells")
    return {"groups": len(results["groups"]), "group_policy_summaries": sum(len(g) for g in results["groups"].values()),
            "checked_strata": checked, "primary_table_rows": len(actual_rows), "primary_table": actual_rows,
            "additional_checks": optional,
            "limit": "Arithmetic from frozen result strata and source hashes; no recalibration, raw-score decision replay, or new inference."}


def main():
    report = {"status": "saved_evidence_consistency_checks_passed", "p191": verify_p191(), "p190": verify_p190(),
              "writes": False, "research_modules_imported": False, "signal_or_training_run": False}
    print(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False))


if __name__ == "__main__":
    main()
